export default {
    HOST: "localhost",
    PORT: 3000,
    API_URL: "http://localhost:3000",
    GOOGLE_SHEET_ID: "1pMMKcYx6NXLOqNn6pLHJTPMTOLRYZmSNg2QQcAu7-Pw",
    APP: {
        htmlAttributes: { lang: "en" },
        title: "Force Orange",
        description: "Le site des bénévoles",
        titleTemplate: "Force Orange - %s",
        meta: [
            {
                name: "description",
                content: "The best react universal starter boilerplate in the world.",
            },
        ],
    },
    JWT_SECRET: "RblQqA6uF#msq2312bebf2FLFn4XzWQ6dttXSJwBX#?gL2JWf!",
}
