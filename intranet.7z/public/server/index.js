require("source-map-support").install();
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/app/index.tsx":
/*!***************************!*\
  !*** ./src/app/index.tsx ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "@babel/runtime/helpers/defineProperty");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-router-dom */ "react-router-dom");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_router_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_router_config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-router-config */ "react-router-config");
/* harmony import */ var react_router_config__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_router_config__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-helmet */ "react-helmet");
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_helmet__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-toastify */ "react-toastify");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../config */ "./src/config/index.ts");
/* harmony import */ var normalize_css_normalize_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! normalize.css/normalize.css */ "./node_modules/normalize.css/normalize.css");
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ "./node_modules/react-toastify/dist/ReactToastify.css");
/* harmony import */ var _styles_module_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./styles.module.scss */ "./src/app/styles.module.scss");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react/jsx-runtime */ "react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__);


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }





 // Import your global styles here







var App = function App(_ref) {
  var route = _ref.route;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(react_helmet__WEBPACK_IMPORTED_MODULE_3__.Helmet, _objectSpread(_objectSpread({}, _config__WEBPACK_IMPORTED_MODULE_5__["default"].APP), {}, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("meta", {
        name: "viewport",
        content: "minimum-scale=1, initial-scale=1, width=device-width, shrink-to-fit=no"
      })
    })), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("header", {
      className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_8__["default"].header,
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("div", {
        className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_8__["default"].logo
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("h1", {
        className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_8__["default"].siteName,
        children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(react_router_dom__WEBPACK_IMPORTED_MODULE_1__.Link, {
          to: "/",
          children: _config__WEBPACK_IMPORTED_MODULE_5__["default"].APP.title
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)("div", {
        className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_8__["default"].siteDescription,
        children: _config__WEBPACK_IMPORTED_MODULE_5__["default"].APP.description
      })]
    }), (0,react_router_config__WEBPACK_IMPORTED_MODULE_2__.renderRoutes)(route.routes), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx)(react_toastify__WEBPACK_IMPORTED_MODULE_4__.ToastContainer, {})]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (App);

/***/ }),

/***/ "./src/components/AddEnvie/index.tsx":
/*!*******************************************!*\
  !*** ./src/components/AddEnvie/index.tsx ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "@babel/runtime/helpers/slicedToArray");
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-toastify */ "react-toastify");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store_envieAdd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../store/envieAdd */ "./src/store/envieAdd.ts");
/* harmony import */ var _styles_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./styles.module.scss */ "./src/components/AddEnvie/styles.module.scss");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react/jsx-runtime */ "react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);








var AddEnvie = function AddEnvie(_ref) {
  var dispatch = _ref.dispatch;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(""),
      _useState2 = _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0___default()(_useState, 2),
      domaine = _useState2[0],
      setDomaine = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(""),
      _useState4 = _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0___default()(_useState3, 2),
      envies = _useState4[0],
      setEnvies = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(""),
      _useState6 = _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0___default()(_useState5, 2),
      precisions = _useState6[0],
      setPrecisions = _useState6[1];

  var _useState7 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([""]),
      _useState8 = _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0___default()(_useState7, 2),
      equipes = _useState8[0],
      setEquipes = _useState8[1];

  var _useState9 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(""),
      _useState10 = _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_0___default()(_useState9, 2),
      dateAjout = _useState10[0],
      setDateAjout = _useState10[1];

  var onDomaineChanged = function onDomaineChanged(e) {
    return setDomaine(e.target.value);
  };

  var onEnviesChanged = function onEnviesChanged(e) {
    return setEnvies(e.target.value);
  };

  var onPrecisionsChanged = function onPrecisionsChanged(e) {
    return setPrecisions(e.target.value);
  };

  var onEquipesChanged = function onEquipesChanged(e) {
    return setEquipes(e.target.value.split(/, ?/));
  };

  var onDateAjoutChanged = function onDateAjoutChanged(e) {
    return setDateAjout(e.target.value);
  };

  var onSavePostClicked = function onSavePostClicked() {
    if (domaine && envies) {
      dispatch((0,_store_envieAdd__WEBPACK_IMPORTED_MODULE_3__.fetchEnvieAdd)({
        domaine: domaine,
        envies: envies,
        precisions: precisions,
        equipes: equipes,
        dateAjout: dateAjout
      }));
      setDomaine("");
      setEnvies("");
      setPrecisions("");
      setEquipes([""]);
      setDateAjout("");
    } else {
      react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.warning("Il faut au moins préciser un domaine et l'envie", {
        position: "top-center",
        autoClose: 6000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined
      });
    }
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("section", {
    className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_4__["default"].EnvieList,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("h2", {
      children: "Ajouter une nouvelle envie"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("form", {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("label", {
        htmlFor: "postDomaine",
        children: ["Domaine:", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("input", {
          type: "text",
          id: "postDomaine",
          name: "postDomaine",
          value: domaine,
          onChange: onDomaineChanged
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("label", {
        htmlFor: "postEnvies",
        children: ["Envies:", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("textarea", {
          id: "postEnvies",
          name: "postEnvies",
          value: envies,
          onChange: onEnviesChanged
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("label", {
        htmlFor: "postPrecisions",
        children: ["Precisions:", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("textarea", {
          id: "postPrecisions",
          name: "postPrecisions",
          value: precisions,
          onChange: onPrecisionsChanged
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("label", {
        htmlFor: "postEquipes",
        children: ["Equipes:", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("input", {
          type: "text",
          id: "postEquipes",
          name: "postEquipes",
          value: equipes.join(", "),
          onChange: onEquipesChanged
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("label", {
        htmlFor: "postDateAjout",
        children: ["DateAjout:", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("input", {
          type: "date",
          id: "postDateAjout",
          name: "postDateAjout",
          value: dateAjout,
          onChange: onDateAjoutChanged
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx)("button", {
        type: "button",
        onClick: onSavePostClicked,
        children: "Save Post"
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.memo)(AddEnvie));

/***/ }),

/***/ "./src/components/ErrorBoundary/index.tsx":
/*!************************************************!*\
  !*** ./src/components/ErrorBoundary/index.tsx ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "@babel/runtime/helpers/classCallCheck");
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/createClass */ "@babel/runtime/helpers/createClass");
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/inherits */ "@babel/runtime/helpers/inherits");
/* harmony import */ var _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime/helpers/possibleConstructorReturn */ "@babel/runtime/helpers/possibleConstructorReturn");
/* harmony import */ var _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime/helpers/getPrototypeOf */ "@babel/runtime/helpers/getPrototypeOf");
/* harmony import */ var _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react/jsx-runtime */ "react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);






function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4___default()(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_4___default()(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_3___default()(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }





var ErrorBoundary = /*#__PURE__*/function (_PureComponent) {
  _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_2___default()(ErrorBoundary, _PureComponent);

  var _super = _createSuper(ErrorBoundary);

  function ErrorBoundary(props) {
    var _this;

    _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, ErrorBoundary);

    _this = _super.call(this, props);
    _this.state = {
      error: null,
      errorInfo: null
    };
    return _this;
  }

  _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default()(ErrorBoundary, [{
    key: "componentDidCatch",
    value: function componentDidCatch(error, errorInfo) {
      // Catch errors in any components below and re-render with error message
      this.setState({
        error: error,
        errorInfo: errorInfo
      }); // You can also log error messages to an error reporting service here
    }
  }, {
    key: "render",
    value: function render() {
      var children = this.props.children;
      var _this$state = this.state,
          errorInfo = _this$state.errorInfo,
          error = _this$state.error; // If there's an error, render error path

      return errorInfo ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("div", {
        "data-testid": "error-view",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)("h2", {
          children: "Something went wrong."
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("details", {
          style: {
            whiteSpace: "pre-wrap"
          },
          children: [error && error.toString(), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)("br", {}), errorInfo.componentStack]
        })]
      }) : children || null;
    }
  }]);

  return ErrorBoundary;
}(react__WEBPACK_IMPORTED_MODULE_5__.PureComponent);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ErrorBoundary);

/***/ }),

/***/ "./src/components/JeuJavList/index.tsx":
/*!*********************************************!*\
  !*** ./src/components/JeuJavList/index.tsx ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-redux */ "react-redux");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles.module.scss */ "./src/components/JeuJavList/styles.module.scss");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-runtime */ "react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);






var JeuJavList = function JeuJavList(_ref) {
  var ids = _ref.ids;

  var _useSelector = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)(function (state) {
    return state.jeuJavList;
  }, react_redux__WEBPACK_IMPORTED_MODULE_1__.shallowEqual),
      jeuxJav = _useSelector.entities;

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
    className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].JeuJavList,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)("h4", {
      children: "Jeux JAV"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)("ul", {
      children: ids.map(function (id) {
        var jeu = jeuxJav[id];

        if (!jeu) {
          return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("li", {
            children: ["Le jeu #", id, " n'existe pas"]
          }, id);
        }

        var titre = jeu.titre,
            bggId = jeu.bggId;
        return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("li", {
          children: [titre, " - [", bggId, "]"]
        }, id);
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(JeuJavList));

/***/ }),

/***/ "./src/components/Loading/index.tsx":
/*!******************************************!*\
  !*** ./src/components/Loading/index.tsx ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _styles_module_scss__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./styles.module.scss */ "./src/components/Loading/styles.module.scss");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react/jsx-runtime */ "react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);



var Loading = function Loading() {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("div", {
    className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_0__["default"].loading,
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("p", {
      children: "Loading..."
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Loading);

/***/ }),

/***/ "./src/components/MembreInfo/index.tsx":
/*!*********************************************!*\
  !*** ./src/components/MembreInfo/index.tsx ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./styles.module.scss */ "./src/components/MembreInfo/styles.module.scss");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-runtime */ "react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);





var MembreInfo = function MembreInfo(_ref) {
  var item = _ref.item;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
    className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].MembreCard,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("h4", {
      children: "Membre Info"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("ul", {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("li", {
        children: ["Pr\xE9nom: ", item.prenom]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("li", {
        children: ["Nom: ", item.nom]
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(MembreInfo));

/***/ }),

/***/ "./src/components/MembreList/index.tsx":
/*!*********************************************!*\
  !*** ./src/components/MembreList/index.tsx ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-router-dom */ "react-router-dom");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_router_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles.module.scss */ "./src/components/MembreList/styles.module.scss");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-runtime */ "react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);






var MembreList = function MembreList(_ref) {
  var items = _ref.items;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
    className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"]["user-list"],
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)("h4", {
      children: "Membre List"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)("ul", {
      children: items.map(function (_ref2) {
        var id = _ref2.id,
            nom = _ref2.nom,
            prenom = _ref2.prenom;
        return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)("li", {
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)(react_router_dom__WEBPACK_IMPORTED_MODULE_1__.Link, {
            to: "/Membre/".concat(id),
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)("b", {
              children: prenom
            }), " ", nom]
          })
        }, id);
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(MembreList));

/***/ }),

/***/ "./src/components/MembreSet/index.tsx":
/*!********************************************!*\
  !*** ./src/components/MembreSet/index.tsx ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "@babel/runtime/helpers/defineProperty");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/slicedToArray */ "@babel/runtime/helpers/slicedToArray");
/* harmony import */ var _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-toastify */ "react-toastify");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _store_membreSet__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../store/membreSet */ "./src/store/membreSet.ts");
/* harmony import */ var _styles_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./styles.module.scss */ "./src/components/MembreSet/styles.module.scss");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react/jsx-runtime */ "react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);



function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }








var MembreSet = function MembreSet(_ref) {
  var dispatch = _ref.dispatch,
      membre = _ref.membre;

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(membre.prenom),
      _useState2 = _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1___default()(_useState, 2),
      prenom = _useState2[0],
      setPrenom = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(membre.nom),
      _useState4 = _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1___default()(_useState3, 2),
      nom = _useState4[0],
      setNom = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(membre.majeur),
      _useState6 = _babel_runtime_helpers_slicedToArray__WEBPACK_IMPORTED_MODULE_1___default()(_useState5, 2),
      majeur = _useState6[0],
      setMajeur = _useState6[1];

  var onPrenomChanged = function onPrenomChanged(e) {
    return setPrenom(e.target.value);
  };

  var onNomChanged = function onNomChanged(e) {
    return setNom(e.target.value);
  };

  var onMajeurChanged = function onMajeurChanged(e) {
    return setMajeur(+e.target.value);
  };

  var onSavePostClicked = function onSavePostClicked() {
    if (prenom && nom) {
      dispatch((0,_store_membreSet__WEBPACK_IMPORTED_MODULE_4__.fetchMembreSet)(_objectSpread(_objectSpread({}, membre), {}, {
        prenom: prenom,
        nom: nom,
        majeur: majeur
      })));
    } else {
      react_toastify__WEBPACK_IMPORTED_MODULE_3__.toast.warning("Il faut au moins préciser un prenom et un nom", {
        position: "top-center",
        autoClose: 6000,
        hideProgressBar: true,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined
      });
    }
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("section", {
    className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].MembreList,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)("h2", {
      children: "Modifier un membre"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("form", {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("label", {
        htmlFor: "postPrenom",
        children: ["Prenom:", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)("input", {
          type: "text",
          id: "postPrenom",
          name: "postPrenom",
          value: prenom,
          onChange: onPrenomChanged
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("label", {
        htmlFor: "postNom",
        children: ["Nom:", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)("input", {
          type: "text",
          id: "postNom",
          name: "postNom",
          value: nom,
          onChange: onNomChanged
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("label", {
        htmlFor: "postMajeur",
        children: ["Majeur:", /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)("input", {
          type: "text",
          id: "postMajeur",
          name: "postMajeur",
          value: majeur,
          onChange: onMajeurChanged
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)("button", {
        type: "button",
        onClick: onSavePostClicked,
        children: "Save changes"
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_2__.memo)(MembreSet));

/***/ }),

/***/ "./src/components/index.ts":
/*!*********************************!*\
  !*** ./src/components/index.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MembreList": () => (/* reexport safe */ _MembreList__WEBPACK_IMPORTED_MODULE_0__["default"]),
/* harmony export */   "JeuJavList": () => (/* reexport safe */ _JeuJavList__WEBPACK_IMPORTED_MODULE_1__["default"]),
/* harmony export */   "MembreInfo": () => (/* reexport safe */ _MembreInfo__WEBPACK_IMPORTED_MODULE_2__["default"]),
/* harmony export */   "MembreSet": () => (/* reexport safe */ _MembreSet__WEBPACK_IMPORTED_MODULE_3__["default"]),
/* harmony export */   "ErrorBoundary": () => (/* reexport safe */ _ErrorBoundary__WEBPACK_IMPORTED_MODULE_4__["default"]),
/* harmony export */   "Loading": () => (/* reexport safe */ _Loading__WEBPACK_IMPORTED_MODULE_5__["default"]),
/* harmony export */   "AddEnvie": () => (/* reexport safe */ _AddEnvie__WEBPACK_IMPORTED_MODULE_6__["default"])
/* harmony export */ });
/* harmony import */ var _MembreList__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./MembreList */ "./src/components/MembreList/index.tsx");
/* harmony import */ var _JeuJavList__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./JeuJavList */ "./src/components/JeuJavList/index.tsx");
/* harmony import */ var _MembreInfo__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./MembreInfo */ "./src/components/MembreInfo/index.tsx");
/* harmony import */ var _MembreSet__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./MembreSet */ "./src/components/MembreSet/index.tsx");
/* harmony import */ var _ErrorBoundary__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ErrorBoundary */ "./src/components/ErrorBoundary/index.tsx");
/* harmony import */ var _Loading__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Loading */ "./src/components/Loading/index.tsx");
/* harmony import */ var _AddEnvie__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./AddEnvie */ "./src/components/AddEnvie/index.tsx");









/***/ }),

/***/ "./src/config/default.ts":
/*!*******************************!*\
  !*** ./src/config/default.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  HOST: "localhost",
  PORT: 3000,
  API_URL: "http://localhost:3000",
  GOOGLE_SHEET_ID: "1pMMKcYx6NXLOqNn6pLHJTPMTOLRYZmSNg2QQcAu7-Pw",
  APP: {
    htmlAttributes: {
      lang: "en"
    },
    title: "Force Orange",
    description: "Le site des bénévoles",
    titleTemplate: "Force Orange - %s",
    meta: [{
      name: "description",
      content: "The best react universal starter boilerplate in the world."
    }]
  },
  JWT_SECRET: "RblQqA6uF#msq2312bebf2FLFn4XzWQ6dttXSJwBX#?gL2JWf!"
});

/***/ }),

/***/ "./src/config/index.ts":
/*!*****************************!*\
  !*** ./src/config/index.ts ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "@babel/runtime/helpers/defineProperty");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _default__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./default */ "./src/config/default.ts");
/* harmony import */ var _prod__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./prod */ "./src/config/prod.ts");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ( true ? _default__WEBPACK_IMPORTED_MODULE_1__["default"] : 0);

/***/ }),

/***/ "./src/config/prod.ts":
/*!****************************!*\
  !*** ./src/config/prod.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
var PORT = 4000;
var API_URL =  true ? "http://localhost:".concat(PORT) : 0;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  PORT: PORT,
  HOST: "0.0.0.0",
  API_URL: API_URL
});

/***/ }),

/***/ "./src/pages/Home/Home.tsx":
/*!*********************************!*\
  !*** ./src/pages/Home/Home.tsx ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "loadData": () => (/* binding */ loadData),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-redux */ "react-redux");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-helmet */ "react-helmet");
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_helmet__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store_jeuJavList__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../store/jeuJavList */ "./src/store/jeuJavList.ts");
/* harmony import */ var _store_envieList__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../store/envieList */ "./src/store/envieList.ts");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../components */ "./src/components/index.ts");
/* harmony import */ var _styles_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./styles.module.scss */ "./src/pages/Home/styles.module.scss");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react/jsx-runtime */ "react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);










function useList(stateToProp, fetchDataIfNeed) {
  var dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch)();

  var _useSelector = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)(stateToProp, react_redux__WEBPACK_IMPORTED_MODULE_1__.shallowEqual),
      readyStatus = _useSelector.readyStatus,
      ids = _useSelector.ids; // Fetch client-side data here


  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
    dispatch(fetchDataIfNeed()); // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dispatch]);
  return function () {
    if (!readyStatus || readyStatus === "idle" || readyStatus === "request") return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx)("p", {
      children: "Loading..."
    });
    if (readyStatus === "failure") return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx)("p", {
      children: "Oops, Failed to load list!"
    });
    return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx)(_components__WEBPACK_IMPORTED_MODULE_5__.JeuJavList, {
      ids: ids
    });
  };
}

var Home = function Home() {
  var dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch)();
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
    className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_6__["default"].home,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx)(react_helmet__WEBPACK_IMPORTED_MODULE_2__.Helmet, {
      title: "Home"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx)(_components__WEBPACK_IMPORTED_MODULE_5__.AddEnvie, {
      dispatch: dispatch
    }), useList(function (state) {
      return state.jeuJavList;
    }, _store_jeuJavList__WEBPACK_IMPORTED_MODULE_3__.fetchJeuJavListIfNeed)()]
  });
}; // Fetch server-side data here


var loadData = function loadData() {
  return [(0,_store_envieList__WEBPACK_IMPORTED_MODULE_4__.fetchEnvieListIfNeed)(), (0,_store_jeuJavList__WEBPACK_IMPORTED_MODULE_3__.fetchJeuJavListIfNeed)() // More pre-fetched actions...
  ];
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(Home));

/***/ }),

/***/ "./src/pages/Home/index.tsx":
/*!**********************************!*\
  !*** ./src/pages/Home/index.tsx ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "loadData": () => (/* reexport safe */ _Home__WEBPACK_IMPORTED_MODULE_3__.loadData)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "@babel/runtime/helpers/defineProperty");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _loadable_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @loadable/component */ "@loadable/component");
/* harmony import */ var _loadable_component__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_loadable_component__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../components */ "./src/components/index.ts");
/* harmony import */ var _Home__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Home */ "./src/pages/Home/Home.tsx");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-runtime */ "react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }





var Home = _loadable_component__WEBPACK_IMPORTED_MODULE_1___default()({
  resolved: {},
  chunkName: function chunkName() {
    return "Home";
  },
  isReady: function isReady(props) {
    var key = this.resolve(props);

    if (this.resolved[key] !== true) {
      return false;
    }

    if (true) {
      return !!__webpack_require__.m[key];
    }

    return false;
  },
  importAsync: function importAsync() {
    return Promise.resolve(/*! import() */).then(__webpack_require__.bind(__webpack_require__, /*! ./Home */ "./src/pages/Home/Home.tsx"));
  },
  requireAsync: function requireAsync(props) {
    var _this = this;

    var key = this.resolve(props);
    this.resolved[key] = false;
    return this.importAsync(props).then(function (resolved) {
      _this.resolved[key] = true;
      return resolved;
    });
  },
  requireSync: function requireSync(props) {
    var id = this.resolve(props);

    if (true) {
      return __webpack_require__(id);
    }

    return eval('module.require')(id);
  },
  resolve: function resolve() {
    if (true) {
      return /*require.resolve*/(/*! ./Home */ "./src/pages/Home/Home.tsx");
    }

    return eval('require.resolve')("./Home");
  }
}, {
  fallback: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_components__WEBPACK_IMPORTED_MODULE_2__.Loading, {})
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (function (props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_components__WEBPACK_IMPORTED_MODULE_2__.ErrorBoundary, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(Home, _objectSpread({}, props))
  });
});


/***/ }),

/***/ "./src/pages/Login/index.tsx":
/*!***********************************!*\
  !*** ./src/pages/Login/index.tsx ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "@babel/runtime/helpers/defineProperty");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _loadable_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @loadable/component */ "@loadable/component");
/* harmony import */ var _loadable_component__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_loadable_component__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../components */ "./src/components/index.ts");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-runtime */ "react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }




var LoginPage = _loadable_component__WEBPACK_IMPORTED_MODULE_1___default()({
  resolved: {},
  chunkName: function chunkName() {
    return "LoginPage";
  },
  isReady: function isReady(props) {
    var key = this.resolve(props);

    if (this.resolved[key] !== true) {
      return false;
    }

    if (true) {
      return !!__webpack_require__.m[key];
    }

    return false;
  },
  importAsync: function importAsync() {
    return __webpack_require__.e(/*! import() | LoginPage */ "LoginPage").then(__webpack_require__.bind(__webpack_require__, /*! ./LoginPage */ "./src/pages/Login/LoginPage.tsx"));
  },
  requireAsync: function requireAsync(props) {
    var _this = this;

    var key = this.resolve(props);
    this.resolved[key] = false;
    return this.importAsync(props).then(function (resolved) {
      _this.resolved[key] = true;
      return resolved;
    });
  },
  requireSync: function requireSync(props) {
    var id = this.resolve(props);

    if (true) {
      return __webpack_require__(id);
    }

    return eval('module.require')(id);
  },
  resolve: function resolve() {
    if (true) {
      return /*require.resolve*/(/*! ./LoginPage */ "./src/pages/Login/LoginPage.tsx");
    }

    return eval('require.resolve')("./LoginPage");
  }
}, {
  fallback: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(_components__WEBPACK_IMPORTED_MODULE_2__.Loading, {})
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (function (props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(_components__WEBPACK_IMPORTED_MODULE_2__.ErrorBoundary, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(LoginPage, _objectSpread({}, props))
  });
});

/***/ }),

/***/ "./src/pages/MembrePage/MembrePage.tsx":
/*!*********************************************!*\
  !*** ./src/pages/MembrePage/MembrePage.tsx ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "loadData": () => (/* binding */ loadData),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-redux */ "react-redux");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-helmet */ "react-helmet");
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_helmet__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store_membre__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../store/membre */ "./src/store/membre.ts");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../components */ "./src/components/index.ts");
/* harmony import */ var _styles_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./styles.module.scss */ "./src/pages/MembrePage/styles.module.scss");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react/jsx-runtime */ "react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);









var MembrePage = function MembrePage(_ref) {
  var match = _ref.match;
  var rawId = match.params.id;
  var id = +rawId;
  var dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch)();
  var membre = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)(function (state) {
    return state.membre;
  }, react_redux__WEBPACK_IMPORTED_MODULE_1__.shallowEqual);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
    dispatch((0,_store_membre__WEBPACK_IMPORTED_MODULE_3__.fetchMembreIfNeed)(id));
  }, [dispatch, id]);

  var renderInfo = function renderInfo() {
    var membreInfo = membre;
    if (!membreInfo || membreInfo.readyStatus === "request") return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)("p", {
      children: "Loading..."
    });
    if (membreInfo.readyStatus === "failure" || !membreInfo.entity) return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)("p", {
      children: "Oops! Failed to load data."
    });
    return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("div", {
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)(_components__WEBPACK_IMPORTED_MODULE_4__.MembreInfo, {
        item: membreInfo.entity
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)(_components__WEBPACK_IMPORTED_MODULE_4__.MembreSet, {
        dispatch: dispatch,
        membre: membreInfo.entity
      })]
    });
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("div", {
    className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_5__["default"].membre,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx)(react_helmet__WEBPACK_IMPORTED_MODULE_2__.Helmet, {
      title: "User Info"
    }), renderInfo()]
  });
};

var loadData = function loadData(_ref2) {
  var params = _ref2.params;
  return [(0,_store_membre__WEBPACK_IMPORTED_MODULE_3__.fetchMembreIfNeed)(params.id)];
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(MembrePage));

/***/ }),

/***/ "./src/pages/MembrePage/index.tsx":
/*!****************************************!*\
  !*** ./src/pages/MembrePage/index.tsx ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "loadData": () => (/* reexport safe */ _MembrePage__WEBPACK_IMPORTED_MODULE_3__.loadData)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "@babel/runtime/helpers/defineProperty");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _loadable_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @loadable/component */ "@loadable/component");
/* harmony import */ var _loadable_component__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_loadable_component__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../components */ "./src/components/index.ts");
/* harmony import */ var _MembrePage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./MembrePage */ "./src/pages/MembrePage/MembrePage.tsx");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-runtime */ "react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }





var MembrePage = _loadable_component__WEBPACK_IMPORTED_MODULE_1___default()({
  resolved: {},
  chunkName: function chunkName() {
    return "MembrePage";
  },
  isReady: function isReady(props) {
    var key = this.resolve(props);

    if (this.resolved[key] !== true) {
      return false;
    }

    if (true) {
      return !!__webpack_require__.m[key];
    }

    return false;
  },
  importAsync: function importAsync() {
    return Promise.resolve(/*! import() */).then(__webpack_require__.bind(__webpack_require__, /*! ./MembrePage */ "./src/pages/MembrePage/MembrePage.tsx"));
  },
  requireAsync: function requireAsync(props) {
    var _this = this;

    var key = this.resolve(props);
    this.resolved[key] = false;
    return this.importAsync(props).then(function (resolved) {
      _this.resolved[key] = true;
      return resolved;
    });
  },
  requireSync: function requireSync(props) {
    var id = this.resolve(props);

    if (true) {
      return __webpack_require__(id);
    }

    return eval('module.require')(id);
  },
  resolve: function resolve() {
    if (true) {
      return /*require.resolve*/(/*! ./MembrePage */ "./src/pages/MembrePage/MembrePage.tsx");
    }

    return eval('require.resolve')("./MembrePage");
  }
}, {
  fallback: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_components__WEBPACK_IMPORTED_MODULE_2__.Loading, {})
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (function (props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_components__WEBPACK_IMPORTED_MODULE_2__.ErrorBoundary, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(MembrePage, _objectSpread({}, props))
  });
});


/***/ }),

/***/ "./src/pages/NotFound/index.tsx":
/*!**************************************!*\
  !*** ./src/pages/NotFound/index.tsx ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-helmet */ "react-helmet");
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_helmet__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles.module.scss */ "./src/pages/NotFound/styles.module.scss");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-runtime */ "react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);






var NotFound = function NotFound(_ref) {
  var staticContext = _ref.staticContext;
  // We have to check if staticContext exists
  // because it will be undefined if rendered through a BrowserRoute

  /* istanbul ignore next */
  if (staticContext) staticContext.statusCode = 404;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
    className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"]["not-found"],
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(react_helmet__WEBPACK_IMPORTED_MODULE_1__.Helmet, {
      title: "Oops"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)("p", {
      children: "Oops, Page was not found!"
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(NotFound));

/***/ }),

/***/ "./src/pages/Register/index.tsx":
/*!**************************************!*\
  !*** ./src/pages/Register/index.tsx ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "@babel/runtime/helpers/defineProperty");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _loadable_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @loadable/component */ "@loadable/component");
/* harmony import */ var _loadable_component__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_loadable_component__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../components */ "./src/components/index.ts");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-runtime */ "react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }




var RegisterPage = _loadable_component__WEBPACK_IMPORTED_MODULE_1___default()({
  resolved: {},
  chunkName: function chunkName() {
    return "RegisterPage";
  },
  isReady: function isReady(props) {
    var key = this.resolve(props);

    if (this.resolved[key] !== true) {
      return false;
    }

    if (true) {
      return !!__webpack_require__.m[key];
    }

    return false;
  },
  importAsync: function importAsync() {
    return __webpack_require__.e(/*! import() | RegisterPage */ "RegisterPage").then(__webpack_require__.bind(__webpack_require__, /*! ./RegisterPage */ "./src/pages/Register/RegisterPage.tsx"));
  },
  requireAsync: function requireAsync(props) {
    var _this = this;

    var key = this.resolve(props);
    this.resolved[key] = false;
    return this.importAsync(props).then(function (resolved) {
      _this.resolved[key] = true;
      return resolved;
    });
  },
  requireSync: function requireSync(props) {
    var id = this.resolve(props);

    if (true) {
      return __webpack_require__(id);
    }

    return eval('module.require')(id);
  },
  resolve: function resolve() {
    if (true) {
      return /*require.resolve*/(/*! ./RegisterPage */ "./src/pages/Register/RegisterPage.tsx");
    }

    return eval('require.resolve')("./RegisterPage");
  }
}, {
  fallback: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(_components__WEBPACK_IMPORTED_MODULE_2__.Loading, {})
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (function (props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(_components__WEBPACK_IMPORTED_MODULE_2__.ErrorBoundary, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx)(RegisterPage, _objectSpread({}, props))
  });
});

/***/ }),

/***/ "./src/routes/certbot.ts":
/*!*******************************!*\
  !*** ./src/routes/certbot.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var express__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! express */ "express");
/* harmony import */ var express__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(express__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! path */ "path");
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_1__);
/* Copyright Coplay. All Rights Reserved. Use of this source code is governed by an MIT-style license that can be found in the LICENSE file at https://coplay.org/colicense */


var certbotRouter = (0,express__WEBPACK_IMPORTED_MODULE_0__.Router)();
certbotRouter.use(function (request, response, _next) {
  var filename = request.originalUrl.replace(/.*\//, "");
  var resolvedPath = path__WEBPACK_IMPORTED_MODULE_1__.resolve("../certbot/.well-known/acme-challenge/".concat(filename));
  response.setHeader("Content-Type", "text/html");
  return response.sendFile(resolvedPath);
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (certbotRouter);

/***/ }),

/***/ "./src/routes/index.ts":
/*!*****************************!*\
  !*** ./src/routes/index.ts ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../app */ "./src/app/index.tsx");
/* harmony import */ var _pages_Home__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../pages/Home */ "./src/pages/Home/index.tsx");
/* harmony import */ var _pages_MembrePage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../pages/MembrePage */ "./src/pages/MembrePage/index.tsx");
/* harmony import */ var _pages_Login__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../pages/Login */ "./src/pages/Login/index.tsx");
/* harmony import */ var _pages_Register__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../pages/Register */ "./src/pages/Register/index.tsx");
/* harmony import */ var _pages_NotFound__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../pages/NotFound */ "./src/pages/NotFound/index.tsx");






/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ([{
  component: _app__WEBPACK_IMPORTED_MODULE_0__["default"],
  routes: [{
    path: "/",
    exact: true,
    component: _pages_Home__WEBPACK_IMPORTED_MODULE_1__["default"],
    // Add your page here
    loadData: _pages_Home__WEBPACK_IMPORTED_MODULE_1__.loadData // Add your pre-fetch method here

  }, {
    path: "/MembrePage/:id",
    component: _pages_MembrePage__WEBPACK_IMPORTED_MODULE_2__["default"],
    loadData: _pages_MembrePage__WEBPACK_IMPORTED_MODULE_2__.loadData
  }, {
    path: "/login",
    component: _pages_Login__WEBPACK_IMPORTED_MODULE_3__["default"]
  }, {
    path: "/register",
    component: _pages_Register__WEBPACK_IMPORTED_MODULE_4__["default"]
  }, {
    component: _pages_NotFound__WEBPACK_IMPORTED_MODULE_5__["default"]
  }]
}]);

/***/ }),

/***/ "./src/server/devServer.ts":
/*!*********************************!*\
  !*** ./src/server/devServer.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var chalk__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! chalk */ "chalk");
/* harmony import */ var chalk__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(chalk__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (function (app) {
  var webpack = __webpack_require__(/*! webpack */ "webpack");

  var webpackConfig = (__webpack_require__(/*! ../../webpack/client.config */ "./webpack/client.config.ts")["default"]);

  var compiler = webpack(webpackConfig);

  var instance = __webpack_require__(/*! webpack-dev-middleware */ "webpack-dev-middleware")(compiler, {
    headers: {
      "Access-Control-Allow-Origin": "*"
    },
    serverSideRender: true
  });

  app.use(instance);
  app.use(__webpack_require__(/*! webpack-hot-middleware */ "webpack-hot-middleware")(compiler, {
    log: false,
    path: "/__webpack_hmr",
    heartbeat: 10 * 1000
  }));
  instance.waitUntilValid(function () {
    console.info(chalk__WEBPACK_IMPORTED_MODULE_0___default().green("webpack-dev-middleware activated"));
  });
});

/***/ }),

/***/ "./src/server/gsheets/DBManager.ts":
/*!*****************************************!*\
  !*** ./src/server/gsheets/DBManager.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ DBManager)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "@babel/runtime/helpers/asyncToGenerator");
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/regenerator */ "@babel/runtime/regenerator");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__);


var CACHE_RENEW_DELAY = 10000;
var cache = {};
var cacheTime = {};
function DBManager(sheetName) {
  cacheTime[sheetName] = 0;
  var operations = [];

  function addDBOperation(_x, _x2) {
    return _addDBOperation.apply(this, arguments);
  }

  function _addDBOperation() {
    _addDBOperation = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().mark(function _callee(type, task) {
      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              return _context.abrupt("return", new Promise(function (resolve, reject) {
                operations.push({
                  task: task,
                  type: type,
                  resolve: resolve,
                  reject: reject
                });

                if (operations.length === 1) {
                  runOperation(operations[0]);
                }
              }));

            case 1:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));
    return _addDBOperation.apply(this, arguments);
  }

  function runNextDBOperation() {
    operations.shift();

    if (operations[0]) {
      runOperation(operations[0]);
    }
  }

  function runOperation(operation) {
    var task = operation.task,
        type = operation.type,
        resolve = operation.resolve,
        reject = operation.reject;

    if (type === "list") {
      var now = +new Date();

      if (now < cacheTime[sheetName] + CACHE_RENEW_DELAY) {
        resolve(cache[sheetName]);
        runNextDBOperation();
      } else {
        task().then(function (val) {
          cache[sheetName] = val;
          cacheTime[sheetName] = now;
          resolve(val);
        }).catch(reject).finally(runNextDBOperation);
      }
    } else {
      cacheTime[sheetName] = 0;
      task().then(resolve).catch(reject).finally(runNextDBOperation);
    }
  }

  return addDBOperation;
}

/***/ }),

/***/ "./src/server/gsheets/accessors.ts":
/*!*****************************************!*\
  !*** ./src/server/gsheets/accessors.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ getAccessors)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "@babel/runtime/helpers/defineProperty");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "@babel/runtime/helpers/asyncToGenerator");
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/regenerator */ "@babel/runtime/regenerator");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! path */ "path");
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash */ "lodash");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! fs */ "fs");
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var google_spreadsheet__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! google-spreadsheet */ "google-spreadsheet");
/* harmony import */ var google_spreadsheet__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(google_spreadsheet__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _DBManager__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./DBManager */ "./src/server/gsheets/DBManager.ts");



function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }







var CRED_PATH = path__WEBPACK_IMPORTED_MODULE_3___default().resolve(process.cwd(), "access/gsheets.json");
function getAccessors(sheetName, specimen) {
  var addDBOperation = (0,_DBManager__WEBPACK_IMPORTED_MODULE_7__["default"])(sheetName);

  function listGet() {
    return _listGet.apply(this, arguments);
  }

  function _listGet() {
    _listGet = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee2() {
      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              return _context2.abrupt("return", addDBOperation("list", /*#__PURE__*/_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee() {
                var sheet, rows, elements, types;
                return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee$(_context) {
                  while (1) {
                    switch (_context.prev = _context.next) {
                      case 0:
                        _context.next = 2;
                        return getGSheet();

                      case 2:
                        sheet = _context.sent;
                        _context.next = 5;
                        return sheet.getRows();

                      case 5:
                        rows = _context.sent;
                        elements = [];

                        if (rows[0]) {
                          _context.next = 9;
                          break;
                        }

                        throw new Error("No column types defined in sheet ".concat(sheetName));

                      case 9:
                        types = lodash__WEBPACK_IMPORTED_MODULE_4___default().pick(rows[0], Object.keys(specimen));
                        rows.shift();
                        rows.forEach(function (row) {
                          var stringifiedElement = lodash__WEBPACK_IMPORTED_MODULE_4___default().pick(row, Object.keys(specimen));

                          var element = parseElement(stringifiedElement, types);

                          if (element !== undefined) {
                            elements.push(element);
                          }
                        });
                        return _context.abrupt("return", elements);

                      case 13:
                      case "end":
                        return _context.stop();
                    }
                  }
                }, _callee);
              }))));

            case 1:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2);
    }));
    return _listGet.apply(this, arguments);
  }

  function get(_x) {
    return _get.apply(this, arguments);
  }

  function _get() {
    _get = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee3(membreId) {
      var list;
      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee3$(_context3) {
        while (1) {
          switch (_context3.prev = _context3.next) {
            case 0:
              _context3.next = 2;
              return listGet();

            case 2:
              list = _context3.sent;
              return _context3.abrupt("return", list.find(function (element) {
                return element.id === membreId;
              }));

            case 4:
            case "end":
              return _context3.stop();
          }
        }
      }, _callee3);
    }));
    return _get.apply(this, arguments);
  }

  function setList(_x2) {
    return _setList.apply(this, arguments);
  }

  function _setList() {
    _setList = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee5(elements) {
      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee5$(_context6) {
        while (1) {
          switch (_context6.prev = _context6.next) {
            case 0:
              return _context6.abrupt("return", addDBOperation("listSet", /*#__PURE__*/_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee4() {
                var sheet, rows, types, rowid, _iterator, _step, _loop, rowToDelete;

                return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee4$(_context5) {
                  while (1) {
                    switch (_context5.prev = _context5.next) {
                      case 0:
                        _context5.next = 2;
                        return getGSheet();

                      case 2:
                        sheet = _context5.sent;
                        _context5.next = 5;
                        return sheet.getRows();

                      case 5:
                        rows = _context5.sent;

                        if (rows[0]) {
                          _context5.next = 8;
                          break;
                        }

                        throw new Error("No column types defined in sheet ".concat(sheetName));

                      case 8:
                        types = lodash__WEBPACK_IMPORTED_MODULE_4___default().pick(rows[0], Object.keys(elements[0] || {})); // Update received rows

                        // Update received rows
                        rowid = 1; // eslint-disable-next-line no-restricted-syntax

                        // eslint-disable-next-line no-restricted-syntax
                        _iterator = _createForOfIteratorHelper(elements);
                        _context5.prev = 11;
                        _loop = /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _loop() {
                          var element, row, stringifiedRow, keys, sameCells;
                          return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _loop$(_context4) {
                            while (1) {
                              switch (_context4.prev = _context4.next) {
                                case 0:
                                  element = _step.value;
                                  row = rows[rowid];
                                  stringifiedRow = stringifyElement(element, types);

                                  if (row) {
                                    _context4.next = 8;
                                    break;
                                  }

                                  _context4.next = 6;
                                  return sheet.addRow(stringifiedRow);

                                case 6:
                                  _context4.next = 14;
                                  break;

                                case 8:
                                  keys = Object.keys(stringifiedRow);
                                  sameCells = lodash__WEBPACK_IMPORTED_MODULE_4___default().every(keys, function (key) {
                                    return row[key] === stringifiedRow[key];
                                  });

                                  if (sameCells) {
                                    _context4.next = 14;
                                    break;
                                  }

                                  keys.forEach(function (key) {
                                    row[key] = stringifiedRow[key];
                                  }); // eslint-disable-next-line no-await-in-loop

                                  _context4.next = 14;
                                  return row.save();

                                case 14:
                                  rowid += 1;

                                case 15:
                                case "end":
                                  return _context4.stop();
                              }
                            }
                          }, _loop);
                        });

                        _iterator.s();

                      case 14:
                        if ((_step = _iterator.n()).done) {
                          _context5.next = 18;
                          break;
                        }

                        return _context5.delegateYield(_loop(), "t0", 16);

                      case 16:
                        _context5.next = 14;
                        break;

                      case 18:
                        _context5.next = 23;
                        break;

                      case 20:
                        _context5.prev = 20;
                        _context5.t1 = _context5["catch"](11);

                        _iterator.e(_context5.t1);

                      case 23:
                        _context5.prev = 23;

                        _iterator.f();

                        return _context5.finish(23);

                      case 26:
                        rowToDelete = sheet.rowCount - 1;

                      case 27:
                        if (!(rowToDelete >= rowid)) {
                          _context5.next = 34;
                          break;
                        }

                        if (!rows[rowToDelete]) {
                          _context5.next = 31;
                          break;
                        }

                        _context5.next = 31;
                        return rows[rowToDelete].delete();

                      case 31:
                        rowToDelete -= 1;
                        _context5.next = 27;
                        break;

                      case 34:
                        return _context5.abrupt("return", true);

                      case 35:
                      case "end":
                        return _context5.stop();
                    }
                  }
                }, _callee4, null, [[11, 20, 23, 26]]);
              }))));

            case 1:
            case "end":
              return _context6.stop();
          }
        }
      }, _callee5);
    }));
    return _setList.apply(this, arguments);
  }

  function set(_x3) {
    return _set.apply(this, arguments);
  }

  function _set() {
    _set = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee7(element) {
      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee7$(_context8) {
        while (1) {
          switch (_context8.prev = _context8.next) {
            case 0:
              if (element) {
                _context8.next = 2;
                break;
              }

              return _context8.abrupt("return", undefined);

            case 2:
              return _context8.abrupt("return", addDBOperation("set", /*#__PURE__*/_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee6() {
                var sheet, rows, types, stringifiedRow, row;
                return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee6$(_context7) {
                  while (1) {
                    switch (_context7.prev = _context7.next) {
                      case 0:
                        _context7.next = 2;
                        return getGSheet();

                      case 2:
                        sheet = _context7.sent;
                        _context7.next = 5;
                        return sheet.getRows();

                      case 5:
                        rows = _context7.sent;

                        if (rows[0]) {
                          _context7.next = 8;
                          break;
                        }

                        throw new Error("No column types defined in sheet ".concat(sheetName));

                      case 8:
                        types = lodash__WEBPACK_IMPORTED_MODULE_4___default().pick(rows[0], Object.keys(element || {}));
                        rows.shift(); // Replace previous row

                        // Replace previous row
                        stringifiedRow = stringifyElement(element, types);
                        row = rows.find(function (rowItem) {
                          return +rowItem.id === element.id;
                        });

                        if (row) {
                          _context7.next = 14;
                          break;
                        }

                        return _context7.abrupt("return", undefined);

                      case 14:
                        Object.assign(row, stringifiedRow);
                        _context7.next = 17;
                        return row.save();

                      case 17:
                        return _context7.abrupt("return", element);

                      case 18:
                      case "end":
                        return _context7.stop();
                    }
                  }
                }, _callee6);
              }))));

            case 3:
            case "end":
              return _context8.stop();
          }
        }
      }, _callee7);
    }));
    return _set.apply(this, arguments);
  }

  function add(_x4) {
    return _add.apply(this, arguments);
  }

  function _add() {
    _add = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee9(partialElement) {
      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee9$(_context10) {
        while (1) {
          switch (_context10.prev = _context10.next) {
            case 0:
              if (partialElement) {
                _context10.next = 2;
                break;
              }

              return _context10.abrupt("return", undefined);

            case 2:
              return _context10.abrupt("return", addDBOperation("add", /*#__PURE__*/_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee8() {
                var sheet, rows, types, highestId, element, stringifiedRow;
                return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee8$(_context9) {
                  while (1) {
                    switch (_context9.prev = _context9.next) {
                      case 0:
                        _context9.next = 2;
                        return getGSheet();

                      case 2:
                        sheet = _context9.sent;
                        _context9.next = 5;
                        return sheet.getRows();

                      case 5:
                        rows = _context9.sent;

                        if (rows[0]) {
                          _context9.next = 8;
                          break;
                        }

                        throw new Error("No column types defined in sheet ".concat(sheetName));

                      case 8:
                        types = _objectSpread({
                          id: "number"
                        }, lodash__WEBPACK_IMPORTED_MODULE_4___default().pick(rows[0], Object.keys(partialElement || {}))); // Create full element

                        // Create full element
                        rows.shift();
                        highestId = rows.reduce(function (id, row) {
                          return Math.max(id, +row.id || 0);
                        }, 0);
                        element = _objectSpread({
                          id: highestId + 1
                        }, partialElement); // Add element

                        // Add element
                        stringifiedRow = stringifyElement(element, types);
                        _context9.next = 15;
                        return sheet.addRow(stringifiedRow);

                      case 15:
                        return _context9.abrupt("return", element);

                      case 16:
                      case "end":
                        return _context9.stop();
                    }
                  }
                }, _callee8);
              }))));

            case 3:
            case "end":
              return _context10.stop();
          }
        }
      }, _callee9);
    }));
    return _add.apply(this, arguments);
  }

  function getGSheet() {
    return _getGSheet.apply(this, arguments);
  }

  function _getGSheet() {
    _getGSheet = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee10() {
      var doc, creds;
      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee10$(_context11) {
        while (1) {
          switch (_context11.prev = _context11.next) {
            case 0:
              doc = new google_spreadsheet__WEBPACK_IMPORTED_MODULE_6__.GoogleSpreadsheet("1pMMKcYx6NXLOqNn6pLHJTPMTOLRYZmSNg2QQcAu7-Pw");
              _context11.next = 3;
              return fs__WEBPACK_IMPORTED_MODULE_5__.promises.readFile(CRED_PATH);

            case 3:
              creds = _context11.sent;
              _context11.next = 6;
              return doc.useServiceAccountAuth(JSON.parse(creds.toString()));

            case 6:
              _context11.next = 8;
              return doc.loadInfo();

            case 8:
              return _context11.abrupt("return", doc.sheetsByTitle[sheetName]);

            case 9:
            case "end":
              return _context11.stop();
          }
        }
      }, _callee10);
    }));
    return _getGSheet.apply(this, arguments);
  }

  function parseElement(rawElement, types) {
    var fullElement = lodash__WEBPACK_IMPORTED_MODULE_4___default().reduce(types, function (element, type, prop) {
      var rawProp = rawElement[prop];

      switch (type) {
        case "string":
          element[prop] = rawProp;
          break;

        case "number":
          element[prop] = +rawProp;
          break;

        case "boolean":
          element[prop] = rawProp !== "0" && rawProp !== "";
          break;

        case "date":
          // eslint-disable-next-line no-case-declarations
          var matchDate = rawProp.match(/^([0-9]+)\/([0-9]+)\/([0-9]+)$/);

          if (matchDate) {
            element[prop] = new Date(+matchDate[3], +matchDate[2] - 1, +matchDate[1]);
            break;
          }

          throw new Error("Unable to read date from ".concat(rawProp));

        default:
          // eslint-disable-next-line no-case-declarations
          var matchArrayType = type.match(/^(number|string|boolean|date)\[([^\]]+)\]$/);

          if (!matchArrayType) {
            throw new Error("Unknown array type for ".concat(type));
          }

          if (!rawProp) {
            element[prop] = [];
          } else {
            var arrayType = matchArrayType[1];
            var delimiter = matchArrayType[2];

            switch (arrayType) {
              case "string":
                element[prop] = rawProp.split(delimiter);
                break;

              case "number":
                element[prop] = lodash__WEBPACK_IMPORTED_MODULE_4___default().map(rawProp.split(delimiter), function (val) {
                  return +val;
                });
                break;

              case "boolean":
                element[prop] = lodash__WEBPACK_IMPORTED_MODULE_4___default().map(rawProp.split(delimiter), function (val) {
                  return val !== "0" && val !== "";
                });
                break;

              case "date":
                // eslint-disable-next-line no-case-declarations
                var rawDates = rawProp.split(delimiter);
                element[prop] = []; // eslint-disable-next-line no-case-declarations

                var rightFormat = rawDates.every(function (rawDate) {
                  var matchDateArray = rawDate.match(/^([0-9]+)\/([0-9]+)\/([0-9]+)$/);

                  if (!matchDateArray) {
                    return false;
                  }

                  element[prop].push(new Date(+matchDateArray[3], +matchDateArray[2] - 1, +matchDateArray[1]));
                  return true;
                });

                if (!rightFormat) {
                  throw new Error("One array item is not a date in ".concat(rawProp));
                }

                break;

              default:
                throw new Error("Unknown array type ".concat(arrayType));
            }
          }

      }

      return element;
    }, JSON.parse(JSON.stringify(specimen)));

    return fullElement;
  }

  function stringifyElement(element, types) {
    var rawElement = lodash__WEBPACK_IMPORTED_MODULE_4___default().reduce(types, function (stringifiedElement, type, prop) {
      var value = element[prop];

      switch (type) {
        case "string":
          stringifiedElement[prop] = formulaSafe("".concat(value));
          break;

        case "number":
          stringifiedElement[prop] = "".concat(value);
          break;

        case "boolean":
          stringifiedElement[prop] = value ? "X" : "";
          break;

        case "date":
          stringifiedElement[prop] = stringifiedDate(value);
          break;

        default:
          // eslint-disable-next-line no-case-declarations
          var matchArrayType = type.match(/^(number|string|boolean|date)\[([^\]]+)\]$/);

          if (!matchArrayType || !lodash__WEBPACK_IMPORTED_MODULE_4___default().isArray(value)) {
            throw new Error("Unknown matchArrayType or not an array in stringifyElement");
          } // eslint-disable-next-line no-case-declarations


          var arrayType = matchArrayType[1]; // eslint-disable-next-line no-case-declarations

          var delimiter = matchArrayType[2];

          switch (arrayType) {
            case "string":
              if (!lodash__WEBPACK_IMPORTED_MODULE_4___default().every(value, (lodash__WEBPACK_IMPORTED_MODULE_4___default().isString))) {
                throw new Error("Each date of ".concat(value, " is not a string"));
              }

              stringifiedElement[prop] = formulaSafe(value.join(delimiter));
              break;

            case "number":
              if (!lodash__WEBPACK_IMPORTED_MODULE_4___default().every(value, (lodash__WEBPACK_IMPORTED_MODULE_4___default().isNumber))) {
                throw new Error("Each date of ".concat(value, " is not a number"));
              }

              stringifiedElement[prop] = value.join(delimiter);
              break;

            case "boolean":
              if (!lodash__WEBPACK_IMPORTED_MODULE_4___default().every(value, (lodash__WEBPACK_IMPORTED_MODULE_4___default().isBoolean))) {
                throw new Error("Each date of ".concat(value, " is not a boolean"));
              }

              stringifiedElement[prop] = lodash__WEBPACK_IMPORTED_MODULE_4___default().map(value, function (val) {
                return val ? "X" : "";
              }).join(delimiter);
              break;

            case "date":
              if (!lodash__WEBPACK_IMPORTED_MODULE_4___default().every(value, (lodash__WEBPACK_IMPORTED_MODULE_4___default().isDate))) {
                throw new Error("Each date of ".concat(value, " is not a date"));
              }

              stringifiedElement[prop] = lodash__WEBPACK_IMPORTED_MODULE_4___default().map(value, function (val) {
                return "".concat(val.getDate(), "/").concat(val.getMonth() + 1, "/").concat(val.getFullYear());
              }).join(delimiter);
              break;

            default:
              throw new Error("Unknown array type ".concat(arrayType));
          }

      }

      return stringifiedElement;
    }, JSON.parse(JSON.stringify(element)));

    return rawElement;
  }

  function formulaSafe(value) {
    return value.replace(/^=+/, "");
  }

  function stringifiedDate(value) {
    var date;

    if (value instanceof Date) {
      date = value;
    } else if (typeof value === "string") {
      try {
        date = new Date(value);
      } catch (e) {
        throw new Error("Wrong date string format in stringifyElement");
      }
    } else {
      throw new Error("Wrong date format in stringifyElement");
    }

    return "".concat(date.getDate(), "/").concat(date.getMonth() + 1, "/").concat(date.getFullYear());
  }

  return {
    listGet: listGet,
    get: get,
    setList: setList,
    set: set,
    add: add
  };
}

/***/ }),

/***/ "./src/server/gsheets/envies.ts":
/*!**************************************!*\
  !*** ./src/server/gsheets/envies.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "envieListGet": () => (/* binding */ envieListGet),
/* harmony export */   "envieGet": () => (/* binding */ envieGet),
/* harmony export */   "envieAdd": () => (/* binding */ envieAdd),
/* harmony export */   "envieSet": () => (/* binding */ envieSet)
/* harmony export */ });
/* harmony import */ var _expressAccessors__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./expressAccessors */ "./src/server/gsheets/expressAccessors.ts");
/* harmony import */ var _services_envies__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../services/envies */ "./src/services/envies.ts");



var _getExpressAccessors = (0,_expressAccessors__WEBPACK_IMPORTED_MODULE_0__["default"])("Envies d'aider", new _services_envies__WEBPACK_IMPORTED_MODULE_1__.Envie()),
    listGetRequest = _getExpressAccessors.listGetRequest,
    getRequest = _getExpressAccessors.getRequest,
    setRequest = _getExpressAccessors.setRequest,
    addRequest = _getExpressAccessors.addRequest;

var envieListGet = listGetRequest();
var envieGet = getRequest();
var envieAdd = addRequest();
var envieSet = setRequest();

/***/ }),

/***/ "./src/server/gsheets/expressAccessors.ts":
/*!************************************************!*\
  !*** ./src/server/gsheets/expressAccessors.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ getExpressAccessors)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "@babel/runtime/helpers/asyncToGenerator");
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/regenerator */ "@babel/runtime/regenerator");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _accessors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./accessors */ "./src/server/gsheets/accessors.ts");



function getExpressAccessors(sheetName, specimen) {
  var _getAccessors = (0,_accessors__WEBPACK_IMPORTED_MODULE_2__["default"])(sheetName, specimen),
      get = _getAccessors.get,
      listGet = _getAccessors.listGet,
      add = _getAccessors.add,
      set = _getAccessors.set;

  function listGetRequest() {
    return /*#__PURE__*/function () {
      var _ref = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().mark(function _callee(_request, response, _next) {
        var elements;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.prev = 0;
                _context.next = 3;
                return listGet();

              case 3:
                elements = _context.sent;

                if (elements) {
                  response.status(200).json(elements);
                }

                _context.next = 10;
                break;

              case 7:
                _context.prev = 7;
                _context.t0 = _context["catch"](0);
                response.status(400).json(_context.t0);

              case 10:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, null, [[0, 7]]);
      }));

      return function (_x, _x2, _x3) {
        return _ref.apply(this, arguments);
      };
    }();
  }

  function getRequest() {
    return /*#__PURE__*/function () {
      var _ref2 = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().mark(function _callee2(request, response, _next) {
        var id, elements;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.prev = 0;
                id = parseInt(request.query.id, 10) || -1;
                _context2.next = 4;
                return get(id);

              case 4:
                elements = _context2.sent;

                if (elements) {
                  response.status(200).json(elements);
                }

                _context2.next = 11;
                break;

              case 8:
                _context2.prev = 8;
                _context2.t0 = _context2["catch"](0);
                response.status(400).json(_context2.t0);

              case 11:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, null, [[0, 8]]);
      }));

      return function (_x4, _x5, _x6) {
        return _ref2.apply(this, arguments);
      };
    }();
  }

  function addRequest() {
    return /*#__PURE__*/function () {
      var _ref3 = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().mark(function _callee3(request, response, _next) {
        var element;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                _context3.prev = 0;
                _context3.next = 3;
                return add(request.body);

              case 3:
                element = _context3.sent;

                if (element) {
                  response.status(200).json(element);
                }

                _context3.next = 10;
                break;

              case 7:
                _context3.prev = 7;
                _context3.t0 = _context3["catch"](0);
                response.status(400).json(_context3.t0);

              case 10:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, null, [[0, 7]]);
      }));

      return function (_x7, _x8, _x9) {
        return _ref3.apply(this, arguments);
      };
    }();
  }

  function setRequest() {
    return /*#__PURE__*/function () {
      var _ref4 = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().mark(function _callee4(request, response, _next) {
        var element;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.prev = 0;
                _context4.next = 3;
                return set(request.body);

              case 3:
                element = _context4.sent;

                if (element) {
                  response.status(200).json(element);
                }

                _context4.next = 10;
                break;

              case 7:
                _context4.prev = 7;
                _context4.t0 = _context4["catch"](0);
                response.status(400).json(_context4.t0);

              case 10:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, null, [[0, 7]]);
      }));

      return function (_x10, _x11, _x12) {
        return _ref4.apply(this, arguments);
      };
    }();
  }

  return {
    getRequest: getRequest,
    addRequest: addRequest,
    listGetRequest: listGetRequest,
    setRequest: setRequest
  };
}

/***/ }),

/***/ "./src/server/gsheets/jeuJav.ts":
/*!**************************************!*\
  !*** ./src/server/gsheets/jeuJav.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "jeuJavListGet": () => (/* binding */ jeuJavListGet),
/* harmony export */   "jeuJavGet": () => (/* binding */ jeuJavGet),
/* harmony export */   "jeuJavAdd": () => (/* binding */ jeuJavAdd),
/* harmony export */   "jeuJavSet": () => (/* binding */ jeuJavSet)
/* harmony export */ });
/* harmony import */ var _expressAccessors__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./expressAccessors */ "./src/server/gsheets/expressAccessors.ts");
/* harmony import */ var _services_jeuxJav__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../services/jeuxJav */ "./src/services/jeuxJav.ts");



var _getExpressAccessors = (0,_expressAccessors__WEBPACK_IMPORTED_MODULE_0__["default"])("Jeux JAV", new _services_jeuxJav__WEBPACK_IMPORTED_MODULE_1__.JeuJav()),
    listGetRequest = _getExpressAccessors.listGetRequest,
    getRequest = _getExpressAccessors.getRequest,
    setRequest = _getExpressAccessors.setRequest,
    addRequest = _getExpressAccessors.addRequest;

var jeuJavListGet = listGetRequest();
var jeuJavGet = getRequest();
var jeuJavAdd = addRequest();
var jeuJavSet = setRequest();

/***/ }),

/***/ "./src/server/gsheets/membres.ts":
/*!***************************************!*\
  !*** ./src/server/gsheets/membres.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "membreListGet": () => (/* binding */ membreListGet),
/* harmony export */   "membreGet": () => (/* binding */ membreGet),
/* harmony export */   "membreAdd": () => (/* binding */ membreAdd),
/* harmony export */   "membreSet": () => (/* binding */ membreSet)
/* harmony export */ });
/* harmony import */ var _expressAccessors__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./expressAccessors */ "./src/server/gsheets/expressAccessors.ts");
/* harmony import */ var _services_membres__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../services/membres */ "./src/services/membres.ts");



var _getExpressAccessors = (0,_expressAccessors__WEBPACK_IMPORTED_MODULE_0__["default"])("Membres", new _services_membres__WEBPACK_IMPORTED_MODULE_1__.Membre()),
    listGetRequest = _getExpressAccessors.listGetRequest,
    getRequest = _getExpressAccessors.getRequest,
    setRequest = _getExpressAccessors.setRequest,
    addRequest = _getExpressAccessors.addRequest;

var membreListGet = listGetRequest();
var membreGet = getRequest();
var membreAdd = addRequest();
var membreSet = setRequest();

/***/ }),

/***/ "./src/server/index.ts":
/*!*****************************!*\
  !*** ./src/server/index.ts ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! path */ "path");
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var express__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! express */ "express");
/* harmony import */ var express__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(express__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var morgan__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! morgan */ "morgan");
/* harmony import */ var morgan__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(morgan__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var compression__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! compression */ "compression");
/* harmony import */ var compression__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(compression__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var helmet__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! helmet */ "helmet");
/* harmony import */ var helmet__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(helmet__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var hpp__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! hpp */ "hpp");
/* harmony import */ var hpp__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(hpp__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var serve_favicon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! serve-favicon */ "serve-favicon");
/* harmony import */ var serve_favicon__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(serve_favicon__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var chalk__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! chalk */ "chalk");
/* harmony import */ var chalk__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(chalk__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var http__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! http */ "http");
/* harmony import */ var http__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(http__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var https__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! https */ "https");
/* harmony import */ var https__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(https__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! fs */ "fs");
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! lodash */ "lodash");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _devServer__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./devServer */ "./src/server/devServer.ts");
/* harmony import */ var _ssr__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./ssr */ "./src/server/ssr.tsx");
/* harmony import */ var _routes_certbot__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../routes/certbot */ "./src/routes/certbot.ts");
/* harmony import */ var _secure__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./secure */ "./src/server/secure.ts");
/* harmony import */ var _gsheets_jeuJav__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./gsheets/jeuJav */ "./src/server/gsheets/jeuJav.ts");
/* harmony import */ var _gsheets_envies__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./gsheets/envies */ "./src/server/gsheets/envies.ts");
/* harmony import */ var _gsheets_membres__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./gsheets/membres */ "./src/server/gsheets/membres.ts");
/* harmony import */ var _userManagement_login__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./userManagement/login */ "./src/server/userManagement/login.ts");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ../config */ "./src/config/index.ts");





















var app = express__WEBPACK_IMPORTED_MODULE_1___default()(); // Use helmet to secure Express with various HTTP headers

app.use(helmet__WEBPACK_IMPORTED_MODULE_4___default()({
  contentSecurityPolicy: false
})); // Prevent HTTP parameter pollution

app.use(hpp__WEBPACK_IMPORTED_MODULE_5___default()()); // Compress all requests

app.use(compression__WEBPACK_IMPORTED_MODULE_3___default()()); // Https with certbot and Let's Encrypt

if (false) {} // Use for http request debug (show errors only)


app.use(morgan__WEBPACK_IMPORTED_MODULE_2___default()("dev", {
  skip: function skip(_req, res) {
    return res.statusCode < 400;
  }
}));
app.use(serve_favicon__WEBPACK_IMPORTED_MODULE_6___default()(path__WEBPACK_IMPORTED_MODULE_0___default().resolve(process.cwd(), "public/favicon.ico")));
app.use(express__WEBPACK_IMPORTED_MODULE_1___default()["static"](path__WEBPACK_IMPORTED_MODULE_0___default().resolve(process.cwd(), "public"))); // Enable dev-server in development

if (true) (0,_devServer__WEBPACK_IMPORTED_MODULE_12__["default"])(app);
app.use(express__WEBPACK_IMPORTED_MODULE_1___default().json()); // Sign in & up API

app.post("/api/user/login", _userManagement_login__WEBPACK_IMPORTED_MODULE_19__["default"]);
/**
 * APIs
 */
// Google Sheets API

app.get("/JeuJavListGet", _gsheets_jeuJav__WEBPACK_IMPORTED_MODULE_16__.jeuJavListGet);
app.get("/EnvieListGet", _gsheets_envies__WEBPACK_IMPORTED_MODULE_17__.envieListGet);
app.post("/EnvieAdd", _gsheets_envies__WEBPACK_IMPORTED_MODULE_17__.envieAdd); // Secured APIs

app.get("/MembreGet", _secure__WEBPACK_IMPORTED_MODULE_15__.secure, _gsheets_membres__WEBPACK_IMPORTED_MODULE_18__.membreGet);
app.post("/MembreSet", _secure__WEBPACK_IMPORTED_MODULE_15__.secure, _gsheets_membres__WEBPACK_IMPORTED_MODULE_18__.membreSet); // Use React server-side rendering middleware

app.get("*", _ssr__WEBPACK_IMPORTED_MODULE_13__["default"]);
/**
 * Create HTTP and HTTPS server.
 */

var servers = [{
  protocol: "http",
  server: http__WEBPACK_IMPORTED_MODULE_8__.createServer(app)
}];
var certPaths = [{
  // Prod
  key: "/root/certbot/config/live/fo.parisestludique.fr/privkey.pem",
  cert: "/root/certbot/config/live/fo.parisestludique.fr/fullchain.pem"
}, {
  // Local
  key: "../certbot/key.pem",
  cert: "../certbot/cert.pem"
}];
var validCertPath = certPaths.find(function (certPath) {
  return lodash__WEBPACK_IMPORTED_MODULE_11___default().every(certPath, function (pemPath) {
    return fs__WEBPACK_IMPORTED_MODULE_10__.existsSync(pemPath);
  });
});

if (validCertPath) {
  var httpsOptions = lodash__WEBPACK_IMPORTED_MODULE_11___default().mapValues(validCertPath, function (pemPath) {
    return fs__WEBPACK_IMPORTED_MODULE_10__.readFileSync(pemPath);
  });

  servers.push({
    protocol: "https",
    server: https__WEBPACK_IMPORTED_MODULE_9__.createServer(httpsOptions, app)
  });
}
/**
 * Listen on provided port, on all network interfaces.
 */


servers.forEach(function (_ref) {
  var protocol = _ref.protocol,
      server = _ref.server;
  server.listen(protocol === "http" ? _config__WEBPACK_IMPORTED_MODULE_20__["default"].PORT : _config__WEBPACK_IMPORTED_MODULE_20__["default"].PORT + 2);
  server.on("error", onError);
  server.on("listening", function () {
    return onListening(server);
  });
});
/**
 * Event listener for HTTP server 'error' event.
 */

function onError(error) {
  if (error) {
    console.error(chalk__WEBPACK_IMPORTED_MODULE_7___default().red("==> \uD83D\uDE2D  OMG!!! ".concat(error)));
  }
}
/**
 * Event listener for HTTP server 'listening' event.
 */


function onListening(server) {
  var addr = server.address();
  var bind = typeof addr === "string" ? "pipe ".concat(addr) : "port ".concat(addr.port);
  console.error(chalk__WEBPACK_IMPORTED_MODULE_7___default().green("\nServer listening on ".concat(bind)));
}

/***/ }),

/***/ "./src/server/renderHtml.ts":
/*!**********************************!*\
  !*** ./src/server/renderHtml.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var serialize_javascript__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! serialize-javascript */ "serialize-javascript");
/* harmony import */ var serialize_javascript__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(serialize_javascript__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var html_minifier__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! html-minifier */ "html-minifier");
/* harmony import */ var html_minifier__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(html_minifier__WEBPACK_IMPORTED_MODULE_1__);


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (function (head, extractor, htmlContent, initialState) {
  var html = "\n    <!doctype html>\n    <html ".concat(head.htmlAttributes.toString(), ">\n      <head>\n        <meta charset=\"utf-8\" />\n        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />\n        <meta name=\"theme-color\" content=\"#000\" />\n\n        <link rel=\"icon\" href=\"/favicon.ico\" />\n        <link rel=\"apple-touch-icon\" href=\"/logo192.png\" />\n        <link rel=\"manifest\" href=\"/manifest.json\" />\n\n        ").concat(head.title.toString(), "\n        ").concat(head.base.toString(), "\n        ").concat(head.meta.toString(), "\n        ").concat(head.link.toString(), "\n\n        <!-- Insert bundled styles into <link> tag -->\n        ").concat(extractor.getLinkTags(), "\n        ").concat(extractor.getStyleTags(), "\n      </head>\n      <body>\n        <!-- Insert the router, which passed from server-side -->\n        <div id=\"react-view\">").concat(htmlContent, "</div>\n\n        <!-- Store the initial state into window -->\n        <script>\n          // Use serialize-javascript for mitigating XSS attacks. See the following security issues:\n          // http://redux.js.org/docs/recipes/ServerRendering.html#security-considerations\n          window.__INITIAL_STATE__=").concat(serialize_javascript__WEBPACK_IMPORTED_MODULE_0___default()(initialState), ";\n        </script>\n\n        <!-- Insert bundled scripts into <script> tag -->\n        ").concat(extractor.getScriptTags(), "\n        ").concat(head.script.toString(), "\n      </body>\n    </html>\n  "); // html-minifier configuration, refer to "https://github.com/kangax/html-minifier" for more configuration

  var minifyConfig = {
    collapseWhitespace: true,
    removeComments: true,
    trimCustomFragments: true,
    minifyCSS: true,
    minifyJS: true,
    minifyURLs: true
  }; // Minify HTML in production

  return  true ? html : 0;
});

/***/ }),

/***/ "./src/server/secure.ts":
/*!******************************!*\
  !*** ./src/server/secure.ts ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "secure": () => (/* binding */ secure),
/* harmony export */   "getJwt": () => (/* binding */ getJwt)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "@babel/runtime/helpers/asyncToGenerator");
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/regenerator */ "@babel/runtime/regenerator");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! path */ "path");
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! fs */ "fs");
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! jsonwebtoken */ "jsonwebtoken");
/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils_standardization__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../utils/standardization */ "./src/utils/standardization.ts");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../config */ "./src/config/index.ts");







var cachedSecret;
getSecret(); // Necessary until we can make async express middleware

function secure(request, response, next) {
  if (!cachedSecret) {
    response.status(408).json({
      error: "Server still loading"
    });
    return;
  }

  var rawToken = request.headers.authorization;
  var token = rawToken && rawToken.split(/\s/)[1];
  (0,jsonwebtoken__WEBPACK_IMPORTED_MODULE_4__.verify)(token, cachedSecret, function (tokenError, decoded) {
    if (tokenError) {
      response.status(403).json({
        error: "Invalid token, please Log in first, criterion auth"
      });
      return;
    }

    decoded.user.replace(/@gmailcom$/, "@gmail.com");
    response.locals.jwt = decoded;
    next();
  });
}

function getSecret() {
  return _getSecret.apply(this, arguments);
}

function _getSecret() {
  _getSecret = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().mark(function _callee() {
    var SECRET_PATH, secretContent;
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            if (cachedSecret) {
              _context.next = 12;
              break;
            }

            SECRET_PATH = path__WEBPACK_IMPORTED_MODULE_2___default().resolve(process.cwd(), "access/jwt_secret.json");
            _context.prev = 2;
            _context.next = 5;
            return fs__WEBPACK_IMPORTED_MODULE_3__.promises.readFile(SECRET_PATH);

          case 5:
            secretContent = _context.sent;
            cachedSecret = secretContent && JSON.parse(secretContent.toString()).secret;
            _context.next = 12;
            break;

          case 9:
            _context.prev = 9;
            _context.t0 = _context["catch"](2);
            cachedSecret = _config__WEBPACK_IMPORTED_MODULE_6__["default"].JWT_SECRET;

          case 12:
            return _context.abrupt("return", cachedSecret);

          case 13:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, null, [[2, 9]]);
  }));
  return _getSecret.apply(this, arguments);
}

function getJwt(_x) {
  return _getJwt.apply(this, arguments);
}

function _getJwt() {
  _getJwt = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().mark(function _callee2(email) {
    var jwt;
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.t0 = jsonwebtoken__WEBPACK_IMPORTED_MODULE_4__.sign;
            _context2.t1 = {
              user: (0,_utils_standardization__WEBPACK_IMPORTED_MODULE_5__.canonicalEmail)(email),
              permissions: []
            };
            _context2.next = 4;
            return getSecret();

          case 4:
            _context2.t2 = _context2.sent;
            _context2.t3 = __TEST__ ? undefined : {
              expiresIn: "365d"
            };
            jwt = (0, _context2.t0)(_context2.t1, _context2.t2, _context2.t3);
            return _context2.abrupt("return", jwt);

          case 8:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));
  return _getJwt.apply(this, arguments);
}

/***/ }),

/***/ "./src/server/ssr.tsx":
/*!****************************!*\
  !*** ./src/server/ssr.tsx ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "@babel/runtime/helpers/asyncToGenerator");
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/regenerator */ "@babel/runtime/regenerator");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! path */ "path");
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_dom_server__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-dom/server */ "react-dom/server");
/* harmony import */ var react_dom_server__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_dom_server__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-router-dom */ "react-router-dom");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_router_dom__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_router_config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-router-config */ "react-router-config");
/* harmony import */ var react_router_config__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_router_config__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-redux */ "react-redux");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _loadable_server__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @loadable/server */ "@loadable/server");
/* harmony import */ var _loadable_server__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_loadable_server__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-helmet */ "react-helmet");
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_helmet__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var chalk__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! chalk */ "chalk");
/* harmony import */ var chalk__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(chalk__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../store */ "./src/store/index.ts");
/* harmony import */ var _renderHtml__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./renderHtml */ "./src/server/renderHtml.ts");
/* harmony import */ var _routes__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../routes */ "./src/routes/index.ts");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! react/jsx-runtime */ "react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__);














/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(function () {
  var _ref = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().mark(function _callee(req, res, next) {
    var _createStore, store, loadBranchData, statsFile, extractor, staticContext, App, initialState, htmlContent, head;

    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _createStore = (0,_store__WEBPACK_IMPORTED_MODULE_10__["default"])({
              url: req.url
            }), store = _createStore.store; // The method for loading data from server-side

            loadBranchData = function loadBranchData() {
              var branch = (0,react_router_config__WEBPACK_IMPORTED_MODULE_5__.matchRoutes)(_routes__WEBPACK_IMPORTED_MODULE_12__["default"], req.path);
              var promises = branch.map(function (_ref2) {
                var route = _ref2.route,
                    match = _ref2.match;
                if (route.loadData) return Promise.all(route.loadData({
                  params: match.params,
                  getState: store.getState,
                  req: req,
                  res: res
                }).map(function (item) {
                  return store.dispatch(item);
                }));
                return Promise.resolve(null);
              });
              return Promise.all(promises);
            };

            _context.prev = 2;
            _context.next = 5;
            return loadBranchData();

          case 5:
            statsFile = path__WEBPACK_IMPORTED_MODULE_2___default().resolve(process.cwd(), "public/loadable-stats");
            extractor = new _loadable_server__WEBPACK_IMPORTED_MODULE_7__.ChunkExtractor({
              statsFile: statsFile
            });
            staticContext = {};
            App = extractor.collectChunks( /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx)(react_redux__WEBPACK_IMPORTED_MODULE_6__.Provider, {
              store: store,
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_13__.jsx)(react_router_dom__WEBPACK_IMPORTED_MODULE_4__.StaticRouter, {
                location: req.path,
                context: staticContext,
                children: (0,react_router_config__WEBPACK_IMPORTED_MODULE_5__.renderRoutes)(_routes__WEBPACK_IMPORTED_MODULE_12__["default"])
              })
            }));
            initialState = store.getState();
            htmlContent = (0,react_dom_server__WEBPACK_IMPORTED_MODULE_3__.renderToString)(App); // head must be placed after "renderToString"
            // see: https://github.com/nfl/react-helmet#server-usage

            head = react_helmet__WEBPACK_IMPORTED_MODULE_8__.Helmet.renderStatic(); // Check if the render result contains a redirect, if so we need to set
            // the specific status and redirect header and end the response

            if (!staticContext.url) {
              _context.next = 16;
              break;
            }

            res.status(301).setHeader("Location", staticContext.url);
            res.end();
            return _context.abrupt("return");

          case 16:
            // Pass the route and initial state into html template, the "statusCode" comes from <NotFound />
            res.status(staticContext.statusCode === "404" ? 404 : 200).send((0,_renderHtml__WEBPACK_IMPORTED_MODULE_11__["default"])(head, extractor, htmlContent, initialState));
            _context.next = 23;
            break;

          case 19:
            _context.prev = 19;
            _context.t0 = _context["catch"](2);
            res.status(404).send("Not Found :(");
            console.error(chalk__WEBPACK_IMPORTED_MODULE_9___default().red("==> \uD83D\uDE2D  Rendering routes error: ".concat(_context.t0)));

          case 23:
            next();

          case 24:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, null, [[2, 19]]);
  }));

  return function (_x, _x2, _x3) {
    return _ref.apply(this, arguments);
  };
})());

/***/ }),

/***/ "./src/server/userManagement/login.ts":
/*!********************************************!*\
  !*** ./src/server/userManagement/login.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ loginHandler),
/* harmony export */   "login": () => (/* binding */ login)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "@babel/runtime/helpers/asyncToGenerator");
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/regenerator */ "@babel/runtime/regenerator");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! bcrypt */ "bcrypt");
/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(bcrypt__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _services_membres__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../services/membres */ "./src/services/membres.ts");
/* harmony import */ var _gsheets_accessors__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../gsheets/accessors */ "./src/server/gsheets/accessors.ts");
/* harmony import */ var _secure__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../secure */ "./src/server/secure.ts");







var _getAccessors = (0,_gsheets_accessors__WEBPACK_IMPORTED_MODULE_4__["default"])("Membres", new _services_membres__WEBPACK_IMPORTED_MODULE_3__.Membre()),
    listGet = _getAccessors.listGet;

function loginHandler(_x, _x2, _x3) {
  return _loginHandler.apply(this, arguments);
}

function _loginHandler() {
  _loginHandler = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().mark(function _callee(request, response, _next) {
    var res;
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.prev = 0;

            if (!(typeof request.body.email !== "string" || typeof request.body.password !== "string")) {
              _context.next = 3;
              break;
            }

            throw Error();

          case 3:
            _context.next = 5;
            return login(request.body.email, request.body.password);

          case 5:
            res = _context.sent;
            response.status(200).json(res);
            _context.next = 12;
            break;

          case 9:
            _context.prev = 9;
            _context.t0 = _context["catch"](0);

            if (_context.t0.message) {
              response.status(200).json({
                error: _context.t0.message
              });
            } else {
              response.status(400).json(_context.t0);
            }

          case 12:
          case "end":
            return _context.stop();
        }
      }
    }, _callee, null, [[0, 9]]);
  }));
  return _loginHandler.apply(this, arguments);
}

function login(_x4, _x5) {
  return _login.apply(this, arguments);
}

function _login() {
  _login = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().mark(function _callee2(rawEmail, rawPassword) {
    var email, password, membres, membre, passwordMatch, jwt;
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            email = rawEmail.replace(/^\s*/, "").replace(/\s*$/, "");

            if (_services_membres__WEBPACK_IMPORTED_MODULE_3__.emailRegexp.test(email)) {
              _context2.next = 3;
              break;
            }

            throw Error("Email invalid");

          case 3:
            password = rawPassword.replace(/^\s*/, "").replace(/\s*$/, "");

            if (!(password.length === 0)) {
              _context2.next = 6;
              break;
            }

            throw Error("Mot de passe nécessaire");

          case 6:
            if (!(password.length < _services_membres__WEBPACK_IMPORTED_MODULE_3__.passwordMinLength)) {
              _context2.next = 8;
              break;
            }

            throw Error("Mot de passe trop court");

          case 8:
            _context2.next = 10;
            return listGet();

          case 10:
            membres = _context2.sent;
            membre = membres.find(function (m) {
              return m.mail === email;
            });

            if (membre) {
              _context2.next = 14;
              break;
            }

            throw Error("Cet email ne correspond à aucun utilisateur");

          case 14:
            _context2.next = 16;
            return bcrypt__WEBPACK_IMPORTED_MODULE_2___default().compare(password, membre.passe.replace(/^\$2y/, "$2a"));

          case 16:
            passwordMatch = _context2.sent;

            if (passwordMatch) {
              _context2.next = 19;
              break;
            }

            throw Error("Mauvais mot de passe pour cet email");

          case 19:
            _context2.next = 21;
            return (0,_secure__WEBPACK_IMPORTED_MODULE_5__.getJwt)(email);

          case 21:
            jwt = _context2.sent;
            return _context2.abrupt("return", {
              membre: {
                prenom: membre.prenom
              },
              jwt: jwt
            });

          case 23:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));
  return _login.apply(this, arguments);
}

/***/ }),

/***/ "./src/services/accessors.ts":
/*!***********************************!*\
  !*** ./src/services/accessors.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "get": () => (/* binding */ get),
/* harmony export */   "listGet": () => (/* binding */ listGet),
/* harmony export */   "add": () => (/* binding */ add),
/* harmony export */   "set": () => (/* binding */ set)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "@babel/runtime/helpers/defineProperty");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "@babel/runtime/helpers/asyncToGenerator");
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/regenerator */ "@babel/runtime/regenerator");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! axios */ "axios");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../config */ "./src/config/index.ts");
/* harmony import */ var _auth__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./auth */ "./src/services/auth.ts");




function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }




function get(elementName) {
  return /*#__PURE__*/function () {
    var _ref = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee(id) {
      var _yield$axios$get, data;

      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.prev = 0;
              _context.next = 3;
              return axios__WEBPACK_IMPORTED_MODULE_3___default().get("".concat(_config__WEBPACK_IMPORTED_MODULE_4__["default"].API_URL, "/").concat(elementName, "Get"), _objectSpread(_objectSpread({}, _auth__WEBPACK_IMPORTED_MODULE_5__.axiosConfig), {}, {
                params: {
                  id: id
                }
              }));

            case 3:
              _yield$axios$get = _context.sent;
              data = _yield$axios$get.data;
              return _context.abrupt("return", {
                data: data
              });

            case 8:
              _context.prev = 8;
              _context.t0 = _context["catch"](0);
              return _context.abrupt("return", {
                error: _context.t0
              });

            case 11:
            case "end":
              return _context.stop();
          }
        }
      }, _callee, null, [[0, 8]]);
    }));

    return function (_x) {
      return _ref.apply(this, arguments);
    };
  }();
}
function listGet(elementName) {
  return /*#__PURE__*/_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee2() {
    var _yield$axios$get2, data;

    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.prev = 0;
            _context2.next = 3;
            return axios__WEBPACK_IMPORTED_MODULE_3___default().get("".concat(_config__WEBPACK_IMPORTED_MODULE_4__["default"].API_URL, "/").concat(elementName, "ListGet"), _auth__WEBPACK_IMPORTED_MODULE_5__.axiosConfig);

          case 3:
            _yield$axios$get2 = _context2.sent;
            data = _yield$axios$get2.data;
            return _context2.abrupt("return", {
              data: data
            });

          case 8:
            _context2.prev = 8;
            _context2.t0 = _context2["catch"](0);
            return _context2.abrupt("return", {
              error: _context2.t0
            });

          case 11:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2, null, [[0, 8]]);
  }));
} // eslint-disable-next-line @typescript-eslint/ban-types

function add(elementName) {
  return /*#__PURE__*/function () {
    var _ref3 = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee3(membreWithoutId) {
      var _yield$axios$post, data;

      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee3$(_context3) {
        while (1) {
          switch (_context3.prev = _context3.next) {
            case 0:
              _context3.prev = 0;
              _context3.next = 3;
              return axios__WEBPACK_IMPORTED_MODULE_3___default().post("".concat(_config__WEBPACK_IMPORTED_MODULE_4__["default"].API_URL, "/").concat(elementName, "Add"), membreWithoutId, _auth__WEBPACK_IMPORTED_MODULE_5__.axiosConfig);

            case 3:
              _yield$axios$post = _context3.sent;
              data = _yield$axios$post.data;
              return _context3.abrupt("return", {
                data: data
              });

            case 8:
              _context3.prev = 8;
              _context3.t0 = _context3["catch"](0);
              return _context3.abrupt("return", {
                error: _context3.t0
              });

            case 11:
            case "end":
              return _context3.stop();
          }
        }
      }, _callee3, null, [[0, 8]]);
    }));

    return function (_x2) {
      return _ref3.apply(this, arguments);
    };
  }();
}
function set(elementName) {
  return /*#__PURE__*/function () {
    var _ref4 = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_1___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee4(membre) {
      var _yield$axios$post2, data;

      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee4$(_context4) {
        while (1) {
          switch (_context4.prev = _context4.next) {
            case 0:
              _context4.prev = 0;
              _context4.next = 3;
              return axios__WEBPACK_IMPORTED_MODULE_3___default().post("".concat(_config__WEBPACK_IMPORTED_MODULE_4__["default"].API_URL, "/").concat(elementName, "Set"), membre, _auth__WEBPACK_IMPORTED_MODULE_5__.axiosConfig);

            case 3:
              _yield$axios$post2 = _context4.sent;
              data = _yield$axios$post2.data;
              return _context4.abrupt("return", {
                data: data
              });

            case 8:
              _context4.prev = 8;
              _context4.t0 = _context4["catch"](0);
              return _context4.abrupt("return", {
                error: _context4.t0
              });

            case 11:
            case "end":
              return _context4.stop();
          }
        }
      }, _callee4, null, [[0, 8]]);
    }));

    return function (_x3) {
      return _ref4.apply(this, arguments);
    };
  }();
}

/***/ }),

/***/ "./src/services/auth.ts":
/*!******************************!*\
  !*** ./src/services/auth.ts ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "axiosConfig": () => (/* binding */ axiosConfig),
/* harmony export */   "setJWT": () => (/* binding */ setJWT),
/* harmony export */   "unsetJWT": () => (/* binding */ unsetJWT)
/* harmony export */ });
var storage = ({"getItem":(function () { return null; }),"setItem":(function () { return null; }),"removeItem":(function () { return null; })});
var jwt = storage === null || storage === void 0 ? void 0 : storage.getItem("id_token");

if (jwt) {
  setJWT(jwt);
}

var axiosConfig = {
  headers: {}
};
function setJWT(token) {
  axiosConfig.headers.Authorization = "Bearer ".concat(token);
  storage === null || storage === void 0 ? void 0 : storage.setItem("id_token", token);
}
function unsetJWT() {
  delete axiosConfig.headers.Authorization;
  storage === null || storage === void 0 ? void 0 : storage.removeItem("id_token");
}

/***/ }),

/***/ "./src/services/envies.ts":
/*!********************************!*\
  !*** ./src/services/envies.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Envie": () => (/* binding */ Envie),
/* harmony export */   "envieGet": () => (/* binding */ envieGet),
/* harmony export */   "envieListGet": () => (/* binding */ envieListGet),
/* harmony export */   "envieAdd": () => (/* binding */ envieAdd),
/* harmony export */   "envieSet": () => (/* binding */ envieSet)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "@babel/runtime/helpers/classCallCheck");
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "@babel/runtime/helpers/defineProperty");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _accessors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./accessors */ "./src/services/accessors.ts");



var Envie = function Envie() {
  _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, Envie);

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "id", 0);

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "domaine", "");

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "envies", "");

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "precisions", "");

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "equipes", []);

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "dateAjout", "");
};
var envieGet = (0,_accessors__WEBPACK_IMPORTED_MODULE_2__.get)("Envie");
var envieListGet = (0,_accessors__WEBPACK_IMPORTED_MODULE_2__.listGet)("Envie");
var envieAdd = (0,_accessors__WEBPACK_IMPORTED_MODULE_2__.add)("Envie");
var envieSet = (0,_accessors__WEBPACK_IMPORTED_MODULE_2__.set)("Envie");

/***/ }),

/***/ "./src/services/jeuxJav.ts":
/*!*********************************!*\
  !*** ./src/services/jeuxJav.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "JeuJav": () => (/* binding */ JeuJav),
/* harmony export */   "jeuJavGet": () => (/* binding */ jeuJavGet),
/* harmony export */   "jeuJavListGet": () => (/* binding */ jeuJavListGet),
/* harmony export */   "jeuJavAdd": () => (/* binding */ jeuJavAdd),
/* harmony export */   "jeuJavSet": () => (/* binding */ jeuJavSet)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "@babel/runtime/helpers/classCallCheck");
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "@babel/runtime/helpers/defineProperty");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _accessors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./accessors */ "./src/services/accessors.ts");



var JeuJav = function JeuJav() {
  _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, JeuJav);

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "id", 0);

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "titre", "");

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "auteur", "");

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "editeur", "");

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "minJoueurs", 0);

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "maxJoueurs", 0);

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "duree", 0);

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "type", "");

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "poufpaf", "");

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "bggId", 0);

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "exemplaires", 1);

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "dispoPret", 0);

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "nonRangee", 0);

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "ean", "");

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "bggPhoto", "");
};
var jeuJavGet = (0,_accessors__WEBPACK_IMPORTED_MODULE_2__.get)("JeuJav");
var jeuJavListGet = (0,_accessors__WEBPACK_IMPORTED_MODULE_2__.listGet)("JeuJav");
var jeuJavAdd = (0,_accessors__WEBPACK_IMPORTED_MODULE_2__.add)("JeuJav");
var jeuJavSet = (0,_accessors__WEBPACK_IMPORTED_MODULE_2__.set)("JeuJav");

/***/ }),

/***/ "./src/services/membres.ts":
/*!*********************************!*\
  !*** ./src/services/membres.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Membre": () => (/* binding */ Membre),
/* harmony export */   "emailRegexp": () => (/* binding */ emailRegexp),
/* harmony export */   "passwordMinLength": () => (/* binding */ passwordMinLength),
/* harmony export */   "membreGet": () => (/* binding */ membreGet),
/* harmony export */   "membreListGet": () => (/* binding */ membreListGet),
/* harmony export */   "membreAdd": () => (/* binding */ membreAdd),
/* harmony export */   "membreSet": () => (/* binding */ membreSet)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "@babel/runtime/helpers/classCallCheck");
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "@babel/runtime/helpers/defineProperty");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _accessors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./accessors */ "./src/services/accessors.ts");



var Membre = function Membre() {
  _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, Membre);

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "id", 0);

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "nom", "");

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "prenom", "");

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "mail", "");

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "telephone", "");

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "photo", "");

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "alimentation", "");

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "majeur", 1);

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "privilege", 0);

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "actif", 0);

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "commentaire", "");

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "horodatage", "");

  _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(this, "passe", "");
};
var emailRegexp = /^(([^<>()[\].,;:\s@"]+(\.[^<>()[\].,;:\s@"]+)*)|(".+"))@(([^<>()[\].,;:\s@"]+\.)+[^<>()[\].,;:\s@"]{2,})$/i;
var passwordMinLength = 4;
var membreGet = (0,_accessors__WEBPACK_IMPORTED_MODULE_2__.get)("Membre");
var membreListGet = (0,_accessors__WEBPACK_IMPORTED_MODULE_2__.listGet)("Membre");
var membreAdd = (0,_accessors__WEBPACK_IMPORTED_MODULE_2__.add)("Membre");
var membreSet = (0,_accessors__WEBPACK_IMPORTED_MODULE_2__.set)("Membre");

/***/ }),

/***/ "./src/store/envieAdd.ts":
/*!*******************************!*\
  !*** ./src/store/envieAdd.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getRequesting": () => (/* binding */ getRequesting),
/* harmony export */   "getSuccess": () => (/* binding */ getSuccess),
/* harmony export */   "getFailure": () => (/* binding */ getFailure),
/* harmony export */   "fetchEnvieAdd": () => (/* binding */ fetchEnvieAdd)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ "@reduxjs/toolkit");
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils */ "./src/store/utils.ts");
/* harmony import */ var _services_envies__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/envies */ "./src/services/envies.ts");



var envieAdapter = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createEntityAdapter)();
var envieAddSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: "addEnvie",
  initialState: envieAdapter.getInitialState({
    readyStatus: "idle"
  }),
  reducers: {
    getRequesting: function getRequesting(state) {
      state.readyStatus = "request";
    },
    getSuccess: function getSuccess(state, _ref) {
      var payload = _ref.payload;
      state.readyStatus = "success";
      envieAdapter.addOne(state, payload);
    },
    getFailure: function getFailure(state, _ref2) {
      var payload = _ref2.payload;
      state.readyStatus = "failure";
      state.error = payload;
    }
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (envieAddSlice.reducer);
var _envieAddSlice$action = envieAddSlice.actions,
    getRequesting = _envieAddSlice$action.getRequesting,
    getSuccess = _envieAddSlice$action.getSuccess,
    getFailure = _envieAddSlice$action.getFailure;

var fetchEnvieAdd = (0,_utils__WEBPACK_IMPORTED_MODULE_1__.elementAddFetch)(_services_envies__WEBPACK_IMPORTED_MODULE_2__.envieAdd, getRequesting, getSuccess, getFailure, function (error) {
  return (0,_utils__WEBPACK_IMPORTED_MODULE_1__.toastError)("Erreur lors de l'ajout d'une envie: ".concat(error.message));
}, function () {
  return (0,_utils__WEBPACK_IMPORTED_MODULE_1__.toastSuccess)("Envie ajoutée !");
});

/***/ }),

/***/ "./src/store/envieList.ts":
/*!********************************!*\
  !*** ./src/store/envieList.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getRequesting": () => (/* binding */ getRequesting),
/* harmony export */   "getSuccess": () => (/* binding */ getSuccess),
/* harmony export */   "getFailure": () => (/* binding */ getFailure),
/* harmony export */   "fetchEnvieList": () => (/* binding */ fetchEnvieList),
/* harmony export */   "fetchEnvieListIfNeed": () => (/* binding */ fetchEnvieListIfNeed)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ "@reduxjs/toolkit");
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils */ "./src/store/utils.ts");
/* harmony import */ var _services_envies__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/envies */ "./src/services/envies.ts");



var envieAdapter = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createEntityAdapter)();
var envieList = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: "getEnvieList",
  initialState: envieAdapter.getInitialState({
    readyStatus: "idle"
  }),
  reducers: {
    getRequesting: function getRequesting(state) {
      state.readyStatus = "request";
    },
    getSuccess: function getSuccess(state, _ref) {
      var payload = _ref.payload;
      state.readyStatus = "success";
      envieAdapter.setAll(state, payload);
    },
    getFailure: function getFailure(state, _ref2) {
      var payload = _ref2.payload;
      state.readyStatus = "failure";
      state.error = payload;
    }
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (envieList.reducer);
var _envieList$actions = envieList.actions,
    getRequesting = _envieList$actions.getRequesting,
    getSuccess = _envieList$actions.getSuccess,
    getFailure = _envieList$actions.getFailure;

var fetchEnvieList = (0,_utils__WEBPACK_IMPORTED_MODULE_1__.elementListFetch)(_services_envies__WEBPACK_IMPORTED_MODULE_2__.envieListGet, getRequesting, getSuccess, getFailure, function (error) {
  return (0,_utils__WEBPACK_IMPORTED_MODULE_1__.toastError)("Erreur lors du chargement des envies: ".concat(error.message));
});

var shouldFetchEnvieList = function shouldFetchEnvieList(state) {
  return state.envieList.readyStatus !== "success";
};

var fetchEnvieListIfNeed = function fetchEnvieListIfNeed() {
  return function (dispatch, getState) {
    if (shouldFetchEnvieList(getState())) return dispatch(fetchEnvieList());
    return null;
  };
};

/***/ }),

/***/ "./src/store/index.ts":
/*!****************************!*\
  !*** ./src/store/index.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "@babel/runtime/helpers/toConsumableArray");
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var history__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! history */ "history");
/* harmony import */ var history__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(history__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @reduxjs/toolkit */ "@reduxjs/toolkit");
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var connected_react_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! connected-react-router */ "connected-react-router");
/* harmony import */ var connected_react_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(connected_react_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _rootReducer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./rootReducer */ "./src/store/rootReducer.ts");






// Use inferred return type for making correctly Redux types
// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
var createStore = function createStore() {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      initialState = _ref.initialState,
      url = _ref.url;

  var history =  true ? (0,history__WEBPACK_IMPORTED_MODULE_1__.createMemoryHistory)({
    initialEntries: [url || "/"]
  }) : 0;
  var store = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_2__.configureStore)({
    preloadedState: initialState,
    reducer: (0,_rootReducer__WEBPACK_IMPORTED_MODULE_4__["default"])(history),
    middleware: function middleware(getDefaultMiddleware) {
      return [].concat(_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default()(getDefaultMiddleware()), [(0,connected_react_router__WEBPACK_IMPORTED_MODULE_3__.routerMiddleware)(history)]);
    },
    devTools: true
  });
  return {
    store: store,
    history: history
  };
};

var _createStore = createStore(),
    store = _createStore.store;

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (createStore);

/***/ }),

/***/ "./src/store/jeuJavList.ts":
/*!*********************************!*\
  !*** ./src/store/jeuJavList.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "initialState": () => (/* binding */ initialState),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getRequesting": () => (/* binding */ getRequesting),
/* harmony export */   "getSuccess": () => (/* binding */ getSuccess),
/* harmony export */   "getFailure": () => (/* binding */ getFailure),
/* harmony export */   "fetchJeuJavList": () => (/* binding */ fetchJeuJavList),
/* harmony export */   "fetchJeuJavListIfNeed": () => (/* binding */ fetchJeuJavListIfNeed)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ "@reduxjs/toolkit");
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils */ "./src/store/utils.ts");
/* harmony import */ var _services_jeuxJav__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/jeuxJav */ "./src/services/jeuxJav.ts");



var jeuJavAdapter = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createEntityAdapter)();
var initialState = jeuJavAdapter.getInitialState({
  readyStatus: "idle"
});
var jeuJavList = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: "jeuJavList",
  initialState: initialState,
  reducers: {
    getRequesting: function getRequesting(state) {
      state.readyStatus = "request";
    },
    getSuccess: function getSuccess(state, _ref) {
      var payload = _ref.payload;
      state.readyStatus = "success";
      jeuJavAdapter.setAll(state, payload);
    },
    getFailure: function getFailure(state, _ref2) {
      var payload = _ref2.payload;
      state.readyStatus = "failure";
      state.error = payload;
    }
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (jeuJavList.reducer);
var _jeuJavList$actions = jeuJavList.actions,
    getRequesting = _jeuJavList$actions.getRequesting,
    getSuccess = _jeuJavList$actions.getSuccess,
    getFailure = _jeuJavList$actions.getFailure;

var fetchJeuJavList = (0,_utils__WEBPACK_IMPORTED_MODULE_1__.elementListFetch)(_services_jeuxJav__WEBPACK_IMPORTED_MODULE_2__.jeuJavListGet, getRequesting, getSuccess, getFailure, function (error) {
  return (0,_utils__WEBPACK_IMPORTED_MODULE_1__.toastError)("Erreur lors du chargement des jeux JAV: ".concat(error.message));
});

var shouldFetchJeuJavList = function shouldFetchJeuJavList(state) {
  return state.jeuJavList.readyStatus !== "success";
};

var fetchJeuJavListIfNeed = function fetchJeuJavListIfNeed() {
  return function (dispatch, getState) {
    if (shouldFetchJeuJavList(getState())) return dispatch(fetchJeuJavList());
    return null;
  };
};

/***/ }),

/***/ "./src/store/membre.ts":
/*!*****************************!*\
  !*** ./src/store/membre.ts ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "initialState": () => (/* binding */ initialState),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getRequesting": () => (/* binding */ getRequesting),
/* harmony export */   "getSuccess": () => (/* binding */ getSuccess),
/* harmony export */   "getFailure": () => (/* binding */ getFailure),
/* harmony export */   "fetchMembre": () => (/* binding */ fetchMembre),
/* harmony export */   "fetchMembreIfNeed": () => (/* binding */ fetchMembreIfNeed)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ "@reduxjs/toolkit");
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils */ "./src/store/utils.ts");
/* harmony import */ var _services_membres__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/membres */ "./src/services/membres.ts");



var initialState = {
  readyStatus: "idle"
};
var membre = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: "membre",
  initialState: initialState,
  reducers: {
    getRequesting: function getRequesting(_) {
      return {
        readyStatus: "request"
      };
    },
    getSuccess: function getSuccess(_, _ref) {
      var payload = _ref.payload;
      return {
        readyStatus: "success",
        entity: payload
      };
    },
    getFailure: function getFailure(_, _ref2) {
      var payload = _ref2.payload;
      return {
        readyStatus: "failure",
        error: payload
      };
    }
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (membre.reducer);
var _membre$actions = membre.actions,
    getRequesting = _membre$actions.getRequesting,
    getSuccess = _membre$actions.getSuccess,
    getFailure = _membre$actions.getFailure;

var fetchMembre = (0,_utils__WEBPACK_IMPORTED_MODULE_1__.elementFetch)(_services_membres__WEBPACK_IMPORTED_MODULE_2__.membreGet, getRequesting, getSuccess, getFailure, function (error) {
  return (0,_utils__WEBPACK_IMPORTED_MODULE_1__.toastError)("Erreur lors du chargement d'un membre: ".concat(error.message));
});

var shouldFetchMembre = function shouldFetchMembre(state, id) {
  return state.membre.readyStatus !== "success" || state.membre.entity && state.membre.entity.id !== id;
};

var fetchMembreIfNeed = function fetchMembreIfNeed(id) {
  return function (dispatch, getState) {
    if (shouldFetchMembre(getState(), id)) return dispatch(fetchMembre(id));
    return null;
  };
};

/***/ }),

/***/ "./src/store/membreAdd.ts":
/*!********************************!*\
  !*** ./src/store/membreAdd.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getRequesting": () => (/* binding */ getRequesting),
/* harmony export */   "getSuccess": () => (/* binding */ getSuccess),
/* harmony export */   "getFailure": () => (/* binding */ getFailure),
/* harmony export */   "fetchMembreAdd": () => (/* binding */ fetchMembreAdd)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ "@reduxjs/toolkit");
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils */ "./src/store/utils.ts");
/* harmony import */ var _services_membres__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/membres */ "./src/services/membres.ts");



var membreAdapter = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createEntityAdapter)();
var membreAddSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: "addMembre",
  initialState: membreAdapter.getInitialState({
    readyStatus: "idle"
  }),
  reducers: {
    getRequesting: function getRequesting(state) {
      state.readyStatus = "request";
    },
    getSuccess: function getSuccess(state, _ref) {
      var payload = _ref.payload;
      state.readyStatus = "success";
      membreAdapter.addOne(state, payload);
    },
    getFailure: function getFailure(state, _ref2) {
      var payload = _ref2.payload;
      state.readyStatus = "failure";
      state.error = payload;
    }
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (membreAddSlice.reducer);
var _membreAddSlice$actio = membreAddSlice.actions,
    getRequesting = _membreAddSlice$actio.getRequesting,
    getSuccess = _membreAddSlice$actio.getSuccess,
    getFailure = _membreAddSlice$actio.getFailure;

var fetchMembreAdd = (0,_utils__WEBPACK_IMPORTED_MODULE_1__.elementAddFetch)(_services_membres__WEBPACK_IMPORTED_MODULE_2__.membreAdd, getRequesting, getSuccess, getFailure, function (error) {
  return (0,_utils__WEBPACK_IMPORTED_MODULE_1__.toastError)("Erreur lors de l'ajout d'une membre: ".concat(error.message));
}, function () {
  return (0,_utils__WEBPACK_IMPORTED_MODULE_1__.toastSuccess)("Membre ajoutée !");
});

/***/ }),

/***/ "./src/store/membreList.ts":
/*!*********************************!*\
  !*** ./src/store/membreList.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "initialState": () => (/* binding */ initialState),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getRequesting": () => (/* binding */ getRequesting),
/* harmony export */   "getSuccess": () => (/* binding */ getSuccess),
/* harmony export */   "getFailure": () => (/* binding */ getFailure),
/* harmony export */   "fetchMembreList": () => (/* binding */ fetchMembreList),
/* harmony export */   "fetchMembreListIfNeed": () => (/* binding */ fetchMembreListIfNeed)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ "@reduxjs/toolkit");
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils */ "./src/store/utils.ts");
/* harmony import */ var _services_membres__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/membres */ "./src/services/membres.ts");



var membreAdapter = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createEntityAdapter)();
var initialState = membreAdapter.getInitialState({
  readyStatus: "idle"
});
var membreList = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: "membreList",
  initialState: initialState,
  reducers: {
    getRequesting: function getRequesting(state) {
      state.readyStatus = "request";
    },
    getSuccess: function getSuccess(state, _ref) {
      var payload = _ref.payload;
      state.readyStatus = "success";
      membreAdapter.setAll(state, payload);
    },
    getFailure: function getFailure(state, _ref2) {
      var payload = _ref2.payload;
      state.readyStatus = "failure";
      state.error = payload;
    }
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (membreList.reducer);
var _membreList$actions = membreList.actions,
    getRequesting = _membreList$actions.getRequesting,
    getSuccess = _membreList$actions.getSuccess,
    getFailure = _membreList$actions.getFailure;

var fetchMembreList = (0,_utils__WEBPACK_IMPORTED_MODULE_1__.elementListFetch)(_services_membres__WEBPACK_IMPORTED_MODULE_2__.membreListGet, getRequesting, getSuccess, getFailure, function (error) {
  return (0,_utils__WEBPACK_IMPORTED_MODULE_1__.toastError)("Erreur lors du chargement des membres: ".concat(error.message));
});

var shouldFetchMembreList = function shouldFetchMembreList(state) {
  return state.membreList.readyStatus !== "success";
};

var fetchMembreListIfNeed = function fetchMembreListIfNeed() {
  return function (dispatch, getState) {
    if (shouldFetchMembreList(getState())) return dispatch(fetchMembreList());
    return null;
  };
};

/***/ }),

/***/ "./src/store/membreSet.ts":
/*!********************************!*\
  !*** ./src/store/membreSet.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getRequesting": () => (/* binding */ getRequesting),
/* harmony export */   "getSuccess": () => (/* binding */ getSuccess),
/* harmony export */   "getFailure": () => (/* binding */ getFailure),
/* harmony export */   "fetchMembreSet": () => (/* binding */ fetchMembreSet)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @reduxjs/toolkit */ "@reduxjs/toolkit");
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils */ "./src/store/utils.ts");
/* harmony import */ var _services_membres__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/membres */ "./src/services/membres.ts");



var membreAdapter = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createEntityAdapter)();
var membreSetSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
  name: "membreSet",
  initialState: membreAdapter.getInitialState({
    readyStatus: "idle"
  }),
  reducers: {
    getRequesting: function getRequesting(state) {
      state.readyStatus = "request";
    },
    getSuccess: function getSuccess(state, _ref) {
      var payload = _ref.payload;
      state.readyStatus = "success";
      membreAdapter.setOne(state, payload);
    },
    getFailure: function getFailure(state, _ref2) {
      var payload = _ref2.payload;
      state.readyStatus = "failure";
      state.error = payload;
    }
  }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (membreSetSlice.reducer);
var _membreSetSlice$actio = membreSetSlice.actions,
    getRequesting = _membreSetSlice$actio.getRequesting,
    getSuccess = _membreSetSlice$actio.getSuccess,
    getFailure = _membreSetSlice$actio.getFailure;

var fetchMembreSet = (0,_utils__WEBPACK_IMPORTED_MODULE_1__.elementSet)(_services_membres__WEBPACK_IMPORTED_MODULE_2__.membreSet, getRequesting, getSuccess, getFailure, function (error) {
  return (0,_utils__WEBPACK_IMPORTED_MODULE_1__.toastError)("Erreur lors de la modification d'un membre: ".concat(error.message));
}, function () {
  return (0,_utils__WEBPACK_IMPORTED_MODULE_1__.toastSuccess)("Membre modifié !");
});

/***/ }),

/***/ "./src/store/rootReducer.ts":
/*!**********************************!*\
  !*** ./src/store/rootReducer.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var connected_react_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! connected-react-router */ "connected-react-router");
/* harmony import */ var connected_react_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(connected_react_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _envieAdd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./envieAdd */ "./src/store/envieAdd.ts");
/* harmony import */ var _envieList__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./envieList */ "./src/store/envieList.ts");
/* harmony import */ var _jeuJavList__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./jeuJavList */ "./src/store/jeuJavList.ts");
/* harmony import */ var _membre__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./membre */ "./src/store/membre.ts");
/* harmony import */ var _membreAdd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./membreAdd */ "./src/store/membreAdd.ts");
/* harmony import */ var _membreList__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./membreList */ "./src/store/membreList.ts");
/* harmony import */ var _membreSet__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./membreSet */ "./src/store/membreSet.ts");







 // Use inferred return type for making correctly Redux types
// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (function (history) {
  return {
    envieAdd: _envieAdd__WEBPACK_IMPORTED_MODULE_1__["default"],
    envieList: _envieList__WEBPACK_IMPORTED_MODULE_2__["default"],
    jeuJavList: _jeuJavList__WEBPACK_IMPORTED_MODULE_3__["default"],
    membre: _membre__WEBPACK_IMPORTED_MODULE_4__["default"],
    membreAdd: _membreAdd__WEBPACK_IMPORTED_MODULE_5__["default"],
    membreList: _membreList__WEBPACK_IMPORTED_MODULE_6__["default"],
    membreSet: _membreSet__WEBPACK_IMPORTED_MODULE_7__["default"],
    router: (0,connected_react_router__WEBPACK_IMPORTED_MODULE_0__.connectRouter)(history) // Register more reducers...

  };
});

/***/ }),

/***/ "./src/store/utils.ts":
/*!****************************!*\
  !*** ./src/store/utils.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "toastError": () => (/* binding */ toastError),
/* harmony export */   "toastSuccess": () => (/* binding */ toastSuccess),
/* harmony export */   "elementFetch": () => (/* binding */ elementFetch),
/* harmony export */   "elementAddFetch": () => (/* binding */ elementAddFetch),
/* harmony export */   "elementListFetch": () => (/* binding */ elementListFetch),
/* harmony export */   "elementSet": () => (/* binding */ elementSet)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "@babel/runtime/helpers/asyncToGenerator");
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/regenerator */ "@babel/runtime/regenerator");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-toastify */ "react-toastify");
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_2__);



function toastError(message) {
  react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.error(message, {
    position: "top-center",
    autoClose: 6000,
    hideProgressBar: true,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    progress: undefined
  });
}
function toastSuccess(message) {
  react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.success(message, {
    position: "top-center",
    autoClose: 3000,
    hideProgressBar: true,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    progress: undefined
  });
}
function elementFetch(elementService, getRequesting, getSuccess, getFailure) {
  var errorMessage = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : function (_error) {
    /* Meant to be empty */
  };
  var successMessage = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : function () {
    /* Meant to be empty */
  };
  return function (id) {
    return /*#__PURE__*/function () {
      var _ref = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().mark(function _callee(dispatch) {
        var _yield$elementService, error, data;

        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                dispatch(getRequesting());
                _context.next = 3;
                return elementService(id);

              case 3:
                _yield$elementService = _context.sent;
                error = _yield$elementService.error;
                data = _yield$elementService.data;

                if (error) {
                  dispatch(getFailure(error.message));
                  errorMessage(error);
                } else {
                  dispatch(getSuccess(data));
                  successMessage();
                }

              case 7:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));

      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }();
  };
}
function elementAddFetch(elementAddService, getRequesting, getSuccess, getFailure) {
  var errorMessage = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : function (_error) {
    /* Meant to be empty */
  };
  var successMessage = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : function () {
    /* Meant to be empty */
  };
  return function (membreWithoutId) {
    return /*#__PURE__*/function () {
      var _ref2 = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().mark(function _callee2(dispatch) {
        var _yield$elementAddServ, error, data;

        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                dispatch(getRequesting());
                _context2.next = 3;
                return elementAddService(membreWithoutId);

              case 3:
                _yield$elementAddServ = _context2.sent;
                error = _yield$elementAddServ.error;
                data = _yield$elementAddServ.data;

                if (error) {
                  dispatch(getFailure(error.message));
                  errorMessage(error);
                } else {
                  dispatch(getSuccess(data));
                  successMessage();
                }

              case 7:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }));

      return function (_x2) {
        return _ref2.apply(this, arguments);
      };
    }();
  };
}
function elementListFetch(elementListService, getRequesting, getSuccess, getFailure) {
  var errorMessage = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : function (_error) {
    /* Meant to be empty */
  };
  var successMessage = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : function () {
    /* Meant to be empty */
  };
  return function () {
    return /*#__PURE__*/function () {
      var _ref3 = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().mark(function _callee3(dispatch) {
        var _yield$elementListSer, error, data;

        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                dispatch(getRequesting());
                _context3.next = 3;
                return elementListService();

              case 3:
                _yield$elementListSer = _context3.sent;
                error = _yield$elementListSer.error;
                data = _yield$elementListSer.data;

                if (error) {
                  dispatch(getFailure(error.message));
                  errorMessage(error);
                } else {
                  dispatch(getSuccess(data));
                  successMessage();
                }

              case 7:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3);
      }));

      return function (_x3) {
        return _ref3.apply(this, arguments);
      };
    }();
  };
}
function elementSet(elementSetService, getRequesting, getSuccess, getFailure) {
  var errorMessage = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : function (_error) {
    /* Meant to be empty */
  };
  var successMessage = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : function () {
    /* Meant to be empty */
  };
  return function (element) {
    return /*#__PURE__*/function () {
      var _ref4 = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().mark(function _callee4(dispatch) {
        var _yield$elementSetServ, error, data;

        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                dispatch(getRequesting());
                _context4.next = 3;
                return elementSetService(element);

              case 3:
                _yield$elementSetServ = _context4.sent;
                error = _yield$elementSetServ.error;
                data = _yield$elementSetServ.data;

                if (error) {
                  dispatch(getFailure(error.message));
                  errorMessage(error);
                } else {
                  dispatch(getSuccess(data));
                  successMessage();
                }

              case 7:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4);
      }));

      return function (_x4) {
        return _ref4.apply(this, arguments);
      };
    }();
  };
}

/***/ }),

/***/ "./src/utils/standardization.ts":
/*!**************************************!*\
  !*** ./src/utils/standardization.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "canonicalEmail": () => (/* binding */ canonicalEmail),
/* harmony export */   "validEmail": () => (/* binding */ validEmail)
/* harmony export */ });
function canonicalEmail(email) {
  email = email.replace(/^\s+|\s+$/g, "");

  if (/@gmail.com$/.test(email)) {
    var domain = email.replace(/^.*@/, "");
    domain = domain.replace(/^googlemail%.com$/, "gmail.com");
    email = email.replace(/\./g, "").replace(/^[^@]+/, function (match) {
      return match.toLowerCase();
    }).replace(/@.*$/, "@".concat(domain));
  }

  return email.toLowerCase();
}
function validEmail(email) {
  return /^(?=.{1,254}$)(?=.{1,64}@)[-!#$%&'*+/0-9=?A-Z^_`a-z{|}~]+(\.[-!#$%&'*+/0-9=?A-Z^_`a-z{|}~]+)*@[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*$/.test(email);
}

/***/ }),

/***/ "./webpack/base.config.ts":
/*!********************************!*\
  !*** ./webpack/base.config.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "isDev": () => (/* binding */ isDev),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "@babel/runtime/helpers/toConsumableArray");
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! path */ "path");
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var webpack__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! webpack */ "webpack");
/* harmony import */ var webpack__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(webpack__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var webpack_manifest_plugin__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! webpack-manifest-plugin */ "webpack-manifest-plugin");
/* harmony import */ var webpack_manifest_plugin__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(webpack_manifest_plugin__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var terser_webpack_plugin__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! terser-webpack-plugin */ "terser-webpack-plugin");
/* harmony import */ var terser_webpack_plugin__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(terser_webpack_plugin__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var mini_css_extract_plugin__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! mini-css-extract-plugin */ "mini-css-extract-plugin");
/* harmony import */ var mini_css_extract_plugin__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(mini_css_extract_plugin__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var fork_ts_checker_webpack_plugin__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! fork-ts-checker-webpack-plugin */ "fork-ts-checker-webpack-plugin");
/* harmony import */ var fork_ts_checker_webpack_plugin__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(fork_ts_checker_webpack_plugin__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _loadable_webpack_plugin__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @loadable/webpack-plugin */ "@loadable/webpack-plugin");
/* harmony import */ var _loadable_webpack_plugin__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_loadable_webpack_plugin__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var webpack_bundle_analyzer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! webpack-bundle-analyzer */ "webpack-bundle-analyzer");
/* harmony import */ var webpack_bundle_analyzer__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(webpack_bundle_analyzer__WEBPACK_IMPORTED_MODULE_8__);









var isDev = "development" === "development";
var isLocal = process.env.LOCAL === "true";

var getStyleLoaders = function getStyleLoaders(isWeb, isSass) {
  var loaders = [{
    loader: "css-loader",
    options: {
      importLoaders: isSass ? 2 : 1,
      modules: {
        auto: true,
        localIdentName: "[path][name]__[local]",
        // Don't use hash:base64, a bug makes it generate different hashes in the .js and the .css files
        exportOnlyLocals: !isWeb
      }
    }
  }, {
    loader: "postcss-loader"
  }];
  if (isWeb) loaders = [(mini_css_extract_plugin__WEBPACK_IMPORTED_MODULE_5___default().loader)].concat(_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default()(loaders));
  if (isSass) loaders = [].concat(_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default()(loaders), [{
    loader: "sass-loader"
  }]);
  return loaders;
};

var getPlugins = function getPlugins(isWeb) {
  var plugins = [new (webpack__WEBPACK_IMPORTED_MODULE_2___default().ProgressPlugin)(), new webpack_manifest_plugin__WEBPACK_IMPORTED_MODULE_3__.WebpackManifestPlugin({
    fileName: path__WEBPACK_IMPORTED_MODULE_1___default().resolve(process.cwd(), "public/webpack-assets.json"),
    filter: function filter(file) {
      return file.isInitial;
    }
  }), new (_loadable_webpack_plugin__WEBPACK_IMPORTED_MODULE_7___default())({
    writeToDisk: true,
    filename: "../loadable-stats.json"
  }), // Setting global variables
  new (webpack__WEBPACK_IMPORTED_MODULE_2___default().DefinePlugin)({
    __CLIENT__: isWeb,
    __SERVER__: !isWeb,
    __DEV__: isDev,
    __LOCAL__: isLocal
  })];
  if (isDev) plugins = [].concat(_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default()(plugins), [// Runs TypeScript type checker on a separate process
  new (fork_ts_checker_webpack_plugin__WEBPACK_IMPORTED_MODULE_6___default())({
    // (Required) Same as eslint command
    eslint: {
      files: "./src/**/*.{js,jsx,ts,tsx}"
    }
  })]);
  if (!isDev) plugins = [].concat(_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default()(plugins), [// Visualize size of webpack output files, see: https://github.com/webpack-contrib/webpack-bundle-analyzer
  new webpack_bundle_analyzer__WEBPACK_IMPORTED_MODULE_8__.BundleAnalyzerPlugin({
    analyzerMode:  false ? 0 : "disabled"
  })]);
  return plugins;
};

var config = function config() {
  var isWeb = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;
  return {
    mode: isDev ? "development" : "production",
    stats: "minimal",
    context: path__WEBPACK_IMPORTED_MODULE_1___default().resolve(process.cwd()),
    output: {
      clean: true
    },
    optimization: {
      minimizer: [new (terser_webpack_plugin__WEBPACK_IMPORTED_MODULE_4___default())({
        // See more options: https://github.com/webpack-contrib/terser-webpack-plugin#terseroptions
        terserOptions: {
          compress: {
            drop_console: true
          }
        }
      })]
    },
    plugins: getPlugins(isWeb),
    module: {
      rules: [{
        test: /\.(t|j)sx?$/,
        exclude: /node_modules/,
        loader: "babel-loader",
        options: {
          caller: {
            target: isWeb ? "web" : "node"
          },
          cacheDirectory: isDev
        }
      }, {
        test: /\.css$/,
        use: getStyleLoaders(isWeb)
      }, {
        test: /\.(scss|sass)$/,
        use: getStyleLoaders(isWeb, true)
      }, {
        test: /\.(woff2?|eot|ttf|otf)$/i,
        type: "asset",
        generator: {
          emit: isWeb
        }
      }, {
        test: /\.(png|svg|jpe?g|gif)$/i,
        type: "asset",
        generator: {
          emit: isWeb
        }
      }]
    },
    resolve: {
      modules: ["src", "node_modules"],
      extensions: [".ts", ".tsx", ".js", ".jsx", ".json"]
    }
  };
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (config);

/***/ }),

/***/ "./webpack/client.config.ts":
/*!**********************************!*\
  !*** ./webpack/client.config.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "@babel/runtime/helpers/toConsumableArray");
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! path */ "path");
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var webpack__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! webpack */ "webpack");
/* harmony import */ var webpack__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(webpack__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _pmmmwh_react_refresh_webpack_plugin__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @pmmmwh/react-refresh-webpack-plugin */ "@pmmmwh/react-refresh-webpack-plugin");
/* harmony import */ var _pmmmwh_react_refresh_webpack_plugin__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_pmmmwh_react_refresh_webpack_plugin__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var mini_css_extract_plugin__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! mini-css-extract-plugin */ "mini-css-extract-plugin");
/* harmony import */ var mini_css_extract_plugin__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(mini_css_extract_plugin__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var css_minimizer_webpack_plugin__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! css-minimizer-webpack-plugin */ "css-minimizer-webpack-plugin");
/* harmony import */ var css_minimizer_webpack_plugin__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(css_minimizer_webpack_plugin__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var compression_webpack_plugin__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! compression-webpack-plugin */ "compression-webpack-plugin");
/* harmony import */ var compression_webpack_plugin__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(compression_webpack_plugin__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var image_minimizer_webpack_plugin__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! image-minimizer-webpack-plugin */ "image-minimizer-webpack-plugin");
/* harmony import */ var image_minimizer_webpack_plugin__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(image_minimizer_webpack_plugin__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var webpack_merge__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! webpack-merge */ "webpack-merge");
/* harmony import */ var webpack_merge__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(webpack_merge__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _base_config__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./base.config */ "./webpack/base.config.ts");











var getPlugins = function getPlugins() {
  var plugins = [new (mini_css_extract_plugin__WEBPACK_IMPORTED_MODULE_4___default())({
    // Don't use hash in development, we need the persistent for "renderHtml.ts"
    filename: _base_config__WEBPACK_IMPORTED_MODULE_9__.isDev ? "[name].css" : "[name].[contenthash].css",
    chunkFilename: _base_config__WEBPACK_IMPORTED_MODULE_9__.isDev ? "[id].css" : "[id].[contenthash].css"
  })];
  if (_base_config__WEBPACK_IMPORTED_MODULE_9__.isDev) plugins = [].concat(_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default()(plugins), [new (webpack__WEBPACK_IMPORTED_MODULE_2___default().HotModuleReplacementPlugin)(), new (_pmmmwh_react_refresh_webpack_plugin__WEBPACK_IMPORTED_MODULE_3___default())({
    overlay: {
      sockIntegration: "whm"
    }
  }), new (webpack__WEBPACK_IMPORTED_MODULE_2___default().DefinePlugin)({
    process: "process/browser"
  })]);
  if (!_base_config__WEBPACK_IMPORTED_MODULE_9__.isDev) plugins = [].concat(_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default()(plugins), [// Prepare compressed versions of assets to serve them with Content-Encoding
  new (compression_webpack_plugin__WEBPACK_IMPORTED_MODULE_6___default())(), new (image_minimizer_webpack_plugin__WEBPACK_IMPORTED_MODULE_7___default())({
    // Lossless optimization with default option, feel free to experiment with options for better result for you
    // See https://github.com/webpack-contrib/image-minimizer-webpack-plugin#getting-started
    minimizerOptions: {
      plugins: [["gifsicle"], ["jpegtran"], ["optipng"], ["svgo"]]
    }
  })]);
  return plugins;
};

var config = {
  devtool: _base_config__WEBPACK_IMPORTED_MODULE_9__.isDev ? "inline-source-map" : "hidden-source-map",
  entry: _base_config__WEBPACK_IMPORTED_MODULE_9__.isDev ? ["webpack-hot-middleware/client?reload=true", "./src/client"] : "./src/client",
  output: {
    filename: _base_config__WEBPACK_IMPORTED_MODULE_9__.isDev ? "[name].js" : "[name].[contenthash].js",
    chunkFilename: _base_config__WEBPACK_IMPORTED_MODULE_9__.isDev ? "[id].js" : "[id].[contenthash].js",
    path: path__WEBPACK_IMPORTED_MODULE_1___default().resolve(process.cwd(), "public/assets"),
    publicPath: "/assets/"
  },
  optimization: {
    minimizer: [new (css_minimizer_webpack_plugin__WEBPACK_IMPORTED_MODULE_5___default())()]
  },
  plugins: getPlugins(),
  performance: {
    maxAssetSize: 512000,
    maxEntrypointSize: 512000
  }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (webpack_merge__WEBPACK_IMPORTED_MODULE_8___default()((0,_base_config__WEBPACK_IMPORTED_MODULE_9__["default"])(true), config));

/***/ }),

/***/ "./node_modules/normalize.css/normalize.css":
/*!**************************************************!*\
  !*** ./node_modules/normalize.css/normalize.css ***!
  \**************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "/*! normalize.css v8.0.1 | MIT License | github.com/necolas/normalize.css */\n\n/* Document\n   ========================================================================== */\n\n/**\n * 1. Correct the line height in all browsers.\n * 2. Prevent adjustments of font size after orientation changes in iOS.\n */\n\nhtml {\n  line-height: 1.15; /* 1 */\n  -webkit-text-size-adjust: 100%; /* 2 */\n}\n\n/* Sections\n   ========================================================================== */\n\n/**\n * Remove the margin in all browsers.\n */\n\nbody {\n  margin: 0;\n}\n\n/**\n * Render the `main` element consistently in IE.\n */\n\nmain {\n  display: block;\n}\n\n/**\n * Correct the font size and margin on `h1` elements within `section` and\n * `article` contexts in Chrome, Firefox, and Safari.\n */\n\nh1 {\n  font-size: 2em;\n  margin: 0.67em 0;\n}\n\n/* Grouping content\n   ========================================================================== */\n\n/**\n * 1. Add the correct box sizing in Firefox.\n * 2. Show the overflow in Edge and IE.\n */\n\nhr {\n  -webkit-box-sizing: content-box;\n          box-sizing: content-box; /* 1 */\n  height: 0; /* 1 */\n  overflow: visible; /* 2 */\n}\n\n/**\n * 1. Correct the inheritance and scaling of font size in all browsers.\n * 2. Correct the odd `em` font sizing in all browsers.\n */\n\npre {\n  font-family: monospace, monospace; /* 1 */\n  font-size: 1em; /* 2 */\n}\n\n/* Text-level semantics\n   ========================================================================== */\n\n/**\n * Remove the gray background on active links in IE 10.\n */\n\na {\n  background-color: transparent;\n}\n\n/**\n * 1. Remove the bottom border in Chrome 57-\n * 2. Add the correct text decoration in Chrome, Edge, IE, Opera, and Safari.\n */\n\nabbr[title] {\n  border-bottom: none; /* 1 */\n  text-decoration: underline; /* 2 */\n  -webkit-text-decoration: underline dotted;\n          text-decoration: underline dotted; /* 2 */\n}\n\n/**\n * Add the correct font weight in Chrome, Edge, and Safari.\n */\n\nb,\nstrong {\n  font-weight: bolder;\n}\n\n/**\n * 1. Correct the inheritance and scaling of font size in all browsers.\n * 2. Correct the odd `em` font sizing in all browsers.\n */\n\ncode,\nkbd,\nsamp {\n  font-family: monospace, monospace; /* 1 */\n  font-size: 1em; /* 2 */\n}\n\n/**\n * Add the correct font size in all browsers.\n */\n\nsmall {\n  font-size: 80%;\n}\n\n/**\n * Prevent `sub` and `sup` elements from affecting the line height in\n * all browsers.\n */\n\nsub,\nsup {\n  font-size: 75%;\n  line-height: 0;\n  position: relative;\n  vertical-align: baseline;\n}\n\nsub {\n  bottom: -0.25em;\n}\n\nsup {\n  top: -0.5em;\n}\n\n/* Embedded content\n   ========================================================================== */\n\n/**\n * Remove the border on images inside links in IE 10.\n */\n\nimg {\n  border-style: none;\n}\n\n/* Forms\n   ========================================================================== */\n\n/**\n * 1. Change the font styles in all browsers.\n * 2. Remove the margin in Firefox and Safari.\n */\n\nbutton,\ninput,\noptgroup,\nselect,\ntextarea {\n  font-family: inherit; /* 1 */\n  font-size: 100%; /* 1 */\n  line-height: 1.15; /* 1 */\n  margin: 0; /* 2 */\n}\n\n/**\n * Show the overflow in IE.\n * 1. Show the overflow in Edge.\n */\n\nbutton,\ninput { /* 1 */\n  overflow: visible;\n}\n\n/**\n * Remove the inheritance of text transform in Edge, Firefox, and IE.\n * 1. Remove the inheritance of text transform in Firefox.\n */\n\nbutton,\nselect { /* 1 */\n  text-transform: none;\n}\n\n/**\n * Correct the inability to style clickable types in iOS and Safari.\n */\n\nbutton,\n[type=\"button\"],\n[type=\"reset\"],\n[type=\"submit\"] {\n  -webkit-appearance: button;\n}\n\n/**\n * Remove the inner border and padding in Firefox.\n */\n\nbutton::-moz-focus-inner,\n[type=\"button\"]::-moz-focus-inner,\n[type=\"reset\"]::-moz-focus-inner,\n[type=\"submit\"]::-moz-focus-inner {\n  border-style: none;\n  padding: 0;\n}\n\n/**\n * Restore the focus styles unset by the previous rule.\n */\n\nbutton:-moz-focusring,\n[type=\"button\"]:-moz-focusring,\n[type=\"reset\"]:-moz-focusring,\n[type=\"submit\"]:-moz-focusring {\n  outline: 1px dotted ButtonText;\n}\n\n/**\n * Correct the padding in Firefox.\n */\n\nfieldset {\n  padding: 0.35em 0.75em 0.625em;\n}\n\n/**\n * 1. Correct the text wrapping in Edge and IE.\n * 2. Correct the color inheritance from `fieldset` elements in IE.\n * 3. Remove the padding so developers are not caught out when they zero out\n *    `fieldset` elements in all browsers.\n */\n\nlegend {\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box; /* 1 */\n  color: inherit; /* 2 */\n  display: table; /* 1 */\n  max-width: 100%; /* 1 */\n  padding: 0; /* 3 */\n  white-space: normal; /* 1 */\n}\n\n/**\n * Add the correct vertical alignment in Chrome, Firefox, and Opera.\n */\n\nprogress {\n  vertical-align: baseline;\n}\n\n/**\n * Remove the default vertical scrollbar in IE 10+.\n */\n\ntextarea {\n  overflow: auto;\n}\n\n/**\n * 1. Add the correct box sizing in IE 10.\n * 2. Remove the padding in IE 10.\n */\n\n[type=\"checkbox\"],\n[type=\"radio\"] {\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box; /* 1 */\n  padding: 0; /* 2 */\n}\n\n/**\n * Correct the cursor style of increment and decrement buttons in Chrome.\n */\n\n[type=\"number\"]::-webkit-inner-spin-button,\n[type=\"number\"]::-webkit-outer-spin-button {\n  height: auto;\n}\n\n/**\n * 1. Correct the odd appearance in Chrome and Safari.\n * 2. Correct the outline style in Safari.\n */\n\n[type=\"search\"] {\n  -webkit-appearance: textfield; /* 1 */\n  outline-offset: -2px; /* 2 */\n}\n\n/**\n * Remove the inner padding in Chrome and Safari on macOS.\n */\n\n[type=\"search\"]::-webkit-search-decoration {\n  -webkit-appearance: none;\n}\n\n/**\n * 1. Correct the inability to style clickable types in iOS and Safari.\n * 2. Change font properties to `inherit` in Safari.\n */\n\n::-webkit-file-upload-button {\n  -webkit-appearance: button; /* 1 */\n  font: inherit; /* 2 */\n}\n\n/* Interactive\n   ========================================================================== */\n\n/*\n * Add the correct display in Edge, IE 10+, and Firefox.\n */\n\ndetails {\n  display: block;\n}\n\n/*\n * Add the correct display in all browsers.\n */\n\nsummary {\n  display: list-item;\n}\n\n/* Misc\n   ========================================================================== */\n\n/**\n * Add the correct display in IE 10+.\n */\n\ntemplate {\n  display: none;\n}\n\n/**\n * Add the correct display in IE 10.\n */\n\n[hidden] {\n  display: none;\n}\n", "",{"version":3,"sources":["webpack://./node_modules/normalize.css/normalize.css"],"names":[],"mappings":"AAAA,2EAA2E;;AAE3E;+EAC+E;;AAE/E;;;EAGE;;AAEF;EACE,iBAAiB,EAAE,MAAM;EACzB,8BAA8B,EAAE,MAAM;AACxC;;AAEA;+EAC+E;;AAE/E;;EAEE;;AAEF;EACE,SAAS;AACX;;AAEA;;EAEE;;AAEF;EACE,cAAc;AAChB;;AAEA;;;EAGE;;AAEF;EACE,cAAc;EACd,gBAAgB;AAClB;;AAEA;+EAC+E;;AAE/E;;;EAGE;;AAEF;EACE,+BAAuB;UAAvB,uBAAuB,EAAE,MAAM;EAC/B,SAAS,EAAE,MAAM;EACjB,iBAAiB,EAAE,MAAM;AAC3B;;AAEA;;;EAGE;;AAEF;EACE,iCAAiC,EAAE,MAAM;EACzC,cAAc,EAAE,MAAM;AACxB;;AAEA;+EAC+E;;AAE/E;;EAEE;;AAEF;EACE,6BAA6B;AAC/B;;AAEA;;;EAGE;;AAEF;EACE,mBAAmB,EAAE,MAAM;EAC3B,0BAA0B,EAAE,MAAM;EAClC,yCAAiC;UAAjC,iCAAiC,EAAE,MAAM;AAC3C;;AAEA;;EAEE;;AAEF;;EAEE,mBAAmB;AACrB;;AAEA;;;EAGE;;AAEF;;;EAGE,iCAAiC,EAAE,MAAM;EACzC,cAAc,EAAE,MAAM;AACxB;;AAEA;;EAEE;;AAEF;EACE,cAAc;AAChB;;AAEA;;;EAGE;;AAEF;;EAEE,cAAc;EACd,cAAc;EACd,kBAAkB;EAClB,wBAAwB;AAC1B;;AAEA;EACE,eAAe;AACjB;;AAEA;EACE,WAAW;AACb;;AAEA;+EAC+E;;AAE/E;;EAEE;;AAEF;EACE,kBAAkB;AACpB;;AAEA;+EAC+E;;AAE/E;;;EAGE;;AAEF;;;;;EAKE,oBAAoB,EAAE,MAAM;EAC5B,eAAe,EAAE,MAAM;EACvB,iBAAiB,EAAE,MAAM;EACzB,SAAS,EAAE,MAAM;AACnB;;AAEA;;;EAGE;;AAEF;QACQ,MAAM;EACZ,iBAAiB;AACnB;;AAEA;;;EAGE;;AAEF;SACS,MAAM;EACb,oBAAoB;AACtB;;AAEA;;EAEE;;AAEF;;;;EAIE,0BAA0B;AAC5B;;AAEA;;EAEE;;AAEF;;;;EAIE,kBAAkB;EAClB,UAAU;AACZ;;AAEA;;EAEE;;AAEF;;;;EAIE,8BAA8B;AAChC;;AAEA;;EAEE;;AAEF;EACE,8BAA8B;AAChC;;AAEA;;;;;EAKE;;AAEF;EACE,8BAAsB;UAAtB,sBAAsB,EAAE,MAAM;EAC9B,cAAc,EAAE,MAAM;EACtB,cAAc,EAAE,MAAM;EACtB,eAAe,EAAE,MAAM;EACvB,UAAU,EAAE,MAAM;EAClB,mBAAmB,EAAE,MAAM;AAC7B;;AAEA;;EAEE;;AAEF;EACE,wBAAwB;AAC1B;;AAEA;;EAEE;;AAEF;EACE,cAAc;AAChB;;AAEA;;;EAGE;;AAEF;;EAEE,8BAAsB;UAAtB,sBAAsB,EAAE,MAAM;EAC9B,UAAU,EAAE,MAAM;AACpB;;AAEA;;EAEE;;AAEF;;EAEE,YAAY;AACd;;AAEA;;;EAGE;;AAEF;EACE,6BAA6B,EAAE,MAAM;EACrC,oBAAoB,EAAE,MAAM;AAC9B;;AAEA;;EAEE;;AAEF;EACE,wBAAwB;AAC1B;;AAEA;;;EAGE;;AAEF;EACE,0BAA0B,EAAE,MAAM;EAClC,aAAa,EAAE,MAAM;AACvB;;AAEA;+EAC+E;;AAE/E;;EAEE;;AAEF;EACE,cAAc;AAChB;;AAEA;;EAEE;;AAEF;EACE,kBAAkB;AACpB;;AAEA;+EAC+E;;AAE/E;;EAEE;;AAEF;EACE,aAAa;AACf;;AAEA;;EAEE;;AAEF;EACE,aAAa;AACf","sourcesContent":["/*! normalize.css v8.0.1 | MIT License | github.com/necolas/normalize.css */\n\n/* Document\n   ========================================================================== */\n\n/**\n * 1. Correct the line height in all browsers.\n * 2. Prevent adjustments of font size after orientation changes in iOS.\n */\n\nhtml {\n  line-height: 1.15; /* 1 */\n  -webkit-text-size-adjust: 100%; /* 2 */\n}\n\n/* Sections\n   ========================================================================== */\n\n/**\n * Remove the margin in all browsers.\n */\n\nbody {\n  margin: 0;\n}\n\n/**\n * Render the `main` element consistently in IE.\n */\n\nmain {\n  display: block;\n}\n\n/**\n * Correct the font size and margin on `h1` elements within `section` and\n * `article` contexts in Chrome, Firefox, and Safari.\n */\n\nh1 {\n  font-size: 2em;\n  margin: 0.67em 0;\n}\n\n/* Grouping content\n   ========================================================================== */\n\n/**\n * 1. Add the correct box sizing in Firefox.\n * 2. Show the overflow in Edge and IE.\n */\n\nhr {\n  box-sizing: content-box; /* 1 */\n  height: 0; /* 1 */\n  overflow: visible; /* 2 */\n}\n\n/**\n * 1. Correct the inheritance and scaling of font size in all browsers.\n * 2. Correct the odd `em` font sizing in all browsers.\n */\n\npre {\n  font-family: monospace, monospace; /* 1 */\n  font-size: 1em; /* 2 */\n}\n\n/* Text-level semantics\n   ========================================================================== */\n\n/**\n * Remove the gray background on active links in IE 10.\n */\n\na {\n  background-color: transparent;\n}\n\n/**\n * 1. Remove the bottom border in Chrome 57-\n * 2. Add the correct text decoration in Chrome, Edge, IE, Opera, and Safari.\n */\n\nabbr[title] {\n  border-bottom: none; /* 1 */\n  text-decoration: underline; /* 2 */\n  text-decoration: underline dotted; /* 2 */\n}\n\n/**\n * Add the correct font weight in Chrome, Edge, and Safari.\n */\n\nb,\nstrong {\n  font-weight: bolder;\n}\n\n/**\n * 1. Correct the inheritance and scaling of font size in all browsers.\n * 2. Correct the odd `em` font sizing in all browsers.\n */\n\ncode,\nkbd,\nsamp {\n  font-family: monospace, monospace; /* 1 */\n  font-size: 1em; /* 2 */\n}\n\n/**\n * Add the correct font size in all browsers.\n */\n\nsmall {\n  font-size: 80%;\n}\n\n/**\n * Prevent `sub` and `sup` elements from affecting the line height in\n * all browsers.\n */\n\nsub,\nsup {\n  font-size: 75%;\n  line-height: 0;\n  position: relative;\n  vertical-align: baseline;\n}\n\nsub {\n  bottom: -0.25em;\n}\n\nsup {\n  top: -0.5em;\n}\n\n/* Embedded content\n   ========================================================================== */\n\n/**\n * Remove the border on images inside links in IE 10.\n */\n\nimg {\n  border-style: none;\n}\n\n/* Forms\n   ========================================================================== */\n\n/**\n * 1. Change the font styles in all browsers.\n * 2. Remove the margin in Firefox and Safari.\n */\n\nbutton,\ninput,\noptgroup,\nselect,\ntextarea {\n  font-family: inherit; /* 1 */\n  font-size: 100%; /* 1 */\n  line-height: 1.15; /* 1 */\n  margin: 0; /* 2 */\n}\n\n/**\n * Show the overflow in IE.\n * 1. Show the overflow in Edge.\n */\n\nbutton,\ninput { /* 1 */\n  overflow: visible;\n}\n\n/**\n * Remove the inheritance of text transform in Edge, Firefox, and IE.\n * 1. Remove the inheritance of text transform in Firefox.\n */\n\nbutton,\nselect { /* 1 */\n  text-transform: none;\n}\n\n/**\n * Correct the inability to style clickable types in iOS and Safari.\n */\n\nbutton,\n[type=\"button\"],\n[type=\"reset\"],\n[type=\"submit\"] {\n  -webkit-appearance: button;\n}\n\n/**\n * Remove the inner border and padding in Firefox.\n */\n\nbutton::-moz-focus-inner,\n[type=\"button\"]::-moz-focus-inner,\n[type=\"reset\"]::-moz-focus-inner,\n[type=\"submit\"]::-moz-focus-inner {\n  border-style: none;\n  padding: 0;\n}\n\n/**\n * Restore the focus styles unset by the previous rule.\n */\n\nbutton:-moz-focusring,\n[type=\"button\"]:-moz-focusring,\n[type=\"reset\"]:-moz-focusring,\n[type=\"submit\"]:-moz-focusring {\n  outline: 1px dotted ButtonText;\n}\n\n/**\n * Correct the padding in Firefox.\n */\n\nfieldset {\n  padding: 0.35em 0.75em 0.625em;\n}\n\n/**\n * 1. Correct the text wrapping in Edge and IE.\n * 2. Correct the color inheritance from `fieldset` elements in IE.\n * 3. Remove the padding so developers are not caught out when they zero out\n *    `fieldset` elements in all browsers.\n */\n\nlegend {\n  box-sizing: border-box; /* 1 */\n  color: inherit; /* 2 */\n  display: table; /* 1 */\n  max-width: 100%; /* 1 */\n  padding: 0; /* 3 */\n  white-space: normal; /* 1 */\n}\n\n/**\n * Add the correct vertical alignment in Chrome, Firefox, and Opera.\n */\n\nprogress {\n  vertical-align: baseline;\n}\n\n/**\n * Remove the default vertical scrollbar in IE 10+.\n */\n\ntextarea {\n  overflow: auto;\n}\n\n/**\n * 1. Add the correct box sizing in IE 10.\n * 2. Remove the padding in IE 10.\n */\n\n[type=\"checkbox\"],\n[type=\"radio\"] {\n  box-sizing: border-box; /* 1 */\n  padding: 0; /* 2 */\n}\n\n/**\n * Correct the cursor style of increment and decrement buttons in Chrome.\n */\n\n[type=\"number\"]::-webkit-inner-spin-button,\n[type=\"number\"]::-webkit-outer-spin-button {\n  height: auto;\n}\n\n/**\n * 1. Correct the odd appearance in Chrome and Safari.\n * 2. Correct the outline style in Safari.\n */\n\n[type=\"search\"] {\n  -webkit-appearance: textfield; /* 1 */\n  outline-offset: -2px; /* 2 */\n}\n\n/**\n * Remove the inner padding in Chrome and Safari on macOS.\n */\n\n[type=\"search\"]::-webkit-search-decoration {\n  -webkit-appearance: none;\n}\n\n/**\n * 1. Correct the inability to style clickable types in iOS and Safari.\n * 2. Change font properties to `inherit` in Safari.\n */\n\n::-webkit-file-upload-button {\n  -webkit-appearance: button; /* 1 */\n  font: inherit; /* 2 */\n}\n\n/* Interactive\n   ========================================================================== */\n\n/*\n * Add the correct display in Edge, IE 10+, and Firefox.\n */\n\ndetails {\n  display: block;\n}\n\n/*\n * Add the correct display in all browsers.\n */\n\nsummary {\n  display: list-item;\n}\n\n/* Misc\n   ========================================================================== */\n\n/**\n * Add the correct display in IE 10+.\n */\n\ntemplate {\n  display: none;\n}\n\n/**\n * Add the correct display in IE 10.\n */\n\n[hidden] {\n  display: none;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/react-toastify/dist/ReactToastify.css":
/*!************************************************************!*\
  !*** ./node_modules/react-toastify/dist/ReactToastify.css ***!
  \************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ":root {\n  --toastify-color-light: #fff;\n  --toastify-color-dark: #121212;\n  --toastify-color-info: #3498db;\n  --toastify-color-success: #07bc0c;\n  --toastify-color-warning: #f1c40f;\n  --toastify-color-error: #e74c3c;\n  --toastify-color-transparent: rgba(255, 255, 255, 0.7);\n  --toastify-icon-color-info: var(--toastify-color-info);\n  --toastify-icon-color-success: var(--toastify-color-success);\n  --toastify-icon-color-warning: var(--toastify-color-warning);\n  --toastify-icon-color-error: var(--toastify-color-error);\n  --toastify-toast-width: 320px;\n  --toastify-toast-background: #fff;\n  --toastify-toast-min-height: 64px;\n  --toastify-toast-max-height: 800px;\n  --toastify-font-family: sans-serif;\n  --toastify-z-index: 9999;\n  --toastify-text-color-light: #757575;\n  --toastify-text-color-dark: #fff;\n  --toastify-text-color-info: #fff;\n  --toastify-text-color-success: #fff;\n  --toastify-text-color-warning: #fff;\n  --toastify-text-color-error: #fff;\n  --toastify-spinner-color: #616161;\n  --toastify-spinner-color-empty-area: #e0e0e0;\n  --toastify-color-progress-light: linear-gradient(\n    to right,\n    #4cd964,\n    #5ac8fa,\n    #007aff,\n    #34aadc,\n    #5856d6,\n    #ff2d55\n  );\n  --toastify-color-progress-dark: #bb86fc;\n  --toastify-color-progress-info: var(--toastify-color-info);\n  --toastify-color-progress-success: var(--toastify-color-success);\n  --toastify-color-progress-warning: var(--toastify-color-warning);\n  --toastify-color-progress-error: var(--toastify-color-error);\n}\n\n.Toastify__toast-container {\n  z-index: var(--toastify-z-index);\n  -webkit-transform: translate3d(0, 0, var(--toastify-z-index) px);\n  position: fixed;\n  padding: 4px;\n  width: var(--toastify-toast-width);\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  color: #fff;\n}\n.Toastify__toast-container--top-left {\n  top: 1em;\n  left: 1em;\n}\n.Toastify__toast-container--top-center {\n  top: 1em;\n  left: 50%;\n  -webkit-transform: translateX(-50%);\n          transform: translateX(-50%);\n}\n.Toastify__toast-container--top-right {\n  top: 1em;\n  right: 1em;\n}\n.Toastify__toast-container--bottom-left {\n  bottom: 1em;\n  left: 1em;\n}\n.Toastify__toast-container--bottom-center {\n  bottom: 1em;\n  left: 50%;\n  -webkit-transform: translateX(-50%);\n          transform: translateX(-50%);\n}\n.Toastify__toast-container--bottom-right {\n  bottom: 1em;\n  right: 1em;\n}\n\n@media only screen and (max-width : 480px) {\n  .Toastify__toast-container {\n    width: 100vw;\n    padding: 0;\n    left: 0;\n    margin: 0;\n  }\n  .Toastify__toast-container--top-left, .Toastify__toast-container--top-center, .Toastify__toast-container--top-right {\n    top: 0;\n    -webkit-transform: translateX(0);\n            transform: translateX(0);\n  }\n  .Toastify__toast-container--bottom-left, .Toastify__toast-container--bottom-center, .Toastify__toast-container--bottom-right {\n    bottom: 0;\n    -webkit-transform: translateX(0);\n            transform: translateX(0);\n  }\n  .Toastify__toast-container--rtl {\n    right: 0;\n    left: initial;\n  }\n}\n.Toastify__toast {\n  position: relative;\n  min-height: var(--toastify-toast-min-height);\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  margin-bottom: 1rem;\n  padding: 8px;\n  border-radius: 4px;\n  -webkit-box-shadow: 0 1px 10px 0 rgba(0, 0, 0, 0.1), 0 2px 15px 0 rgba(0, 0, 0, 0.05);\n          box-shadow: 0 1px 10px 0 rgba(0, 0, 0, 0.1), 0 2px 15px 0 rgba(0, 0, 0, 0.05);\n  display: -ms-flexbox;\n  display: -webkit-box;\n  display: flex;\n  -ms-flex-pack: justify;\n      -webkit-box-pack: justify;\n          justify-content: space-between;\n  max-height: var(--toastify-toast-max-height);\n  overflow: hidden;\n  font-family: var(--toastify-font-family);\n  cursor: pointer;\n  direction: ltr;\n}\n.Toastify__toast--rtl {\n  direction: rtl;\n}\n.Toastify__toast-body {\n  margin: auto 0;\n  -ms-flex: 1 1 auto;\n      -webkit-box-flex: 1;\n          flex: 1 1 auto;\n  padding: 6px;\n  display: -ms-flexbox;\n  display: -webkit-box;\n  display: flex;\n  -ms-flex-align: center;\n      -webkit-box-align: center;\n          align-items: center;\n}\n.Toastify__toast-body > div:last-child {\n  -ms-flex: 1;\n      -webkit-box-flex: 1;\n          flex: 1;\n}\n.Toastify__toast-icon {\n  -webkit-margin-end: 10px;\n          margin-inline-end: 10px;\n  width: 20px;\n  -ms-flex-negative: 0;\n      flex-shrink: 0;\n  display: -ms-flexbox;\n  display: -webkit-box;\n  display: flex;\n}\n\n.Toastify--animate {\n  -webkit-animation-fill-mode: both;\n          animation-fill-mode: both;\n  -webkit-animation-duration: 0.7s;\n          animation-duration: 0.7s;\n}\n\n.Toastify--animate-icon {\n  -webkit-animation-fill-mode: both;\n          animation-fill-mode: both;\n  -webkit-animation-duration: 0.3s;\n          animation-duration: 0.3s;\n}\n\n@media only screen and (max-width : 480px) {\n  .Toastify__toast {\n    margin-bottom: 0;\n    border-radius: 0;\n  }\n}\n.Toastify__toast-theme--dark {\n  background: var(--toastify-color-dark);\n  color: var(--toastify-text-color-dark);\n}\n.Toastify__toast-theme--light {\n  background: var(--toastify-color-light);\n  color: var(--toastify-text-color-light);\n}\n.Toastify__toast-theme--colored.Toastify__toast--default {\n  background: var(--toastify-color-light);\n  color: var(--toastify-text-color-light);\n}\n.Toastify__toast-theme--colored.Toastify__toast--info {\n  color: var(--toastify-text-color-info);\n  background: var(--toastify-color-info);\n}\n.Toastify__toast-theme--colored.Toastify__toast--success {\n  color: var(--toastify-text-color-success);\n  background: var(--toastify-color-success);\n}\n.Toastify__toast-theme--colored.Toastify__toast--warning {\n  color: var(--toastify-text-color-warning);\n  background: var(--toastify-color-warning);\n}\n.Toastify__toast-theme--colored.Toastify__toast--error {\n  color: var(--toastify-text-color-error);\n  background: var(--toastify-color-error);\n}\n\n.Toastify__progress-bar-theme--light {\n  background: var(--toastify-color-progress-light);\n}\n.Toastify__progress-bar-theme--dark {\n  background: var(--toastify-color-progress-dark);\n}\n.Toastify__progress-bar--info {\n  background: var(--toastify-color-progress-info);\n}\n.Toastify__progress-bar--success {\n  background: var(--toastify-color-progress-success);\n}\n.Toastify__progress-bar--warning {\n  background: var(--toastify-color-progress-warning);\n}\n.Toastify__progress-bar--error {\n  background: var(--toastify-color-progress-error);\n}\n.Toastify__progress-bar-theme--colored.Toastify__progress-bar--info, .Toastify__progress-bar-theme--colored.Toastify__progress-bar--success, .Toastify__progress-bar-theme--colored.Toastify__progress-bar--warning, .Toastify__progress-bar-theme--colored.Toastify__progress-bar--error {\n  background: var(--toastify-color-transparent);\n}\n\n.Toastify__close-button {\n  color: #fff;\n  background: transparent;\n  outline: none;\n  border: none;\n  padding: 0;\n  cursor: pointer;\n  opacity: 0.7;\n  -webkit-transition: 0.3s ease;\n  transition: 0.3s ease;\n  -ms-flex-item-align: start;\n      align-self: flex-start;\n}\n.Toastify__close-button--light {\n  color: #000;\n  opacity: 0.3;\n}\n.Toastify__close-button > svg {\n  fill: currentColor;\n  height: 16px;\n  width: 14px;\n}\n.Toastify__close-button:hover, .Toastify__close-button:focus {\n  opacity: 1;\n}\n\n@-webkit-keyframes Toastify__trackProgress {\n  0% {\n    -webkit-transform: scaleX(1);\n            transform: scaleX(1);\n  }\n  100% {\n    -webkit-transform: scaleX(0);\n            transform: scaleX(0);\n  }\n}\n\n@keyframes Toastify__trackProgress {\n  0% {\n    -webkit-transform: scaleX(1);\n            transform: scaleX(1);\n  }\n  100% {\n    -webkit-transform: scaleX(0);\n            transform: scaleX(0);\n  }\n}\n.Toastify__progress-bar {\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  width: 100%;\n  height: 5px;\n  z-index: var(--toastify-z-index);\n  opacity: 0.7;\n  -webkit-transform-origin: left;\n          transform-origin: left;\n}\n.Toastify__progress-bar--animated {\n  -webkit-animation: Toastify__trackProgress linear 1 forwards;\n          animation: Toastify__trackProgress linear 1 forwards;\n}\n.Toastify__progress-bar--controlled {\n  -webkit-transition: -webkit-transform 0.2s;\n  transition: -webkit-transform 0.2s;\n  transition: transform 0.2s;\n  transition: transform 0.2s, -webkit-transform 0.2s;\n}\n.Toastify__progress-bar--rtl {\n  right: 0;\n  left: initial;\n  -webkit-transform-origin: right;\n          transform-origin: right;\n}\n\n.Toastify__spinner {\n  width: 20px;\n  height: 20px;\n  -webkit-box-sizing: border-box;\n          box-sizing: border-box;\n  border: 2px solid;\n  border-radius: 100%;\n  border-color: var(--toastify-spinner-color-empty-area);\n  border-right-color: var(--toastify-spinner-color);\n  -webkit-animation: Toastify__spin 0.65s linear infinite;\n          animation: Toastify__spin 0.65s linear infinite;\n}\n\n@-webkit-keyframes Toastify__bounceInRight {\n  from, 60%, 75%, 90%, to {\n    -webkit-animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);\n            animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);\n  }\n  from {\n    opacity: 0;\n    -webkit-transform: translate3d(3000px, 0, 0);\n            transform: translate3d(3000px, 0, 0);\n  }\n  60% {\n    opacity: 1;\n    -webkit-transform: translate3d(-25px, 0, 0);\n            transform: translate3d(-25px, 0, 0);\n  }\n  75% {\n    -webkit-transform: translate3d(10px, 0, 0);\n            transform: translate3d(10px, 0, 0);\n  }\n  90% {\n    -webkit-transform: translate3d(-5px, 0, 0);\n            transform: translate3d(-5px, 0, 0);\n  }\n  to {\n    -webkit-transform: none;\n            transform: none;\n  }\n}\n\n@keyframes Toastify__bounceInRight {\n  from, 60%, 75%, 90%, to {\n    -webkit-animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);\n            animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);\n  }\n  from {\n    opacity: 0;\n    -webkit-transform: translate3d(3000px, 0, 0);\n            transform: translate3d(3000px, 0, 0);\n  }\n  60% {\n    opacity: 1;\n    -webkit-transform: translate3d(-25px, 0, 0);\n            transform: translate3d(-25px, 0, 0);\n  }\n  75% {\n    -webkit-transform: translate3d(10px, 0, 0);\n            transform: translate3d(10px, 0, 0);\n  }\n  90% {\n    -webkit-transform: translate3d(-5px, 0, 0);\n            transform: translate3d(-5px, 0, 0);\n  }\n  to {\n    -webkit-transform: none;\n            transform: none;\n  }\n}\n@-webkit-keyframes Toastify__bounceOutRight {\n  20% {\n    opacity: 1;\n    -webkit-transform: translate3d(-20px, 0, 0);\n            transform: translate3d(-20px, 0, 0);\n  }\n  to {\n    opacity: 0;\n    -webkit-transform: translate3d(2000px, 0, 0);\n            transform: translate3d(2000px, 0, 0);\n  }\n}\n@keyframes Toastify__bounceOutRight {\n  20% {\n    opacity: 1;\n    -webkit-transform: translate3d(-20px, 0, 0);\n            transform: translate3d(-20px, 0, 0);\n  }\n  to {\n    opacity: 0;\n    -webkit-transform: translate3d(2000px, 0, 0);\n            transform: translate3d(2000px, 0, 0);\n  }\n}\n@-webkit-keyframes Toastify__bounceInLeft {\n  from, 60%, 75%, 90%, to {\n    -webkit-animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);\n            animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);\n  }\n  0% {\n    opacity: 0;\n    -webkit-transform: translate3d(-3000px, 0, 0);\n            transform: translate3d(-3000px, 0, 0);\n  }\n  60% {\n    opacity: 1;\n    -webkit-transform: translate3d(25px, 0, 0);\n            transform: translate3d(25px, 0, 0);\n  }\n  75% {\n    -webkit-transform: translate3d(-10px, 0, 0);\n            transform: translate3d(-10px, 0, 0);\n  }\n  90% {\n    -webkit-transform: translate3d(5px, 0, 0);\n            transform: translate3d(5px, 0, 0);\n  }\n  to {\n    -webkit-transform: none;\n            transform: none;\n  }\n}\n@keyframes Toastify__bounceInLeft {\n  from, 60%, 75%, 90%, to {\n    -webkit-animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);\n            animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);\n  }\n  0% {\n    opacity: 0;\n    -webkit-transform: translate3d(-3000px, 0, 0);\n            transform: translate3d(-3000px, 0, 0);\n  }\n  60% {\n    opacity: 1;\n    -webkit-transform: translate3d(25px, 0, 0);\n            transform: translate3d(25px, 0, 0);\n  }\n  75% {\n    -webkit-transform: translate3d(-10px, 0, 0);\n            transform: translate3d(-10px, 0, 0);\n  }\n  90% {\n    -webkit-transform: translate3d(5px, 0, 0);\n            transform: translate3d(5px, 0, 0);\n  }\n  to {\n    -webkit-transform: none;\n            transform: none;\n  }\n}\n@-webkit-keyframes Toastify__bounceOutLeft {\n  20% {\n    opacity: 1;\n    -webkit-transform: translate3d(20px, 0, 0);\n            transform: translate3d(20px, 0, 0);\n  }\n  to {\n    opacity: 0;\n    -webkit-transform: translate3d(-2000px, 0, 0);\n            transform: translate3d(-2000px, 0, 0);\n  }\n}\n@keyframes Toastify__bounceOutLeft {\n  20% {\n    opacity: 1;\n    -webkit-transform: translate3d(20px, 0, 0);\n            transform: translate3d(20px, 0, 0);\n  }\n  to {\n    opacity: 0;\n    -webkit-transform: translate3d(-2000px, 0, 0);\n            transform: translate3d(-2000px, 0, 0);\n  }\n}\n@-webkit-keyframes Toastify__bounceInUp {\n  from, 60%, 75%, 90%, to {\n    -webkit-animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);\n            animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);\n  }\n  from {\n    opacity: 0;\n    -webkit-transform: translate3d(0, 3000px, 0);\n            transform: translate3d(0, 3000px, 0);\n  }\n  60% {\n    opacity: 1;\n    -webkit-transform: translate3d(0, -20px, 0);\n            transform: translate3d(0, -20px, 0);\n  }\n  75% {\n    -webkit-transform: translate3d(0, 10px, 0);\n            transform: translate3d(0, 10px, 0);\n  }\n  90% {\n    -webkit-transform: translate3d(0, -5px, 0);\n            transform: translate3d(0, -5px, 0);\n  }\n  to {\n    -webkit-transform: translate3d(0, 0, 0);\n            transform: translate3d(0, 0, 0);\n  }\n}\n@keyframes Toastify__bounceInUp {\n  from, 60%, 75%, 90%, to {\n    -webkit-animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);\n            animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);\n  }\n  from {\n    opacity: 0;\n    -webkit-transform: translate3d(0, 3000px, 0);\n            transform: translate3d(0, 3000px, 0);\n  }\n  60% {\n    opacity: 1;\n    -webkit-transform: translate3d(0, -20px, 0);\n            transform: translate3d(0, -20px, 0);\n  }\n  75% {\n    -webkit-transform: translate3d(0, 10px, 0);\n            transform: translate3d(0, 10px, 0);\n  }\n  90% {\n    -webkit-transform: translate3d(0, -5px, 0);\n            transform: translate3d(0, -5px, 0);\n  }\n  to {\n    -webkit-transform: translate3d(0, 0, 0);\n            transform: translate3d(0, 0, 0);\n  }\n}\n@-webkit-keyframes Toastify__bounceOutUp {\n  20% {\n    -webkit-transform: translate3d(0, -10px, 0);\n            transform: translate3d(0, -10px, 0);\n  }\n  40%, 45% {\n    opacity: 1;\n    -webkit-transform: translate3d(0, 20px, 0);\n            transform: translate3d(0, 20px, 0);\n  }\n  to {\n    opacity: 0;\n    -webkit-transform: translate3d(0, -2000px, 0);\n            transform: translate3d(0, -2000px, 0);\n  }\n}\n@keyframes Toastify__bounceOutUp {\n  20% {\n    -webkit-transform: translate3d(0, -10px, 0);\n            transform: translate3d(0, -10px, 0);\n  }\n  40%, 45% {\n    opacity: 1;\n    -webkit-transform: translate3d(0, 20px, 0);\n            transform: translate3d(0, 20px, 0);\n  }\n  to {\n    opacity: 0;\n    -webkit-transform: translate3d(0, -2000px, 0);\n            transform: translate3d(0, -2000px, 0);\n  }\n}\n@-webkit-keyframes Toastify__bounceInDown {\n  from, 60%, 75%, 90%, to {\n    -webkit-animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);\n            animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);\n  }\n  0% {\n    opacity: 0;\n    -webkit-transform: translate3d(0, -3000px, 0);\n            transform: translate3d(0, -3000px, 0);\n  }\n  60% {\n    opacity: 1;\n    -webkit-transform: translate3d(0, 25px, 0);\n            transform: translate3d(0, 25px, 0);\n  }\n  75% {\n    -webkit-transform: translate3d(0, -10px, 0);\n            transform: translate3d(0, -10px, 0);\n  }\n  90% {\n    -webkit-transform: translate3d(0, 5px, 0);\n            transform: translate3d(0, 5px, 0);\n  }\n  to {\n    -webkit-transform: none;\n            transform: none;\n  }\n}\n@keyframes Toastify__bounceInDown {\n  from, 60%, 75%, 90%, to {\n    -webkit-animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);\n            animation-timing-function: cubic-bezier(0.215, 0.61, 0.355, 1);\n  }\n  0% {\n    opacity: 0;\n    -webkit-transform: translate3d(0, -3000px, 0);\n            transform: translate3d(0, -3000px, 0);\n  }\n  60% {\n    opacity: 1;\n    -webkit-transform: translate3d(0, 25px, 0);\n            transform: translate3d(0, 25px, 0);\n  }\n  75% {\n    -webkit-transform: translate3d(0, -10px, 0);\n            transform: translate3d(0, -10px, 0);\n  }\n  90% {\n    -webkit-transform: translate3d(0, 5px, 0);\n            transform: translate3d(0, 5px, 0);\n  }\n  to {\n    -webkit-transform: none;\n            transform: none;\n  }\n}\n@-webkit-keyframes Toastify__bounceOutDown {\n  20% {\n    -webkit-transform: translate3d(0, 10px, 0);\n            transform: translate3d(0, 10px, 0);\n  }\n  40%, 45% {\n    opacity: 1;\n    -webkit-transform: translate3d(0, -20px, 0);\n            transform: translate3d(0, -20px, 0);\n  }\n  to {\n    opacity: 0;\n    -webkit-transform: translate3d(0, 2000px, 0);\n            transform: translate3d(0, 2000px, 0);\n  }\n}\n@keyframes Toastify__bounceOutDown {\n  20% {\n    -webkit-transform: translate3d(0, 10px, 0);\n            transform: translate3d(0, 10px, 0);\n  }\n  40%, 45% {\n    opacity: 1;\n    -webkit-transform: translate3d(0, -20px, 0);\n            transform: translate3d(0, -20px, 0);\n  }\n  to {\n    opacity: 0;\n    -webkit-transform: translate3d(0, 2000px, 0);\n            transform: translate3d(0, 2000px, 0);\n  }\n}\n.Toastify__bounce-enter--top-left, .Toastify__bounce-enter--bottom-left {\n  -webkit-animation-name: Toastify__bounceInLeft;\n          animation-name: Toastify__bounceInLeft;\n}\n.Toastify__bounce-enter--top-right, .Toastify__bounce-enter--bottom-right {\n  -webkit-animation-name: Toastify__bounceInRight;\n          animation-name: Toastify__bounceInRight;\n}\n.Toastify__bounce-enter--top-center {\n  -webkit-animation-name: Toastify__bounceInDown;\n          animation-name: Toastify__bounceInDown;\n}\n.Toastify__bounce-enter--bottom-center {\n  -webkit-animation-name: Toastify__bounceInUp;\n          animation-name: Toastify__bounceInUp;\n}\n\n.Toastify__bounce-exit--top-left, .Toastify__bounce-exit--bottom-left {\n  -webkit-animation-name: Toastify__bounceOutLeft;\n          animation-name: Toastify__bounceOutLeft;\n}\n.Toastify__bounce-exit--top-right, .Toastify__bounce-exit--bottom-right {\n  -webkit-animation-name: Toastify__bounceOutRight;\n          animation-name: Toastify__bounceOutRight;\n}\n.Toastify__bounce-exit--top-center {\n  -webkit-animation-name: Toastify__bounceOutUp;\n          animation-name: Toastify__bounceOutUp;\n}\n.Toastify__bounce-exit--bottom-center {\n  -webkit-animation-name: Toastify__bounceOutDown;\n          animation-name: Toastify__bounceOutDown;\n}\n\n@-webkit-keyframes Toastify__zoomIn {\n  from {\n    opacity: 0;\n    -webkit-transform: scale3d(0.3, 0.3, 0.3);\n            transform: scale3d(0.3, 0.3, 0.3);\n  }\n  50% {\n    opacity: 1;\n  }\n}\n\n@keyframes Toastify__zoomIn {\n  from {\n    opacity: 0;\n    -webkit-transform: scale3d(0.3, 0.3, 0.3);\n            transform: scale3d(0.3, 0.3, 0.3);\n  }\n  50% {\n    opacity: 1;\n  }\n}\n@-webkit-keyframes Toastify__zoomOut {\n  from {\n    opacity: 1;\n  }\n  50% {\n    opacity: 0;\n    -webkit-transform: scale3d(0.3, 0.3, 0.3);\n            transform: scale3d(0.3, 0.3, 0.3);\n  }\n  to {\n    opacity: 0;\n  }\n}\n@keyframes Toastify__zoomOut {\n  from {\n    opacity: 1;\n  }\n  50% {\n    opacity: 0;\n    -webkit-transform: scale3d(0.3, 0.3, 0.3);\n            transform: scale3d(0.3, 0.3, 0.3);\n  }\n  to {\n    opacity: 0;\n  }\n}\n.Toastify__zoom-enter {\n  -webkit-animation-name: Toastify__zoomIn;\n          animation-name: Toastify__zoomIn;\n}\n\n.Toastify__zoom-exit {\n  -webkit-animation-name: Toastify__zoomOut;\n          animation-name: Toastify__zoomOut;\n}\n\n@-webkit-keyframes Toastify__flipIn {\n  from {\n    -webkit-transform: perspective(400px) rotate3d(1, 0, 0, 90deg);\n            transform: perspective(400px) rotate3d(1, 0, 0, 90deg);\n    -webkit-animation-timing-function: ease-in;\n            animation-timing-function: ease-in;\n    opacity: 0;\n  }\n  40% {\n    -webkit-transform: perspective(400px) rotate3d(1, 0, 0, -20deg);\n            transform: perspective(400px) rotate3d(1, 0, 0, -20deg);\n    -webkit-animation-timing-function: ease-in;\n            animation-timing-function: ease-in;\n  }\n  60% {\n    -webkit-transform: perspective(400px) rotate3d(1, 0, 0, 10deg);\n            transform: perspective(400px) rotate3d(1, 0, 0, 10deg);\n    opacity: 1;\n  }\n  80% {\n    -webkit-transform: perspective(400px) rotate3d(1, 0, 0, -5deg);\n            transform: perspective(400px) rotate3d(1, 0, 0, -5deg);\n  }\n  to {\n    -webkit-transform: perspective(400px);\n            transform: perspective(400px);\n  }\n}\n\n@keyframes Toastify__flipIn {\n  from {\n    -webkit-transform: perspective(400px) rotate3d(1, 0, 0, 90deg);\n            transform: perspective(400px) rotate3d(1, 0, 0, 90deg);\n    -webkit-animation-timing-function: ease-in;\n            animation-timing-function: ease-in;\n    opacity: 0;\n  }\n  40% {\n    -webkit-transform: perspective(400px) rotate3d(1, 0, 0, -20deg);\n            transform: perspective(400px) rotate3d(1, 0, 0, -20deg);\n    -webkit-animation-timing-function: ease-in;\n            animation-timing-function: ease-in;\n  }\n  60% {\n    -webkit-transform: perspective(400px) rotate3d(1, 0, 0, 10deg);\n            transform: perspective(400px) rotate3d(1, 0, 0, 10deg);\n    opacity: 1;\n  }\n  80% {\n    -webkit-transform: perspective(400px) rotate3d(1, 0, 0, -5deg);\n            transform: perspective(400px) rotate3d(1, 0, 0, -5deg);\n  }\n  to {\n    -webkit-transform: perspective(400px);\n            transform: perspective(400px);\n  }\n}\n@-webkit-keyframes Toastify__flipOut {\n  from {\n    -webkit-transform: perspective(400px);\n            transform: perspective(400px);\n  }\n  30% {\n    -webkit-transform: perspective(400px) rotate3d(1, 0, 0, -20deg);\n            transform: perspective(400px) rotate3d(1, 0, 0, -20deg);\n    opacity: 1;\n  }\n  to {\n    -webkit-transform: perspective(400px) rotate3d(1, 0, 0, 90deg);\n            transform: perspective(400px) rotate3d(1, 0, 0, 90deg);\n    opacity: 0;\n  }\n}\n@keyframes Toastify__flipOut {\n  from {\n    -webkit-transform: perspective(400px);\n            transform: perspective(400px);\n  }\n  30% {\n    -webkit-transform: perspective(400px) rotate3d(1, 0, 0, -20deg);\n            transform: perspective(400px) rotate3d(1, 0, 0, -20deg);\n    opacity: 1;\n  }\n  to {\n    -webkit-transform: perspective(400px) rotate3d(1, 0, 0, 90deg);\n            transform: perspective(400px) rotate3d(1, 0, 0, 90deg);\n    opacity: 0;\n  }\n}\n.Toastify__flip-enter {\n  -webkit-animation-name: Toastify__flipIn;\n          animation-name: Toastify__flipIn;\n}\n\n.Toastify__flip-exit {\n  -webkit-animation-name: Toastify__flipOut;\n          animation-name: Toastify__flipOut;\n}\n\n@-webkit-keyframes Toastify__slideInRight {\n  from {\n    -webkit-transform: translate3d(110%, 0, 0);\n            transform: translate3d(110%, 0, 0);\n    visibility: visible;\n  }\n  to {\n    -webkit-transform: translate3d(0, 0, 0);\n            transform: translate3d(0, 0, 0);\n  }\n}\n\n@keyframes Toastify__slideInRight {\n  from {\n    -webkit-transform: translate3d(110%, 0, 0);\n            transform: translate3d(110%, 0, 0);\n    visibility: visible;\n  }\n  to {\n    -webkit-transform: translate3d(0, 0, 0);\n            transform: translate3d(0, 0, 0);\n  }\n}\n@-webkit-keyframes Toastify__slideInLeft {\n  from {\n    -webkit-transform: translate3d(-110%, 0, 0);\n            transform: translate3d(-110%, 0, 0);\n    visibility: visible;\n  }\n  to {\n    -webkit-transform: translate3d(0, 0, 0);\n            transform: translate3d(0, 0, 0);\n  }\n}\n@keyframes Toastify__slideInLeft {\n  from {\n    -webkit-transform: translate3d(-110%, 0, 0);\n            transform: translate3d(-110%, 0, 0);\n    visibility: visible;\n  }\n  to {\n    -webkit-transform: translate3d(0, 0, 0);\n            transform: translate3d(0, 0, 0);\n  }\n}\n@-webkit-keyframes Toastify__slideInUp {\n  from {\n    -webkit-transform: translate3d(0, 110%, 0);\n            transform: translate3d(0, 110%, 0);\n    visibility: visible;\n  }\n  to {\n    -webkit-transform: translate3d(0, 0, 0);\n            transform: translate3d(0, 0, 0);\n  }\n}\n@keyframes Toastify__slideInUp {\n  from {\n    -webkit-transform: translate3d(0, 110%, 0);\n            transform: translate3d(0, 110%, 0);\n    visibility: visible;\n  }\n  to {\n    -webkit-transform: translate3d(0, 0, 0);\n            transform: translate3d(0, 0, 0);\n  }\n}\n@-webkit-keyframes Toastify__slideInDown {\n  from {\n    -webkit-transform: translate3d(0, -110%, 0);\n            transform: translate3d(0, -110%, 0);\n    visibility: visible;\n  }\n  to {\n    -webkit-transform: translate3d(0, 0, 0);\n            transform: translate3d(0, 0, 0);\n  }\n}\n@keyframes Toastify__slideInDown {\n  from {\n    -webkit-transform: translate3d(0, -110%, 0);\n            transform: translate3d(0, -110%, 0);\n    visibility: visible;\n  }\n  to {\n    -webkit-transform: translate3d(0, 0, 0);\n            transform: translate3d(0, 0, 0);\n  }\n}\n@-webkit-keyframes Toastify__slideOutRight {\n  from {\n    -webkit-transform: translate3d(0, 0, 0);\n            transform: translate3d(0, 0, 0);\n  }\n  to {\n    visibility: hidden;\n    -webkit-transform: translate3d(110%, 0, 0);\n            transform: translate3d(110%, 0, 0);\n  }\n}\n@keyframes Toastify__slideOutRight {\n  from {\n    -webkit-transform: translate3d(0, 0, 0);\n            transform: translate3d(0, 0, 0);\n  }\n  to {\n    visibility: hidden;\n    -webkit-transform: translate3d(110%, 0, 0);\n            transform: translate3d(110%, 0, 0);\n  }\n}\n@-webkit-keyframes Toastify__slideOutLeft {\n  from {\n    -webkit-transform: translate3d(0, 0, 0);\n            transform: translate3d(0, 0, 0);\n  }\n  to {\n    visibility: hidden;\n    -webkit-transform: translate3d(-110%, 0, 0);\n            transform: translate3d(-110%, 0, 0);\n  }\n}\n@keyframes Toastify__slideOutLeft {\n  from {\n    -webkit-transform: translate3d(0, 0, 0);\n            transform: translate3d(0, 0, 0);\n  }\n  to {\n    visibility: hidden;\n    -webkit-transform: translate3d(-110%, 0, 0);\n            transform: translate3d(-110%, 0, 0);\n  }\n}\n@-webkit-keyframes Toastify__slideOutDown {\n  from {\n    -webkit-transform: translate3d(0, 0, 0);\n            transform: translate3d(0, 0, 0);\n  }\n  to {\n    visibility: hidden;\n    -webkit-transform: translate3d(0, 500px, 0);\n            transform: translate3d(0, 500px, 0);\n  }\n}\n@keyframes Toastify__slideOutDown {\n  from {\n    -webkit-transform: translate3d(0, 0, 0);\n            transform: translate3d(0, 0, 0);\n  }\n  to {\n    visibility: hidden;\n    -webkit-transform: translate3d(0, 500px, 0);\n            transform: translate3d(0, 500px, 0);\n  }\n}\n@-webkit-keyframes Toastify__slideOutUp {\n  from {\n    -webkit-transform: translate3d(0, 0, 0);\n            transform: translate3d(0, 0, 0);\n  }\n  to {\n    visibility: hidden;\n    -webkit-transform: translate3d(0, -500px, 0);\n            transform: translate3d(0, -500px, 0);\n  }\n}\n@keyframes Toastify__slideOutUp {\n  from {\n    -webkit-transform: translate3d(0, 0, 0);\n            transform: translate3d(0, 0, 0);\n  }\n  to {\n    visibility: hidden;\n    -webkit-transform: translate3d(0, -500px, 0);\n            transform: translate3d(0, -500px, 0);\n  }\n}\n.Toastify__slide-enter--top-left, .Toastify__slide-enter--bottom-left {\n  -webkit-animation-name: Toastify__slideInLeft;\n          animation-name: Toastify__slideInLeft;\n}\n.Toastify__slide-enter--top-right, .Toastify__slide-enter--bottom-right {\n  -webkit-animation-name: Toastify__slideInRight;\n          animation-name: Toastify__slideInRight;\n}\n.Toastify__slide-enter--top-center {\n  -webkit-animation-name: Toastify__slideInDown;\n          animation-name: Toastify__slideInDown;\n}\n.Toastify__slide-enter--bottom-center {\n  -webkit-animation-name: Toastify__slideInUp;\n          animation-name: Toastify__slideInUp;\n}\n\n.Toastify__slide-exit--top-left, .Toastify__slide-exit--bottom-left {\n  -webkit-animation-name: Toastify__slideOutLeft;\n          animation-name: Toastify__slideOutLeft;\n}\n.Toastify__slide-exit--top-right, .Toastify__slide-exit--bottom-right {\n  -webkit-animation-name: Toastify__slideOutRight;\n          animation-name: Toastify__slideOutRight;\n}\n.Toastify__slide-exit--top-center {\n  -webkit-animation-name: Toastify__slideOutUp;\n          animation-name: Toastify__slideOutUp;\n}\n.Toastify__slide-exit--bottom-center {\n  -webkit-animation-name: Toastify__slideOutDown;\n          animation-name: Toastify__slideOutDown;\n}\n\n@-webkit-keyframes Toastify__spin {\n  from {\n    -webkit-transform: rotate(0deg);\n            transform: rotate(0deg);\n  }\n  to {\n    -webkit-transform: rotate(360deg);\n            transform: rotate(360deg);\n  }\n}\n\n@keyframes Toastify__spin {\n  from {\n    -webkit-transform: rotate(0deg);\n            transform: rotate(0deg);\n  }\n  to {\n    -webkit-transform: rotate(360deg);\n            transform: rotate(360deg);\n  }\n}\n\n/*# sourceMappingURL=ReactToastify.css.map */", "",{"version":3,"sources":["webpack://./node_modules/react-toastify/scss/_variables.scss","webpack://./node_modules/react-toastify/dist/ReactToastify.css","webpack://./node_modules/react-toastify/scss/_toastContainer.scss","webpack://./node_modules/react-toastify/scss/_toast.scss","webpack://./node_modules/react-toastify/scss/_theme.scss","webpack://./node_modules/react-toastify/scss/_closeButton.scss","webpack://./node_modules/react-toastify/scss/_progressBar.scss","webpack://./node_modules/react-toastify/scss/_icons.scss","webpack://./node_modules/react-toastify/scss/animations/_bounce.scss","webpack://./node_modules/react-toastify/scss/animations/_zoom.scss","webpack://./node_modules/react-toastify/scss/animations/_flip.scss","webpack://./node_modules/react-toastify/scss/animations/_slide.scss","webpack://./node_modules/react-toastify/scss/animations/_spin.scss"],"names":[],"mappings":"AAGA;EACE,4BAAA;EACA,8BAAA;EACA,8BAAA;EACA,iCAAA;EACA,iCAAA;EACA,+BAAA;EACA,sDAAA;EAEA,sDAAA;EACA,4DAAA;EACA,4DAAA;EACA,wDAAA;EAEA,6BAAA;EACA,iCAAA;EACA,iCAAA;EACA,kCAAA;EACA,kCAAA;EACA,wBAAA;EAEA,oCAAA;EACA,gCAAA;EAGA,gCAAA;EACA,mCAAA;EACA,mCAAA;EACA,iCAAA;EAEA,iCAAA;EACA,4CAAA;EAGA;;;;;;;;GAAA;EAUA,uCAAA;EACA,0DAAA;EACA,gEAAA;EACA,gEAAA;EACA,4DAAA;ACXF;;ACxCA;EACE,gCAAA;EACA,gEAAA;EACA,eAAA;EACA,YAAA;EACA,kCAAA;EACA,8BAAA;UAAA,sBAAA;EACA,WAAA;AD2CF;AC1CE;EACE,QAAA;EACA,SAAA;AD4CJ;AC1CE;EACE,QAAA;EACA,SAAA;EACA,mCAAA;UAAA,2BAAA;AD4CJ;AC1CE;EACE,QAAA;EACA,UAAA;AD4CJ;AC1CE;EACE,WAAA;EACA,SAAA;AD4CJ;AC1CE;EACE,WAAA;EACA,SAAA;EACA,mCAAA;UAAA,2BAAA;AD4CJ;AC1CE;EACE,WAAA;EACA,UAAA;AD4CJ;;ACxCA;EACE;IACE,YAAA;IACA,UAAA;IACA,OAAA;IACA,SAAA;ED2CF;EC1CE;IAGE,MAAA;IACA,gCAAA;YAAA,wBAAA;ED0CJ;ECxCE;IAGE,SAAA;IACA,gCAAA;YAAA,wBAAA;EDwCJ;ECtCE;IACE,QAAA;IACA,aAAA;EDwCJ;AACF;AEjGA;EACE,kBAAA;EACA,4CAAA;EACA,8BAAA;UAAA,sBAAA;EACA,mBAAA;EACA,YAAA;EACA,kBAAA;EACA,qFAAA;UAAA,6EAAA;EACA,oBAAA;EAAA,oBAAA;EAAA,aAAA;EACA,sBAAA;MAAA,yBAAA;UAAA,8BAAA;EACA,4CAAA;EACA,gBAAA;EACA,wCAAA;EACA,eAAA;EACA,cAAA;AFmGF;AElGE;EACE,cAAA;AFoGJ;AElGE;EACE,cAAA;EACA,kBAAA;MAAA,mBAAA;UAAA,cAAA;EACA,YAAA;EACA,oBAAA;EAAA,oBAAA;EAAA,aAAA;EACA,sBAAA;MAAA,yBAAA;UAAA,mBAAA;AFoGJ;AEnGI;EACE,WAAA;MAAA,mBAAA;UAAA,OAAA;AFqGN;AElGE;EACE,wBAAA;UAAA,uBAAA;EACA,WAAA;EACA,oBAAA;MAAA,cAAA;EACA,oBAAA;EAAA,oBAAA;EAAA,aAAA;AFoGJ;;AEhGA;EACE,iCAAA;UAAA,yBAAA;EACA,gCAAA;UAAA,wBAAA;AFmGF;;AEhGA;EACE,iCAAA;UAAA,yBAAA;EACA,gCAAA;UAAA,wBAAA;AFmGF;;AEhGA;EACE;IACE,gBAAA;IACA,gBAAA;EFmGF;AACF;AGpJE;EACE,sCAAA;EACA,sCAAA;AHsJJ;AGpJE;EACE,uCAAA;EACA,uCAAA;AHsJJ;AGpJE;EACE,uCAAA;EACA,uCAAA;AHsJJ;AGpJE;EACE,sCAAA;EACA,sCAAA;AHsJJ;AGpJE;EACE,yCAAA;EACA,yCAAA;AHsJJ;AGpJE;EACE,yCAAA;EACA,yCAAA;AHsJJ;AGpJE;EACE,uCAAA;EACA,uCAAA;AHsJJ;;AGjJE;EACE,gDAAA;AHoJJ;AGlJE;EACE,+CAAA;AHoJJ;AGlJE;EACE,+CAAA;AHoJJ;AGlJE;EACE,kDAAA;AHoJJ;AGlJE;EACE,kDAAA;AHoJJ;AGlJE;EACE,gDAAA;AHoJJ;AGlJE;EAIE,6CAAA;AHiJJ;;AIvMA;EACE,WAAA;EACA,uBAAA;EACA,aAAA;EACA,YAAA;EACA,UAAA;EACA,eAAA;EACA,YAAA;EACA,6BAAA;EAAA,qBAAA;EACA,0BAAA;MAAA,sBAAA;AJ0MF;AIxME;EACE,WAAA;EACA,YAAA;AJ0MJ;AIvME;EACE,kBAAA;EACA,YAAA;EACA,WAAA;AJyMJ;AItME;EACE,UAAA;AJwMJ;;AK/NA;EACE;IACE,4BAAA;YAAA,oBAAA;ELkOF;EKhOA;IACE,4BAAA;YAAA,oBAAA;ELkOF;AACF;;AKxOA;EACE;IACE,4BAAA;YAAA,oBAAA;ELkOF;EKhOA;IACE,4BAAA;YAAA,oBAAA;ELkOF;AACF;AK/NA;EACE,kBAAA;EACA,SAAA;EACA,OAAA;EACA,WAAA;EACA,WAAA;EACA,gCAAA;EACA,YAAA;EACA,8BAAA;UAAA,sBAAA;ALiOF;AK/NE;EACE,4DAAA;UAAA,oDAAA;ALiOJ;AK9NE;EACE,0CAAA;EAAA,kCAAA;EAAA,0BAAA;EAAA,kDAAA;ALgOJ;AK7NE;EACE,QAAA;EACA,aAAA;EACA,+BAAA;UAAA,uBAAA;AL+NJ;;AM7PA;EACE,WAAA;EACA,YAAA;EACA,8BAAA;UAAA,sBAAA;EACA,iBAAA;EACA,mBAAA;EACA,sDAAA;EACA,iDAAA;EACA,uDAAA;UAAA,+CAAA;ANgQF;;AOpQA;EACI;IAJA,sEAAA;YAAA,8DAAA;EP4QF;EOjQE;IACI,UAAA;IACA,4CAAA;YAAA,oCAAA;EPmQN;EOjQE;IACI,UAAA;IACA,2CAAA;YAAA,mCAAA;EPmQN;EOjQE;IACI,0CAAA;YAAA,kCAAA;EPmQN;EOjQE;IACI,0CAAA;YAAA,kCAAA;EPmQN;EOjQE;IACI,uBAAA;YAAA,eAAA;EPmQN;AACF;;AO3RA;EACI;IAJA,sEAAA;YAAA,8DAAA;EP4QF;EOjQE;IACI,UAAA;IACA,4CAAA;YAAA,oCAAA;EPmQN;EOjQE;IACI,UAAA;IACA,2CAAA;YAAA,mCAAA;EPmQN;EOjQE;IACI,0CAAA;YAAA,kCAAA;EPmQN;EOjQE;IACI,0CAAA;YAAA,kCAAA;EPmQN;EOjQE;IACI,uBAAA;YAAA,eAAA;EPmQN;AACF;AOhQA;EACI;IACI,UAAA;IACA,2CAAA;YAAA,mCAAA;EPkQN;EOhQE;IACI,UAAA;IACA,4CAAA;YAAA,oCAAA;EPkQN;AACF;AO1QA;EACI;IACI,UAAA;IACA,2CAAA;YAAA,mCAAA;EPkQN;EOhQE;IACI,UAAA;IACA,4CAAA;YAAA,oCAAA;EPkQN;AACF;AO/PA;EACI;IA1CA,sEAAA;YAAA,8DAAA;EP4SF;EO3PE;IACI,UAAA;IACA,6CAAA;YAAA,qCAAA;EP6PN;EO3PE;IACI,UAAA;IACA,0CAAA;YAAA,kCAAA;EP6PN;EO3PE;IACI,2CAAA;YAAA,mCAAA;EP6PN;EO3PE;IACI,yCAAA;YAAA,iCAAA;EP6PN;EO3PE;IACI,uBAAA;YAAA,eAAA;EP6PN;AACF;AOrRA;EACI;IA1CA,sEAAA;YAAA,8DAAA;EP4SF;EO3PE;IACI,UAAA;IACA,6CAAA;YAAA,qCAAA;EP6PN;EO3PE;IACI,UAAA;IACA,0CAAA;YAAA,kCAAA;EP6PN;EO3PE;IACI,2CAAA;YAAA,mCAAA;EP6PN;EO3PE;IACI,yCAAA;YAAA,iCAAA;EP6PN;EO3PE;IACI,uBAAA;YAAA,eAAA;EP6PN;AACF;AO1PA;EACI;IACI,UAAA;IACA,0CAAA;YAAA,kCAAA;EP4PN;EO1PE;IACI,UAAA;IACA,6CAAA;YAAA,qCAAA;EP4PN;AACF;AOpQA;EACI;IACI,UAAA;IACA,0CAAA;YAAA,kCAAA;EP4PN;EO1PE;IACI,UAAA;IACA,6CAAA;YAAA,qCAAA;EP4PN;AACF;AOzPA;EACI;IAhFA,sEAAA;YAAA,8DAAA;EP4UF;EOrPE;IACI,UAAA;IACA,4CAAA;YAAA,oCAAA;EPuPN;EOrPE;IACI,UAAA;IACA,2CAAA;YAAA,mCAAA;EPuPN;EOrPE;IACI,0CAAA;YAAA,kCAAA;EPuPN;EOrPE;IACI,0CAAA;YAAA,kCAAA;EPuPN;EOrPE;IACI,uCAAA;YAAA,+BAAA;EPuPN;AACF;AO/QA;EACI;IAhFA,sEAAA;YAAA,8DAAA;EP4UF;EOrPE;IACI,UAAA;IACA,4CAAA;YAAA,oCAAA;EPuPN;EOrPE;IACI,UAAA;IACA,2CAAA;YAAA,mCAAA;EPuPN;EOrPE;IACI,0CAAA;YAAA,kCAAA;EPuPN;EOrPE;IACI,0CAAA;YAAA,kCAAA;EPuPN;EOrPE;IACI,uCAAA;YAAA,+BAAA;EPuPN;AACF;AOpPA;EACI;IACI,2CAAA;YAAA,mCAAA;EPsPN;EOpPE;IAEI,UAAA;IACA,0CAAA;YAAA,kCAAA;EPqPN;EOnPE;IACI,UAAA;IACA,6CAAA;YAAA,qCAAA;EPqPN;AACF;AOjQA;EACI;IACI,2CAAA;YAAA,mCAAA;EPsPN;EOpPE;IAEI,UAAA;IACA,0CAAA;YAAA,kCAAA;EPqPN;EOnPE;IACI,UAAA;IACA,6CAAA;YAAA,qCAAA;EPqPN;AACF;AOlPA;EACI;IA1HA,sEAAA;YAAA,8DAAA;EP+WF;EO9OE;IACI,UAAA;IACA,6CAAA;YAAA,qCAAA;EPgPN;EO9OE;IACI,UAAA;IACA,0CAAA;YAAA,kCAAA;EPgPN;EO9OE;IACI,2CAAA;YAAA,mCAAA;EPgPN;EO9OE;IACI,yCAAA;YAAA,iCAAA;EPgPN;EO9OE;IACI,uBAAA;YAAA,eAAA;EPgPN;AACF;AOxQA;EACI;IA1HA,sEAAA;YAAA,8DAAA;EP+WF;EO9OE;IACI,UAAA;IACA,6CAAA;YAAA,qCAAA;EPgPN;EO9OE;IACI,UAAA;IACA,0CAAA;YAAA,kCAAA;EPgPN;EO9OE;IACI,2CAAA;YAAA,mCAAA;EPgPN;EO9OE;IACI,yCAAA;YAAA,iCAAA;EPgPN;EO9OE;IACI,uBAAA;YAAA,eAAA;EPgPN;AACF;AO7OA;EACI;IACI,0CAAA;YAAA,kCAAA;EP+ON;EO7OE;IAEI,UAAA;IACA,2CAAA;YAAA,mCAAA;EP8ON;EO5OE;IACI,UAAA;IACA,4CAAA;YAAA,oCAAA;EP8ON;AACF;AO1PA;EACI;IACI,0CAAA;YAAA,kCAAA;EP+ON;EO7OE;IAEI,UAAA;IACA,2CAAA;YAAA,mCAAA;EP8ON;EO5OE;IACI,UAAA;IACA,4CAAA;YAAA,oCAAA;EP8ON;AACF;AO1OI;EAEI,8CAAA;UAAA,sCAAA;AP2OR;AOzOI;EAEI,+CAAA;UAAA,uCAAA;AP0OR;AOxOI;EACI,8CAAA;UAAA,sCAAA;AP0OR;AOxOI;EACI,4CAAA;UAAA,oCAAA;AP0OR;;AOrOI;EAEI,+CAAA;UAAA,uCAAA;APuOR;AOrOI;EAEI,gDAAA;UAAA,wCAAA;APsOR;AOpOI;EACI,6CAAA;UAAA,qCAAA;APsOR;AOpOI;EACI,+CAAA;UAAA,uCAAA;APsOR;;AQxaA;EACI;IACI,UAAA;IACA,yCAAA;YAAA,iCAAA;ER2aN;EQzaE;IACI,UAAA;ER2aN;AACF;;AQlbA;EACI;IACI,UAAA;IACA,yCAAA;YAAA,iCAAA;ER2aN;EQzaE;IACI,UAAA;ER2aN;AACF;AQxaA;EACI;IACI,UAAA;ER0aN;EQxaE;IACI,UAAA;IACA,yCAAA;YAAA,iCAAA;ER0aN;EQxaE;IACI,UAAA;ER0aN;AACF;AQpbA;EACI;IACI,UAAA;ER0aN;EQxaE;IACI,UAAA;IACA,yCAAA;YAAA,iCAAA;ER0aN;EQxaE;IACI,UAAA;ER0aN;AACF;AQvaA;EACI,wCAAA;UAAA,gCAAA;ARyaJ;;AQtaA;EACI,yCAAA;UAAA,iCAAA;ARyaJ;;ASrcA;EACI;IACI,8DAAA;YAAA,sDAAA;IACA,0CAAA;YAAA,kCAAA;IACA,UAAA;ETwcN;EStcE;IACI,+DAAA;YAAA,uDAAA;IACA,0CAAA;YAAA,kCAAA;ETwcN;EStcE;IACI,8DAAA;YAAA,sDAAA;IACA,UAAA;ETwcN;EStcE;IACI,8DAAA;YAAA,sDAAA;ETwcN;EStcE;IACI,qCAAA;YAAA,6BAAA;ETwcN;AACF;;AS3dA;EACI;IACI,8DAAA;YAAA,sDAAA;IACA,0CAAA;YAAA,kCAAA;IACA,UAAA;ETwcN;EStcE;IACI,+DAAA;YAAA,uDAAA;IACA,0CAAA;YAAA,kCAAA;ETwcN;EStcE;IACI,8DAAA;YAAA,sDAAA;IACA,UAAA;ETwcN;EStcE;IACI,8DAAA;YAAA,sDAAA;ETwcN;EStcE;IACI,qCAAA;YAAA,6BAAA;ETwcN;AACF;ASrcA;EACI;IACI,qCAAA;YAAA,6BAAA;ETucN;ESrcE;IACI,+DAAA;YAAA,uDAAA;IACA,UAAA;ETucN;ESrcE;IACI,8DAAA;YAAA,sDAAA;IACA,UAAA;ETucN;AACF;ASldA;EACI;IACI,qCAAA;YAAA,6BAAA;ETucN;ESrcE;IACI,+DAAA;YAAA,uDAAA;IACA,UAAA;ETucN;ESrcE;IACI,8DAAA;YAAA,sDAAA;IACA,UAAA;ETucN;AACF;ASpcA;EACI,wCAAA;UAAA,gCAAA;ATscJ;;ASncA;EACI,yCAAA;UAAA,iCAAA;ATscJ;;AU3eA;EACI;IACI,0CAAA;YAAA,kCAAA;IACA,mBAAA;EV8eN;EU5eE;IARA,uCAAA;YAAA,+BAAA;EVufF;AACF;;AUrfA;EACI;IACI,0CAAA;YAAA,kCAAA;IACA,mBAAA;EV8eN;EU5eE;IARA,uCAAA;YAAA,+BAAA;EVufF;AACF;AU3eA;EACI;IACI,2CAAA;YAAA,mCAAA;IACA,mBAAA;EV6eN;EU3eE;IAlBA,uCAAA;YAAA,+BAAA;EVggBF;AACF;AUpfA;EACI;IACI,2CAAA;YAAA,mCAAA;IACA,mBAAA;EV6eN;EU3eE;IAlBA,uCAAA;YAAA,+BAAA;EVggBF;AACF;AU1eA;EACI;IACI,0CAAA;YAAA,kCAAA;IACA,mBAAA;EV4eN;EU1eE;IA5BA,uCAAA;YAAA,+BAAA;EVygBF;AACF;AUnfA;EACI;IACI,0CAAA;YAAA,kCAAA;IACA,mBAAA;EV4eN;EU1eE;IA5BA,uCAAA;YAAA,+BAAA;EVygBF;AACF;AUzeA;EACI;IACI,2CAAA;YAAA,mCAAA;IACA,mBAAA;EV2eN;EUzeE;IAtCA,uCAAA;YAAA,+BAAA;EVkhBF;AACF;AUlfA;EACI;IACI,2CAAA;YAAA,mCAAA;IACA,mBAAA;EV2eN;EUzeE;IAtCA,uCAAA;YAAA,+BAAA;EVkhBF;AACF;AUxeA;EACI;IA5CA,uCAAA;YAAA,+BAAA;EVuhBF;EUxeE;IACI,kBAAA;IACA,0CAAA;YAAA,kCAAA;EV0eN;AACF;AUjfA;EACI;IA5CA,uCAAA;YAAA,+BAAA;EVuhBF;EUxeE;IACI,kBAAA;IACA,0CAAA;YAAA,kCAAA;EV0eN;AACF;AUveA;EACI;IAtDA,uCAAA;YAAA,+BAAA;EVgiBF;EUveE;IACI,kBAAA;IACA,2CAAA;YAAA,mCAAA;EVyeN;AACF;AUhfA;EACI;IAtDA,uCAAA;YAAA,+BAAA;EVgiBF;EUveE;IACI,kBAAA;IACA,2CAAA;YAAA,mCAAA;EVyeN;AACF;AUteA;EACI;IAhEA,uCAAA;YAAA,+BAAA;EVyiBF;EUteE;IACI,kBAAA;IACA,2CAAA;YAAA,mCAAA;EVweN;AACF;AU/eA;EACI;IAhEA,uCAAA;YAAA,+BAAA;EVyiBF;EUteE;IACI,kBAAA;IACA,2CAAA;YAAA,mCAAA;EVweN;AACF;AUreA;EACI;IA1EA,uCAAA;YAAA,+BAAA;EVkjBF;EUreE;IACI,kBAAA;IACA,4CAAA;YAAA,oCAAA;EVueN;AACF;AU9eA;EACI;IA1EA,uCAAA;YAAA,+BAAA;EVkjBF;EUreE;IACI,kBAAA;IACA,4CAAA;YAAA,oCAAA;EVueN;AACF;AUneI;EAEI,6CAAA;UAAA,qCAAA;AVoeR;AUleI;EAEI,8CAAA;UAAA,sCAAA;AVmeR;AUjeI;EACI,6CAAA;UAAA,qCAAA;AVmeR;AUjeI;EACI,2CAAA;UAAA,mCAAA;AVmeR;;AU9dI;EAEI,8CAAA;UAAA,sCAAA;AVgeR;AU9dI;EAEI,+CAAA;UAAA,uCAAA;AV+dR;AU7dI;EACI,4CAAA;UAAA,oCAAA;AV+dR;AU7dI;EACI,8CAAA;UAAA,sCAAA;AV+dR;;AWjlBA;EACE;IACE,+BAAA;YAAA,uBAAA;EXolBF;EWllBA;IACE,iCAAA;YAAA,yBAAA;EXolBF;AACF;;AW1lBA;EACE;IACE,+BAAA;YAAA,uBAAA;EXolBF;EWllBA;IACE,iCAAA;YAAA,yBAAA;EXolBF;AACF;;AAYA,4CAA4C","sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./src/app/styles.module.scss":
/*!************************************!*\
  !*** ./src/app/styles.module.scss ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
	"header": "src-app-styles-module__header",
	"logo": "src-app-styles-module__logo",
	"siteName": "src-app-styles-module__siteName",
	"siteDescription": "src-app-styles-module__siteDescription"
});


/***/ }),

/***/ "./src/components/AddEnvie/styles.module.scss":
/*!****************************************************!*\
  !*** ./src/components/AddEnvie/styles.module.scss ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
	"jav-game-list": "src-components-AddEnvie-styles-module__jav-game-list"
});


/***/ }),

/***/ "./src/components/JeuJavList/styles.module.scss":
/*!******************************************************!*\
  !*** ./src/components/JeuJavList/styles.module.scss ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
	"jav-game-list": "src-components-JeuJavList-styles-module__jav-game-list"
});


/***/ }),

/***/ "./src/components/Loading/styles.module.scss":
/*!***************************************************!*\
  !*** ./src/components/Loading/styles.module.scss ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
	"loading": "src-components-Loading-styles-module__loading"
});


/***/ }),

/***/ "./src/components/MembreInfo/styles.module.scss":
/*!******************************************************!*\
  !*** ./src/components/MembreInfo/styles.module.scss ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
	"membre-card": "src-components-MembreInfo-styles-module__membre-card"
});


/***/ }),

/***/ "./src/components/MembreList/styles.module.scss":
/*!******************************************************!*\
  !*** ./src/components/MembreList/styles.module.scss ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
	"user-list": "src-components-MembreList-styles-module__user-list"
});


/***/ }),

/***/ "./src/components/MembreSet/styles.module.scss":
/*!*****************************************************!*\
  !*** ./src/components/MembreSet/styles.module.scss ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
	"jav-game-list": "src-components-MembreSet-styles-module__jav-game-list"
});


/***/ }),

/***/ "./src/pages/Home/styles.module.scss":
/*!*******************************************!*\
  !*** ./src/pages/Home/styles.module.scss ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
	"home": "src-pages-Home-styles-module__home"
});


/***/ }),

/***/ "./src/pages/MembrePage/styles.module.scss":
/*!*************************************************!*\
  !*** ./src/pages/MembrePage/styles.module.scss ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
	"membre": "src-pages-MembrePage-styles-module__membre"
});


/***/ }),

/***/ "./src/pages/NotFound/styles.module.scss":
/*!***********************************************!*\
  !*** ./src/pages/NotFound/styles.module.scss ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
	"not-found": "src-pages-NotFound-styles-module__not-found"
});


/***/ }),

/***/ "./node_modules/css-loader/dist/runtime/api.js":
/*!*****************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/api.js ***!
  \*****************************************************/
/***/ ((module) => {



/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
*/
// css base code, injected by the css-loader
// eslint-disable-next-line func-names
module.exports = function (cssWithMappingToString) {
  var list = []; // return the list of modules as css string

  list.toString = function toString() {
    return this.map(function (item) {
      var content = cssWithMappingToString(item);

      if (item[2]) {
        return "@media ".concat(item[2], " {").concat(content, "}");
      }

      return content;
    }).join("");
  }; // import a list of modules into the list
  // eslint-disable-next-line func-names


  list.i = function (modules, mediaQuery, dedupe) {
    if (typeof modules === "string") {
      // eslint-disable-next-line no-param-reassign
      modules = [[null, modules, ""]];
    }

    var alreadyImportedModules = {};

    if (dedupe) {
      for (var i = 0; i < this.length; i++) {
        // eslint-disable-next-line prefer-destructuring
        var id = this[i][0];

        if (id != null) {
          alreadyImportedModules[id] = true;
        }
      }
    }

    for (var _i = 0; _i < modules.length; _i++) {
      var item = [].concat(modules[_i]);

      if (dedupe && alreadyImportedModules[item[0]]) {
        // eslint-disable-next-line no-continue
        continue;
      }

      if (mediaQuery) {
        if (!item[2]) {
          item[2] = mediaQuery;
        } else {
          item[2] = "".concat(mediaQuery, " and ").concat(item[2]);
        }
      }

      list.push(item);
    }
  };

  return list;
};

/***/ }),

/***/ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js":
/*!************************************************************************!*\
  !*** ./node_modules/css-loader/dist/runtime/cssWithMappingToString.js ***!
  \************************************************************************/
/***/ ((module) => {



function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _iterableToArrayLimit(arr, i) { var _i = arr && (typeof Symbol !== "undefined" && arr[Symbol.iterator] || arr["@@iterator"]); if (_i == null) return; var _arr = []; var _n = true; var _d = false; var _s, _e; try { for (_i = _i.call(arr); !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

module.exports = function cssWithMappingToString(item) {
  var _item = _slicedToArray(item, 4),
      content = _item[1],
      cssMapping = _item[3];

  if (!cssMapping) {
    return content;
  }

  if (typeof btoa === "function") {
    // eslint-disable-next-line no-undef
    var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(cssMapping))));
    var data = "sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(base64);
    var sourceMapping = "/*# ".concat(data, " */");
    var sourceURLs = cssMapping.sources.map(function (source) {
      return "/*# sourceURL=".concat(cssMapping.sourceRoot || "").concat(source, " */");
    });
    return [content].concat(sourceURLs).concat([sourceMapping]).join("\n");
  }

  return [content].join("\n");
};

/***/ }),

/***/ "@babel/runtime/helpers/asyncToGenerator":
/*!**********************************************************!*\
  !*** external "@babel/runtime/helpers/asyncToGenerator" ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = require("@babel/runtime/helpers/asyncToGenerator");

/***/ }),

/***/ "@babel/runtime/helpers/classCallCheck":
/*!********************************************************!*\
  !*** external "@babel/runtime/helpers/classCallCheck" ***!
  \********************************************************/
/***/ ((module) => {

module.exports = require("@babel/runtime/helpers/classCallCheck");

/***/ }),

/***/ "@babel/runtime/helpers/createClass":
/*!*****************************************************!*\
  !*** external "@babel/runtime/helpers/createClass" ***!
  \*****************************************************/
/***/ ((module) => {

module.exports = require("@babel/runtime/helpers/createClass");

/***/ }),

/***/ "@babel/runtime/helpers/defineProperty":
/*!********************************************************!*\
  !*** external "@babel/runtime/helpers/defineProperty" ***!
  \********************************************************/
/***/ ((module) => {

module.exports = require("@babel/runtime/helpers/defineProperty");

/***/ }),

/***/ "@babel/runtime/helpers/getPrototypeOf":
/*!********************************************************!*\
  !*** external "@babel/runtime/helpers/getPrototypeOf" ***!
  \********************************************************/
/***/ ((module) => {

module.exports = require("@babel/runtime/helpers/getPrototypeOf");

/***/ }),

/***/ "@babel/runtime/helpers/inherits":
/*!**************************************************!*\
  !*** external "@babel/runtime/helpers/inherits" ***!
  \**************************************************/
/***/ ((module) => {

module.exports = require("@babel/runtime/helpers/inherits");

/***/ }),

/***/ "@babel/runtime/helpers/possibleConstructorReturn":
/*!*******************************************************************!*\
  !*** external "@babel/runtime/helpers/possibleConstructorReturn" ***!
  \*******************************************************************/
/***/ ((module) => {

module.exports = require("@babel/runtime/helpers/possibleConstructorReturn");

/***/ }),

/***/ "@babel/runtime/helpers/slicedToArray":
/*!*******************************************************!*\
  !*** external "@babel/runtime/helpers/slicedToArray" ***!
  \*******************************************************/
/***/ ((module) => {

module.exports = require("@babel/runtime/helpers/slicedToArray");

/***/ }),

/***/ "@babel/runtime/helpers/toConsumableArray":
/*!***********************************************************!*\
  !*** external "@babel/runtime/helpers/toConsumableArray" ***!
  \***********************************************************/
/***/ ((module) => {

module.exports = require("@babel/runtime/helpers/toConsumableArray");

/***/ }),

/***/ "@babel/runtime/regenerator":
/*!*********************************************!*\
  !*** external "@babel/runtime/regenerator" ***!
  \*********************************************/
/***/ ((module) => {

module.exports = require("@babel/runtime/regenerator");

/***/ }),

/***/ "@loadable/server":
/*!***********************************!*\
  !*** external "@loadable/server" ***!
  \***********************************/
/***/ ((module) => {

module.exports = require("@loadable/server");

/***/ }),

/***/ "@loadable/webpack-plugin":
/*!*******************************************!*\
  !*** external "@loadable/webpack-plugin" ***!
  \*******************************************/
/***/ ((module) => {

module.exports = require("@loadable/webpack-plugin");

/***/ }),

/***/ "@pmmmwh/react-refresh-webpack-plugin":
/*!*******************************************************!*\
  !*** external "@pmmmwh/react-refresh-webpack-plugin" ***!
  \*******************************************************/
/***/ ((module) => {

module.exports = require("@pmmmwh/react-refresh-webpack-plugin");

/***/ }),

/***/ "@reduxjs/toolkit":
/*!***********************************!*\
  !*** external "@reduxjs/toolkit" ***!
  \***********************************/
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ "bcrypt":
/*!*************************!*\
  !*** external "bcrypt" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ "chalk":
/*!************************!*\
  !*** external "chalk" ***!
  \************************/
/***/ ((module) => {

module.exports = require("chalk");

/***/ }),

/***/ "compression":
/*!******************************!*\
  !*** external "compression" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("compression");

/***/ }),

/***/ "compression-webpack-plugin":
/*!*********************************************!*\
  !*** external "compression-webpack-plugin" ***!
  \*********************************************/
/***/ ((module) => {

module.exports = require("compression-webpack-plugin");

/***/ }),

/***/ "connected-react-router":
/*!*****************************************!*\
  !*** external "connected-react-router" ***!
  \*****************************************/
/***/ ((module) => {

module.exports = require("connected-react-router");

/***/ }),

/***/ "css-minimizer-webpack-plugin":
/*!***********************************************!*\
  !*** external "css-minimizer-webpack-plugin" ***!
  \***********************************************/
/***/ ((module) => {

module.exports = require("css-minimizer-webpack-plugin");

/***/ }),

/***/ "express":
/*!**************************!*\
  !*** external "express" ***!
  \**************************/
/***/ ((module) => {

module.exports = require("express");

/***/ }),

/***/ "fork-ts-checker-webpack-plugin":
/*!*************************************************!*\
  !*** external "fork-ts-checker-webpack-plugin" ***!
  \*************************************************/
/***/ ((module) => {

module.exports = require("fork-ts-checker-webpack-plugin");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ "google-spreadsheet":
/*!*************************************!*\
  !*** external "google-spreadsheet" ***!
  \*************************************/
/***/ ((module) => {

module.exports = require("google-spreadsheet");

/***/ }),

/***/ "helmet":
/*!*************************!*\
  !*** external "helmet" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("helmet");

/***/ }),

/***/ "history":
/*!**************************!*\
  !*** external "history" ***!
  \**************************/
/***/ ((module) => {

module.exports = require("history");

/***/ }),

/***/ "hpp":
/*!**********************!*\
  !*** external "hpp" ***!
  \**********************/
/***/ ((module) => {

module.exports = require("hpp");

/***/ }),

/***/ "html-minifier":
/*!********************************!*\
  !*** external "html-minifier" ***!
  \********************************/
/***/ ((module) => {

module.exports = require("html-minifier");

/***/ }),

/***/ "https":
/*!************************!*\
  !*** external "https" ***!
  \************************/
/***/ ((module) => {

module.exports = require("https");

/***/ }),

/***/ "image-minimizer-webpack-plugin":
/*!*************************************************!*\
  !*** external "image-minimizer-webpack-plugin" ***!
  \*************************************************/
/***/ ((module) => {

module.exports = require("image-minimizer-webpack-plugin");

/***/ }),

/***/ "jsonwebtoken":
/*!*******************************!*\
  !*** external "jsonwebtoken" ***!
  \*******************************/
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ "lodash":
/*!*************************!*\
  !*** external "lodash" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("lodash");

/***/ }),

/***/ "mini-css-extract-plugin":
/*!******************************************!*\
  !*** external "mini-css-extract-plugin" ***!
  \******************************************/
/***/ ((module) => {

module.exports = require("mini-css-extract-plugin");

/***/ }),

/***/ "morgan":
/*!*************************!*\
  !*** external "morgan" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("morgan");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react-dom/server":
/*!***********************************!*\
  !*** external "react-dom/server" ***!
  \***********************************/
/***/ ((module) => {

module.exports = require("react-dom/server");

/***/ }),

/***/ "react-helmet":
/*!*******************************!*\
  !*** external "react-helmet" ***!
  \*******************************/
/***/ ((module) => {

module.exports = require("react-helmet");

/***/ }),

/***/ "react-redux":
/*!******************************!*\
  !*** external "react-redux" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ "react-router-config":
/*!**************************************!*\
  !*** external "react-router-config" ***!
  \**************************************/
/***/ ((module) => {

module.exports = require("react-router-config");

/***/ }),

/***/ "react-router-dom":
/*!***********************************!*\
  !*** external "react-router-dom" ***!
  \***********************************/
/***/ ((module) => {

module.exports = require("react-router-dom");

/***/ }),

/***/ "react-toastify":
/*!*********************************!*\
  !*** external "react-toastify" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("react-toastify");

/***/ }),

/***/ "react/jsx-runtime":
/*!************************************!*\
  !*** external "react/jsx-runtime" ***!
  \************************************/
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ "serialize-javascript":
/*!***************************************!*\
  !*** external "serialize-javascript" ***!
  \***************************************/
/***/ ((module) => {

module.exports = require("serialize-javascript");

/***/ }),

/***/ "serve-favicon":
/*!********************************!*\
  !*** external "serve-favicon" ***!
  \********************************/
/***/ ((module) => {

module.exports = require("serve-favicon");

/***/ }),

/***/ "terser-webpack-plugin":
/*!****************************************!*\
  !*** external "terser-webpack-plugin" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("terser-webpack-plugin");

/***/ }),

/***/ "webpack":
/*!**************************!*\
  !*** external "webpack" ***!
  \**************************/
/***/ ((module) => {

module.exports = require("webpack");

/***/ }),

/***/ "webpack-bundle-analyzer":
/*!******************************************!*\
  !*** external "webpack-bundle-analyzer" ***!
  \******************************************/
/***/ ((module) => {

module.exports = require("webpack-bundle-analyzer");

/***/ }),

/***/ "webpack-dev-middleware":
/*!*****************************************!*\
  !*** external "webpack-dev-middleware" ***!
  \*****************************************/
/***/ ((module) => {

module.exports = require("webpack-dev-middleware");

/***/ }),

/***/ "webpack-hot-middleware":
/*!*****************************************!*\
  !*** external "webpack-hot-middleware" ***!
  \*****************************************/
/***/ ((module) => {

module.exports = require("webpack-hot-middleware");

/***/ }),

/***/ "webpack-manifest-plugin":
/*!******************************************!*\
  !*** external "webpack-manifest-plugin" ***!
  \******************************************/
/***/ ((module) => {

module.exports = require("webpack-manifest-plugin");

/***/ }),

/***/ "webpack-merge":
/*!********************************!*\
  !*** external "webpack-merge" ***!
  \********************************/
/***/ ((module) => {

module.exports = require("webpack-merge");

/***/ }),

/***/ "@loadable/component":
/*!**************************************!*\
  !*** external "@loadable/component" ***!
  \**************************************/
/***/ ((module) => {

module.exports = require("@loadable/component");

/***/ }),

/***/ "http":
/*!***********************!*\
  !*** external "http" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("http");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("path");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/ensure chunk */
/******/ 	(() => {
/******/ 		__webpack_require__.f = {};
/******/ 		// This file contains only the entry chunk.
/******/ 		// The chunk loading function for additional chunks
/******/ 		__webpack_require__.e = (chunkId) => {
/******/ 			return Promise.all(Object.keys(__webpack_require__.f).reduce((promises, key) => {
/******/ 				__webpack_require__.f[key](chunkId, promises);
/******/ 				return promises;
/******/ 			}, []));
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/get javascript chunk filename */
/******/ 	(() => {
/******/ 		// This function allow to reference async chunks
/******/ 		__webpack_require__.u = (chunkId) => {
/******/ 			// return url for filenames based on template
/******/ 			return "" + chunkId + ".js";
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/require chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded chunks
/******/ 		// "1" means "loaded", otherwise not loaded yet
/******/ 		var installedChunks = {
/******/ 			"main": 1
/******/ 		};
/******/ 		
/******/ 		// no on chunks loaded
/******/ 		
/******/ 		var installChunk = (chunk) => {
/******/ 			var moreModules = chunk.modules, chunkIds = chunk.ids, runtime = chunk.runtime;
/******/ 			for(var moduleId in moreModules) {
/******/ 				if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 					__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 				}
/******/ 			}
/******/ 			if(runtime) runtime(__webpack_require__);
/******/ 			for(var i = 0; i < chunkIds.length; i++)
/******/ 				installedChunks[chunkIds[i]] = 1;
/******/ 		
/******/ 		};
/******/ 		
/******/ 		// require() chunk loading for javascript
/******/ 		__webpack_require__.f.require = (chunkId, promises) => {
/******/ 			// "1" is the signal for "already loaded"
/******/ 			if(!installedChunks[chunkId]) {
/******/ 				if(true) { // all chunks have JS
/******/ 					installChunk(require("./" + __webpack_require__.u(chunkId)));
/******/ 				} else installedChunks[chunkId] = 1;
/******/ 			}
/******/ 		};
/******/ 		
/******/ 		// no external install chunk
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// module factories are used so entry inlining is disabled
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	var __webpack_exports__ = __webpack_require__("./src/server/index.ts");
/******/ 	module.exports = __webpack_exports__;
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0NBR0E7O0FBQ0E7QUFDQTtBQUNBOzs7O0FBTUEsSUFBTU0sR0FBRyxHQUFHLFNBQU5BLEdBQU07QUFBQSxNQUFHQyxLQUFILFFBQUdBLEtBQUg7QUFBQSxzQkFDUjtBQUFBLDRCQUNJLHVEQUFDLGdEQUFELGtDQUFZSCxtREFBWjtBQUFBLDZCQUNJO0FBQ0ksWUFBSSxFQUFDLFVBRFQ7QUFFSSxlQUFPLEVBQUM7QUFGWjtBQURKLE9BREosZUFPSTtBQUFRLGVBQVMsRUFBRUMsa0VBQW5CO0FBQUEsOEJBQ0k7QUFBSyxpQkFBUyxFQUFFQSxnRUFBV0s7QUFBM0IsUUFESixlQUVJO0FBQUksaUJBQVMsRUFBRUwsb0VBQWY7QUFBQSwrQkFDSSx1REFBQyxrREFBRDtBQUFNLFlBQUUsRUFBQyxHQUFUO0FBQUEsb0JBQWNELHlEQUFnQlE7QUFBOUI7QUFESixRQUZKLGVBS0k7QUFBSyxpQkFBUyxFQUFFUCwyRUFBaEI7QUFBQSxrQkFBeUNELCtEQUFzQlU7QUFBL0QsUUFMSjtBQUFBLE1BUEosRUFlS2IsaUVBQVksQ0FBQ00sS0FBSyxDQUFDUSxNQUFQLENBZmpCLGVBZ0JJLHVEQUFDLDBEQUFELEtBaEJKO0FBQUEsSUFEUTtBQUFBLENBQVo7O0FBcUJBLGlFQUFlVCxHQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcENBO0FBQ0E7QUFJQTtBQUNBOzs7O0FBTUEsSUFBTWUsUUFBUSxHQUFHLFNBQVhBLFFBQVcsT0FBeUI7QUFBQSxNQUF0QkMsUUFBc0IsUUFBdEJBLFFBQXNCOztBQUN0QyxrQkFBOEJMLCtDQUFRLENBQUMsRUFBRCxDQUF0QztBQUFBO0FBQUEsTUFBT00sT0FBUDtBQUFBLE1BQWdCQyxVQUFoQjs7QUFDQSxtQkFBNEJQLCtDQUFRLENBQUMsRUFBRCxDQUFwQztBQUFBO0FBQUEsTUFBT1EsTUFBUDtBQUFBLE1BQWVDLFNBQWY7O0FBQ0EsbUJBQW9DVCwrQ0FBUSxDQUFDLEVBQUQsQ0FBNUM7QUFBQTtBQUFBLE1BQU9VLFVBQVA7QUFBQSxNQUFtQkMsYUFBbkI7O0FBQ0EsbUJBQThCWCwrQ0FBUSxDQUFDLENBQUMsRUFBRCxDQUFELENBQXRDO0FBQUE7QUFBQSxNQUFPWSxPQUFQO0FBQUEsTUFBZ0JDLFVBQWhCOztBQUNBLG1CQUFrQ2IsK0NBQVEsQ0FBQyxFQUFELENBQTFDO0FBQUE7QUFBQSxNQUFPYyxTQUFQO0FBQUEsTUFBa0JDLFlBQWxCOztBQUVBLE1BQU1DLGdCQUFnQixHQUFHLFNBQW5CQSxnQkFBbUIsQ0FBQ0MsQ0FBRDtBQUFBLFdBQTRDVixVQUFVLENBQUNVLENBQUMsQ0FBQ0MsTUFBRixDQUFTQyxLQUFWLENBQXREO0FBQUEsR0FBekI7O0FBQ0EsTUFBTUMsZUFBZSxHQUFHLFNBQWxCQSxlQUFrQixDQUFDSCxDQUFEO0FBQUEsV0FBK0NSLFNBQVMsQ0FBQ1EsQ0FBQyxDQUFDQyxNQUFGLENBQVNDLEtBQVYsQ0FBeEQ7QUFBQSxHQUF4Qjs7QUFDQSxNQUFNRSxtQkFBbUIsR0FBRyxTQUF0QkEsbUJBQXNCLENBQUNKLENBQUQ7QUFBQSxXQUN4Qk4sYUFBYSxDQUFDTSxDQUFDLENBQUNDLE1BQUYsQ0FBU0MsS0FBVixDQURXO0FBQUEsR0FBNUI7O0FBRUEsTUFBTUcsZ0JBQWdCLEdBQUcsU0FBbkJBLGdCQUFtQixDQUFDTCxDQUFEO0FBQUEsV0FDckJKLFVBQVUsQ0FBQ0ksQ0FBQyxDQUFDQyxNQUFGLENBQVNDLEtBQVQsQ0FBZUksS0FBZixDQUFxQixLQUFyQixDQUFELENBRFc7QUFBQSxHQUF6Qjs7QUFFQSxNQUFNQyxrQkFBa0IsR0FBRyxTQUFyQkEsa0JBQXFCLENBQUNQLENBQUQ7QUFBQSxXQUN2QkYsWUFBWSxDQUFDRSxDQUFDLENBQUNDLE1BQUYsQ0FBU0MsS0FBVixDQURXO0FBQUEsR0FBM0I7O0FBR0EsTUFBTU0saUJBQWlCLEdBQUcsU0FBcEJBLGlCQUFvQixHQUFNO0FBQzVCLFFBQUluQixPQUFPLElBQUlFLE1BQWYsRUFBdUI7QUFDbkJILE1BQUFBLFFBQVEsQ0FDSkYsOERBQWEsQ0FBQztBQUNWRyxRQUFBQSxPQUFPLEVBQVBBLE9BRFU7QUFFVkUsUUFBQUEsTUFBTSxFQUFOQSxNQUZVO0FBR1ZFLFFBQUFBLFVBQVUsRUFBVkEsVUFIVTtBQUlWRSxRQUFBQSxPQUFPLEVBQVBBLE9BSlU7QUFLVkUsUUFBQUEsU0FBUyxFQUFUQTtBQUxVLE9BQUQsQ0FEVCxDQUFSO0FBVUFQLE1BQUFBLFVBQVUsQ0FBQyxFQUFELENBQVY7QUFDQUUsTUFBQUEsU0FBUyxDQUFDLEVBQUQsQ0FBVDtBQUNBRSxNQUFBQSxhQUFhLENBQUMsRUFBRCxDQUFiO0FBQ0FFLE1BQUFBLFVBQVUsQ0FBQyxDQUFDLEVBQUQsQ0FBRCxDQUFWO0FBQ0FFLE1BQUFBLFlBQVksQ0FBQyxFQUFELENBQVo7QUFDSCxLQWhCRCxNQWdCTztBQUNIYixNQUFBQSx5REFBQSxDQUFjLGlEQUFkLEVBQWlFO0FBQzdEeUIsUUFBQUEsUUFBUSxFQUFFLFlBRG1EO0FBRTdEQyxRQUFBQSxTQUFTLEVBQUUsSUFGa0Q7QUFHN0RDLFFBQUFBLGVBQWUsRUFBRSxJQUg0QztBQUk3REMsUUFBQUEsWUFBWSxFQUFFLElBSitDO0FBSzdEQyxRQUFBQSxZQUFZLEVBQUUsSUFMK0M7QUFNN0RDLFFBQUFBLFNBQVMsRUFBRSxJQU5rRDtBQU83REMsUUFBQUEsUUFBUSxFQUFFQztBQVBtRCxPQUFqRTtBQVNIO0FBQ0osR0E1QkQ7O0FBNkJBLHNCQUNJO0FBQVMsYUFBUyxFQUFFOUMscUVBQXBCO0FBQUEsNEJBQ0k7QUFBQTtBQUFBLE1BREosZUFFSTtBQUFBLDhCQUNJO0FBQU8sZUFBTyxFQUFDLGFBQWY7QUFBQSw0Q0FFSTtBQUNJLGNBQUksRUFBQyxNQURUO0FBRUksWUFBRSxFQUFDLGFBRlA7QUFHSSxjQUFJLEVBQUMsYUFIVDtBQUlJLGVBQUssRUFBRWtCLE9BSlg7QUFLSSxrQkFBUSxFQUFFVTtBQUxkLFVBRko7QUFBQSxRQURKLGVBV0k7QUFBTyxlQUFPLEVBQUMsWUFBZjtBQUFBLDJDQUVJO0FBQ0ksWUFBRSxFQUFDLFlBRFA7QUFFSSxjQUFJLEVBQUMsWUFGVDtBQUdJLGVBQUssRUFBRVIsTUFIWDtBQUlJLGtCQUFRLEVBQUVZO0FBSmQsVUFGSjtBQUFBLFFBWEosZUFvQkk7QUFBTyxlQUFPLEVBQUMsZ0JBQWY7QUFBQSwrQ0FFSTtBQUNJLFlBQUUsRUFBQyxnQkFEUDtBQUVJLGNBQUksRUFBQyxnQkFGVDtBQUdJLGVBQUssRUFBRVYsVUFIWDtBQUlJLGtCQUFRLEVBQUVXO0FBSmQsVUFGSjtBQUFBLFFBcEJKLGVBNkJJO0FBQU8sZUFBTyxFQUFDLGFBQWY7QUFBQSw0Q0FFSTtBQUNJLGNBQUksRUFBQyxNQURUO0FBRUksWUFBRSxFQUFDLGFBRlA7QUFHSSxjQUFJLEVBQUMsYUFIVDtBQUlJLGVBQUssRUFBRVQsT0FBTyxDQUFDd0IsSUFBUixDQUFhLElBQWIsQ0FKWDtBQUtJLGtCQUFRLEVBQUVkO0FBTGQsVUFGSjtBQUFBLFFBN0JKLGVBdUNJO0FBQU8sZUFBTyxFQUFDLGVBQWY7QUFBQSw4Q0FFSTtBQUNJLGNBQUksRUFBQyxNQURUO0FBRUksWUFBRSxFQUFDLGVBRlA7QUFHSSxjQUFJLEVBQUMsZUFIVDtBQUlJLGVBQUssRUFBRVIsU0FKWDtBQUtJLGtCQUFRLEVBQUVVO0FBTGQsVUFGSjtBQUFBLFFBdkNKLGVBaURJO0FBQVEsWUFBSSxFQUFDLFFBQWI7QUFBc0IsZUFBTyxFQUFFQyxpQkFBL0I7QUFBQTtBQUFBLFFBakRKO0FBQUEsTUFGSjtBQUFBLElBREo7QUEwREgsQ0F2R0Q7O0FBd0dBLDhFQUFleEIsMkNBQUksQ0FBQ0csUUFBRCxDQUFuQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwSEE7Ozs7SUFVTWtDOzs7OztBQUNGLHlCQUFZQyxLQUFaLEVBQTBCO0FBQUE7O0FBQUE7O0FBQ3RCLDhCQUFNQSxLQUFOO0FBRUEsVUFBS0MsS0FBTCxHQUFhO0FBQUVDLE1BQUFBLEtBQUssRUFBRSxJQUFUO0FBQWVDLE1BQUFBLFNBQVMsRUFBRTtBQUExQixLQUFiO0FBSHNCO0FBSXpCOzs7O1dBRUQsMkJBQWtCRCxLQUFsQixFQUFnQ0MsU0FBaEMsRUFBNkU7QUFDekU7QUFDQSxXQUFLQyxRQUFMLENBQWM7QUFBRUYsUUFBQUEsS0FBSyxFQUFMQSxLQUFGO0FBQVNDLFFBQUFBLFNBQVMsRUFBVEE7QUFBVCxPQUFkLEVBRnlFLENBSXpFO0FBQ0g7OztXQUVELGtCQUFvQjtBQUNoQixVQUFRRSxRQUFSLEdBQXFCLEtBQUtMLEtBQTFCLENBQVFLLFFBQVI7QUFDQSx3QkFBNkIsS0FBS0osS0FBbEM7QUFBQSxVQUFRRSxTQUFSLGVBQVFBLFNBQVI7QUFBQSxVQUFtQkQsS0FBbkIsZUFBbUJBLEtBQW5CLENBRmdCLENBSWhCOztBQUNBLGFBQU9DLFNBQVMsZ0JBQ1o7QUFBSyx1QkFBWSxZQUFqQjtBQUFBLGdDQUNJO0FBQUE7QUFBQSxVQURKLGVBRUk7QUFBUyxlQUFLLEVBQUU7QUFBRUcsWUFBQUEsVUFBVSxFQUFFO0FBQWQsV0FBaEI7QUFBQSxxQkFDS0osS0FBSyxJQUFJQSxLQUFLLENBQUNLLFFBQU4sRUFEZCxlQUVJLGdFQUZKLEVBR0tKLFNBQVMsQ0FBQ0ssY0FIZjtBQUFBLFVBRko7QUFBQSxRQURZLEdBVVpILFFBQVEsSUFBSSxJQVZoQjtBQVlIOzs7O0VBL0J1QlA7O0FBa0M1QixpRUFBZUMsYUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNUNBO0FBQ0E7QUFLQTs7OztBQU1BLElBQU1ZLFVBQVUsR0FBRyxTQUFiQSxVQUFhLE9BQW9CO0FBQUEsTUFBakJDLEdBQWlCLFFBQWpCQSxHQUFpQjs7QUFDbkMscUJBQThCSCx3REFBVyxDQUFDLFVBQUNSLEtBQUQ7QUFBQSxXQUFxQkEsS0FBSyxDQUFDWSxVQUEzQjtBQUFBLEdBQUQsRUFBd0NILHFEQUF4QyxDQUF6QztBQUFBLE1BQWtCSSxPQUFsQixnQkFBUUMsUUFBUjs7QUFDQSxzQkFDSTtBQUFLLGFBQVMsRUFBRWxFLHNFQUFoQjtBQUFBLDRCQUNJO0FBQUE7QUFBQSxNQURKLGVBRUk7QUFBQSxnQkFDSytELEdBQUcsQ0FBQ0ksR0FBSixDQUFRLFVBQUNDLEVBQUQsRUFBUTtBQUNiLFlBQU1DLEdBQUcsR0FBR0osT0FBTyxDQUFDRyxFQUFELENBQW5COztBQUNBLFlBQUksQ0FBQ0MsR0FBTCxFQUFVO0FBQ04sOEJBQU87QUFBQSxtQ0FBc0JELEVBQXRCO0FBQUEsYUFBU0EsRUFBVCxDQUFQO0FBQ0g7O0FBQ0QsWUFBUUUsS0FBUixHQUF5QkQsR0FBekIsQ0FBUUMsS0FBUjtBQUFBLFlBQWVDLEtBQWYsR0FBeUJGLEdBQXpCLENBQWVFLEtBQWY7QUFDQSw0QkFDSTtBQUFBLHFCQUNLRCxLQURMLFVBQ2dCQyxLQURoQjtBQUFBLFdBQVNILEVBQVQsQ0FESjtBQUtILE9BWEE7QUFETCxNQUZKO0FBQUEsSUFESjtBQW1CSCxDQXJCRDs7QUF1QkEsOEVBQWV2RCwyQ0FBSSxDQUFDaUQsVUFBRCxDQUFuQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuQ0E7OztBQUVBLElBQU1VLE9BQU8sR0FBRyxTQUFWQSxPQUFVO0FBQUEsc0JBQ1o7QUFBSyxhQUFTLEVBQUV4RSxtRUFBaEI7QUFBQSwyQkFDSTtBQUFBO0FBQUE7QUFESixJQURZO0FBQUEsQ0FBaEI7O0FBTUEsaUVBQWV3RSxPQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUkE7QUFHQTs7OztBQU1BLElBQU1FLFVBQVUsR0FBRyxTQUFiQSxVQUFhO0FBQUEsTUFBR0MsSUFBSCxRQUFHQSxJQUFIO0FBQUEsc0JBQ2Y7QUFBSyxhQUFTLEVBQUUzRSxzRUFBaEI7QUFBQSw0QkFDSTtBQUFBO0FBQUEsTUFESixlQUVJO0FBQUEsOEJBQ0k7QUFBQSxrQ0FBYTJFLElBQUksQ0FBQ0UsTUFBbEI7QUFBQSxRQURKLGVBRUk7QUFBQSw0QkFBVUYsSUFBSSxDQUFDRyxHQUFmO0FBQUEsUUFGSjtBQUFBLE1BRko7QUFBQSxJQURlO0FBQUEsQ0FBbkI7O0FBVUEsOEVBQWVqRSwyQ0FBSSxDQUFDNkQsVUFBRCxDQUFuQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbkJBO0FBQ0E7QUFHQTs7OztBQU1BLElBQU1LLFVBQVUsR0FBRyxTQUFiQSxVQUFhO0FBQUEsTUFBR0MsS0FBSCxRQUFHQSxLQUFIO0FBQUEsc0JBQ2Y7QUFBSyxhQUFTLEVBQUVoRix3RUFBaEI7QUFBQSw0QkFDSTtBQUFBO0FBQUEsTUFESixlQUVJO0FBQUEsZ0JBQ0tnRixLQUFLLENBQUNiLEdBQU4sQ0FBVTtBQUFBLFlBQUdDLEVBQUgsU0FBR0EsRUFBSDtBQUFBLFlBQU9VLEdBQVAsU0FBT0EsR0FBUDtBQUFBLFlBQVlELE1BQVosU0FBWUEsTUFBWjtBQUFBLDRCQUNQO0FBQUEsaUNBQ0ksd0RBQUMsa0RBQUQ7QUFBTSxjQUFFLG9CQUFhVCxFQUFiLENBQVI7QUFBQSxvQ0FDSTtBQUFBLHdCQUFJUztBQUFKLGNBREosT0FDcUJDLEdBRHJCO0FBQUE7QUFESixXQUFTVixFQUFULENBRE87QUFBQSxPQUFWO0FBREwsTUFGSjtBQUFBLElBRGU7QUFBQSxDQUFuQjs7QUFlQSw4RUFBZXZELDJDQUFJLENBQUNrRSxVQUFELENBQW5COzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6QkE7QUFDQTtBQUlBO0FBRUE7Ozs7QUFPQSxJQUFNRyxTQUFTLEdBQUcsU0FBWkEsU0FBWSxPQUFpQztBQUFBLE1BQTlCakUsUUFBOEIsUUFBOUJBLFFBQThCO0FBQUEsTUFBcEJrRSxNQUFvQixRQUFwQkEsTUFBb0I7O0FBQy9DLGtCQUE0QnZFLCtDQUFRLENBQUN1RSxNQUFNLENBQUNOLE1BQVIsQ0FBcEM7QUFBQTtBQUFBLE1BQU9BLE1BQVA7QUFBQSxNQUFlTyxTQUFmOztBQUNBLG1CQUFzQnhFLCtDQUFRLENBQUN1RSxNQUFNLENBQUNMLEdBQVIsQ0FBOUI7QUFBQTtBQUFBLE1BQU9BLEdBQVA7QUFBQSxNQUFZTyxNQUFaOztBQUNBLG1CQUE0QnpFLCtDQUFRLENBQUN1RSxNQUFNLENBQUNHLE1BQVIsQ0FBcEM7QUFBQTtBQUFBLE1BQU9BLE1BQVA7QUFBQSxNQUFlQyxTQUFmOztBQUVBLE1BQU1DLGVBQWUsR0FBRyxTQUFsQkEsZUFBa0IsQ0FBQzNELENBQUQ7QUFBQSxXQUE0Q3VELFNBQVMsQ0FBQ3ZELENBQUMsQ0FBQ0MsTUFBRixDQUFTQyxLQUFWLENBQXJEO0FBQUEsR0FBeEI7O0FBQ0EsTUFBTTBELFlBQVksR0FBRyxTQUFmQSxZQUFlLENBQUM1RCxDQUFEO0FBQUEsV0FBNEN3RCxNQUFNLENBQUN4RCxDQUFDLENBQUNDLE1BQUYsQ0FBU0MsS0FBVixDQUFsRDtBQUFBLEdBQXJCOztBQUNBLE1BQU0yRCxlQUFlLEdBQUcsU0FBbEJBLGVBQWtCLENBQUM3RCxDQUFEO0FBQUEsV0FBNEMwRCxTQUFTLENBQUMsQ0FBQzFELENBQUMsQ0FBQ0MsTUFBRixDQUFTQyxLQUFYLENBQXJEO0FBQUEsR0FBeEI7O0FBRUEsTUFBTU0saUJBQWlCLEdBQUcsU0FBcEJBLGlCQUFvQixHQUFNO0FBQzVCLFFBQUl3QyxNQUFNLElBQUlDLEdBQWQsRUFBbUI7QUFDZjdELE1BQUFBLFFBQVEsQ0FDSmdFLGdFQUFjLGlDQUNQRSxNQURPO0FBRVZOLFFBQUFBLE1BQU0sRUFBTkEsTUFGVTtBQUdWQyxRQUFBQSxHQUFHLEVBQUhBLEdBSFU7QUFJVlEsUUFBQUEsTUFBTSxFQUFOQTtBQUpVLFNBRFYsQ0FBUjtBQVFILEtBVEQsTUFTTztBQUNIeEUsTUFBQUEseURBQUEsQ0FBYywrQ0FBZCxFQUErRDtBQUMzRHlCLFFBQUFBLFFBQVEsRUFBRSxZQURpRDtBQUUzREMsUUFBQUEsU0FBUyxFQUFFLElBRmdEO0FBRzNEQyxRQUFBQSxlQUFlLEVBQUUsSUFIMEM7QUFJM0RDLFFBQUFBLFlBQVksRUFBRSxJQUo2QztBQUszREMsUUFBQUEsWUFBWSxFQUFFLElBTDZDO0FBTTNEQyxRQUFBQSxTQUFTLEVBQUUsSUFOZ0Q7QUFPM0RDLFFBQUFBLFFBQVEsRUFBRUM7QUFQaUQsT0FBL0Q7QUFTSDtBQUNKLEdBckJEOztBQXNCQSxzQkFDSTtBQUFTLGFBQVMsRUFBRTlDLHNFQUFwQjtBQUFBLDRCQUNJO0FBQUE7QUFBQSxNQURKLGVBRUk7QUFBQSw4QkFDSTtBQUFPLGVBQU8sRUFBQyxZQUFmO0FBQUEsMkNBRUk7QUFDSSxjQUFJLEVBQUMsTUFEVDtBQUVJLFlBQUUsRUFBQyxZQUZQO0FBR0ksY0FBSSxFQUFDLFlBSFQ7QUFJSSxlQUFLLEVBQUU2RSxNQUpYO0FBS0ksa0JBQVEsRUFBRVc7QUFMZCxVQUZKO0FBQUEsUUFESixlQVdJO0FBQU8sZUFBTyxFQUFDLFNBQWY7QUFBQSx3Q0FFSTtBQUNJLGNBQUksRUFBQyxNQURUO0FBRUksWUFBRSxFQUFDLFNBRlA7QUFHSSxjQUFJLEVBQUMsU0FIVDtBQUlJLGVBQUssRUFBRVYsR0FKWDtBQUtJLGtCQUFRLEVBQUVXO0FBTGQsVUFGSjtBQUFBLFFBWEosZUFxQkk7QUFBTyxlQUFPLEVBQUMsWUFBZjtBQUFBLDJDQUVJO0FBQ0ksY0FBSSxFQUFDLE1BRFQ7QUFFSSxZQUFFLEVBQUMsWUFGUDtBQUdJLGNBQUksRUFBQyxZQUhUO0FBSUksZUFBSyxFQUFFSCxNQUpYO0FBS0ksa0JBQVEsRUFBRUk7QUFMZCxVQUZKO0FBQUEsUUFyQkosZUErQkk7QUFBUSxZQUFJLEVBQUMsUUFBYjtBQUFzQixlQUFPLEVBQUVyRCxpQkFBL0I7QUFBQTtBQUFBLFFBL0JKO0FBQUEsTUFGSjtBQUFBLElBREo7QUF3Q0gsQ0F2RUQ7O0FBd0VBLDhFQUFleEIsMkNBQUksQ0FBQ3FFLFNBQUQsQ0FBbkI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3RGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7O0FDTkEsaUVBQWU7QUFDWFMsRUFBQUEsSUFBSSxFQUFFLFdBREs7QUFFWEMsRUFBQUEsSUFBSSxFQUFFLElBRks7QUFHWEMsRUFBQUEsT0FBTyxFQUFFLHVCQUhFO0FBSVhDLEVBQUFBLGVBQWUsRUFBRSw4Q0FKTjtBQUtYM0YsRUFBQUEsR0FBRyxFQUFFO0FBQ0Q0RixJQUFBQSxjQUFjLEVBQUU7QUFBRUMsTUFBQUEsSUFBSSxFQUFFO0FBQVIsS0FEZjtBQUVEekYsSUFBQUEsS0FBSyxFQUFFLGNBRk47QUFHREUsSUFBQUEsV0FBVyxFQUFFLHVCQUhaO0FBSUR3RixJQUFBQSxhQUFhLEVBQUUsbUJBSmQ7QUFLREMsSUFBQUEsSUFBSSxFQUFFLENBQ0Y7QUFDSUMsTUFBQUEsSUFBSSxFQUFFLGFBRFY7QUFFSUMsTUFBQUEsT0FBTyxFQUFFO0FBRmIsS0FERTtBQUxMLEdBTE07QUFpQlhDLEVBQUFBLFVBQVUsRUFBRTtBQWpCRCxDQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBQTtBQUNBO0FBRUEsaUVBQWVHLEtBQU8sR0FBR0YsZ0RBQUgsSUFBdEI7Ozs7Ozs7Ozs7Ozs7O0FDSEEsSUFBTVYsSUFBSSxHQUFHLElBQWI7QUFDQSxJQUFNQyxPQUFPLEdBQUdXLEtBQUEsOEJBQTJDWixJQUEzQyxJQUFvRCxDQUFwRTtBQUVBLGlFQUFlO0FBQ1hBLEVBQUFBLElBQUksRUFBSkEsSUFEVztBQUVYRCxFQUFBQSxJQUFJLEVBQUUsU0FGSztBQUdYRSxFQUFBQSxPQUFPLEVBQVBBO0FBSFcsQ0FBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDSEE7QUFFQTtBQUNBO0FBR0E7QUFDQTtBQUNBO0FBQ0E7Ozs7QUFJQSxTQUFTaUIsT0FBVCxDQUNJQyxXQURKLEVBRUlDLGVBRkosRUFHRTtBQUNFLE1BQU0vRixRQUFRLEdBQUcwRix3REFBVyxFQUE1Qjs7QUFDQSxxQkFBNkIvQyx3REFBVyxDQUFDbUQsV0FBRCxFQUFjbEQscURBQWQsQ0FBeEM7QUFBQSxNQUFRb0QsV0FBUixnQkFBUUEsV0FBUjtBQUFBLE1BQXFCbEQsR0FBckIsZ0JBQXFCQSxHQUFyQixDQUZGLENBSUU7OztBQUNBMkMsRUFBQUEsZ0RBQVMsQ0FBQyxZQUFNO0FBQ1p6RixJQUFBQSxRQUFRLENBQUMrRixlQUFlLEVBQWhCLENBQVIsQ0FEWSxDQUVaO0FBQ0gsR0FIUSxFQUdOLENBQUMvRixRQUFELENBSE0sQ0FBVDtBQUtBLFNBQU8sWUFBTTtBQUNULFFBQUksQ0FBQ2dHLFdBQUQsSUFBZ0JBLFdBQVcsS0FBSyxNQUFoQyxJQUEwQ0EsV0FBVyxLQUFLLFNBQTlELEVBQ0ksb0JBQU87QUFBQTtBQUFBLE1BQVA7QUFFSixRQUFJQSxXQUFXLEtBQUssU0FBcEIsRUFBK0Isb0JBQU87QUFBQTtBQUFBLE1BQVA7QUFFL0Isd0JBQU8sdURBQUMsbURBQUQ7QUFBWSxTQUFHLEVBQUVsRDtBQUFqQixNQUFQO0FBQ0gsR0FQRDtBQVFIOztBQUVELElBQU1tRCxJQUFlLEdBQUcsU0FBbEJBLElBQWtCLEdBQW1CO0FBQ3ZDLE1BQU1qRyxRQUFRLEdBQUcwRix3REFBVyxFQUE1QjtBQUNBLHNCQUNJO0FBQUssYUFBUyxFQUFFM0csZ0VBQWhCO0FBQUEsNEJBQ0ksdURBQUMsZ0RBQUQ7QUFBUSxXQUFLLEVBQUM7QUFBZCxNQURKLGVBRUksdURBQUMsaURBQUQ7QUFBVSxjQUFRLEVBQUVpQjtBQUFwQixNQUZKLEVBSUs2RixPQUFPLENBQUMsVUFBQzFELEtBQUQ7QUFBQSxhQUFxQkEsS0FBSyxDQUFDWSxVQUEzQjtBQUFBLEtBQUQsRUFBd0M0QyxvRUFBeEMsQ0FBUCxFQUpMO0FBQUEsSUFESjtBQVdILENBYkQsRUFlQTs7O0FBQ08sSUFBTVEsUUFBUSxHQUFHLFNBQVhBLFFBQVc7QUFBQSxTQUFrQixDQUN0Q1Asc0VBQW9CLEVBRGtCLEVBRXRDRCx3RUFBcUIsRUFGaUIsQ0FHdEM7QUFIc0MsR0FBbEI7QUFBQSxDQUFqQjtBQU1QLDhFQUFlL0YsMkNBQUksQ0FBQ3FHLElBQUQsQ0FBbkI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDMURBO0FBRUE7QUFDQTs7QUFFQSxJQUFNQSxJQUFJLEdBQUdHLDBEQUFRO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBLGVBQUM7QUFBQSxXQUFNLCtIQUFOO0FBQUEsR0FBRDtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFDO0FBQUQ7O0FBQUE7QUFBQTtBQUFBLEdBQXlCO0FBQzFDQyxFQUFBQSxRQUFRLGVBQUUsdURBQUMsZ0RBQUQ7QUFEZ0MsQ0FBekIsQ0FBckI7QUFJQSxpRUFBZSxVQUFDbkUsS0FBRDtBQUFBLHNCQUNYLHVEQUFDLHNEQUFEO0FBQUEsMkJBQ0ksdURBQUMsSUFBRCxvQkFBVUEsS0FBVjtBQURKLElBRFc7QUFBQSxDQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDVEE7QUFFQTs7QUFHQSxJQUFNb0UsU0FBUyxHQUFHRiwwREFBUTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQSxlQUFDO0FBQUEsV0FBTSx3S0FBTjtBQUFBLEdBQUQ7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBQztBQUFEOztBQUFBO0FBQUE7QUFBQSxHQUE4QjtBQUNwREMsRUFBQUEsUUFBUSxlQUFFLHVEQUFDLGdEQUFEO0FBRDBDLENBQTlCLENBQTFCO0FBSUEsaUVBQWUsVUFBQ25FLEtBQUQ7QUFBQSxzQkFDWCx1REFBQyxzREFBRDtBQUFBLDJCQUNJLHVEQUFDLFNBQUQsb0JBQWVBLEtBQWY7QUFESixJQURXO0FBQUEsQ0FBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNUQTtBQUVBO0FBQ0E7QUFHQTtBQUNBO0FBQ0E7Ozs7QUFJQSxJQUFNc0UsVUFBVSxHQUFHLFNBQWJBLFVBQWEsT0FBbUM7QUFBQSxNQUFoQ0MsS0FBZ0MsUUFBaENBLEtBQWdDO0FBQ2xELE1BQVlDLEtBQVosR0FBc0JELEtBQUssQ0FBQ0UsTUFBNUIsQ0FBUXhELEVBQVI7QUFDQSxNQUFNQSxFQUFFLEdBQUcsQ0FBQ3VELEtBQVo7QUFDQSxNQUFNMUcsUUFBUSxHQUFHMEYsd0RBQVcsRUFBNUI7QUFDQSxNQUFNeEIsTUFBTSxHQUFHdkIsd0RBQVcsQ0FBQyxVQUFDUixLQUFEO0FBQUEsV0FBcUJBLEtBQUssQ0FBQytCLE1BQTNCO0FBQUEsR0FBRCxFQUFvQ3RCLHFEQUFwQyxDQUExQjtBQUVBNkMsRUFBQUEsZ0RBQVMsQ0FBQyxZQUFNO0FBQ1p6RixJQUFBQSxRQUFRLENBQUN1RyxnRUFBaUIsQ0FBQ3BELEVBQUQsQ0FBbEIsQ0FBUjtBQUNILEdBRlEsRUFFTixDQUFDbkQsUUFBRCxFQUFXbUQsRUFBWCxDQUZNLENBQVQ7O0FBSUEsTUFBTXlELFVBQVUsR0FBRyxTQUFiQSxVQUFhLEdBQU07QUFDckIsUUFBTUMsVUFBVSxHQUFHM0MsTUFBbkI7QUFFQSxRQUFJLENBQUMyQyxVQUFELElBQWVBLFVBQVUsQ0FBQ2IsV0FBWCxLQUEyQixTQUE5QyxFQUF5RCxvQkFBTztBQUFBO0FBQUEsTUFBUDtBQUV6RCxRQUFJYSxVQUFVLENBQUNiLFdBQVgsS0FBMkIsU0FBM0IsSUFBd0MsQ0FBQ2EsVUFBVSxDQUFDQyxNQUF4RCxFQUNJLG9CQUFPO0FBQUE7QUFBQSxNQUFQO0FBRUosd0JBQ0k7QUFBQSw4QkFDSSx1REFBQyxtREFBRDtBQUFZLFlBQUksRUFBRUQsVUFBVSxDQUFDQztBQUE3QixRQURKLGVBRUksdURBQUMsa0RBQUQ7QUFBVyxnQkFBUSxFQUFFOUcsUUFBckI7QUFBK0IsY0FBTSxFQUFFNkcsVUFBVSxDQUFDQztBQUFsRCxRQUZKO0FBQUEsTUFESjtBQU1ILEdBZEQ7O0FBZ0JBLHNCQUNJO0FBQUssYUFBUyxFQUFFL0gsa0VBQWhCO0FBQUEsNEJBQ0ksdURBQUMsZ0RBQUQ7QUFBUSxXQUFLLEVBQUM7QUFBZCxNQURKLEVBRUs2SCxVQUFVLEVBRmY7QUFBQSxJQURKO0FBTUgsQ0FoQ0Q7O0FBc0NPLElBQU1ULFFBQVEsR0FBRyxTQUFYQSxRQUFXO0FBQUEsTUFBR1EsTUFBSCxTQUFHQSxNQUFIO0FBQUEsU0FBMEMsQ0FBQ0osZ0VBQWlCLENBQUNJLE1BQU0sQ0FBQ3hELEVBQVIsQ0FBbEIsQ0FBMUM7QUFBQSxDQUFqQjtBQUVQLDhFQUFldkQsMkNBQUksQ0FBQzRHLFVBQUQsQ0FBbkI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcERBO0FBRUE7QUFDQTs7QUFFQSxJQUFNQSxVQUFVLEdBQUdKLDBEQUFRO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBLGVBQUM7QUFBQSxXQUFNLGlKQUFOO0FBQUEsR0FBRDtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQUFDO0FBQUQ7O0FBQUE7QUFBQTtBQUFBLEdBQStCO0FBQ3REQyxFQUFBQSxRQUFRLGVBQUUsdURBQUMsZ0RBQUQ7QUFENEMsQ0FBL0IsQ0FBM0I7QUFJQSxpRUFBZSxVQUFDbkUsS0FBRDtBQUFBLHNCQUNYLHVEQUFDLHNEQUFEO0FBQUEsMkJBQ0ksdURBQUMsVUFBRCxvQkFBZ0JBLEtBQWhCO0FBREosSUFEVztBQUFBLENBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNUQTtBQUVBO0FBRUE7Ozs7QUFJQSxJQUFNNkUsUUFBUSxHQUFHLFNBQVhBLFFBQVcsT0FBOEI7QUFBQSxNQUEzQkMsYUFBMkIsUUFBM0JBLGFBQTJCO0FBQzNDO0FBQ0E7O0FBQ0E7QUFDQSxNQUFJQSxhQUFKLEVBQW1CQSxhQUFhLENBQUNDLFVBQWQsR0FBMkIsR0FBM0I7QUFFbkIsc0JBQ0k7QUFBSyxhQUFTLEVBQUVsSSx3RUFBaEI7QUFBQSw0QkFDSSx1REFBQyxnREFBRDtBQUFRLFdBQUssRUFBQztBQUFkLE1BREosZUFFSTtBQUFBO0FBQUEsTUFGSjtBQUFBLElBREo7QUFNSCxDQVpEOztBQWNBLDhFQUFlYSwyQ0FBSSxDQUFDbUgsUUFBRCxDQUFuQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdEJBO0FBRUE7O0FBR0EsSUFBTUcsWUFBWSxHQUFHZCwwREFBUTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQSxlQUFDO0FBQUEsV0FBTSx1TEFBTjtBQUFBLEdBQUQ7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FBQztBQUFEOztBQUFBO0FBQUE7QUFBQSxHQUFpQztBQUMxREMsRUFBQUEsUUFBUSxlQUFFLHVEQUFDLGdEQUFEO0FBRGdELENBQWpDLENBQTdCO0FBSUEsaUVBQWUsVUFBQ25FLEtBQUQ7QUFBQSxzQkFDWCx1REFBQyxzREFBRDtBQUFBLDJCQUNJLHVEQUFDLFlBQUQsb0JBQWtCQSxLQUFsQjtBQURKLElBRFc7QUFBQSxDQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNUQTtBQUNBO0FBQ0E7QUFFQSxJQUFNbUYsYUFBcUIsR0FBR0YsK0NBQU0sRUFBcEM7QUFFQUUsYUFBYSxDQUFDQyxHQUFkLENBQWtCLFVBQUNDLE9BQUQsRUFBbUJDLFFBQW5CLEVBQXVDQyxLQUF2QyxFQUErRDtBQUM3RSxNQUFNQyxRQUFRLEdBQUdILE9BQU8sQ0FBQ0ksV0FBUixDQUFvQkMsT0FBcEIsQ0FBNEIsTUFBNUIsRUFBb0MsRUFBcEMsQ0FBakI7QUFDQSxNQUFNQyxZQUFvQixHQUFHVCx5Q0FBQSxpREFBc0RNLFFBQXRELEVBQTdCO0FBQ0FGLEVBQUFBLFFBQVEsQ0FBQ08sU0FBVCxDQUFtQixjQUFuQixFQUFtQyxXQUFuQztBQUNBLFNBQU9QLFFBQVEsQ0FBQ1EsUUFBVCxDQUFrQkgsWUFBbEIsQ0FBUDtBQUNILENBTEQ7QUFPQSxpRUFBZVIsYUFBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNYQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQSxpRUFBZSxDQUNYO0FBQ0lrQixFQUFBQSxTQUFTLEVBQUV2Siw0Q0FEZjtBQUVJUyxFQUFBQSxNQUFNLEVBQUUsQ0FDSjtBQUNJMkgsSUFBQUEsSUFBSSxFQUFFLEdBRFY7QUFFSW9CLElBQUFBLEtBQUssRUFBRSxJQUZYO0FBR0lELElBQUFBLFNBQVMsRUFBRU4sbURBSGY7QUFHMEI7QUFDdEI5QixJQUFBQSxRQUFRLEVBQUUrQixpREFKZCxDQUk0Qjs7QUFKNUIsR0FESSxFQU9KO0FBQ0lkLElBQUFBLElBQUksRUFBRSxpQkFEVjtBQUVJbUIsSUFBQUEsU0FBUyxFQUFFSix5REFGZjtBQUdJaEMsSUFBQUEsUUFBUSxFQUFFaUMsdURBQWtCQTtBQUhoQyxHQVBJLEVBWUo7QUFDSWhCLElBQUFBLElBQUksRUFBRSxRQURWO0FBRUltQixJQUFBQSxTQUFTLEVBQUVGLG9EQUFLQTtBQUZwQixHQVpJLEVBZ0JKO0FBQ0lqQixJQUFBQSxJQUFJLEVBQUUsV0FEVjtBQUVJbUIsSUFBQUEsU0FBUyxFQUFFRCx1REFBUUE7QUFGdkIsR0FoQkksRUFvQko7QUFDSUMsSUFBQUEsU0FBUyxFQUFFeEIsdURBQVFBO0FBRHZCLEdBcEJJO0FBRlosQ0FEVyxDQUFmOzs7Ozs7Ozs7Ozs7Ozs7O0FDUkE7QUFFQSxpRUFBZSxVQUFDMkIsR0FBRCxFQUF3QjtBQUNuQyxNQUFNQyxPQUFPLEdBQUdDLG1CQUFPLENBQUMsd0JBQUQsQ0FBdkI7O0FBQ0EsTUFBTUMsYUFBYSxHQUFHRCxpR0FBdEI7O0FBQ0EsTUFBTUcsUUFBUSxHQUFHSixPQUFPLENBQUNFLGFBQUQsQ0FBeEI7O0FBQ0EsTUFBTUcsUUFBUSxHQUFHSixtQkFBTyxDQUFDLHNEQUFELENBQVAsQ0FBa0NHLFFBQWxDLEVBQTRDO0FBQ3pERSxJQUFBQSxPQUFPLEVBQUU7QUFBRSxxQ0FBK0I7QUFBakMsS0FEZ0Q7QUFFekRDLElBQUFBLGdCQUFnQixFQUFFO0FBRnVDLEdBQTVDLENBQWpCOztBQUtBUixFQUFBQSxHQUFHLENBQUNwQixHQUFKLENBQVEwQixRQUFSO0FBQ0FOLEVBQUFBLEdBQUcsQ0FBQ3BCLEdBQUosQ0FDSXNCLG1CQUFPLENBQUMsc0RBQUQsQ0FBUCxDQUFrQ0csUUFBbEMsRUFBNEM7QUFDeENJLElBQUFBLEdBQUcsRUFBRSxLQURtQztBQUV4Qy9CLElBQUFBLElBQUksRUFBRSxnQkFGa0M7QUFHeENnQyxJQUFBQSxTQUFTLEVBQUUsS0FBSztBQUh3QixHQUE1QyxDQURKO0FBUUFKLEVBQUFBLFFBQVEsQ0FBQ0ssY0FBVCxDQUF3QixZQUFNO0FBQzFCQyxJQUFBQSxPQUFPLENBQUNDLElBQVIsQ0FBYWQsa0RBQUEsQ0FBWSxrQ0FBWixDQUFiO0FBQ0gsR0FGRDtBQUdILENBckJEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0hBLElBQU1nQixpQkFBaUIsR0FBRyxLQUExQjtBQUVBLElBQU1DLEtBQW1DLEdBQUcsRUFBNUM7QUFDQSxJQUFNQyxTQUEwQyxHQUFHLEVBQW5EO0FBRWUsU0FBU0MsU0FBVCxDQUFvQ0MsU0FBcEMsRUFBNEQ7QUFHdkVGLEVBQUFBLFNBQVMsQ0FBQ0UsU0FBRCxDQUFULEdBQXVCLENBQXZCO0FBU0EsTUFBTUMsVUFBdUIsR0FBRyxFQUFoQzs7QUFadUUsV0FjeERDLGNBZHdEO0FBQUE7QUFBQTs7QUFBQTtBQUFBLDBMQWN2RSxpQkFBOEJDLElBQTlCLEVBQW1EQyxJQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0NBQ1csSUFBSUMsT0FBSixDQUNILFVBQUNwQyxPQUFELEVBQTRDcUMsTUFBNUMsRUFBa0Y7QUFDOUVMLGdCQUFBQSxVQUFVLENBQUNNLElBQVgsQ0FBZ0I7QUFBRUgsa0JBQUFBLElBQUksRUFBSkEsSUFBRjtBQUFRRCxrQkFBQUEsSUFBSSxFQUFKQSxJQUFSO0FBQWNsQyxrQkFBQUEsT0FBTyxFQUFQQSxPQUFkO0FBQXVCcUMsa0JBQUFBLE1BQU0sRUFBTkE7QUFBdkIsaUJBQWhCOztBQUNBLG9CQUFJTCxVQUFVLENBQUNPLE1BQVgsS0FBc0IsQ0FBMUIsRUFBNkI7QUFDekJDLGtCQUFBQSxZQUFZLENBQUNSLFVBQVUsQ0FBQyxDQUFELENBQVgsQ0FBWjtBQUNIO0FBQ0osZUFORSxDQURYOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBZHVFO0FBQUE7QUFBQTs7QUF5QnZFLFdBQVNTLGtCQUFULEdBQW9DO0FBQ2hDVCxJQUFBQSxVQUFVLENBQUNVLEtBQVg7O0FBQ0EsUUFBSVYsVUFBVSxDQUFDLENBQUQsQ0FBZCxFQUFtQjtBQUNmUSxNQUFBQSxZQUFZLENBQUNSLFVBQVUsQ0FBQyxDQUFELENBQVgsQ0FBWjtBQUNIO0FBQ0o7O0FBRUQsV0FBU1EsWUFBVCxDQUFzQkcsU0FBdEIsRUFBa0Q7QUFDOUMsUUFBUVIsSUFBUixHQUF3Q1EsU0FBeEMsQ0FBUVIsSUFBUjtBQUFBLFFBQWNELElBQWQsR0FBd0NTLFNBQXhDLENBQWNULElBQWQ7QUFBQSxRQUFvQmxDLE9BQXBCLEdBQXdDMkMsU0FBeEMsQ0FBb0IzQyxPQUFwQjtBQUFBLFFBQTZCcUMsTUFBN0IsR0FBd0NNLFNBQXhDLENBQTZCTixNQUE3Qjs7QUFDQSxRQUFJSCxJQUFJLEtBQUssTUFBYixFQUFxQjtBQUNqQixVQUFNVSxHQUFHLEdBQUcsQ0FBQyxJQUFJQyxJQUFKLEVBQWI7O0FBQ0EsVUFBSUQsR0FBRyxHQUFHZixTQUFTLENBQUNFLFNBQUQsQ0FBVCxHQUF1QkosaUJBQWpDLEVBQW9EO0FBQ2hEM0IsUUFBQUEsT0FBTyxDQUFDNEIsS0FBSyxDQUFDRyxTQUFELENBQU4sQ0FBUDtBQUNBVSxRQUFBQSxrQkFBa0I7QUFDckIsT0FIRCxNQUdPO0FBQ0hOLFFBQUFBLElBQUksR0FDQ1csSUFETCxDQUNVLFVBQUNDLEdBQUQsRUFBMEI7QUFDNUJuQixVQUFBQSxLQUFLLENBQUNHLFNBQUQsQ0FBTCxHQUFtQmdCLEdBQW5CO0FBQ0FsQixVQUFBQSxTQUFTLENBQUNFLFNBQUQsQ0FBVCxHQUF1QmEsR0FBdkI7QUFDQTVDLFVBQUFBLE9BQU8sQ0FBQytDLEdBQUQsQ0FBUDtBQUNILFNBTEwsRUFNS0MsS0FOTCxDQU1XWCxNQU5YLEVBT0tZLE9BUEwsQ0FPYVIsa0JBUGI7QUFRSDtBQUNKLEtBZkQsTUFlTztBQUNIWixNQUFBQSxTQUFTLENBQUNFLFNBQUQsQ0FBVCxHQUF1QixDQUF2QjtBQUNBSSxNQUFBQSxJQUFJLEdBQUdXLElBQVAsQ0FBWTlDLE9BQVosRUFBcUJnRCxLQUFyQixDQUEyQlgsTUFBM0IsRUFBbUNZLE9BQW5DLENBQTJDUixrQkFBM0M7QUFDSDtBQUNKOztBQUVELFNBQU9SLGNBQVA7QUFDSDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzdERDtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBRUEsSUFBTXFCLFNBQVMsR0FBR2hFLG1EQUFBLENBQWFpRSxPQUFPLENBQUNDLEdBQVIsRUFBYixFQUE0QixxQkFBNUIsQ0FBbEI7QUFJZSxTQUFTQyxZQUFULENBSWIxQixTQUphLEVBSU0yQixRQUpOLEVBSThCO0FBQ3pDLE1BQU16QixjQUFjLEdBQUdILHNEQUFTLENBQUNDLFNBQUQsQ0FBaEM7O0FBRHlDLFdBRzFCNEIsT0FIMEI7QUFBQTtBQUFBOztBQUFBO0FBQUEsbUxBR3pDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnREFFVzFCLGNBQWMsQ0FBQyxNQUFELG1MQUFTO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBQ04yQixTQUFTLEVBREg7O0FBQUE7QUFDcEJDLHdCQUFBQSxLQURvQjtBQUFBO0FBQUEsK0JBSU5BLEtBQUssQ0FBQ0MsT0FBTixFQUpNOztBQUFBO0FBSXBCQyx3QkFBQUEsSUFKb0I7QUFLcEJDLHdCQUFBQSxRQUxvQixHQUtFLEVBTEY7O0FBQUEsNEJBTXJCRCxJQUFJLENBQUMsQ0FBRCxDQU5pQjtBQUFBO0FBQUE7QUFBQTs7QUFBQSw4QkFPaEIsSUFBSUUsS0FBSiw0Q0FBOENsQyxTQUE5QyxFQVBnQjs7QUFBQTtBQVNwQm1DLHdCQUFBQSxLQVRvQixHQVNaaEIsa0RBQUEsQ0FBT2EsSUFBSSxDQUFDLENBQUQsQ0FBWCxFQUFnQkssTUFBTSxDQUFDQyxJQUFQLENBQVlYLFFBQVosQ0FBaEIsQ0FUWTtBQVUxQkssd0JBQUFBLElBQUksQ0FBQ3JCLEtBQUw7QUFDQXFCLHdCQUFBQSxJQUFJLENBQUNPLE9BQUwsQ0FBYSxVQUFDQyxHQUFELEVBQVM7QUFDbEIsOEJBQU1DLGtCQUFrQixHQUFHdEIsa0RBQUEsQ0FBT3FCLEdBQVAsRUFBWUgsTUFBTSxDQUFDQyxJQUFQLENBQVlYLFFBQVosQ0FBWixDQUEzQjs7QUFJQSw4QkFBTWUsT0FBTyxHQUFHQyxZQUFZLENBQUNGLGtCQUFELEVBQXFCTixLQUFyQixDQUE1Qjs7QUFDQSw4QkFBSU8sT0FBTyxLQUFLMUssU0FBaEIsRUFBMkI7QUFDdkJpSyw0QkFBQUEsUUFBUSxDQUFDMUIsSUFBVCxDQUFjbUMsT0FBZDtBQUNIO0FBQ0oseUJBVEQ7QUFYMEIseURBc0JuQlQsUUF0Qm1COztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVQsR0FGekI7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FIeUM7QUFBQTtBQUFBOztBQUFBLFdBK0IxQlcsR0EvQjBCO0FBQUE7QUFBQTs7QUFBQTtBQUFBLCtLQStCekMsa0JBQW1CQyxRQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUV1QmpCLE9BQU8sRUFGOUI7O0FBQUE7QUFFVWtCLGNBQUFBLElBRlY7QUFBQSxnREFHV0EsSUFBSSxDQUFDQyxJQUFMLENBQVUsVUFBQ0wsT0FBRDtBQUFBLHVCQUFhQSxPQUFPLENBQUNwSixFQUFSLEtBQWV1SixRQUE1QjtBQUFBLGVBQVYsQ0FIWDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQS9CeUM7QUFBQTtBQUFBOztBQUFBLFdBcUMxQkcsT0FyQzBCO0FBQUE7QUFBQTs7QUFBQTtBQUFBLG1MQXFDekMsa0JBQXVCZixRQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0RBQ1cvQixjQUFjLENBQUMsU0FBRCxtTEFBWTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFDVDJCLFNBQVMsRUFEQTs7QUFBQTtBQUN2QkMsd0JBQUFBLEtBRHVCO0FBQUE7QUFBQSwrQkFJVkEsS0FBSyxDQUFDQyxPQUFOLEVBSlU7O0FBQUE7QUFJdkJDLHdCQUFBQSxJQUp1Qjs7QUFBQSw0QkFLeEJBLElBQUksQ0FBQyxDQUFELENBTG9CO0FBQUE7QUFBQTtBQUFBOztBQUFBLDhCQU1uQixJQUFJRSxLQUFKLDRDQUE4Q2xDLFNBQTlDLEVBTm1COztBQUFBO0FBUXZCbUMsd0JBQUFBLEtBUnVCLEdBUWZoQixrREFBQSxDQUFPYSxJQUFJLENBQUMsQ0FBRCxDQUFYLEVBQWdCSyxNQUFNLENBQUNDLElBQVAsQ0FBWUwsUUFBUSxDQUFDLENBQUQsQ0FBUixJQUFlLEVBQTNCLENBQWhCLENBUmUsRUFhN0I7O0FBQUE7QUFDSWdCLHdCQUFBQSxLQWR5QixHQWNqQixDQWRpQixFQWU3Qjs7QUFBQTtBQWY2QiwrREFnQlBoQixRQWhCTztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBZ0JsQlMsa0NBQUFBLE9BaEJrQjtBQWlCbkJGLGtDQUFBQSxHQWpCbUIsR0FpQmJSLElBQUksQ0FBQ2lCLEtBQUQsQ0FqQlM7QUFrQm5CQyxrQ0FBQUEsY0FsQm1CLEdBa0JGQyxnQkFBZ0IsQ0FBQ1QsT0FBRCxFQUFVUCxLQUFWLENBbEJkOztBQUFBLHNDQW9CcEJLLEdBcEJvQjtBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBLHlDQXNCZlYsS0FBSyxDQUFDc0IsTUFBTixDQUFhRixjQUFiLENBdEJlOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQXdCZlosa0NBQUFBLElBeEJlLEdBd0JSRCxNQUFNLENBQUNDLElBQVAsQ0FBWVksY0FBWixDQXhCUTtBQXlCZkcsa0NBQUFBLFNBekJlLEdBeUJIbEMsbURBQUEsQ0FDZG1CLElBRGMsRUFFZCxVQUFDaUIsR0FBRDtBQUFBLDJDQUF3QmYsR0FBRyxDQUFDZSxHQUFELENBQUgsS0FBdUJMLGNBQWMsQ0FBQ0ssR0FBRCxDQUE3RDtBQUFBLG1DQUZjLENBekJHOztBQUFBLHNDQTZCaEJGLFNBN0JnQjtBQUFBO0FBQUE7QUFBQTs7QUE4QmpCZixrQ0FBQUEsSUFBSSxDQUFDQyxPQUFMLENBQWEsVUFBQ2dCLEdBQUQsRUFBUztBQUNsQmYsb0NBQUFBLEdBQUcsQ0FBQ2UsR0FBRCxDQUFILEdBQVdMLGNBQWMsQ0FBQ0ssR0FBRCxDQUF6QjtBQUNILG1DQUZELEVBOUJpQixDQWlDakI7O0FBakNpQjtBQUFBLHlDQWtDWGYsR0FBRyxDQUFDZ0IsSUFBSixFQWxDVzs7QUFBQTtBQXNDekJQLGtDQUFBQSxLQUFLLElBQUksQ0FBVDs7QUF0Q3lCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7O0FBQUE7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7O0FBQUE7O0FBQUE7QUFBQTs7QUFBQTs7QUFBQTs7QUFBQTtBQTBDcEJRLHdCQUFBQSxXQTFDb0IsR0EwQ04zQixLQUFLLENBQUM0QixRQUFOLEdBQWlCLENBMUNYOztBQUFBO0FBQUEsOEJBMENjRCxXQUFXLElBQUlSLEtBMUM3QjtBQUFBO0FBQUE7QUFBQTs7QUFBQSw2QkEyQ3JCakIsSUFBSSxDQUFDeUIsV0FBRCxDQTNDaUI7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSwrQkE2Q2Z6QixJQUFJLENBQUN5QixXQUFELENBQUosQ0FBa0JFLE1BQWxCLEVBN0NlOztBQUFBO0FBMENvQ0Ysd0JBQUFBLFdBQVcsSUFBSSxDQTFDbkQ7QUFBQTtBQUFBOztBQUFBO0FBQUEsMERBaUR0QixJQWpEc0I7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBWixHQUR6Qjs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQXJDeUM7QUFBQTtBQUFBOztBQUFBLFdBMkYxQkcsR0EzRjBCO0FBQUE7QUFBQTs7QUFBQTtBQUFBLCtLQTJGekMsa0JBQW1CbEIsT0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUNTQSxPQURUO0FBQUE7QUFBQTtBQUFBOztBQUFBLGdEQUVlMUssU0FGZjs7QUFBQTtBQUFBLGdEQUlXa0ksY0FBYyxDQUFDLEtBQUQsbUxBQVE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFDTDJCLFNBQVMsRUFESjs7QUFBQTtBQUNuQkMsd0JBQUFBLEtBRG1CO0FBQUE7QUFBQSwrQkFJTkEsS0FBSyxDQUFDQyxPQUFOLEVBSk07O0FBQUE7QUFJbkJDLHdCQUFBQSxJQUptQjs7QUFBQSw0QkFLcEJBLElBQUksQ0FBQyxDQUFELENBTGdCO0FBQUE7QUFBQTtBQUFBOztBQUFBLDhCQU1mLElBQUlFLEtBQUosNENBQThDbEMsU0FBOUMsRUFOZTs7QUFBQTtBQVFuQm1DLHdCQUFBQSxLQVJtQixHQVFYaEIsa0RBQUEsQ0FBT2EsSUFBSSxDQUFDLENBQUQsQ0FBWCxFQUFnQkssTUFBTSxDQUFDQyxJQUFQLENBQVlJLE9BQU8sSUFBSSxFQUF2QixDQUFoQixDQVJXO0FBWXpCVix3QkFBQUEsSUFBSSxDQUFDckIsS0FBTCxHQVp5QixDQWN6Qjs7QUFBQTtBQUNNdUMsd0JBQUFBLGNBZm1CLEdBZUZDLGdCQUFnQixDQUFDVCxPQUFELEVBQVVQLEtBQVYsQ0FmZDtBQWdCbkJLLHdCQUFBQSxHQWhCbUIsR0FnQmJSLElBQUksQ0FBQ2UsSUFBTCxDQUFVLFVBQUNjLE9BQUQ7QUFBQSxpQ0FBYSxDQUFDQSxPQUFPLENBQUN2SyxFQUFULEtBQWdCb0osT0FBTyxDQUFDcEosRUFBckM7QUFBQSx5QkFBVixDQWhCYTs7QUFBQSw0QkFpQnBCa0osR0FqQm9CO0FBQUE7QUFBQTtBQUFBOztBQUFBLDBEQWtCZHhLLFNBbEJjOztBQUFBO0FBb0J6QnFLLHdCQUFBQSxNQUFNLENBQUN5QixNQUFQLENBQWN0QixHQUFkLEVBQW1CVSxjQUFuQjtBQXBCeUI7QUFBQSwrQkFxQm5CVixHQUFHLENBQUNnQixJQUFKLEVBckJtQjs7QUFBQTtBQUFBLDBEQXNCbEJkLE9BdEJrQjs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFSLEdBSnpCOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBM0Z5QztBQUFBO0FBQUE7O0FBQUEsV0F5SDFCcUIsR0F6SDBCO0FBQUE7QUFBQTs7QUFBQTtBQUFBLCtLQXlIekMsa0JBQW1CQyxjQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBQ1NBLGNBRFQ7QUFBQTtBQUFBO0FBQUE7O0FBQUEsaURBRWVoTSxTQUZmOztBQUFBO0FBQUEsaURBSVdrSSxjQUFjLENBQUMsS0FBRCxtTEFBUTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUNMMkIsU0FBUyxFQURKOztBQUFBO0FBQ25CQyx3QkFBQUEsS0FEbUI7QUFBQTtBQUFBLCtCQUlOQSxLQUFLLENBQUNDLE9BQU4sRUFKTTs7QUFBQTtBQUluQkMsd0JBQUFBLElBSm1COztBQUFBLDRCQUtwQkEsSUFBSSxDQUFDLENBQUQsQ0FMZ0I7QUFBQTtBQUFBO0FBQUE7O0FBQUEsOEJBTWYsSUFBSUUsS0FBSiw0Q0FBOENsQyxTQUE5QyxFQU5lOztBQUFBO0FBUW5CbUMsd0JBQUFBLEtBUm1CO0FBU3JCN0ksMEJBQUFBLEVBQUUsRUFBRTtBQVRpQiwyQkFVakI2SCxrREFBQSxDQUFPYSxJQUFJLENBQUMsQ0FBRCxDQUFYLEVBQWdCSyxNQUFNLENBQUNDLElBQVAsQ0FBWTBCLGNBQWMsSUFBSSxFQUE5QixDQUFoQixDQVZpQixHQWdCekI7O0FBQUE7QUFDQWhDLHdCQUFBQSxJQUFJLENBQUNyQixLQUFMO0FBQ01zRCx3QkFBQUEsU0FsQm1CLEdBa0JQakMsSUFBSSxDQUFDa0MsTUFBTCxDQUFZLFVBQUM1SyxFQUFELEVBQWFrSixHQUFiO0FBQUEsaUNBQXFCMkIsSUFBSSxDQUFDQyxHQUFMLENBQVM5SyxFQUFULEVBQWEsQ0FBQ2tKLEdBQUcsQ0FBQ2xKLEVBQUwsSUFBVyxDQUF4QixDQUFyQjtBQUFBLHlCQUFaLEVBQTZELENBQTdELENBbEJPO0FBbUJuQm9KLHdCQUFBQSxPQW5CbUI7QUFtQlBwSiwwQkFBQUEsRUFBRSxFQUFFMkssU0FBUyxHQUFHO0FBbkJULDJCQW1CZUQsY0FuQmYsR0FxQnpCOztBQUFBO0FBQ01kLHdCQUFBQSxjQXRCbUIsR0FzQkZDLGdCQUFnQixDQUFDVCxPQUFELEVBQVVQLEtBQVYsQ0F0QmQ7QUFBQTtBQUFBLCtCQXVCbkJMLEtBQUssQ0FBQ3NCLE1BQU4sQ0FBYUYsY0FBYixDQXZCbUI7O0FBQUE7QUFBQSwwREF5QmxCUixPQXpCa0I7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBUixHQUp6Qjs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQXpIeUM7QUFBQTtBQUFBOztBQUFBLFdBMEoxQmIsU0ExSjBCO0FBQUE7QUFBQTs7QUFBQTtBQUFBLHFMQTBKekM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ1V3QyxjQUFBQSxHQURWLEdBQ2dCLElBQUkvQyxpRUFBSixDQUFzQiw4Q0FBdEIsQ0FEaEI7QUFBQTtBQUFBLHFCQUV3QkQsaURBQUEsQ0FBWUUsU0FBWixDQUZ4Qjs7QUFBQTtBQUVVZ0QsY0FBQUEsS0FGVjtBQUFBO0FBQUEscUJBSVVGLEdBQUcsQ0FBQ0cscUJBQUosQ0FBMEJDLElBQUksQ0FBQ0MsS0FBTCxDQUFXSCxLQUFLLENBQUMzTCxRQUFOLEVBQVgsQ0FBMUIsQ0FKVjs7QUFBQTtBQUFBO0FBQUEscUJBS1V5TCxHQUFHLENBQUNNLFFBQUosRUFMVjs7QUFBQTtBQUFBLGlEQU1XTixHQUFHLENBQUNPLGFBQUosQ0FBa0I1RSxTQUFsQixDQU5YOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBMUp5QztBQUFBO0FBQUE7O0FBbUt6QyxXQUFTMkMsWUFBVCxDQUNJa0MsVUFESixFQUVJMUMsS0FGSixFQUdXO0FBQ1AsUUFBTTJDLFdBQVcsR0FBRzNELG9EQUFBLENBQ2hCZ0IsS0FEZ0IsRUFFaEIsVUFBQ08sT0FBRCxFQUFldkMsSUFBZixFQUE2QjRFLElBQTdCLEVBQThDO0FBQzFDLFVBQU1DLE9BQWUsR0FBR0gsVUFBVSxDQUFDRSxJQUFELENBQWxDOztBQUNBLGNBQVE1RSxJQUFSO0FBQ0ksYUFBSyxRQUFMO0FBQ0l1QyxVQUFBQSxPQUFPLENBQUNxQyxJQUFELENBQVAsR0FBZ0JDLE9BQWhCO0FBQ0E7O0FBRUosYUFBSyxRQUFMO0FBQ0l0QyxVQUFBQSxPQUFPLENBQUNxQyxJQUFELENBQVAsR0FBZ0IsQ0FBQ0MsT0FBakI7QUFDQTs7QUFFSixhQUFLLFNBQUw7QUFDSXRDLFVBQUFBLE9BQU8sQ0FBQ3FDLElBQUQsQ0FBUCxHQUFnQkMsT0FBTyxLQUFLLEdBQVosSUFBbUJBLE9BQU8sS0FBSyxFQUEvQztBQUNBOztBQUVKLGFBQUssTUFBTDtBQUNJO0FBQ0EsY0FBTUMsU0FBUyxHQUFHRCxPQUFPLENBQUNwSSxLQUFSLENBQWMsZ0NBQWQsQ0FBbEI7O0FBQ0EsY0FBSXFJLFNBQUosRUFBZTtBQUNYdkMsWUFBQUEsT0FBTyxDQUFDcUMsSUFBRCxDQUFQLEdBQWdCLElBQUlqRSxJQUFKLENBQ1osQ0FBQ21FLFNBQVMsQ0FBQyxDQUFELENBREUsRUFFWixDQUFDQSxTQUFTLENBQUMsQ0FBRCxDQUFWLEdBQWdCLENBRkosRUFHWixDQUFDQSxTQUFTLENBQUMsQ0FBRCxDQUhFLENBQWhCO0FBS0E7QUFDSDs7QUFDRCxnQkFBTSxJQUFJL0MsS0FBSixvQ0FBc0M4QyxPQUF0QyxFQUFOOztBQUVKO0FBQ0k7QUFDQSxjQUFNRSxjQUFjLEdBQUcvRSxJQUFJLENBQUN2RCxLQUFMLENBQ25CLDRDQURtQixDQUF2Qjs7QUFHQSxjQUFJLENBQUNzSSxjQUFMLEVBQXFCO0FBQ2pCLGtCQUFNLElBQUloRCxLQUFKLGtDQUFvQy9CLElBQXBDLEVBQU47QUFDSDs7QUFDRCxjQUFJLENBQUM2RSxPQUFMLEVBQWM7QUFDVnRDLFlBQUFBLE9BQU8sQ0FBQ3FDLElBQUQsQ0FBUCxHQUFnQixFQUFoQjtBQUNILFdBRkQsTUFFTztBQUNILGdCQUFNSSxTQUFTLEdBQUdELGNBQWMsQ0FBQyxDQUFELENBQWhDO0FBQ0EsZ0JBQU1FLFNBQVMsR0FBR0YsY0FBYyxDQUFDLENBQUQsQ0FBaEM7O0FBRUEsb0JBQVFDLFNBQVI7QUFDSSxtQkFBSyxRQUFMO0FBQ0l6QyxnQkFBQUEsT0FBTyxDQUFDcUMsSUFBRCxDQUFQLEdBQWdCQyxPQUFPLENBQUMzTixLQUFSLENBQWMrTixTQUFkLENBQWhCO0FBQ0E7O0FBRUosbUJBQUssUUFBTDtBQUNJMUMsZ0JBQUFBLE9BQU8sQ0FBQ3FDLElBQUQsQ0FBUCxHQUFnQjVELGlEQUFBLENBQU02RCxPQUFPLENBQUMzTixLQUFSLENBQWMrTixTQUFkLENBQU4sRUFBZ0MsVUFBQ3BFLEdBQUQ7QUFBQSx5QkFBUyxDQUFDQSxHQUFWO0FBQUEsaUJBQWhDLENBQWhCO0FBQ0E7O0FBRUosbUJBQUssU0FBTDtBQUNJMEIsZ0JBQUFBLE9BQU8sQ0FBQ3FDLElBQUQsQ0FBUCxHQUFnQjVELGlEQUFBLENBQ1o2RCxPQUFPLENBQUMzTixLQUFSLENBQWMrTixTQUFkLENBRFksRUFFWixVQUFDcEUsR0FBRDtBQUFBLHlCQUFTQSxHQUFHLEtBQUssR0FBUixJQUFlQSxHQUFHLEtBQUssRUFBaEM7QUFBQSxpQkFGWSxDQUFoQjtBQUlBOztBQUVKLG1CQUFLLE1BQUw7QUFDSTtBQUNBLG9CQUFNcUUsUUFBUSxHQUFHTCxPQUFPLENBQUMzTixLQUFSLENBQWMrTixTQUFkLENBQWpCO0FBQ0ExQyxnQkFBQUEsT0FBTyxDQUFDcUMsSUFBRCxDQUFQLEdBQWdCLEVBQWhCLENBSEosQ0FJSTs7QUFDQSxvQkFBTU8sV0FBVyxHQUFHRCxRQUFRLENBQUMvQixLQUFULENBQWUsVUFBQ2lDLE9BQUQsRUFBYTtBQUM1QyxzQkFBTUMsY0FBYyxHQUFHRCxPQUFPLENBQUMzSSxLQUFSLENBQ25CLGdDQURtQixDQUF2Qjs7QUFHQSxzQkFBSSxDQUFDNEksY0FBTCxFQUFxQjtBQUNqQiwyQkFBTyxLQUFQO0FBQ0g7O0FBQ0Q5QyxrQkFBQUEsT0FBTyxDQUFDcUMsSUFBRCxDQUFQLENBQWN4RSxJQUFkLENBQ0ksSUFBSU8sSUFBSixDQUNJLENBQUMwRSxjQUFjLENBQUMsQ0FBRCxDQURuQixFQUVJLENBQUNBLGNBQWMsQ0FBQyxDQUFELENBQWYsR0FBcUIsQ0FGekIsRUFHSSxDQUFDQSxjQUFjLENBQUMsQ0FBRCxDQUhuQixDQURKO0FBT0EseUJBQU8sSUFBUDtBQUNILGlCQWZtQixDQUFwQjs7QUFnQkEsb0JBQUksQ0FBQ0YsV0FBTCxFQUFrQjtBQUNkLHdCQUFNLElBQUlwRCxLQUFKLDJDQUNpQzhDLE9BRGpDLEVBQU47QUFHSDs7QUFDRDs7QUFDSjtBQUNJLHNCQUFNLElBQUk5QyxLQUFKLDhCQUFnQ2lELFNBQWhDLEVBQU47QUE1Q1I7QUE4Q0g7O0FBdEZUOztBQXdGQSxhQUFPekMsT0FBUDtBQUNILEtBN0ZlLEVBOEZoQitCLElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNnQixTQUFMLENBQWU5RCxRQUFmLENBQVgsQ0E5RmdCLENBQXBCOztBQWdHQSxXQUFPbUQsV0FBUDtBQUNIOztBQUVELFdBQVMzQixnQkFBVCxDQUNJVCxPQURKLEVBRUlQLEtBRkosRUFHaUM7QUFDN0IsUUFBTTBDLFVBQXlDLEdBQUcxRCxvREFBQSxDQUM5Q2dCLEtBRDhDLEVBRTlDLFVBQUNNLGtCQUFELEVBQW9EdEMsSUFBcEQsRUFBa0U0RSxJQUFsRSxFQUFtRjtBQUMvRSxVQUFNOU4sS0FBSyxHQUFHeUwsT0FBTyxDQUFDcUMsSUFBRCxDQUFyQjs7QUFDQSxjQUFRNUUsSUFBUjtBQUNJLGFBQUssUUFBTDtBQUNJc0MsVUFBQUEsa0JBQWtCLENBQUNzQyxJQUFELENBQWxCLEdBQTRDVyxXQUFXLFdBQUl6TyxLQUFKLEVBQXZEO0FBQ0E7O0FBRUosYUFBSyxRQUFMO0FBQ0l3TCxVQUFBQSxrQkFBa0IsQ0FBQ3NDLElBQUQsQ0FBbEIsYUFBK0M5TixLQUEvQztBQUNBOztBQUVKLGFBQUssU0FBTDtBQUNJd0wsVUFBQUEsa0JBQWtCLENBQUNzQyxJQUFELENBQWxCLEdBQTRDOU4sS0FBSyxHQUFHLEdBQUgsR0FBUyxFQUExRDtBQUNBOztBQUVKLGFBQUssTUFBTDtBQUNJd0wsVUFBQUEsa0JBQWtCLENBQUNzQyxJQUFELENBQWxCLEdBQTRDWSxlQUFlLENBQUMxTyxLQUFELENBQTNEO0FBQ0E7O0FBRUo7QUFDSTtBQUNBLGNBQU1pTyxjQUFjLEdBQUcvRSxJQUFJLENBQUN2RCxLQUFMLENBQ25CLDRDQURtQixDQUF2Qjs7QUFHQSxjQUFJLENBQUNzSSxjQUFELElBQW1CLENBQUMvRCxxREFBQSxDQUFVbEssS0FBVixDQUF4QixFQUEwQztBQUN0QyxrQkFBTSxJQUFJaUwsS0FBSixDQUNGLDREQURFLENBQU47QUFHSCxXQVRMLENBVUk7OztBQUNBLGNBQU1pRCxTQUFTLEdBQUdELGNBQWMsQ0FBQyxDQUFELENBQWhDLENBWEosQ0FZSTs7QUFDQSxjQUFNRSxTQUFTLEdBQUdGLGNBQWMsQ0FBQyxDQUFELENBQWhDOztBQUVBLGtCQUFRQyxTQUFSO0FBQ0ksaUJBQUssUUFBTDtBQUNJLGtCQUFJLENBQUNoRSxtREFBQSxDQUFRbEssS0FBUixFQUFla0ssd0RBQWYsQ0FBTCxFQUFpQztBQUM3QixzQkFBTSxJQUFJZSxLQUFKLHdCQUEwQmpMLEtBQTFCLHNCQUFOO0FBQ0g7O0FBQ0R3TCxjQUFBQSxrQkFBa0IsQ0FBQ3NDLElBQUQsQ0FBbEIsR0FBNENXLFdBQVcsQ0FDbkR6TyxLQUFLLENBQUNpQixJQUFOLENBQVdrTixTQUFYLENBRG1ELENBQXZEO0FBR0E7O0FBRUosaUJBQUssUUFBTDtBQUNJLGtCQUFJLENBQUNqRSxtREFBQSxDQUFRbEssS0FBUixFQUFla0ssd0RBQWYsQ0FBTCxFQUFpQztBQUM3QixzQkFBTSxJQUFJZSxLQUFKLHdCQUEwQmpMLEtBQTFCLHNCQUFOO0FBQ0g7O0FBQ0R3TCxjQUFBQSxrQkFBa0IsQ0FBQ3NDLElBQUQsQ0FBbEIsR0FBNEM5TixLQUFLLENBQUNpQixJQUFOLENBQVdrTixTQUFYLENBQTVDO0FBQ0E7O0FBRUosaUJBQUssU0FBTDtBQUNJLGtCQUFJLENBQUNqRSxtREFBQSxDQUFRbEssS0FBUixFQUFla0sseURBQWYsQ0FBTCxFQUFrQztBQUM5QixzQkFBTSxJQUFJZSxLQUFKLHdCQUEwQmpMLEtBQTFCLHVCQUFOO0FBQ0g7O0FBQ0R3TCxjQUFBQSxrQkFBa0IsQ0FBQ3NDLElBQUQsQ0FBbEIsR0FBNEM1RCxpREFBQSxDQUFNbEssS0FBTixFQUFhLFVBQUMrSixHQUFEO0FBQUEsdUJBQ3JEQSxHQUFHLEdBQUcsR0FBSCxHQUFTLEVBRHlDO0FBQUEsZUFBYixFQUUxQzlJLElBRjBDLENBRXJDa04sU0FGcUMsQ0FBNUM7QUFHQTs7QUFFSixpQkFBSyxNQUFMO0FBQ0ksa0JBQUksQ0FBQ2pFLG1EQUFBLENBQVFsSyxLQUFSLEVBQWVrSyxzREFBZixDQUFMLEVBQStCO0FBQzNCLHNCQUFNLElBQUllLEtBQUosd0JBQTBCakwsS0FBMUIsb0JBQU47QUFDSDs7QUFDRHdMLGNBQUFBLGtCQUFrQixDQUFDc0MsSUFBRCxDQUFsQixHQUE0QzVELGlEQUFBLENBQ3hDbEssS0FEd0MsRUFFeEMsVUFBQytKLEdBQUQ7QUFBQSxpQ0FDT0EsR0FBRyxDQUFDaUYsT0FBSixFQURQLGNBRVFqRixHQUFHLENBQUNrRixRQUFKLEtBQWlCLENBRnpCLGNBR1FsRixHQUFHLENBQUNtRixXQUFKLEVBSFI7QUFBQSxlQUZ3QyxFQU0xQ2pPLElBTjBDLENBTXJDa04sU0FOcUMsQ0FBNUM7QUFPQTs7QUFFSjtBQUNJLG9CQUFNLElBQUlsRCxLQUFKLDhCQUFnQ2lELFNBQWhDLEVBQU47QUF4Q1I7O0FBaENSOztBQTRFQSxhQUFPMUMsa0JBQVA7QUFDSCxLQWpGNkMsRUFrRjlDZ0MsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ2dCLFNBQUwsQ0FBZS9DLE9BQWYsQ0FBWCxDQWxGOEMsQ0FBbEQ7O0FBcUZBLFdBQU9tQyxVQUFQO0FBQ0g7O0FBRUQsV0FBU2EsV0FBVCxDQUFxQnpPLEtBQXJCLEVBQTRDO0FBQ3hDLFdBQU9BLEtBQUssQ0FBQzhHLE9BQU4sQ0FBYyxLQUFkLEVBQXFCLEVBQXJCLENBQVA7QUFDSDs7QUFFRCxXQUFTNEgsZUFBVCxDQUF5QjFPLEtBQXpCLEVBQWlEO0FBQzdDLFFBQUltUCxJQUFKOztBQUNBLFFBQUluUCxLQUFLLFlBQVk2SixJQUFyQixFQUEyQjtBQUN2QnNGLE1BQUFBLElBQUksR0FBR25QLEtBQVA7QUFDSCxLQUZELE1BRU8sSUFBSSxPQUFPQSxLQUFQLEtBQWlCLFFBQXJCLEVBQStCO0FBQ2xDLFVBQUk7QUFDQW1QLFFBQUFBLElBQUksR0FBRyxJQUFJdEYsSUFBSixDQUFTN0osS0FBVCxDQUFQO0FBQ0gsT0FGRCxDQUVFLE9BQU9GLENBQVAsRUFBVTtBQUNSLGNBQU0sSUFBSW1MLEtBQUosQ0FBVSw4Q0FBVixDQUFOO0FBQ0g7QUFDSixLQU5NLE1BTUE7QUFDSCxZQUFNLElBQUlBLEtBQUosQ0FBVSx1Q0FBVixDQUFOO0FBQ0g7O0FBQ0QscUJBQVVrRSxJQUFJLENBQUNILE9BQUwsRUFBVixjQUE0QkcsSUFBSSxDQUFDRixRQUFMLEtBQWtCLENBQTlDLGNBQW1ERSxJQUFJLENBQUNELFdBQUwsRUFBbkQ7QUFDSDs7QUFFRCxTQUFPO0FBQUV2RSxJQUFBQSxPQUFPLEVBQVBBLE9BQUY7QUFBV2dCLElBQUFBLEdBQUcsRUFBSEEsR0FBWDtBQUFnQkksSUFBQUEsT0FBTyxFQUFQQSxPQUFoQjtBQUF5QlksSUFBQUEsR0FBRyxFQUFIQSxHQUF6QjtBQUE4QkcsSUFBQUEsR0FBRyxFQUFIQTtBQUE5QixHQUFQO0FBQ0g7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMxWUQ7QUFDQTs7QUFFQSwyQkFBK0RzQyw2REFBbUIsQ0FHaEYsZ0JBSGdGLEVBRzlELElBQUlDLG1EQUFKLEVBSDhELENBQWxGO0FBQUEsSUFBUUMsY0FBUix3QkFBUUEsY0FBUjtBQUFBLElBQXdCQyxVQUF4Qix3QkFBd0JBLFVBQXhCO0FBQUEsSUFBb0NDLFVBQXBDLHdCQUFvQ0EsVUFBcEM7QUFBQSxJQUFnREMsVUFBaEQsd0JBQWdEQSxVQUFoRDs7QUFLTyxJQUFNQyxZQUFZLEdBQUdKLGNBQWMsRUFBbkM7QUFFQSxJQUFNSyxRQUFRLEdBQUdKLFVBQVUsRUFBM0I7QUFFQSxJQUFNSyxRQUFRLEdBQUdILFVBQVUsRUFBM0I7QUFFQSxJQUFNSSxRQUFRLEdBQUdMLFVBQVUsRUFBM0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2JQO0FBRWUsU0FBU0osbUJBQVQsQ0FJYnJHLFNBSmEsRUFJTTJCLFFBSk4sRUFJOEI7QUFDekMsc0JBQW1DRCxzREFBWSxDQUFDMUIsU0FBRCxFQUFZMkIsUUFBWixDQUEvQztBQUFBLE1BQVFpQixHQUFSLGlCQUFRQSxHQUFSO0FBQUEsTUFBYWhCLE9BQWIsaUJBQWFBLE9BQWI7QUFBQSxNQUFzQm1DLEdBQXRCLGlCQUFzQkEsR0FBdEI7QUFBQSxNQUEyQkgsR0FBM0IsaUJBQTJCQSxHQUEzQjs7QUFFQSxXQUFTMkMsY0FBVCxHQUEwQjtBQUN0QjtBQUFBLHFMQUFPLGlCQUNIUSxRQURHLEVBRUhwSixRQUZHLEVBR0hDLEtBSEc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU13QmdFLE9BQU8sRUFOL0I7O0FBQUE7QUFNT0ssZ0JBQUFBLFFBTlA7O0FBT0Msb0JBQUlBLFFBQUosRUFBYztBQUNWdEUsa0JBQUFBLFFBQVEsQ0FBQ3FKLE1BQVQsQ0FBZ0IsR0FBaEIsRUFBcUJDLElBQXJCLENBQTBCaEYsUUFBMUI7QUFDSDs7QUFURjtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQVdDdEUsZ0JBQUFBLFFBQVEsQ0FBQ3FKLE1BQVQsQ0FBZ0IsR0FBaEIsRUFBcUJDLElBQXJCOztBQVhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BQVA7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFjSDs7QUFFRCxXQUFTVCxVQUFULEdBQXNCO0FBQ2xCO0FBQUEsc0xBQU8sa0JBQU85SSxPQUFQLEVBQXlCQyxRQUF6QixFQUE2Q0MsS0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFT3RFLGdCQUFBQSxFQUZQLEdBRVk0TixRQUFRLENBQUN4SixPQUFPLENBQUN5SixLQUFSLENBQWM3TixFQUFmLEVBQTZCLEVBQTdCLENBQVIsSUFBNEMsQ0FBQyxDQUZ6RDtBQUFBO0FBQUEsdUJBR3dCc0osR0FBRyxDQUFDdEosRUFBRCxDQUgzQjs7QUFBQTtBQUdPMkksZ0JBQUFBLFFBSFA7O0FBSUMsb0JBQUlBLFFBQUosRUFBYztBQUNWdEUsa0JBQUFBLFFBQVEsQ0FBQ3FKLE1BQVQsQ0FBZ0IsR0FBaEIsRUFBcUJDLElBQXJCLENBQTBCaEYsUUFBMUI7QUFDSDs7QUFORjtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQVFDdEUsZ0JBQUFBLFFBQVEsQ0FBQ3FKLE1BQVQsQ0FBZ0IsR0FBaEIsRUFBcUJDLElBQXJCOztBQVJEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BQVA7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFXSDs7QUFFRCxXQUFTUCxVQUFULEdBQXNCO0FBQ2xCO0FBQUEsc0xBQU8sa0JBQU9oSixPQUFQLEVBQXlCQyxRQUF6QixFQUE2Q0MsS0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUV1Qm1HLEdBQUcsQ0FBQ3JHLE9BQU8sQ0FBQzBKLElBQVQsQ0FGMUI7O0FBQUE7QUFFTzFFLGdCQUFBQSxPQUZQOztBQUdDLG9CQUFJQSxPQUFKLEVBQWE7QUFDVC9FLGtCQUFBQSxRQUFRLENBQUNxSixNQUFULENBQWdCLEdBQWhCLEVBQXFCQyxJQUFyQixDQUEwQnZFLE9BQTFCO0FBQ0g7O0FBTEY7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFPQy9FLGdCQUFBQSxRQUFRLENBQUNxSixNQUFULENBQWdCLEdBQWhCLEVBQXFCQyxJQUFyQjs7QUFQRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUFQOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBVUg7O0FBRUQsV0FBU1IsVUFBVCxHQUFzQjtBQUNsQjtBQUFBLHNMQUFPLGtCQUFPL0ksT0FBUCxFQUF5QkMsUUFBekIsRUFBNkNDLEtBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFdUJnRyxHQUFHLENBQUNsRyxPQUFPLENBQUMwSixJQUFULENBRjFCOztBQUFBO0FBRU8xRSxnQkFBQUEsT0FGUDs7QUFHQyxvQkFBSUEsT0FBSixFQUFhO0FBQ1QvRSxrQkFBQUEsUUFBUSxDQUFDcUosTUFBVCxDQUFnQixHQUFoQixFQUFxQkMsSUFBckIsQ0FBMEJ2RSxPQUExQjtBQUNIOztBQUxGO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBT0MvRSxnQkFBQUEsUUFBUSxDQUFDcUosTUFBVCxDQUFnQixHQUFoQixFQUFxQkMsSUFBckI7O0FBUEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FBUDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVVIOztBQUVELFNBQU87QUFBRVQsSUFBQUEsVUFBVSxFQUFWQSxVQUFGO0FBQWNFLElBQUFBLFVBQVUsRUFBVkEsVUFBZDtBQUEwQkgsSUFBQUEsY0FBYyxFQUFkQSxjQUExQjtBQUEwQ0UsSUFBQUEsVUFBVSxFQUFWQTtBQUExQyxHQUFQO0FBQ0g7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwRUQ7QUFDQTs7QUFFQSwyQkFBK0RKLDZEQUFtQixDQUdoRixVQUhnRixFQUdwRSxJQUFJZ0IscURBQUosRUFIb0UsQ0FBbEY7QUFBQSxJQUFRZCxjQUFSLHdCQUFRQSxjQUFSO0FBQUEsSUFBd0JDLFVBQXhCLHdCQUF3QkEsVUFBeEI7QUFBQSxJQUFvQ0MsVUFBcEMsd0JBQW9DQSxVQUFwQztBQUFBLElBQWdEQyxVQUFoRCx3QkFBZ0RBLFVBQWhEOztBQUtPLElBQU1ZLGFBQWEsR0FBR2YsY0FBYyxFQUFwQztBQUVBLElBQU1nQixTQUFTLEdBQUdmLFVBQVUsRUFBNUI7QUFFQSxJQUFNZ0IsU0FBUyxHQUFHZCxVQUFVLEVBQTVCO0FBRUEsSUFBTWUsU0FBUyxHQUFHaEIsVUFBVSxFQUE1Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2RQO0FBQ0E7O0FBRUEsMkJBQStESiw2REFBbUIsQ0FHaEYsU0FIZ0YsRUFHckUsSUFBSXFCLHFEQUFKLEVBSHFFLENBQWxGO0FBQUEsSUFBUW5CLGNBQVIsd0JBQVFBLGNBQVI7QUFBQSxJQUF3QkMsVUFBeEIsd0JBQXdCQSxVQUF4QjtBQUFBLElBQW9DQyxVQUFwQyx3QkFBb0NBLFVBQXBDO0FBQUEsSUFBZ0RDLFVBQWhELHdCQUFnREEsVUFBaEQ7O0FBS08sSUFBTWlCLGFBQWEsR0FBR3BCLGNBQWMsRUFBcEM7QUFFQSxJQUFNcUIsU0FBUyxHQUFHcEIsVUFBVSxFQUE1QjtBQUVBLElBQU1xQixTQUFTLEdBQUduQixVQUFVLEVBQTVCO0FBRUEsSUFBTW9CLFNBQVMsR0FBR3JCLFVBQVUsRUFBNUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDZFA7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUEsSUFBTTVILEdBQUcsR0FBR2tKLDhDQUFPLEVBQW5CLEVBRUE7O0FBQ0FsSixHQUFHLENBQUNwQixHQUFKLENBQVF5Syw2Q0FBTSxDQUFDO0FBQUVTLEVBQUFBLHFCQUFxQixFQUFFO0FBQXpCLENBQUQsQ0FBZCxHQUNBOztBQUNBOUosR0FBRyxDQUFDcEIsR0FBSixDQUFRMEssMENBQUcsRUFBWCxHQUNBOztBQUNBdEosR0FBRyxDQUFDcEIsR0FBSixDQUFRd0ssa0RBQVcsRUFBbkIsR0FFQTs7QUFDQSxJQUFJLEtBQUosRUFBYyxHQUlkOzs7QUFDQXBKLEdBQUcsQ0FBQ3BCLEdBQUosQ0FBUXVLLDZDQUFNLENBQUMsS0FBRCxFQUFRO0FBQUVZLEVBQUFBLElBQUksRUFBRSxjQUFDQyxJQUFELEVBQU9DLEdBQVA7QUFBQSxXQUFlQSxHQUFHLENBQUMxTCxVQUFKLEdBQWlCLEdBQWhDO0FBQUE7QUFBUixDQUFSLENBQWQ7QUFDQXlCLEdBQUcsQ0FBQ3BCLEdBQUosQ0FBUTJLLG9EQUFPLENBQUM3SyxtREFBQSxDQUFhaUUsT0FBTyxDQUFDQyxHQUFSLEVBQWIsRUFBNEIsb0JBQTVCLENBQUQsQ0FBZjtBQUNBNUMsR0FBRyxDQUFDcEIsR0FBSixDQUFRc0ssd0RBQUEsQ0FBZXhLLG1EQUFBLENBQWFpRSxPQUFPLENBQUNDLEdBQVIsRUFBYixFQUE0QixRQUE1QixDQUFmLENBQVIsR0FFQTs7QUFDQSxJQUFJL0YsSUFBSixFQUFhNk0sdURBQVMsQ0FBQzFKLEdBQUQsQ0FBVDtBQUViQSxHQUFHLENBQUNwQixHQUFKLENBQVFzSyxtREFBQSxFQUFSLEdBRUE7O0FBQ0FsSixHQUFHLENBQUNtSyxJQUFKLENBQVMsaUJBQVQsRUFBNEJOLDhEQUE1QjtBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUNBN0osR0FBRyxDQUFDK0QsR0FBSixDQUFRLGdCQUFSLEVBQTBCMEUsMkRBQTFCO0FBQ0F6SSxHQUFHLENBQUMrRCxHQUFKLENBQVEsZUFBUixFQUF5QitELDBEQUF6QjtBQUNBOUgsR0FBRyxDQUFDbUssSUFBSixDQUFTLFdBQVQsRUFBc0JuQyxzREFBdEIsR0FFQTs7QUFDQWhJLEdBQUcsQ0FBQytELEdBQUosQ0FBUSxZQUFSLEVBQXNCNkYsNENBQXRCLEVBQWdEYix3REFBaEQ7QUFDQS9JLEdBQUcsQ0FBQ21LLElBQUosQ0FBUyxZQUFULEVBQXVCUCw0Q0FBdkIsRUFBaURYLHdEQUFqRCxHQUVBOztBQUNBakosR0FBRyxDQUFDK0QsR0FBSixDQUFRLEdBQVIsRUFBYTRGLDZDQUFiO0FBRUE7QUFDQTtBQUNBOztBQUVBLElBQU1TLE9BQU8sR0FBRyxDQUFDO0FBQUVDLEVBQUFBLFFBQVEsRUFBRSxNQUFaO0FBQW9CQyxFQUFBQSxNQUFNLEVBQUVkLDhDQUFBLENBQWtCeEosR0FBbEI7QUFBNUIsQ0FBRCxDQUFoQjtBQU1BLElBQU13SyxTQUFpQixHQUFHLENBQ3RCO0FBQ0k7QUFDQTlGLEVBQUFBLEdBQUcsRUFBRSw2REFGVDtBQUdJK0YsRUFBQUEsSUFBSSxFQUFFO0FBSFYsQ0FEc0IsRUFNdEI7QUFDSTtBQUNBL0YsRUFBQUEsR0FBRyxFQUFFLG9CQUZUO0FBR0krRixFQUFBQSxJQUFJLEVBQUU7QUFIVixDQU5zQixDQUExQjtBQVlBLElBQU1DLGFBQStCLEdBQUdGLFNBQVMsQ0FBQ3RHLElBQVYsQ0FBZSxVQUFDeUcsUUFBRDtBQUFBLFNBQ25Eckksb0RBQUEsQ0FBUXFJLFFBQVIsRUFBa0IsVUFBQ0MsT0FBRDtBQUFBLFdBQXFCcEksMkNBQUEsQ0FBY29JLE9BQWQsQ0FBckI7QUFBQSxHQUFsQixDQURtRDtBQUFBLENBQWYsQ0FBeEM7O0FBR0EsSUFBSUYsYUFBSixFQUFtQjtBQUNmLE1BQU1JLFlBQVksR0FBR3hJLHdEQUFBLENBQVlvSSxhQUFaLEVBQTJCLFVBQUNFLE9BQUQ7QUFBQSxXQUFxQnBJLDZDQUFBLENBQWdCb0ksT0FBaEIsQ0FBckI7QUFBQSxHQUEzQixDQUFyQjs7QUFFQVIsRUFBQUEsT0FBTyxDQUFDMUksSUFBUixDQUFhO0FBQUUySSxJQUFBQSxRQUFRLEVBQUUsT0FBWjtBQUFxQkMsSUFBQUEsTUFBTSxFQUFFYiwrQ0FBQSxDQUFtQnFCLFlBQW5CLEVBQWlDOUssR0FBakM7QUFBN0IsR0FBYjtBQUNIO0FBRUQ7QUFDQTtBQUNBOzs7QUFDQW9LLE9BQU8sQ0FBQzFHLE9BQVIsQ0FBZ0IsZ0JBQTBCO0FBQUEsTUFBdkIyRyxRQUF1QixRQUF2QkEsUUFBdUI7QUFBQSxNQUFiQyxNQUFhLFFBQWJBLE1BQWE7QUFDdENBLEVBQUFBLE1BQU0sQ0FBQ1csTUFBUCxDQUFjWixRQUFRLEtBQUssTUFBYixHQUFzQmpVLHFEQUF0QixHQUE0Q0EscURBQVIsR0FBc0IsQ0FBeEU7QUFDQWtVLEVBQUFBLE1BQU0sQ0FBQ1ksRUFBUCxDQUFVLE9BQVYsRUFBbUJDLE9BQW5CO0FBQ0FiLEVBQUFBLE1BQU0sQ0FBQ1ksRUFBUCxDQUFVLFdBQVYsRUFBdUI7QUFBQSxXQUFNRSxXQUFXLENBQUNkLE1BQUQsQ0FBakI7QUFBQSxHQUF2QjtBQUNILENBSkQ7QUFNQTtBQUNBO0FBQ0E7O0FBRUEsU0FBU2EsT0FBVCxDQUFpQnpSLEtBQWpCLEVBQTZCO0FBQ3pCLE1BQUlBLEtBQUosRUFBVztBQUNQa0gsSUFBQUEsT0FBTyxDQUFDbEgsS0FBUixDQUFjcUcsZ0RBQUEsb0NBQTRCckcsS0FBNUIsRUFBZDtBQUNIO0FBQ0o7QUFFRDtBQUNBO0FBQ0E7OztBQUVBLFNBQVMwUixXQUFULENBQXFCZCxNQUFyQixFQUFrQztBQUM5QixNQUFNZ0IsSUFBSSxHQUFHaEIsTUFBTSxDQUFDaUIsT0FBUCxFQUFiO0FBQ0EsTUFBTUMsSUFBSSxHQUFHLE9BQU9GLElBQVAsS0FBZ0IsUUFBaEIsa0JBQW1DQSxJQUFuQyxtQkFBb0RBLElBQUksQ0FBQ0csSUFBekQsQ0FBYjtBQUNBN0ssRUFBQUEsT0FBTyxDQUFDbEgsS0FBUixDQUFjcUcsa0RBQUEsaUNBQXFDeUwsSUFBckMsRUFBZDtBQUNIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMxSEQ7QUFDQTtBQUVBLGlFQUFlLFVBQ1hJLElBRFcsRUFFWEMsU0FGVyxFQUdYQyxXQUhXLEVBSVhDLFlBSlcsRUFLTDtBQUNOLE1BQU1DLElBQUksOENBRUZKLElBQUksQ0FBQ3hQLGNBQUwsQ0FBb0JyQyxRQUFwQixFQUZFLDJZQVlKNlIsSUFBSSxDQUFDaFYsS0FBTCxDQUFXbUQsUUFBWCxFQVpJLHVCQWFKNlIsSUFBSSxDQUFDSyxJQUFMLENBQVVsUyxRQUFWLEVBYkksdUJBY0o2UixJQUFJLENBQUNyUCxJQUFMLENBQVV4QyxRQUFWLEVBZEksdUJBZUo2UixJQUFJLENBQUNNLElBQUwsQ0FBVW5TLFFBQVYsRUFmSSxpRkFrQko4UixTQUFTLENBQUNNLFdBQVYsRUFsQkksdUJBbUJKTixTQUFTLENBQUNPLFlBQVYsRUFuQkksOElBdUJpQk4sV0F2QmpCLG9VQTZCdUJKLDJEQUFTLENBQUNLLFlBQUQsQ0E3QmhDLHdHQWlDSkYsU0FBUyxDQUFDUSxhQUFWLEVBakNJLHVCQWtDSlQsSUFBSSxDQUFDVSxNQUFMLENBQVl2UyxRQUFaLEVBbENJLHFDQUFWLENBRE0sQ0F3Q047O0FBQ0EsTUFBTXdTLFlBQVksR0FBRztBQUNqQkMsSUFBQUEsa0JBQWtCLEVBQUUsSUFESDtBQUVqQkMsSUFBQUEsY0FBYyxFQUFFLElBRkM7QUFHakJDLElBQUFBLG1CQUFtQixFQUFFLElBSEo7QUFJakJDLElBQUFBLFNBQVMsRUFBRSxJQUpNO0FBS2pCQyxJQUFBQSxRQUFRLEVBQUUsSUFMTztBQU1qQkMsSUFBQUEsVUFBVSxFQUFFO0FBTkssR0FBckIsQ0F6Q00sQ0FrRE47O0FBQ0EsU0FBT2hRLEtBQU8sR0FBR21QLElBQUgsR0FBVUwsQ0FBeEI7QUFDSCxDQXpERDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNKQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBSUEsSUFBSXNCLFlBQUo7QUFDQUMsU0FBUyxJQUFHOztBQUVMLFNBQVN0RCxNQUFULENBQWdCL0ssT0FBaEIsRUFBNENDLFFBQTVDLEVBQWdFcU8sSUFBaEUsRUFBMEY7QUFDN0YsTUFBSSxDQUFDRixZQUFMLEVBQW1CO0FBQ2ZuTyxJQUFBQSxRQUFRLENBQUNxSixNQUFULENBQWdCLEdBQWhCLEVBQXFCQyxJQUFyQixDQUEwQjtBQUN0QjFPLE1BQUFBLEtBQUssRUFBRTtBQURlLEtBQTFCO0FBR0E7QUFDSDs7QUFFRCxNQUFNMFQsUUFBUSxHQUFHdk8sT0FBTyxDQUFDMEIsT0FBUixDQUFnQjhNLGFBQWpDO0FBQ0EsTUFBTUMsS0FBSyxHQUFHRixRQUFRLElBQUlBLFFBQVEsQ0FBQzVVLEtBQVQsQ0FBZSxJQUFmLEVBQXFCLENBQXJCLENBQTFCO0FBRUFzVSxFQUFBQSxvREFBTSxDQUFDUSxLQUFELEVBQVFMLFlBQVIsRUFBc0IsVUFBQ00sVUFBRCxFQUFrQkMsT0FBbEIsRUFBbUM7QUFDM0QsUUFBSUQsVUFBSixFQUFnQjtBQUNaek8sTUFBQUEsUUFBUSxDQUFDcUosTUFBVCxDQUFnQixHQUFoQixFQUFxQkMsSUFBckIsQ0FBMEI7QUFDdEIxTyxRQUFBQSxLQUFLLEVBQUU7QUFEZSxPQUExQjtBQUdBO0FBQ0g7O0FBQ0Q4VCxJQUFBQSxPQUFPLENBQUNDLElBQVIsQ0FBYXZPLE9BQWIsQ0FBcUIsWUFBckIsRUFBbUMsWUFBbkM7QUFDQUosSUFBQUEsUUFBUSxDQUFDNE8sTUFBVCxDQUFnQkMsR0FBaEIsR0FBc0JILE9BQXRCO0FBQ0FMLElBQUFBLElBQUk7QUFDUCxHQVZLLENBQU47QUFXSDs7U0FFY0Q7Ozs7O21MQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUNTRCxZQURUO0FBQUE7QUFBQTtBQUFBOztBQUVjVyxZQUFBQSxXQUZkLEdBRTRCbFAsbURBQUEsQ0FBYWlFLE9BQU8sQ0FBQ0MsR0FBUixFQUFiLEVBQTRCLHdCQUE1QixDQUY1QjtBQUFBO0FBQUE7QUFBQSxtQkFLd0NKLGlEQUFBLENBQVlvTCxXQUFaLENBTHhDOztBQUFBO0FBS2tCQyxZQUFBQSxhQUxsQjtBQU1ZWixZQUFBQSxZQUFZLEdBQUdZLGFBQWEsSUFBSWpJLElBQUksQ0FBQ0MsS0FBTCxDQUFXZ0ksYUFBYSxDQUFDOVQsUUFBZCxFQUFYLEVBQXFDK1QsTUFBckU7QUFOWjtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQVFZYixZQUFBQSxZQUFZLEdBQUc3VywwREFBZjs7QUFSWjtBQUFBLDZDQVlXNlcsWUFaWDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTs7OztBQWVPLFNBQWVjLE1BQXRCO0FBQUE7QUFBQTs7O2dMQUFPLGtCQUFzQkMsS0FBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQ1NqQiw4Q0FEVDtBQUFBLDJCQUVDO0FBQUVVLGNBQUFBLElBQUksRUFBRVQsc0VBQWMsQ0FBQ2dCLEtBQUQsQ0FBdEI7QUFBK0JDLGNBQUFBLFdBQVcsRUFBRTtBQUE1QyxhQUZEO0FBQUE7QUFBQSxtQkFHT2YsU0FBUyxFQUhoQjs7QUFBQTtBQUFBO0FBQUEsMkJBSUNnQixRQUFRLEdBQ0YvVSxTQURFLEdBRUY7QUFDSWdWLGNBQUFBLFNBQVMsRUFBRTtBQURmLGFBTlA7QUFDR1IsWUFBQUEsR0FESDtBQUFBLDhDQVVJQSxHQVZKOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcERQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFJQTtBQUNBO0FBQ0E7O0FBRUE7QUFBQSxpTEFBZSxpQkFBT2dCLEdBQVAsRUFBcUIxRSxHQUFyQixFQUFvQ2tELElBQXBDO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFDT3NCLG1EQUFXLENBQUM7QUFBRUcsY0FBQUEsR0FBRyxFQUFFRCxHQUFHLENBQUNDO0FBQVgsYUFBRCxDQURsQixFQUNIQyxLQURHLGdCQUNIQSxLQURHLEVBR1g7O0FBQ01DLFlBQUFBLGNBSkssR0FJWSxTQUFqQkEsY0FBaUIsR0FBb0I7QUFDdkMsa0JBQU1DLE1BQU0sR0FBR1QsZ0VBQVcsQ0FBQ3ZYLGdEQUFELEVBQVM0WCxHQUFHLENBQUNqUSxJQUFiLENBQTFCO0FBQ0Esa0JBQU02RCxRQUFRLEdBQUd3TSxNQUFNLENBQUN2VSxHQUFQLENBQVcsaUJBQXNCO0FBQUEsb0JBQW5CakUsS0FBbUIsU0FBbkJBLEtBQW1CO0FBQUEsb0JBQVp3SCxLQUFZLFNBQVpBLEtBQVk7QUFDOUMsb0JBQUl4SCxLQUFLLENBQUNrSCxRQUFWLEVBQ0ksT0FBTytELE9BQU8sQ0FBQ3dOLEdBQVIsQ0FDSHpZLEtBQUssQ0FDQWtILFFBREwsQ0FDYztBQUNOUSxrQkFBQUEsTUFBTSxFQUFFRixLQUFLLENBQUNFLE1BRFI7QUFFTmdSLGtCQUFBQSxRQUFRLEVBQUVKLEtBQUssQ0FBQ0ksUUFGVjtBQUdOTixrQkFBQUEsR0FBRyxFQUFIQSxHQUhNO0FBSU4xRSxrQkFBQUEsR0FBRyxFQUFIQTtBQUpNLGlCQURkLEVBT0t6UCxHQVBMLENBT1MsVUFBQ1EsSUFBRDtBQUFBLHlCQUFrQjZULEtBQUssQ0FBQ3ZYLFFBQU4sQ0FBZTBELElBQWYsQ0FBbEI7QUFBQSxpQkFQVCxDQURHLENBQVA7QUFXSix1QkFBT3dHLE9BQU8sQ0FBQ3BDLE9BQVIsQ0FBZ0IsSUFBaEIsQ0FBUDtBQUNILGVBZGdCLENBQWpCO0FBZ0JBLHFCQUFPb0MsT0FBTyxDQUFDd04sR0FBUixDQUFZek0sUUFBWixDQUFQO0FBQ0gsYUF2QlU7O0FBQUE7QUFBQTtBQUFBLG1CQTJCRHVNLGNBQWMsRUEzQmI7O0FBQUE7QUE2QkRJLFlBQUFBLFNBN0JDLEdBNkJXeFEsbURBQUEsQ0FBYWlFLE9BQU8sQ0FBQ0MsR0FBUixFQUFiLEVBQTRCLHVCQUE1QixDQTdCWDtBQThCRGlKLFlBQUFBLFNBOUJDLEdBOEJXLElBQUkyQyw0REFBSixDQUFtQjtBQUFFVSxjQUFBQSxTQUFTLEVBQVRBO0FBQUYsYUFBbkIsQ0E5Qlg7QUFnQ0Q1USxZQUFBQSxhQWhDQyxHQWdDb0MsRUFoQ3BDO0FBaUNEaEksWUFBQUEsR0FqQ0MsR0FpQ0t1VixTQUFTLENBQUNzRCxhQUFWLGVBQ1Isd0RBQUMsaURBQUQ7QUFBVSxtQkFBSyxFQUFFTixLQUFqQjtBQUFBLHFDQUVJLHdEQUFDLDBEQUFEO0FBQWMsd0JBQVEsRUFBRUYsR0FBRyxDQUFDalEsSUFBNUI7QUFBa0MsdUJBQU8sRUFBRUosYUFBM0M7QUFBQSwwQkFDS3JJLGlFQUFZLENBQUNjLGdEQUFEO0FBRGpCO0FBRkosY0FEUSxDQWpDTDtBQTBDRGdWLFlBQUFBLFlBMUNDLEdBMENjOEMsS0FBSyxDQUFDSSxRQUFOLEVBMUNkO0FBMkNEbkQsWUFBQUEsV0EzQ0MsR0EyQ2FzQyxnRUFBYyxDQUFDOVgsR0FBRCxDQTNDM0IsRUE0Q1A7QUFDQTs7QUFDTXNWLFlBQUFBLElBOUNDLEdBOENNMVYsNkRBQUEsRUE5Q04sRUFnRFA7QUFDQTs7QUFqRE8saUJBa0RIb0ksYUFBYSxDQUFDc1EsR0FsRFg7QUFBQTtBQUFBO0FBQUE7O0FBbURIM0UsWUFBQUEsR0FBRyxDQUFDOUIsTUFBSixDQUFXLEdBQVgsRUFBZ0I5SSxTQUFoQixDQUEwQixVQUExQixFQUFzQ2YsYUFBYSxDQUFDc1EsR0FBcEQ7QUFDQTNFLFlBQUFBLEdBQUcsQ0FBQ29GLEdBQUo7QUFwREc7O0FBQUE7QUF5RFA7QUFDQXBGLFlBQUFBLEdBQUcsQ0FBQzlCLE1BQUosQ0FBVzdKLGFBQWEsQ0FBQ0MsVUFBZCxLQUE2QixLQUE3QixHQUFxQyxHQUFyQyxHQUEyQyxHQUF0RCxFQUEyRCtRLElBQTNELENBQ0laLHdEQUFVLENBQUM5QyxJQUFELEVBQU9DLFNBQVAsRUFBa0JDLFdBQWxCLEVBQStCQyxZQUEvQixDQURkO0FBMURPO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBOERQOUIsWUFBQUEsR0FBRyxDQUFDOUIsTUFBSixDQUFXLEdBQVgsRUFBZ0JtSCxJQUFoQixDQUFxQixjQUFyQjtBQUNBMU8sWUFBQUEsT0FBTyxDQUFDbEgsS0FBUixDQUFjcUcsZ0RBQUEsa0VBQWQ7O0FBL0RPO0FBa0VYb04sWUFBQUEsSUFBSTs7QUFsRU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsR0FBZjs7QUFBQTtBQUFBO0FBQUE7QUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNkQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxvQkFBb0J0Syw4REFBWSxDQUFDLFNBQUQsRUFBWSxJQUFJZ0cscURBQUosRUFBWixDQUFoQztBQUFBLElBQVE5RixPQUFSLGlCQUFRQSxPQUFSOztBQUVlLFNBQWU4RyxZQUE5QjtBQUFBO0FBQUE7OztzTEFBZSxpQkFDWGhMLE9BRFcsRUFFWEMsUUFGVyxFQUdYQyxLQUhXO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQUFBLGtCQU1ILE9BQU9GLE9BQU8sQ0FBQzBKLElBQVIsQ0FBYXlGLEtBQXBCLEtBQThCLFFBQTlCLElBQTBDLE9BQU9uUCxPQUFPLENBQUMwSixJQUFSLENBQWFtSCxRQUFwQixLQUFpQyxRQU54RTtBQUFBO0FBQUE7QUFBQTs7QUFBQSxrQkFPR3JNLEtBQUssRUFQUjs7QUFBQTtBQUFBO0FBQUEsbUJBU1dzTSxLQUFLLENBQUM5USxPQUFPLENBQUMwSixJQUFSLENBQWF5RixLQUFkLEVBQXFCblAsT0FBTyxDQUFDMEosSUFBUixDQUFhbUgsUUFBbEMsQ0FUaEI7O0FBQUE7QUFTRHpGLFlBQUFBLEdBVEM7QUFVUG5MLFlBQUFBLFFBQVEsQ0FBQ3FKLE1BQVQsQ0FBZ0IsR0FBaEIsRUFBcUJDLElBQXJCLENBQTBCNkIsR0FBMUI7QUFWTztBQUFBOztBQUFBO0FBQUE7QUFBQTs7QUFZUCxnQkFBSSxZQUFFMkYsT0FBTixFQUFlO0FBQ1g5USxjQUFBQSxRQUFRLENBQUNxSixNQUFULENBQWdCLEdBQWhCLEVBQXFCQyxJQUFyQixDQUEwQjtBQUFFMU8sZ0JBQUFBLEtBQUssRUFBRSxZQUFFa1c7QUFBWCxlQUExQjtBQUNILGFBRkQsTUFFTztBQUNIOVEsY0FBQUEsUUFBUSxDQUFDcUosTUFBVCxDQUFnQixHQUFoQixFQUFxQkMsSUFBckI7QUFDSDs7QUFoQk07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7Ozs7QUFvQlIsU0FBZXVILEtBQXRCO0FBQUE7QUFBQTs7OytLQUFPLGtCQUFxQkUsUUFBckIsRUFBdUNDLFdBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNHOUIsWUFBQUEsS0FESCxHQUNXNkIsUUFBUSxDQUFDM1EsT0FBVCxDQUFpQixNQUFqQixFQUF5QixFQUF6QixFQUE2QkEsT0FBN0IsQ0FBcUMsTUFBckMsRUFBNkMsRUFBN0MsQ0FEWDs7QUFBQSxnQkFFRXNRLCtEQUFBLENBQWlCeEIsS0FBakIsQ0FGRjtBQUFBO0FBQUE7QUFBQTs7QUFBQSxrQkFHTzNLLEtBQUssQ0FBQyxlQUFELENBSFo7O0FBQUE7QUFNR3FNLFlBQUFBLFFBTkgsR0FNY0ksV0FBVyxDQUFDNVEsT0FBWixDQUFvQixNQUFwQixFQUE0QixFQUE1QixFQUFnQ0EsT0FBaEMsQ0FBd0MsTUFBeEMsRUFBZ0QsRUFBaEQsQ0FOZDs7QUFBQSxrQkFPQ3dRLFFBQVEsQ0FBQy9OLE1BQVQsS0FBb0IsQ0FQckI7QUFBQTtBQUFBO0FBQUE7O0FBQUEsa0JBUU8wQixLQUFLLENBQUMseUJBQUQsQ0FSWjs7QUFBQTtBQUFBLGtCQVVDcU0sUUFBUSxDQUFDL04sTUFBVCxHQUFrQjhOLGdFQVZuQjtBQUFBO0FBQUE7QUFBQTs7QUFBQSxrQkFXT3BNLEtBQUssQ0FBQyx5QkFBRCxDQVhaOztBQUFBO0FBQUE7QUFBQSxtQkFjNkJOLE9BQU8sRUFkcEM7O0FBQUE7QUFjR2lOLFlBQUFBLE9BZEg7QUFlR3hVLFlBQUFBLE1BZkgsR0FlWXdVLE9BQU8sQ0FBQzlMLElBQVIsQ0FBYSxVQUFDK0wsQ0FBRDtBQUFBLHFCQUFPQSxDQUFDLENBQUNDLElBQUYsS0FBV2xDLEtBQWxCO0FBQUEsYUFBYixDQWZaOztBQUFBLGdCQWdCRXhTLE1BaEJGO0FBQUE7QUFBQTtBQUFBOztBQUFBLGtCQWlCTzZILEtBQUssQ0FBQyw2Q0FBRCxDQWpCWjs7QUFBQTtBQUFBO0FBQUEsbUJBb0J5QmtNLHFEQUFBLENBQWVHLFFBQWYsRUFBeUJsVSxNQUFNLENBQUM0VSxLQUFQLENBQWFsUixPQUFiLENBQXFCLE9BQXJCLEVBQThCLEtBQTlCLENBQXpCLENBcEJ6Qjs7QUFBQTtBQW9CR21SLFlBQUFBLGFBcEJIOztBQUFBLGdCQXFCRUEsYUFyQkY7QUFBQTtBQUFBO0FBQUE7O0FBQUEsa0JBc0JPaE4sS0FBSyxDQUFDLHFDQUFELENBdEJaOztBQUFBO0FBQUE7QUFBQSxtQkF5QmUwSywrQ0FBTSxDQUFDQyxLQUFELENBekJyQjs7QUFBQTtBQXlCR0wsWUFBQUEsR0F6Qkg7QUFBQSw4Q0EyQkk7QUFDSG5TLGNBQUFBLE1BQU0sRUFBRTtBQUNKTixnQkFBQUEsTUFBTSxFQUFFTSxNQUFNLENBQUNOO0FBRFgsZUFETDtBQUlIeVMsY0FBQUEsR0FBRyxFQUFIQTtBQUpHLGFBM0JKOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNUJQO0FBRUE7QUFDQTtBQUlPLFNBQVM1SixHQUFULENBQXNCeU0sV0FBdEIsRUFHSjtBQUtDO0FBQUEsbUxBQU8saUJBQU8vVixFQUFQO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRXdCNlYsZ0RBQUEsV0FBYWxhLHVEQUFiLGNBQStCb2EsV0FBL0IsMENBQ2hCRCw4Q0FEZ0I7QUFFbkJ0UyxnQkFBQUEsTUFBTSxFQUFFO0FBQUV4RCxrQkFBQUEsRUFBRSxFQUFGQTtBQUFGO0FBRlcsaUJBRnhCOztBQUFBO0FBQUE7QUFFU2dXLGNBQUFBLElBRlQsb0JBRVNBLElBRlQ7QUFBQSwrQ0FNUTtBQUFFQSxnQkFBQUEsSUFBSSxFQUFKQTtBQUFGLGVBTlI7O0FBQUE7QUFBQTtBQUFBO0FBQUEsK0NBUVE7QUFBRS9XLGdCQUFBQSxLQUFLO0FBQVAsZUFSUjs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUFQOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBV0g7QUFFTSxTQUFTcUosT0FBVCxDQUEwQnlOLFdBQTFCLEVBR0o7QUFLQywwTEFBTztBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUV3QkYsZ0RBQUEsV0FBYWxhLHVEQUFiLGNBQStCb2EsV0FBL0IsY0FBcURELDhDQUFyRCxDQUZ4Qjs7QUFBQTtBQUFBO0FBRVNFLFlBQUFBLElBRlQscUJBRVNBLElBRlQ7QUFBQSw4Q0FHUTtBQUFFQSxjQUFBQSxJQUFJLEVBQUpBO0FBQUYsYUFIUjs7QUFBQTtBQUFBO0FBQUE7QUFBQSw4Q0FLUTtBQUFFL1csY0FBQUEsS0FBSztBQUFQLGFBTFI7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsR0FBUDtBQVFILEVBRUQ7O0FBQ08sU0FBU3dMLEdBQVQsQ0FDSHNMLFdBREcsRUFLSjtBQUtDO0FBQUEsb0xBQU8sa0JBQU9FLGVBQVA7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFd0JKLGlEQUFBLFdBQ2hCbGEsdURBRGdCLGNBQ0VvYSxXQURGLFVBRW5CRSxlQUZtQixFQUduQkgsOENBSG1CLENBRnhCOztBQUFBO0FBQUE7QUFFU0UsY0FBQUEsSUFGVCxxQkFFU0EsSUFGVDtBQUFBLGdEQU9RO0FBQUVBLGdCQUFBQSxJQUFJLEVBQUpBO0FBQUYsZUFQUjs7QUFBQTtBQUFBO0FBQUE7QUFBQSxnREFTUTtBQUFFL1csZ0JBQUFBLEtBQUs7QUFBUCxlQVRSOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQVA7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFZSDtBQUVNLFNBQVNxTCxHQUFULENBQXNCeUwsV0FBdEIsRUFHSjtBQUtDO0FBQUEsb0xBQU8sa0JBQU9oVixNQUFQO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRXdCOFUsaURBQUEsV0FDaEJsYSx1REFEZ0IsY0FDRW9hLFdBREYsVUFFbkJoVixNQUZtQixFQUduQitVLDhDQUhtQixDQUZ4Qjs7QUFBQTtBQUFBO0FBRVNFLGNBQUFBLElBRlQsc0JBRVNBLElBRlQ7QUFBQSxnREFPUTtBQUFFQSxnQkFBQUEsSUFBSSxFQUFKQTtBQUFGLGVBUFI7O0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0RBU1E7QUFBRS9XLGdCQUFBQSxLQUFLO0FBQVAsZUFUUjs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUFQOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBWUg7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6RkQsSUFBTWlYLE9BQVksR0FBR0MsaUlBQXJCO0FBRUEsSUFBTWpELEdBQWtCLEdBQUdnRCxPQUFILGFBQUdBLE9BQUgsdUJBQUdBLE9BQU8sQ0FBRUUsT0FBVCxDQUFpQixVQUFqQixDQUEzQjs7QUFDQSxJQUFJbEQsR0FBSixFQUFTO0FBQ0xtRCxFQUFBQSxNQUFNLENBQUNuRCxHQUFELENBQU47QUFDSDs7QUFFTSxJQUFNNEMsV0FBK0IsR0FBRztBQUMzQ2hRLEVBQUFBLE9BQU8sRUFBRTtBQURrQyxDQUF4QztBQUlBLFNBQVN1USxNQUFULENBQWdCeEQsS0FBaEIsRUFBcUM7QUFDeENpRCxFQUFBQSxXQUFXLENBQUNoUSxPQUFaLENBQW9Cd1EsYUFBcEIsb0JBQThDekQsS0FBOUM7QUFDQXFELEVBQUFBLE9BQU8sU0FBUCxJQUFBQSxPQUFPLFdBQVAsWUFBQUEsT0FBTyxDQUFFSyxPQUFULENBQWlCLFVBQWpCLEVBQTZCMUQsS0FBN0I7QUFDSDtBQUVNLFNBQVMyRCxRQUFULEdBQTBCO0FBQzdCLFNBQU9WLFdBQVcsQ0FBQ2hRLE9BQVosQ0FBb0J3USxhQUEzQjtBQUNBSixFQUFBQSxPQUFPLFNBQVAsSUFBQUEsT0FBTyxXQUFQLFlBQUFBLE9BQU8sQ0FBRU8sVUFBVCxDQUFvQixVQUFwQjtBQUNIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDckJEO0FBRU8sSUFBTXpKLEtBQWI7QUFBQTs7QUFBQSwyRkFDUyxDQURUOztBQUFBLGdHQUdjLEVBSGQ7O0FBQUEsK0ZBS2EsRUFMYjs7QUFBQSxtR0FPaUIsRUFQakI7O0FBQUEsZ0dBU3dCLEVBVHhCOztBQUFBLGtHQVdnQixFQVhoQjtBQUFBO0FBZ0JPLElBQU1NLFFBQVEsR0FBR2hFLCtDQUFHLENBQVEsT0FBUixDQUFwQjtBQUVBLElBQU0rRCxZQUFZLEdBQUcvRSxtREFBTyxDQUFRLE9BQVIsQ0FBNUI7QUFFQSxJQUFNaUYsUUFBUSxHQUFHOUMsK0NBQUcsQ0FBd0IsT0FBeEIsQ0FBcEI7QUFFQSxJQUFNK0MsUUFBUSxHQUFHbEQsK0NBQUcsQ0FBUSxPQUFSLENBQXBCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeEJQO0FBRU8sSUFBTXlELE1BQWI7QUFBQTs7QUFBQSwyRkFDUyxDQURUOztBQUFBLDhGQUdZLEVBSFo7O0FBQUEsK0ZBS2EsRUFMYjs7QUFBQSxnR0FPYyxFQVBkOztBQUFBLG1HQVNpQixDQVRqQjs7QUFBQSxtR0FXaUIsQ0FYakI7O0FBQUEsOEZBYVksQ0FiWjs7QUFBQSw2RkFlbUQsRUFmbkQ7O0FBQUEsZ0dBaUJjLEVBakJkOztBQUFBLDhGQW1CWSxDQW5CWjs7QUFBQSxvR0FxQmtCLENBckJsQjs7QUFBQSxrR0F1QmdCLENBdkJoQjs7QUFBQSxrR0F5QmdCLENBekJoQjs7QUFBQSw0RkEyQlUsRUEzQlY7O0FBQUEsaUdBNkJlLEVBN0JmO0FBQUE7QUFrQ08sSUFBTUUsU0FBUyxHQUFHM0UsK0NBQUcsQ0FBUyxRQUFULENBQXJCO0FBRUEsSUFBTTBFLGFBQWEsR0FBRzFGLG1EQUFPLENBQVMsUUFBVCxDQUE3QjtBQUVBLElBQU00RixTQUFTLEdBQUd6RCwrQ0FBRyxDQUEwQixRQUExQixDQUFyQjtBQUVBLElBQU0wRCxTQUFTLEdBQUc3RCwrQ0FBRyxDQUFTLFFBQVQsQ0FBckI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFDUDtBQUVPLElBQU04RCxNQUFiO0FBQUE7O0FBQUEsMkZBQ1MsQ0FEVDs7QUFBQSw0RkFHVSxFQUhWOztBQUFBLCtGQUthLEVBTGI7O0FBQUEsNkZBT1csRUFQWDs7QUFBQSxrR0FTZ0IsRUFUaEI7O0FBQUEsOEZBV1ksRUFYWjs7QUFBQSxxR0FhbUIsRUFibkI7O0FBQUEsK0ZBZWEsQ0FmYjs7QUFBQSxrR0FpQmdCLENBakJoQjs7QUFBQSw4RkFtQlksQ0FuQlo7O0FBQUEsb0dBcUJrQixFQXJCbEI7O0FBQUEsbUdBdUJpQixFQXZCakI7O0FBQUEsOEZBeUJZLEVBekJaO0FBQUE7QUE0Qk8sSUFBTTJHLFdBQVcsR0FDcEIsNEdBREc7QUFFQSxJQUFNQyxpQkFBaUIsR0FBRyxDQUExQjtBQVlBLElBQU0xRyxTQUFTLEdBQUdoRiwrQ0FBRyxDQUFTLFFBQVQsQ0FBckI7QUFFQSxJQUFNK0UsYUFBYSxHQUFHL0YsbURBQU8sQ0FBUyxRQUFULENBQTdCO0FBRUEsSUFBTWlHLFNBQVMsR0FBRzlELCtDQUFHLENBQTBCLFFBQTFCLENBQXJCO0FBRUEsSUFBTStELFNBQVMsR0FBR2xFLCtDQUFHLENBQVMsUUFBVCxDQUFyQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2xEUDtBQUVBO0FBQ0E7QUFFQSxJQUFNeU0sWUFBWSxHQUFHSixxRUFBbUIsRUFBeEM7QUFFQSxJQUFNSyxhQUFhLEdBQUdOLDZEQUFXLENBQUM7QUFDOUIzVSxFQUFBQSxJQUFJLEVBQUUsVUFEd0I7QUFFOUJ1UCxFQUFBQSxZQUFZLEVBQUV5RixZQUFZLENBQUNFLGVBQWIsQ0FBNkI7QUFDdkNwVSxJQUFBQSxXQUFXLEVBQUU7QUFEMEIsR0FBN0IsQ0FGZ0I7QUFLOUJxVSxFQUFBQSxRQUFRLEVBQUU7QUFDTkMsSUFBQUEsYUFBYSxFQUFFLHVCQUFDblksS0FBRCxFQUFXO0FBQ3RCQSxNQUFBQSxLQUFLLENBQUM2RCxXQUFOLEdBQW9CLFNBQXBCO0FBQ0gsS0FISztBQUlOdVUsSUFBQUEsVUFBVSxFQUFFLG9CQUFDcFksS0FBRCxRQUE4QztBQUFBLFVBQXBDcVksT0FBb0MsUUFBcENBLE9BQW9DO0FBQ3REclksTUFBQUEsS0FBSyxDQUFDNkQsV0FBTixHQUFvQixTQUFwQjtBQUNBa1UsTUFBQUEsWUFBWSxDQUFDTyxNQUFiLENBQW9CdFksS0FBcEIsRUFBMkJxWSxPQUEzQjtBQUNILEtBUEs7QUFRTkUsSUFBQUEsVUFBVSxFQUFFLG9CQUFDdlksS0FBRCxTQUErQztBQUFBLFVBQXJDcVksT0FBcUMsU0FBckNBLE9BQXFDO0FBQ3ZEclksTUFBQUEsS0FBSyxDQUFDNkQsV0FBTixHQUFvQixTQUFwQjtBQUNBN0QsTUFBQUEsS0FBSyxDQUFDQyxLQUFOLEdBQWNvWSxPQUFkO0FBQ0g7QUFYSztBQUxvQixDQUFELENBQWpDO0FBb0JBLGlFQUFlTCxhQUFhLENBQUNRLE9BQTdCO0FBQ08sNEJBQWtEUixhQUFhLENBQUNTLE9BQWhFO0FBQUEsSUFBUU4sYUFBUix5QkFBUUEsYUFBUjtBQUFBLElBQXVCQyxVQUF2Qix5QkFBdUJBLFVBQXZCO0FBQUEsSUFBbUNHLFVBQW5DLHlCQUFtQ0EsVUFBbkM7O0FBRUEsSUFBTTVhLGFBQWEsR0FBR21hLHVEQUFlLENBQ3hDdkosc0RBRHdDLEVBRXhDNEosYUFGd0MsRUFHeENDLFVBSHdDLEVBSXhDRyxVQUp3QyxFQUt4QyxVQUFDdFksS0FBRDtBQUFBLFNBQWtCMlgsa0RBQVUsK0NBQXdDM1gsS0FBSyxDQUFDa1csT0FBOUMsRUFBNUI7QUFBQSxDQUx3QyxFQU14QztBQUFBLFNBQU0wQixvREFBWSxDQUFDLGlCQUFELENBQWxCO0FBQUEsQ0FOd0MsQ0FBckM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDOUJQO0FBRUE7QUFDQTtBQUdBLElBQU1FLFlBQVksR0FBR0oscUVBQW1CLEVBQXhDO0FBRUEsSUFBTWdCLFNBQVMsR0FBR2pCLDZEQUFXLENBQUM7QUFDMUIzVSxFQUFBQSxJQUFJLEVBQUUsY0FEb0I7QUFFMUJ1UCxFQUFBQSxZQUFZLEVBQUV5RixZQUFZLENBQUNFLGVBQWIsQ0FBNkI7QUFDdkNwVSxJQUFBQSxXQUFXLEVBQUU7QUFEMEIsR0FBN0IsQ0FGWTtBQUsxQnFVLEVBQUFBLFFBQVEsRUFBRTtBQUNOQyxJQUFBQSxhQUFhLEVBQUUsdUJBQUNuWSxLQUFELEVBQVc7QUFDdEJBLE1BQUFBLEtBQUssQ0FBQzZELFdBQU4sR0FBb0IsU0FBcEI7QUFDSCxLQUhLO0FBSU51VSxJQUFBQSxVQUFVLEVBQUUsb0JBQUNwWSxLQUFELFFBQWdEO0FBQUEsVUFBdENxWSxPQUFzQyxRQUF0Q0EsT0FBc0M7QUFDeERyWSxNQUFBQSxLQUFLLENBQUM2RCxXQUFOLEdBQW9CLFNBQXBCO0FBQ0FrVSxNQUFBQSxZQUFZLENBQUNhLE1BQWIsQ0FBb0I1WSxLQUFwQixFQUEyQnFZLE9BQTNCO0FBQ0gsS0FQSztBQVFORSxJQUFBQSxVQUFVLEVBQUUsb0JBQUN2WSxLQUFELFNBQStDO0FBQUEsVUFBckNxWSxPQUFxQyxTQUFyQ0EsT0FBcUM7QUFDdkRyWSxNQUFBQSxLQUFLLENBQUM2RCxXQUFOLEdBQW9CLFNBQXBCO0FBQ0E3RCxNQUFBQSxLQUFLLENBQUNDLEtBQU4sR0FBY29ZLE9BQWQ7QUFDSDtBQVhLO0FBTGdCLENBQUQsQ0FBN0I7QUFvQkEsaUVBQWVNLFNBQVMsQ0FBQ0gsT0FBekI7QUFDTyx5QkFBa0RHLFNBQVMsQ0FBQ0YsT0FBNUQ7QUFBQSxJQUFRTixhQUFSLHNCQUFRQSxhQUFSO0FBQUEsSUFBdUJDLFVBQXZCLHNCQUF1QkEsVUFBdkI7QUFBQSxJQUFtQ0csVUFBbkMsc0JBQW1DQSxVQUFuQzs7QUFFQSxJQUFNTSxjQUFjLEdBQUdILHdEQUFnQixDQUMxQ3JLLDBEQUQwQyxFQUUxQzhKLGFBRjBDLEVBRzFDQyxVQUgwQyxFQUkxQ0csVUFKMEMsRUFLMUMsVUFBQ3RZLEtBQUQ7QUFBQSxTQUFrQjJYLGtEQUFVLGlEQUEwQzNYLEtBQUssQ0FBQ2tXLE9BQWhELEVBQTVCO0FBQUEsQ0FMMEMsQ0FBdkM7O0FBUVAsSUFBTTJDLG9CQUFvQixHQUFHLFNBQXZCQSxvQkFBdUIsQ0FBQzlZLEtBQUQ7QUFBQSxTQUFxQkEsS0FBSyxDQUFDMlksU0FBTixDQUFnQjlVLFdBQWhCLEtBQWdDLFNBQXJEO0FBQUEsQ0FBN0I7O0FBRU8sSUFBTUosb0JBQW9CLEdBQUcsU0FBdkJBLG9CQUF1QjtBQUFBLFNBQWdCLFVBQUM1RixRQUFELEVBQVcyWCxRQUFYLEVBQXdCO0FBQ3hFLFFBQUlzRCxvQkFBb0IsQ0FBQ3RELFFBQVEsRUFBVCxDQUF4QixFQUFzQyxPQUFPM1gsUUFBUSxDQUFDZ2IsY0FBYyxFQUFmLENBQWY7QUFFdEMsV0FBTyxJQUFQO0FBQ0gsR0FKbUM7QUFBQSxDQUE3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekNQO0FBQ0E7QUFFQTtBQUVBOztBQVFBO0FBQ0E7QUFDQSxJQUFNN0QsV0FBVyxHQUFHLFNBQWRBLFdBQWMsR0FBcUM7QUFBQSxpRkFBUCxFQUFPO0FBQUEsTUFBbEMxQyxZQUFrQyxRQUFsQ0EsWUFBa0M7QUFBQSxNQUFwQjZDLEdBQW9CLFFBQXBCQSxHQUFvQjs7QUFDckQsTUFBTWlFLE9BQU8sR0FBR0MsS0FBVSxHQUNwQk4sNERBQW1CLENBQUM7QUFBRU8sSUFBQUEsY0FBYyxFQUFFLENBQUNuRSxHQUFHLElBQUksR0FBUjtBQUFsQixHQUFELENBREMsR0FFcEI2RCxDQUZOO0FBR0EsTUFBTTVELEtBQUssR0FBRzZELGdFQUFjLENBQUM7QUFDekJNLElBQUFBLGNBQWMsRUFBRWpILFlBRFM7QUFFekJrRyxJQUFBQSxPQUFPLEVBQUVXLHdEQUFpQixDQUFDQyxPQUFELENBRkQ7QUFHekJJLElBQUFBLFVBQVUsRUFBRSxvQkFBQ0Msb0JBQUQ7QUFBQSx1R0FFTEEsb0JBQW9CLEVBRmYsSUFHUlAsd0VBQWdCLENBQUNFLE9BQUQsQ0FIUjtBQUFBLEtBSGE7QUFRekJNLElBQUFBLFFBQVEsRUFBRXRXLElBQU9BO0FBUlEsR0FBRCxDQUE1QjtBQVdBLFNBQU87QUFBRWdTLElBQUFBLEtBQUssRUFBTEEsS0FBRjtBQUFTZ0UsSUFBQUEsT0FBTyxFQUFQQTtBQUFULEdBQVA7QUFDSCxDQWhCRDs7QUFrQkEsbUJBQWtCcEUsV0FBVyxFQUE3QjtBQUFBLElBQVFJLEtBQVIsZ0JBQVFBLEtBQVI7O0FBVUEsaUVBQWVKLFdBQWY7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzNDQTtBQUVBO0FBQ0E7QUFHQSxJQUFNMkUsYUFBYSxHQUFHaEMscUVBQW1CLEVBQXpDO0FBRU8sSUFBTXJGLFlBQVksR0FBR3FILGFBQWEsQ0FBQzFCLGVBQWQsQ0FBOEI7QUFDdERwVSxFQUFBQSxXQUFXLEVBQUU7QUFEeUMsQ0FBOUIsQ0FBckI7QUFJUCxJQUFNakQsVUFBVSxHQUFHOFcsNkRBQVcsQ0FBQztBQUMzQjNVLEVBQUFBLElBQUksRUFBRSxZQURxQjtBQUUzQnVQLEVBQUFBLFlBQVksRUFBWkEsWUFGMkI7QUFHM0I0RixFQUFBQSxRQUFRLEVBQUU7QUFDTkMsSUFBQUEsYUFBYSxFQUFFLHVCQUFDblksS0FBRCxFQUFXO0FBQ3RCQSxNQUFBQSxLQUFLLENBQUM2RCxXQUFOLEdBQW9CLFNBQXBCO0FBQ0gsS0FISztBQUlOdVUsSUFBQUEsVUFBVSxFQUFFLG9CQUFDcFksS0FBRCxRQUFpRDtBQUFBLFVBQXZDcVksT0FBdUMsUUFBdkNBLE9BQXVDO0FBQ3pEclksTUFBQUEsS0FBSyxDQUFDNkQsV0FBTixHQUFvQixTQUFwQjtBQUNBOFYsTUFBQUEsYUFBYSxDQUFDZixNQUFkLENBQXFCNVksS0FBckIsRUFBNEJxWSxPQUE1QjtBQUNILEtBUEs7QUFRTkUsSUFBQUEsVUFBVSxFQUFFLG9CQUFDdlksS0FBRCxTQUErQztBQUFBLFVBQXJDcVksT0FBcUMsU0FBckNBLE9BQXFDO0FBQ3ZEclksTUFBQUEsS0FBSyxDQUFDNkQsV0FBTixHQUFvQixTQUFwQjtBQUNBN0QsTUFBQUEsS0FBSyxDQUFDQyxLQUFOLEdBQWNvWSxPQUFkO0FBQ0g7QUFYSztBQUhpQixDQUFELENBQTlCO0FBa0JBLGlFQUFlelgsVUFBVSxDQUFDNFgsT0FBMUI7QUFDTywwQkFBa0Q1WCxVQUFVLENBQUM2WCxPQUE3RDtBQUFBLElBQVFOLGFBQVIsdUJBQVFBLGFBQVI7QUFBQSxJQUF1QkMsVUFBdkIsdUJBQXVCQSxVQUF2QjtBQUFBLElBQW1DRyxVQUFuQyx1QkFBbUNBLFVBQW5DOztBQUVBLElBQU1xQixlQUFlLEdBQUdsQix3REFBZ0IsQ0FDM0MxSiw0REFEMkMsRUFFM0NtSixhQUYyQyxFQUczQ0MsVUFIMkMsRUFJM0NHLFVBSjJDLEVBSzNDLFVBQUN0WSxLQUFEO0FBQUEsU0FBa0IyWCxrREFBVSxtREFBNEMzWCxLQUFLLENBQUNrVyxPQUFsRCxFQUE1QjtBQUFBLENBTDJDLENBQXhDOztBQVFQLElBQU0wRCxxQkFBcUIsR0FBRyxTQUF4QkEscUJBQXdCLENBQUM3WixLQUFEO0FBQUEsU0FBcUJBLEtBQUssQ0FBQ1ksVUFBTixDQUFpQmlELFdBQWpCLEtBQWlDLFNBQXREO0FBQUEsQ0FBOUI7O0FBRU8sSUFBTUwscUJBQXFCLEdBQUcsU0FBeEJBLHFCQUF3QjtBQUFBLFNBQWdCLFVBQUMzRixRQUFELEVBQVcyWCxRQUFYLEVBQXdCO0FBQ3pFLFFBQUlxRSxxQkFBcUIsQ0FBQ3JFLFFBQVEsRUFBVCxDQUF6QixFQUF1QyxPQUFPM1gsUUFBUSxDQUFDK2IsZUFBZSxFQUFoQixDQUFmO0FBRXZDLFdBQU8sSUFBUDtBQUNILEdBSm9DO0FBQUEsQ0FBOUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzNDUDtBQUVBO0FBQ0E7QUFLTyxJQUFNdEgsWUFBeUIsR0FBRztBQUNyQ3pPLEVBQUFBLFdBQVcsRUFBRTtBQUR3QixDQUFsQztBQUlQLElBQU05QixNQUFNLEdBQUcyViw2REFBVyxDQUFDO0FBQ3ZCM1UsRUFBQUEsSUFBSSxFQUFFLFFBRGlCO0FBRXZCdVAsRUFBQUEsWUFBWSxFQUFaQSxZQUZ1QjtBQUd2QjRGLEVBQUFBLFFBQVEsRUFBRTtBQUNOQyxJQUFBQSxhQUFhLEVBQUUsdUJBQUN0UCxDQUFEO0FBQUEsYUFBUTtBQUNuQmhGLFFBQUFBLFdBQVcsRUFBRTtBQURNLE9BQVI7QUFBQSxLQURUO0FBSU51VSxJQUFBQSxVQUFVLEVBQUUsb0JBQUN2UCxDQUFEO0FBQUEsVUFBTXdQLE9BQU4sUUFBTUEsT0FBTjtBQUFBLGFBQTRDO0FBQ3BEeFUsUUFBQUEsV0FBVyxFQUFFLFNBRHVDO0FBRXBEYyxRQUFBQSxNQUFNLEVBQUUwVDtBQUY0QyxPQUE1QztBQUFBLEtBSk47QUFRTkUsSUFBQUEsVUFBVSxFQUFFLG9CQUFDMVAsQ0FBRDtBQUFBLFVBQU13UCxPQUFOLFNBQU1BLE9BQU47QUFBQSxhQUE0QztBQUNwRHhVLFFBQUFBLFdBQVcsRUFBRSxTQUR1QztBQUVwRDVELFFBQUFBLEtBQUssRUFBRW9ZO0FBRjZDLE9BQTVDO0FBQUE7QUFSTjtBQUhhLENBQUQsQ0FBMUI7QUFrQkEsaUVBQWV0VyxNQUFNLENBQUN5VyxPQUF0QjtBQUNPLHNCQUFrRHpXLE1BQU0sQ0FBQzBXLE9BQXpEO0FBQUEsSUFBUU4sYUFBUixtQkFBUUEsYUFBUjtBQUFBLElBQXVCQyxVQUF2QixtQkFBdUJBLFVBQXZCO0FBQUEsSUFBbUNHLFVBQW5DLG1CQUFtQ0EsVUFBbkM7O0FBRUEsSUFBTXdCLFdBQVcsR0FBR0Qsb0RBQVksQ0FDbkN4Syx3REFEbUMsRUFFbkM2SSxhQUZtQyxFQUduQ0MsVUFIbUMsRUFJbkNHLFVBSm1DLEVBS25DLFVBQUN0WSxLQUFEO0FBQUEsU0FBa0IyWCxrREFBVSxrREFBMkMzWCxLQUFLLENBQUNrVyxPQUFqRCxFQUE1QjtBQUFBLENBTG1DLENBQWhDOztBQVFQLElBQU02RCxpQkFBaUIsR0FBRyxTQUFwQkEsaUJBQW9CLENBQUNoYSxLQUFELEVBQWtCZ0IsRUFBbEI7QUFBQSxTQUN0QmhCLEtBQUssQ0FBQytCLE1BQU4sQ0FBYThCLFdBQWIsS0FBNkIsU0FBN0IsSUFBMkM3RCxLQUFLLENBQUMrQixNQUFOLENBQWE0QyxNQUFiLElBQXVCM0UsS0FBSyxDQUFDK0IsTUFBTixDQUFhNEMsTUFBYixDQUFvQjNELEVBQXBCLEtBQTJCQSxFQUR2RTtBQUFBLENBQTFCOztBQUdPLElBQU1vRCxpQkFBaUIsR0FDMUIsU0FEU0EsaUJBQ1QsQ0FBQ3BELEVBQUQ7QUFBQSxTQUNBLFVBQUNuRCxRQUFELEVBQVcyWCxRQUFYLEVBQXdCO0FBQ3BCLFFBQUl3RSxpQkFBaUIsQ0FBQ3hFLFFBQVEsRUFBVCxFQUFheFUsRUFBYixDQUFyQixFQUF1QyxPQUFPbkQsUUFBUSxDQUFDa2MsV0FBVyxDQUFDL1ksRUFBRCxDQUFaLENBQWY7QUFFdkMsV0FBTyxJQUFQO0FBQ0gsR0FMRDtBQUFBLENBREc7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM1Q1A7QUFFQTtBQUNBO0FBRUEsSUFBTWlaLGFBQWEsR0FBR3RDLHFFQUFtQixFQUF6QztBQUVBLElBQU11QyxjQUFjLEdBQUd4Qyw2REFBVyxDQUFDO0FBQy9CM1UsRUFBQUEsSUFBSSxFQUFFLFdBRHlCO0FBRS9CdVAsRUFBQUEsWUFBWSxFQUFFMkgsYUFBYSxDQUFDaEMsZUFBZCxDQUE4QjtBQUN4Q3BVLElBQUFBLFdBQVcsRUFBRTtBQUQyQixHQUE5QixDQUZpQjtBQUsvQnFVLEVBQUFBLFFBQVEsRUFBRTtBQUNOQyxJQUFBQSxhQUFhLEVBQUUsdUJBQUNuWSxLQUFELEVBQVc7QUFDdEJBLE1BQUFBLEtBQUssQ0FBQzZELFdBQU4sR0FBb0IsU0FBcEI7QUFDSCxLQUhLO0FBSU51VSxJQUFBQSxVQUFVLEVBQUUsb0JBQUNwWSxLQUFELFFBQStDO0FBQUEsVUFBckNxWSxPQUFxQyxRQUFyQ0EsT0FBcUM7QUFDdkRyWSxNQUFBQSxLQUFLLENBQUM2RCxXQUFOLEdBQW9CLFNBQXBCO0FBQ0FvVyxNQUFBQSxhQUFhLENBQUMzQixNQUFkLENBQXFCdFksS0FBckIsRUFBNEJxWSxPQUE1QjtBQUNILEtBUEs7QUFRTkUsSUFBQUEsVUFBVSxFQUFFLG9CQUFDdlksS0FBRCxTQUErQztBQUFBLFVBQXJDcVksT0FBcUMsU0FBckNBLE9BQXFDO0FBQ3ZEclksTUFBQUEsS0FBSyxDQUFDNkQsV0FBTixHQUFvQixTQUFwQjtBQUNBN0QsTUFBQUEsS0FBSyxDQUFDQyxLQUFOLEdBQWNvWSxPQUFkO0FBQ0g7QUFYSztBQUxxQixDQUFELENBQWxDO0FBb0JBLGlFQUFlNkIsY0FBYyxDQUFDMUIsT0FBOUI7QUFDTyw0QkFBa0QwQixjQUFjLENBQUN6QixPQUFqRTtBQUFBLElBQVFOLGFBQVIseUJBQVFBLGFBQVI7QUFBQSxJQUF1QkMsVUFBdkIseUJBQXVCQSxVQUF2QjtBQUFBLElBQW1DRyxVQUFuQyx5QkFBbUNBLFVBQW5DOztBQUVBLElBQU00QixjQUFjLEdBQUdyQyx1REFBZSxDQUN6Q3ZJLHdEQUR5QyxFQUV6QzRJLGFBRnlDLEVBR3pDQyxVQUh5QyxFQUl6Q0csVUFKeUMsRUFLekMsVUFBQ3RZLEtBQUQ7QUFBQSxTQUFrQjJYLGtEQUFVLGdEQUF5QzNYLEtBQUssQ0FBQ2tXLE9BQS9DLEVBQTVCO0FBQUEsQ0FMeUMsRUFNekM7QUFBQSxTQUFNMEIsb0RBQVksQ0FBQyxrQkFBRCxDQUFsQjtBQUFBLENBTnlDLENBQXRDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM5QlA7QUFFQTtBQUNBO0FBR0EsSUFBTW9DLGFBQWEsR0FBR3RDLHFFQUFtQixFQUF6QztBQUVPLElBQU1yRixZQUFZLEdBQUcySCxhQUFhLENBQUNoQyxlQUFkLENBQThCO0FBQ3REcFUsRUFBQUEsV0FBVyxFQUFFO0FBRHlDLENBQTlCLENBQXJCO0FBSVAsSUFBTXVXLFVBQVUsR0FBRzFDLDZEQUFXLENBQUM7QUFDM0IzVSxFQUFBQSxJQUFJLEVBQUUsWUFEcUI7QUFFM0J1UCxFQUFBQSxZQUFZLEVBQVpBLFlBRjJCO0FBRzNCNEYsRUFBQUEsUUFBUSxFQUFFO0FBQ05DLElBQUFBLGFBQWEsRUFBRSx1QkFBQ25ZLEtBQUQsRUFBVztBQUN0QkEsTUFBQUEsS0FBSyxDQUFDNkQsV0FBTixHQUFvQixTQUFwQjtBQUNILEtBSEs7QUFJTnVVLElBQUFBLFVBQVUsRUFBRSxvQkFBQ3BZLEtBQUQsUUFBaUQ7QUFBQSxVQUF2Q3FZLE9BQXVDLFFBQXZDQSxPQUF1QztBQUN6RHJZLE1BQUFBLEtBQUssQ0FBQzZELFdBQU4sR0FBb0IsU0FBcEI7QUFDQW9XLE1BQUFBLGFBQWEsQ0FBQ3JCLE1BQWQsQ0FBcUI1WSxLQUFyQixFQUE0QnFZLE9BQTVCO0FBQ0gsS0FQSztBQVFORSxJQUFBQSxVQUFVLEVBQUUsb0JBQUN2WSxLQUFELFNBQStDO0FBQUEsVUFBckNxWSxPQUFxQyxTQUFyQ0EsT0FBcUM7QUFDdkRyWSxNQUFBQSxLQUFLLENBQUM2RCxXQUFOLEdBQW9CLFNBQXBCO0FBQ0E3RCxNQUFBQSxLQUFLLENBQUNDLEtBQU4sR0FBY29ZLE9BQWQ7QUFDSDtBQVhLO0FBSGlCLENBQUQsQ0FBOUI7QUFrQkEsaUVBQWUrQixVQUFVLENBQUM1QixPQUExQjtBQUNPLDBCQUFrRDRCLFVBQVUsQ0FBQzNCLE9BQTdEO0FBQUEsSUFBUU4sYUFBUix1QkFBUUEsYUFBUjtBQUFBLElBQXVCQyxVQUF2Qix1QkFBdUJBLFVBQXZCO0FBQUEsSUFBbUNHLFVBQW5DLHVCQUFtQ0EsVUFBbkM7O0FBRUEsSUFBTThCLGVBQWUsR0FBRzNCLHdEQUFnQixDQUMzQ3JKLDREQUQyQyxFQUUzQzhJLGFBRjJDLEVBRzNDQyxVQUgyQyxFQUkzQ0csVUFKMkMsRUFLM0MsVUFBQ3RZLEtBQUQ7QUFBQSxTQUFrQjJYLGtEQUFVLGtEQUEyQzNYLEtBQUssQ0FBQ2tXLE9BQWpELEVBQTVCO0FBQUEsQ0FMMkMsQ0FBeEM7O0FBUVAsSUFBTW1FLHFCQUFxQixHQUFHLFNBQXhCQSxxQkFBd0IsQ0FBQ3RhLEtBQUQ7QUFBQSxTQUFxQkEsS0FBSyxDQUFDb2EsVUFBTixDQUFpQnZXLFdBQWpCLEtBQWlDLFNBQXREO0FBQUEsQ0FBOUI7O0FBRU8sSUFBTTBXLHFCQUFxQixHQUFHLFNBQXhCQSxxQkFBd0I7QUFBQSxTQUFnQixVQUFDMWMsUUFBRCxFQUFXMlgsUUFBWCxFQUF3QjtBQUN6RSxRQUFJOEUscUJBQXFCLENBQUM5RSxRQUFRLEVBQVQsQ0FBekIsRUFBdUMsT0FBTzNYLFFBQVEsQ0FBQ3djLGVBQWUsRUFBaEIsQ0FBZjtBQUV2QyxXQUFPLElBQVA7QUFDSCxHQUpvQztBQUFBLENBQTlCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDM0NQO0FBRUE7QUFDQTtBQUVBLElBQU1KLGFBQWEsR0FBR3RDLHFFQUFtQixFQUF6QztBQUVBLElBQU04QyxjQUFjLEdBQUcvQyw2REFBVyxDQUFDO0FBQy9CM1UsRUFBQUEsSUFBSSxFQUFFLFdBRHlCO0FBRS9CdVAsRUFBQUEsWUFBWSxFQUFFMkgsYUFBYSxDQUFDaEMsZUFBZCxDQUE4QjtBQUN4Q3BVLElBQUFBLFdBQVcsRUFBRTtBQUQyQixHQUE5QixDQUZpQjtBQUsvQnFVLEVBQUFBLFFBQVEsRUFBRTtBQUNOQyxJQUFBQSxhQUFhLEVBQUUsdUJBQUNuWSxLQUFELEVBQVc7QUFDdEJBLE1BQUFBLEtBQUssQ0FBQzZELFdBQU4sR0FBb0IsU0FBcEI7QUFDSCxLQUhLO0FBSU51VSxJQUFBQSxVQUFVLEVBQUUsb0JBQUNwWSxLQUFELFFBQStDO0FBQUEsVUFBckNxWSxPQUFxQyxRQUFyQ0EsT0FBcUM7QUFDdkRyWSxNQUFBQSxLQUFLLENBQUM2RCxXQUFOLEdBQW9CLFNBQXBCO0FBQ0FvVyxNQUFBQSxhQUFhLENBQUNTLE1BQWQsQ0FBcUIxYSxLQUFyQixFQUE0QnFZLE9BQTVCO0FBQ0gsS0FQSztBQVFORSxJQUFBQSxVQUFVLEVBQUUsb0JBQUN2WSxLQUFELFNBQStDO0FBQUEsVUFBckNxWSxPQUFxQyxTQUFyQ0EsT0FBcUM7QUFDdkRyWSxNQUFBQSxLQUFLLENBQUM2RCxXQUFOLEdBQW9CLFNBQXBCO0FBQ0E3RCxNQUFBQSxLQUFLLENBQUNDLEtBQU4sR0FBY29ZLE9BQWQ7QUFDSDtBQVhLO0FBTHFCLENBQUQsQ0FBbEM7QUFvQkEsaUVBQWVvQyxjQUFjLENBQUNqQyxPQUE5QjtBQUNPLDRCQUFrRGlDLGNBQWMsQ0FBQ2hDLE9BQWpFO0FBQUEsSUFBUU4sYUFBUix5QkFBUUEsYUFBUjtBQUFBLElBQXVCQyxVQUF2Qix5QkFBdUJBLFVBQXZCO0FBQUEsSUFBbUNHLFVBQW5DLHlCQUFtQ0EsVUFBbkM7O0FBRUEsSUFBTTFXLGNBQWMsR0FBRzJZLGtEQUFVLENBQ3BDaEwsd0RBRG9DLEVBRXBDMkksYUFGb0MsRUFHcENDLFVBSG9DLEVBSXBDRyxVQUpvQyxFQUtwQyxVQUFDdFksS0FBRDtBQUFBLFNBQWtCMlgsa0RBQVUsdURBQWdEM1gsS0FBSyxDQUFDa1csT0FBdEQsRUFBNUI7QUFBQSxDQUxvQyxFQU1wQztBQUFBLFNBQU0wQixvREFBWSxDQUFDLGtCQUFELENBQWxCO0FBQUEsQ0FOb0MsQ0FBakM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDN0JQO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0NBR0E7QUFDQTs7QUFDQSxpRUFBZSxVQUFDdUIsT0FBRDtBQUFBLFNBQXVCO0FBQ2xDN0ssSUFBQUEsUUFBUSxFQUFSQSxpREFEa0M7QUFFbENvSyxJQUFBQSxTQUFTLEVBQVRBLGtEQUZrQztBQUdsQy9YLElBQUFBLFVBQVUsRUFBVkEsbURBSGtDO0FBSWxDbUIsSUFBQUEsTUFBTSxFQUFOQSwrQ0FKa0M7QUFLbEN3TixJQUFBQSxTQUFTLEVBQVRBLGtEQUxrQztBQU1sQzZLLElBQUFBLFVBQVUsRUFBVkEsbURBTmtDO0FBT2xDNUssSUFBQUEsU0FBUyxFQUFUQSxrREFQa0M7QUFRbENvTCxJQUFBQSxNQUFNLEVBQUVELHFFQUFhLENBQUN2QixPQUFELENBUmEsQ0FTbEM7O0FBVGtDLEdBQXZCO0FBQUEsQ0FBZjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDWkE7QUFTTyxTQUFTeEIsVUFBVCxDQUFvQnpCLE9BQXBCLEVBQTJDO0FBQzlDelksRUFBQUEsdURBQUEsQ0FBWXlZLE9BQVosRUFBcUI7QUFDakJoWCxJQUFBQSxRQUFRLEVBQUUsWUFETztBQUVqQkMsSUFBQUEsU0FBUyxFQUFFLElBRk07QUFHakJDLElBQUFBLGVBQWUsRUFBRSxJQUhBO0FBSWpCQyxJQUFBQSxZQUFZLEVBQUUsSUFKRztBQUtqQkMsSUFBQUEsWUFBWSxFQUFFLElBTEc7QUFNakJDLElBQUFBLFNBQVMsRUFBRSxJQU5NO0FBT2pCQyxJQUFBQSxRQUFRLEVBQUVDO0FBUE8sR0FBckI7QUFTSDtBQUVNLFNBQVNtWSxZQUFULENBQXNCMUIsT0FBdEIsRUFBNkM7QUFDaER6WSxFQUFBQSx5REFBQSxDQUFjeVksT0FBZCxFQUF1QjtBQUNuQmhYLElBQUFBLFFBQVEsRUFBRSxZQURTO0FBRW5CQyxJQUFBQSxTQUFTLEVBQUUsSUFGUTtBQUduQkMsSUFBQUEsZUFBZSxFQUFFLElBSEU7QUFJbkJDLElBQUFBLFlBQVksRUFBRSxJQUpLO0FBS25CQyxJQUFBQSxZQUFZLEVBQUUsSUFMSztBQU1uQkMsSUFBQUEsU0FBUyxFQUFFLElBTlE7QUFPbkJDLElBQUFBLFFBQVEsRUFBRUM7QUFQUyxHQUF2QjtBQVNIO0FBRU0sU0FBU29hLFlBQVQsQ0FDSGdCLGNBREcsRUFLSDNDLGFBTEcsRUFNSEMsVUFORyxFQU9IRyxVQVBHLEVBY3FCO0FBQUEsTUFOeEJ3QyxZQU13Qix1RUFOZSxVQUFDQyxNQUFELEVBQVk7QUFDL0M7QUFDSCxHQUl1QjtBQUFBLE1BSHhCQyxjQUd3Qix1RUFISyxZQUFNO0FBQy9CO0FBQ0gsR0FDdUI7QUFDeEIsU0FBTyxVQUFDamEsRUFBRDtBQUFBO0FBQUEscUxBQ0gsaUJBQU9uRCxRQUFQO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDSUEsZ0JBQUFBLFFBQVEsQ0FBQ3NhLGFBQWEsRUFBZCxDQUFSO0FBREo7QUFBQSx1QkFHa0MyQyxjQUFjLENBQUM5WixFQUFELENBSGhEOztBQUFBO0FBQUE7QUFHWWYsZ0JBQUFBLEtBSFoseUJBR1lBLEtBSFo7QUFHbUIrVyxnQkFBQUEsSUFIbkIseUJBR21CQSxJQUhuQjs7QUFLSSxvQkFBSS9XLEtBQUosRUFBVztBQUNQcEMsa0JBQUFBLFFBQVEsQ0FBQzBhLFVBQVUsQ0FBQ3RZLEtBQUssQ0FBQ2tXLE9BQVAsQ0FBWCxDQUFSO0FBQ0E0RSxrQkFBQUEsWUFBWSxDQUFDOWEsS0FBRCxDQUFaO0FBQ0gsaUJBSEQsTUFHTztBQUNIcEMsa0JBQUFBLFFBQVEsQ0FBQ3VhLFVBQVUsQ0FBQ3BCLElBQUQsQ0FBWCxDQUFSO0FBQ0FpRSxrQkFBQUEsY0FBYztBQUNqQjs7QUFYTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQURHOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsR0FBUDtBQWNIO0FBRU0sU0FBU25ELGVBQVQsQ0FDSG9ELGlCQURHLEVBS0gvQyxhQUxHLEVBTUhDLFVBTkcsRUFPSEcsVUFQRyxFQWMrQztBQUFBLE1BTmxEd0MsWUFNa0QsdUVBTlgsVUFBQ0MsTUFBRCxFQUFZO0FBQy9DO0FBQ0gsR0FJaUQ7QUFBQSxNQUhsREMsY0FHa0QsdUVBSHJCLFlBQU07QUFDL0I7QUFDSCxHQUNpRDtBQUNsRCxTQUFPLFVBQUNoRSxlQUFEO0FBQUE7QUFBQSxzTEFDSCxrQkFBT3BaLFFBQVA7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNJQSxnQkFBQUEsUUFBUSxDQUFDc2EsYUFBYSxFQUFkLENBQVI7QUFESjtBQUFBLHVCQUdrQytDLGlCQUFpQixDQUFDakUsZUFBRCxDQUhuRDs7QUFBQTtBQUFBO0FBR1loWCxnQkFBQUEsS0FIWix5QkFHWUEsS0FIWjtBQUdtQitXLGdCQUFBQSxJQUhuQix5QkFHbUJBLElBSG5COztBQUtJLG9CQUFJL1csS0FBSixFQUFXO0FBQ1BwQyxrQkFBQUEsUUFBUSxDQUFDMGEsVUFBVSxDQUFDdFksS0FBSyxDQUFDa1csT0FBUCxDQUFYLENBQVI7QUFDQTRFLGtCQUFBQSxZQUFZLENBQUM5YSxLQUFELENBQVo7QUFDSCxpQkFIRCxNQUdPO0FBQ0hwQyxrQkFBQUEsUUFBUSxDQUFDdWEsVUFBVSxDQUFDcEIsSUFBRCxDQUFYLENBQVI7QUFDQWlFLGtCQUFBQSxjQUFjO0FBQ2pCOztBQVhMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BREc7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxHQUFQO0FBY0g7QUFFTSxTQUFTdkMsZ0JBQVQsQ0FDSHlDLGtCQURHLEVBS0hoRCxhQUxHLEVBTUhDLFVBTkcsRUFPSEcsVUFQRyxFQWNXO0FBQUEsTUFOZHdDLFlBTWMsdUVBTnlCLFVBQUNDLE1BQUQsRUFBWTtBQUMvQztBQUNILEdBSWE7QUFBQSxNQUhkQyxjQUdjLHVFQUhlLFlBQU07QUFDL0I7QUFDSCxHQUNhO0FBQ2QsU0FBTztBQUFBO0FBQUEsc0xBQWdCLGtCQUFPcGQsUUFBUDtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ25CQSxnQkFBQUEsUUFBUSxDQUFDc2EsYUFBYSxFQUFkLENBQVI7QUFEbUI7QUFBQSx1QkFHV2dELGtCQUFrQixFQUg3Qjs7QUFBQTtBQUFBO0FBR1hsYixnQkFBQUEsS0FIVyx5QkFHWEEsS0FIVztBQUdKK1csZ0JBQUFBLElBSEkseUJBR0pBLElBSEk7O0FBS25CLG9CQUFJL1csS0FBSixFQUFXO0FBQ1BwQyxrQkFBQUEsUUFBUSxDQUFDMGEsVUFBVSxDQUFDdFksS0FBSyxDQUFDa1csT0FBUCxDQUFYLENBQVI7QUFDQTRFLGtCQUFBQSxZQUFZLENBQUM5YSxLQUFELENBQVo7QUFDSCxpQkFIRCxNQUdPO0FBQ0hwQyxrQkFBQUEsUUFBUSxDQUFDdWEsVUFBVSxDQUFDcEIsSUFBRCxDQUFYLENBQVI7QUFDQWlFLGtCQUFBQSxjQUFjO0FBQ2pCOztBQVhrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQUFoQjs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEdBQVA7QUFhSDtBQUVNLFNBQVNULFVBQVQsQ0FDSFksaUJBREcsRUFLSGpELGFBTEcsRUFNSEMsVUFORyxFQU9IRyxVQVBHLEVBYzJCO0FBQUEsTUFOOUJ3QyxZQU04Qix1RUFOUyxVQUFDQyxNQUFELEVBQVk7QUFDL0M7QUFDSCxHQUk2QjtBQUFBLE1BSDlCQyxjQUc4Qix1RUFIRCxZQUFNO0FBQy9CO0FBQ0gsR0FDNkI7QUFDOUIsU0FBTyxVQUFDN1EsT0FBRDtBQUFBO0FBQUEsc0xBQ0gsa0JBQU92TSxRQUFQO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDSUEsZ0JBQUFBLFFBQVEsQ0FBQ3NhLGFBQWEsRUFBZCxDQUFSO0FBREo7QUFBQSx1QkFHa0NpRCxpQkFBaUIsQ0FBQ2hSLE9BQUQsQ0FIbkQ7O0FBQUE7QUFBQTtBQUdZbkssZ0JBQUFBLEtBSFoseUJBR1lBLEtBSFo7QUFHbUIrVyxnQkFBQUEsSUFIbkIseUJBR21CQSxJQUhuQjs7QUFLSSxvQkFBSS9XLEtBQUosRUFBVztBQUNQcEMsa0JBQUFBLFFBQVEsQ0FBQzBhLFVBQVUsQ0FBQ3RZLEtBQUssQ0FBQ2tXLE9BQVAsQ0FBWCxDQUFSO0FBQ0E0RSxrQkFBQUEsWUFBWSxDQUFDOWEsS0FBRCxDQUFaO0FBQ0gsaUJBSEQsTUFHTztBQUNIcEMsa0JBQUFBLFFBQVEsQ0FBQ3VhLFVBQVUsQ0FBQ3BCLElBQUQsQ0FBWCxDQUFSO0FBQ0FpRSxrQkFBQUEsY0FBYztBQUNqQjs7QUFYTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQURHOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsR0FBUDtBQWNIOzs7Ozs7Ozs7Ozs7Ozs7QUMzSk0sU0FBUzFILGNBQVQsQ0FBd0JnQixLQUF4QixFQUErQztBQUNsREEsRUFBQUEsS0FBSyxHQUFHQSxLQUFLLENBQUM5TyxPQUFOLENBQWMsWUFBZCxFQUE0QixFQUE1QixDQUFSOztBQUNBLE1BQUksY0FBYzZRLElBQWQsQ0FBbUIvQixLQUFuQixDQUFKLEVBQStCO0FBQzNCLFFBQUk4RyxNQUFNLEdBQUc5RyxLQUFLLENBQUM5TyxPQUFOLENBQWMsTUFBZCxFQUFzQixFQUF0QixDQUFiO0FBQ0E0VixJQUFBQSxNQUFNLEdBQUdBLE1BQU0sQ0FBQzVWLE9BQVAsQ0FBZSxtQkFBZixFQUFvQyxXQUFwQyxDQUFUO0FBQ0E4TyxJQUFBQSxLQUFLLEdBQUdBLEtBQUssQ0FDUjlPLE9BREcsQ0FDSyxLQURMLEVBQ1ksRUFEWixFQUVIQSxPQUZHLENBRUssUUFGTCxFQUVlLFVBQUNuQixLQUFEO0FBQUEsYUFBV0EsS0FBSyxDQUFDZ1gsV0FBTixFQUFYO0FBQUEsS0FGZixFQUdIN1YsT0FIRyxDQUdLLE1BSEwsYUFHaUI0VixNQUhqQixFQUFSO0FBSUg7O0FBQ0QsU0FBTzlHLEtBQUssQ0FBQytHLFdBQU4sRUFBUDtBQUNIO0FBRU0sU0FBU0MsVUFBVCxDQUFvQmhILEtBQXBCLEVBQTRDO0FBQy9DLFNBQU8sNkxBQTZMK0IsSUFBN0wsQ0FDSC9CLEtBREcsQ0FBUDtBQUdIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakJEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFTyxJQUFNdUgsS0FBSyxHQUFHNVMsYUFBQSxLQUF5QixhQUF2QztBQUNQLElBQU0rUyxPQUFPLEdBQUcvUyxPQUFPLENBQUM2UyxHQUFSLENBQVlHLEtBQVosS0FBc0IsTUFBdEM7O0FBQ0EsSUFBTUMsZUFBZSxHQUFHLFNBQWxCQSxlQUFrQixDQUFDQyxLQUFELEVBQWlCQyxNQUFqQixFQUFzQztBQUMxRCxNQUFJQyxPQUF5QixHQUFHLENBQzVCO0FBQ0lDLElBQUFBLE1BQU0sRUFBRSxZQURaO0FBRUlDLElBQUFBLE9BQU8sRUFBRTtBQUNMQyxNQUFBQSxhQUFhLEVBQUVKLE1BQU0sR0FBRyxDQUFILEdBQU8sQ0FEdkI7QUFFTEssTUFBQUEsT0FBTyxFQUFFO0FBQ0xDLFFBQUFBLElBQUksRUFBRSxJQUREO0FBRUxDLFFBQUFBLGNBQWMsRUFBRSx1QkFGWDtBQUVvQztBQUN6Q0MsUUFBQUEsZ0JBQWdCLEVBQUUsQ0FBQ1Q7QUFIZDtBQUZKO0FBRmIsR0FENEIsRUFZNUI7QUFBRUcsSUFBQUEsTUFBTSxFQUFFO0FBQVYsR0FaNEIsQ0FBaEM7QUFlQSxNQUFJSCxLQUFKLEVBQVdFLE9BQU8sSUFBSVosdUVBQUoseUZBQW9DWSxPQUFwQyxFQUFQO0FBRVgsTUFBSUQsTUFBSixFQUFZQyxPQUFPLDZGQUFPQSxPQUFQLElBQWdCO0FBQUVDLElBQUFBLE1BQU0sRUFBRTtBQUFWLEdBQWhCLEVBQVA7QUFFWixTQUFPRCxPQUFQO0FBQ0gsQ0FyQkQ7O0FBdUJBLElBQU1RLFVBQVUsR0FBRyxTQUFiQSxVQUFhLENBQUNWLEtBQUQsRUFBb0I7QUFDbkMsTUFBSVcsT0FBTyxHQUFHLENBQ1YsSUFBSXZXLCtEQUFKLEVBRFUsRUFFVixJQUFJZ1YsMEVBQUosQ0FBMEI7QUFDdEJ5QixJQUFBQSxRQUFRLEVBQUVoWSxtREFBQSxDQUFhaUUsT0FBTyxDQUFDQyxHQUFSLEVBQWIsRUFBNEIsNEJBQTVCLENBRFk7QUFFdEIrVCxJQUFBQSxNQUFNLEVBQUUsZ0JBQUNDLElBQUQ7QUFBQSxhQUFVQSxJQUFJLENBQUNDLFNBQWY7QUFBQTtBQUZjLEdBQTFCLENBRlUsRUFNVixJQUFJeEIsaUVBQUosQ0FBbUI7QUFDZnlCLElBQUFBLFdBQVcsRUFBRSxJQURFO0FBRWY5WCxJQUFBQSxRQUFRLEVBQUU7QUFGSyxHQUFuQixDQU5VLEVBVVY7QUFDQSxNQUFJaUIsNkRBQUosQ0FBeUI7QUFDckIrVyxJQUFBQSxVQUFVLEVBQUVuQixLQURTO0FBRXJCL0MsSUFBQUEsVUFBVSxFQUFFLENBQUMrQyxLQUZRO0FBR3JCaFosSUFBQUEsT0FBTyxFQUFFMFksS0FIWTtBQUlyQnpZLElBQUFBLFNBQVMsRUFBRTRZO0FBSlUsR0FBekIsQ0FYVSxDQUFkO0FBbUJBLE1BQUlILEtBQUosRUFDSWlCLE9BQU8sNkZBQ0FBLE9BREEsSUFFSDtBQUNBLE1BQUlwQix1RUFBSixDQUErQjtBQUMzQjtBQUNBNkIsSUFBQUEsTUFBTSxFQUFFO0FBQUVDLE1BQUFBLEtBQUssRUFBRTtBQUFUO0FBRm1CLEdBQS9CLENBSEcsRUFBUDtBQVNKLE1BQUksQ0FBQzNCLEtBQUwsRUFDSWlCLE9BQU8sNkZBQ0FBLE9BREEsSUFFSDtBQUNBLE1BQUlsQix5RUFBSixDQUF5QjtBQUNyQjZCLElBQUFBLFlBQVksRUFBRXhVLE1BQUEsR0FBcUMsQ0FBckMsR0FBZ0Q7QUFEekMsR0FBekIsQ0FIRyxFQUFQO0FBUUosU0FBTzZULE9BQVA7QUFDSCxDQXhDRDs7QUEwQ0EsSUFBTXBnQixNQUFNLEdBQUcsU0FBVEEsTUFBUztBQUFBLE1BQUN5ZixLQUFELHVFQUFTLEtBQVQ7QUFBQSxTQUFtQztBQUM5Q3VCLElBQUFBLElBQUksRUFBRTdCLEtBQUssR0FBRyxhQUFILEdBQW1CLFlBRGdCO0FBRTlDOEIsSUFBQUEsS0FBSyxFQUFFLFNBRnVDO0FBRzlDQyxJQUFBQSxPQUFPLEVBQUU1WSxtREFBQSxDQUFhaUUsT0FBTyxDQUFDQyxHQUFSLEVBQWIsQ0FIcUM7QUFJOUMyVSxJQUFBQSxNQUFNLEVBQUU7QUFBRUMsTUFBQUEsS0FBSyxFQUFFO0FBQVQsS0FKc0M7QUFLOUNDLElBQUFBLFlBQVksRUFBRTtBQUNWQyxNQUFBQSxTQUFTLEVBQUUsQ0FDUCxJQUFJeEMsOERBQUosQ0FBaUI7QUFDYjtBQUNBeUMsUUFBQUEsYUFBYSxFQUFFO0FBQUVDLFVBQUFBLFFBQVEsRUFBRTtBQUFFQyxZQUFBQSxZQUFZLEVBQUU7QUFBaEI7QUFBWjtBQUZGLE9BQWpCLENBRE87QUFERCxLQUxnQztBQWE5Q3JCLElBQUFBLE9BQU8sRUFBRUQsVUFBVSxDQUFDVixLQUFELENBYjJCO0FBYzlDaUMsSUFBQUEsTUFBTSxFQUFFO0FBQ0pDLE1BQUFBLEtBQUssRUFBRSxDQUNIO0FBQ0loSSxRQUFBQSxJQUFJLEVBQUUsYUFEVjtBQUVJaUksUUFBQUEsT0FBTyxFQUFFLGNBRmI7QUFHSWhDLFFBQUFBLE1BQU0sRUFBRSxjQUhaO0FBSUlDLFFBQUFBLE9BQU8sRUFBRTtBQUNMZ0MsVUFBQUEsTUFBTSxFQUFFO0FBQUU5ZixZQUFBQSxNQUFNLEVBQUUwZCxLQUFLLEdBQUcsS0FBSCxHQUFXO0FBQTFCLFdBREg7QUFFTHFDLFVBQUFBLGNBQWMsRUFBRTNDO0FBRlg7QUFKYixPQURHLEVBVUg7QUFDSXhGLFFBQUFBLElBQUksRUFBRSxRQURWO0FBRUluUixRQUFBQSxHQUFHLEVBQUVnWCxlQUFlLENBQUNDLEtBQUQ7QUFGeEIsT0FWRyxFQWNIO0FBQ0k5RixRQUFBQSxJQUFJLEVBQUUsZ0JBRFY7QUFFSW5SLFFBQUFBLEdBQUcsRUFBRWdYLGVBQWUsQ0FBQ0MsS0FBRCxFQUFRLElBQVI7QUFGeEIsT0FkRyxFQWtCSDtBQUNJOUYsUUFBQUEsSUFBSSxFQUFFLDBCQURWO0FBRUl6TyxRQUFBQSxJQUFJLEVBQUUsT0FGVjtBQUdJNlcsUUFBQUEsU0FBUyxFQUFFO0FBQUVDLFVBQUFBLElBQUksRUFBRXZDO0FBQVI7QUFIZixPQWxCRyxFQXVCSDtBQUNJOUYsUUFBQUEsSUFBSSxFQUFFLHlCQURWO0FBRUl6TyxRQUFBQSxJQUFJLEVBQUUsT0FGVjtBQUdJNlcsUUFBQUEsU0FBUyxFQUFFO0FBQUVDLFVBQUFBLElBQUksRUFBRXZDO0FBQVI7QUFIZixPQXZCRztBQURILEtBZHNDO0FBNkM5Q3pXLElBQUFBLE9BQU8sRUFBRTtBQUNMK1csTUFBQUEsT0FBTyxFQUFFLENBQUMsS0FBRCxFQUFRLGNBQVIsQ0FESjtBQUVMa0MsTUFBQUEsVUFBVSxFQUFFLENBQUMsS0FBRCxFQUFRLE1BQVIsRUFBZ0IsS0FBaEIsRUFBdUIsTUFBdkIsRUFBK0IsT0FBL0I7QUFGUDtBQTdDcUMsR0FBbkM7QUFBQSxDQUFmOztBQW1EQSxpRUFBZWppQixNQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDL0hBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTs7QUFFQSxJQUFNbWdCLFVBQVUsR0FBRyxTQUFiQSxVQUFhLEdBQU07QUFDckIsTUFBSUMsT0FBTyxHQUFHLENBQ1YsSUFBSXJCLGdFQUFKLENBQXlCO0FBQ3JCO0FBQ0FuVyxJQUFBQSxRQUFRLEVBQUV1VywrQ0FBSyxHQUFHLFlBQUgsR0FBa0IsMEJBRlo7QUFHckJxRCxJQUFBQSxhQUFhLEVBQUVyRCwrQ0FBSyxHQUFHLFVBQUgsR0FBZ0I7QUFIZixHQUF6QixDQURVLENBQWQ7QUFRQSxNQUFJQSwrQ0FBSixFQUNJaUIsT0FBTyw2RkFDQUEsT0FEQSxJQUVILElBQUl2VywyRUFBSixFQUZHLEVBR0gsSUFBSXFZLDZFQUFKLENBQThCO0FBQUVRLElBQUFBLE9BQU8sRUFBRTtBQUFFQyxNQUFBQSxlQUFlLEVBQUU7QUFBbkI7QUFBWCxHQUE5QixDQUhHLEVBSUgsSUFBSTlZLDZEQUFKLENBQXlCO0FBQ3JCMEMsSUFBQUEsT0FBTyxFQUFFO0FBRFksR0FBekIsQ0FKRyxFQUFQO0FBU0osTUFBSSxDQUFDNFMsK0NBQUwsRUFDSWlCLE9BQU8sNkZBQ0FBLE9BREEsSUFFSDtBQUNBLE1BQUlnQyxtRUFBSixFQUhHLEVBSUgsSUFBSUMsdUVBQUosQ0FBeUI7QUFDckI7QUFDQTtBQUNBTyxJQUFBQSxnQkFBZ0IsRUFBRTtBQUNkeEMsTUFBQUEsT0FBTyxFQUFFLENBQUMsQ0FBQyxVQUFELENBQUQsRUFBZSxDQUFDLFVBQUQsQ0FBZixFQUE2QixDQUFDLFNBQUQsQ0FBN0IsRUFBMEMsQ0FBQyxNQUFELENBQTFDO0FBREs7QUFIRyxHQUF6QixDQUpHLEVBQVA7QUFhSixTQUFPQSxPQUFQO0FBQ0gsQ0FsQ0Q7O0FBb0NBLElBQU1wZ0IsTUFBcUIsR0FBRztBQUMxQjZpQixFQUFBQSxPQUFPLEVBQUUxRCwrQ0FBSyxHQUFHLG1CQUFILEdBQXlCLG1CQURiO0FBRTFCMkQsRUFBQUEsS0FBSyxFQUFFM0QsK0NBQUssR0FBRyxDQUFDLDJDQUFELEVBQThDLGNBQTlDLENBQUgsR0FBbUUsY0FGckQ7QUFHMUJnQyxFQUFBQSxNQUFNLEVBQUU7QUFDSnZZLElBQUFBLFFBQVEsRUFBRXVXLCtDQUFLLEdBQUcsV0FBSCxHQUFpQix5QkFENUI7QUFFSnFELElBQUFBLGFBQWEsRUFBRXJELCtDQUFLLEdBQUcsU0FBSCxHQUFlLHVCQUYvQjtBQUdKN1csSUFBQUEsSUFBSSxFQUFFQSxtREFBQSxDQUFhaUUsT0FBTyxDQUFDQyxHQUFSLEVBQWIsRUFBNEIsZUFBNUIsQ0FIRjtBQUlKdVcsSUFBQUEsVUFBVSxFQUFFO0FBSlIsR0FIa0I7QUFTMUIxQixFQUFBQSxZQUFZLEVBQUU7QUFBRUMsSUFBQUEsU0FBUyxFQUFFLENBQUMsSUFBSWEscUVBQUosRUFBRDtBQUFiLEdBVFk7QUFVMUIvQixFQUFBQSxPQUFPLEVBQUVELFVBQVUsRUFWTztBQVcxQjZDLEVBQUFBLFdBQVcsRUFBRTtBQUNUQyxJQUFBQSxZQUFZLEVBQUUsTUFETDtBQUVUQyxJQUFBQSxpQkFBaUIsRUFBRTtBQUZWO0FBWGEsQ0FBOUI7QUFpQkEsaUVBQWVaLG9EQUFLLENBQUNDLHdEQUFVLENBQUMsSUFBRCxDQUFYLEVBQW1CdmlCLE1BQW5CLENBQXBCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoRUE7QUFDeUc7QUFDN0I7QUFDNUUsOEJBQThCLHNFQUEyQixDQUFDLDJGQUFxQztBQUMvRjtBQUNBLHVXQUF1Vyx1QkFBdUIsMkNBQTJDLFVBQVUsOEpBQThKLGNBQWMsR0FBRyx3RUFBd0UsbUJBQW1CLEdBQUcsc0pBQXNKLG1CQUFtQixxQkFBcUIsR0FBRyxvTkFBb04sb0NBQW9DLHFDQUFxQyxzQkFBc0IsOEJBQThCLFVBQVUsdUpBQXVKLHVDQUF1QywyQkFBMkIsVUFBVSx5TEFBeUwsa0NBQWtDLEdBQUcsMEpBQTBKLHlCQUF5Qix1Q0FBdUMscURBQXFELCtDQUErQyxVQUFVLHlGQUF5Rix3QkFBd0IsR0FBRyxxS0FBcUssdUNBQXVDLDJCQUEyQixVQUFVLHNFQUFzRSxtQkFBbUIsR0FBRyxvSEFBb0gsbUJBQW1CLG1CQUFtQix1QkFBdUIsNkJBQTZCLEdBQUcsU0FBUyxvQkFBb0IsR0FBRyxTQUFTLGdCQUFnQixHQUFHLHFMQUFxTCx1QkFBdUIsR0FBRyw0UEFBNFAsMEJBQTBCLDRCQUE0Qiw4QkFBOEIsc0JBQXNCLFVBQVUsZ0dBQWdHLDZCQUE2QixHQUFHLHFLQUFxSyxnQ0FBZ0MsR0FBRyx5SkFBeUosK0JBQStCLEdBQUcsK01BQStNLHVCQUF1QixlQUFlLEdBQUcsd01BQXdNLG1DQUFtQyxHQUFHLDhEQUE4RCxtQ0FBbUMsR0FBRyx3UUFBd1EsbUNBQW1DLG9DQUFvQywyQkFBMkIsMkJBQTJCLDRCQUE0Qix1QkFBdUIsZ0NBQWdDLFVBQVUsZ0dBQWdHLDZCQUE2QixHQUFHLCtFQUErRSxtQkFBbUIsR0FBRyx3SUFBd0ksbUNBQW1DLG9DQUFvQyx1QkFBdUIsVUFBVSx3TEFBd0wsaUJBQWlCLEdBQUcsdUlBQXVJLG1DQUFtQyxpQ0FBaUMsVUFBVSwwSEFBMEgsNkJBQTZCLEdBQUcsNktBQTZLLGdDQUFnQywwQkFBMEIsVUFBVSxzTEFBc0wsbUJBQW1CLEdBQUcscUVBQXFFLHVCQUF1QixHQUFHLDhKQUE4SixrQkFBa0IsR0FBRyxnRUFBZ0Usa0JBQWtCLEdBQUcsU0FBUyxtSEFBbUgsTUFBTSxRQUFRLFFBQVEsTUFBTSxLQUFLLHNCQUFzQix1QkFBdUIsT0FBTyxLQUFLLFFBQVEsT0FBTyxNQUFNLEtBQUssVUFBVSxNQUFNLE1BQU0sTUFBTSxLQUFLLFVBQVUsT0FBTyxPQUFPLE1BQU0sS0FBSyxVQUFVLFlBQVksT0FBTyxLQUFLLFFBQVEsUUFBUSxNQUFNLEtBQUssWUFBWSx1QkFBdUIscUJBQXFCLHVCQUF1QixPQUFPLE9BQU8sTUFBTSxLQUFLLHNCQUFzQixxQkFBcUIsT0FBTyxLQUFLLFFBQVEsT0FBTyxNQUFNLEtBQUssWUFBWSxPQUFPLE9BQU8sTUFBTSxLQUFLLHNCQUFzQix1QkFBdUIsYUFBYSx1QkFBdUIsT0FBTyxNQUFNLE1BQU0sTUFBTSxZQUFZLE9BQU8sT0FBTyxNQUFNLE9BQU8sc0JBQXNCLHFCQUFxQixPQUFPLE1BQU0sTUFBTSxLQUFLLFVBQVUsT0FBTyxPQUFPLE1BQU0sTUFBTSxVQUFVLFVBQVUsWUFBWSxhQUFhLE9BQU8sS0FBSyxVQUFVLE9BQU8sS0FBSyxVQUFVLE1BQU0sS0FBSyxRQUFRLE9BQU8sTUFBTSxLQUFLLFlBQVksT0FBTyxLQUFLLFFBQVEsUUFBUSxNQUFNLFNBQVMsc0JBQXNCLHFCQUFxQix1QkFBdUIscUJBQXFCLE9BQU8sT0FBTyxNQUFNLEtBQUssVUFBVSxZQUFZLE9BQU8sT0FBTyxNQUFNLEtBQUssVUFBVSxZQUFZLE9BQU8sTUFBTSxNQUFNLFFBQVEsWUFBWSxPQUFPLE1BQU0sTUFBTSxRQUFRLFlBQVksV0FBVyxNQUFNLE1BQU0sTUFBTSxRQUFRLFlBQVksT0FBTyxNQUFNLE1BQU0sS0FBSyxZQUFZLE9BQU8sU0FBUyxNQUFNLEtBQUssWUFBWSx1QkFBdUIscUJBQXFCLHFCQUFxQixxQkFBcUIscUJBQXFCLHVCQUF1QixPQUFPLE1BQU0sTUFBTSxLQUFLLFlBQVksT0FBTyxNQUFNLE1BQU0sS0FBSyxVQUFVLE9BQU8sT0FBTyxNQUFNLE1BQU0sWUFBWSx1QkFBdUIscUJBQXFCLE9BQU8sTUFBTSxNQUFNLE1BQU0sVUFBVSxNQUFNLE9BQU8sTUFBTSxLQUFLLHNCQUFzQix1QkFBdUIsT0FBTyxNQUFNLE1BQU0sS0FBSyxZQUFZLE9BQU8sT0FBTyxNQUFNLEtBQUssc0JBQXNCLHFCQUFxQixPQUFPLEtBQUssUUFBUSxPQUFPLE1BQU0sS0FBSyxVQUFVLE9BQU8sTUFBTSxNQUFNLEtBQUssWUFBWSxPQUFPLEtBQUssUUFBUSxPQUFPLE1BQU0sS0FBSyxVQUFVLE1BQU0sTUFBTSxNQUFNLEtBQUssVUFBVSxzVkFBc1YsdUJBQXVCLDJDQUEyQyxVQUFVLDhKQUE4SixjQUFjLEdBQUcsd0VBQXdFLG1CQUFtQixHQUFHLHNKQUFzSixtQkFBbUIscUJBQXFCLEdBQUcsb05BQW9OLDZCQUE2QixzQkFBc0IsOEJBQThCLFVBQVUsdUpBQXVKLHVDQUF1QywyQkFBMkIsVUFBVSx5TEFBeUwsa0NBQWtDLEdBQUcsMEpBQTBKLHlCQUF5Qix1Q0FBdUMsOENBQThDLFVBQVUseUZBQXlGLHdCQUF3QixHQUFHLHFLQUFxSyx1Q0FBdUMsMkJBQTJCLFVBQVUsc0VBQXNFLG1CQUFtQixHQUFHLG9IQUFvSCxtQkFBbUIsbUJBQW1CLHVCQUF1Qiw2QkFBNkIsR0FBRyxTQUFTLG9CQUFvQixHQUFHLFNBQVMsZ0JBQWdCLEdBQUcscUxBQXFMLHVCQUF1QixHQUFHLDRQQUE0UCwwQkFBMEIsNEJBQTRCLDhCQUE4QixzQkFBc0IsVUFBVSxnR0FBZ0csNkJBQTZCLEdBQUcscUtBQXFLLGdDQUFnQyxHQUFHLHlKQUF5SiwrQkFBK0IsR0FBRywrTUFBK00sdUJBQXVCLGVBQWUsR0FBRyx3TUFBd00sbUNBQW1DLEdBQUcsOERBQThELG1DQUFtQyxHQUFHLHdRQUF3USw0QkFBNEIsMkJBQTJCLDJCQUEyQiw0QkFBNEIsdUJBQXVCLGdDQUFnQyxVQUFVLGdHQUFnRyw2QkFBNkIsR0FBRywrRUFBK0UsbUJBQW1CLEdBQUcsd0lBQXdJLDRCQUE0Qix1QkFBdUIsVUFBVSx3TEFBd0wsaUJBQWlCLEdBQUcsdUlBQXVJLG1DQUFtQyxpQ0FBaUMsVUFBVSwwSEFBMEgsNkJBQTZCLEdBQUcsNktBQTZLLGdDQUFnQywwQkFBMEIsVUFBVSxzTEFBc0wsbUJBQW1CLEdBQUcscUVBQXFFLHVCQUF1QixHQUFHLDhKQUE4SixrQkFBa0IsR0FBRyxnRUFBZ0Usa0JBQWtCLEdBQUcscUJBQXFCO0FBQ2hnZTtBQUNBLGlFQUFlLHVCQUF1QixFQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUHZDO0FBQzRHO0FBQzdCO0FBQy9FLDhCQUE4QixzRUFBMkIsQ0FBQywyRkFBcUM7QUFDL0Y7QUFDQSxpREFBaUQsaUNBQWlDLG1DQUFtQyxtQ0FBbUMsc0NBQXNDLHNDQUFzQyxvQ0FBb0MsMkRBQTJELDJEQUEyRCxpRUFBaUUsaUVBQWlFLDZEQUE2RCxrQ0FBa0Msc0NBQXNDLHNDQUFzQyx1Q0FBdUMsdUNBQXVDLDZCQUE2Qix5Q0FBeUMscUNBQXFDLHFDQUFxQyx3Q0FBd0Msd0NBQXdDLHNDQUFzQyxzQ0FBc0MsaURBQWlELDZKQUE2Siw0Q0FBNEMsK0RBQStELHFFQUFxRSxxRUFBcUUsaUVBQWlFLEdBQUcsZ0NBQWdDLHFDQUFxQyxxRUFBcUUsb0JBQW9CLGlCQUFpQix1Q0FBdUMsbUNBQW1DLG1DQUFtQyxnQkFBZ0IsR0FBRyx3Q0FBd0MsYUFBYSxjQUFjLEdBQUcsMENBQTBDLGFBQWEsY0FBYyx3Q0FBd0Msd0NBQXdDLEdBQUcseUNBQXlDLGFBQWEsZUFBZSxHQUFHLDJDQUEyQyxnQkFBZ0IsY0FBYyxHQUFHLDZDQUE2QyxnQkFBZ0IsY0FBYyx3Q0FBd0Msd0NBQXdDLEdBQUcsNENBQTRDLGdCQUFnQixlQUFlLEdBQUcsZ0RBQWdELGdDQUFnQyxtQkFBbUIsaUJBQWlCLGNBQWMsZ0JBQWdCLEtBQUsseUhBQXlILGFBQWEsdUNBQXVDLHVDQUF1QyxLQUFLLGtJQUFrSSxnQkFBZ0IsdUNBQXVDLHVDQUF1QyxLQUFLLHFDQUFxQyxlQUFlLG9CQUFvQixLQUFLLEdBQUcsb0JBQW9CLHVCQUF1QixpREFBaUQsbUNBQW1DLG1DQUFtQyx3QkFBd0IsaUJBQWlCLHVCQUF1QiwwRkFBMEYsMEZBQTBGLHlCQUF5Qix5QkFBeUIsa0JBQWtCLDJCQUEyQixrQ0FBa0MsMkNBQTJDLGlEQUFpRCxxQkFBcUIsNkNBQTZDLG9CQUFvQixtQkFBbUIsR0FBRyx5QkFBeUIsbUJBQW1CLEdBQUcseUJBQXlCLG1CQUFtQix1QkFBdUIsNEJBQTRCLDJCQUEyQixpQkFBaUIseUJBQXlCLHlCQUF5QixrQkFBa0IsMkJBQTJCLGtDQUFrQyxnQ0FBZ0MsR0FBRywwQ0FBMEMsZ0JBQWdCLDRCQUE0QixvQkFBb0IsR0FBRyx5QkFBeUIsNkJBQTZCLG9DQUFvQyxnQkFBZ0IseUJBQXlCLHVCQUF1Qix5QkFBeUIseUJBQXlCLGtCQUFrQixHQUFHLHdCQUF3QixzQ0FBc0Msc0NBQXNDLHFDQUFxQyxxQ0FBcUMsR0FBRyw2QkFBNkIsc0NBQXNDLHNDQUFzQyxxQ0FBcUMscUNBQXFDLEdBQUcsZ0RBQWdELHNCQUFzQix1QkFBdUIsdUJBQXVCLEtBQUssR0FBRyxnQ0FBZ0MsMkNBQTJDLDJDQUEyQyxHQUFHLGlDQUFpQyw0Q0FBNEMsNENBQTRDLEdBQUcsNERBQTRELDRDQUE0Qyw0Q0FBNEMsR0FBRyx5REFBeUQsMkNBQTJDLDJDQUEyQyxHQUFHLDREQUE0RCw4Q0FBOEMsOENBQThDLEdBQUcsNERBQTRELDhDQUE4Qyw4Q0FBOEMsR0FBRywwREFBMEQsNENBQTRDLDRDQUE0QyxHQUFHLDBDQUEwQyxxREFBcUQsR0FBRyx1Q0FBdUMsb0RBQW9ELEdBQUcsaUNBQWlDLG9EQUFvRCxHQUFHLG9DQUFvQyx1REFBdUQsR0FBRyxvQ0FBb0MsdURBQXVELEdBQUcsa0NBQWtDLHFEQUFxRCxHQUFHLDZSQUE2UixrREFBa0QsR0FBRyw2QkFBNkIsZ0JBQWdCLDRCQUE0QixrQkFBa0IsaUJBQWlCLGVBQWUsb0JBQW9CLGlCQUFpQixrQ0FBa0MsMEJBQTBCLCtCQUErQiwrQkFBK0IsR0FBRyxrQ0FBa0MsZ0JBQWdCLGlCQUFpQixHQUFHLGlDQUFpQyx1QkFBdUIsaUJBQWlCLGdCQUFnQixHQUFHLGdFQUFnRSxlQUFlLEdBQUcsZ0RBQWdELFFBQVEsbUNBQW1DLG1DQUFtQyxLQUFLLFVBQVUsbUNBQW1DLG1DQUFtQyxLQUFLLEdBQUcsd0NBQXdDLFFBQVEsbUNBQW1DLG1DQUFtQyxLQUFLLFVBQVUsbUNBQW1DLG1DQUFtQyxLQUFLLEdBQUcsMkJBQTJCLHVCQUF1QixjQUFjLFlBQVksZ0JBQWdCLGdCQUFnQixxQ0FBcUMsaUJBQWlCLG1DQUFtQyxtQ0FBbUMsR0FBRyxxQ0FBcUMsaUVBQWlFLGlFQUFpRSxHQUFHLHVDQUF1QywrQ0FBK0MsdUNBQXVDLCtCQUErQix1REFBdUQsR0FBRyxnQ0FBZ0MsYUFBYSxrQkFBa0Isb0NBQW9DLG9DQUFvQyxHQUFHLHdCQUF3QixnQkFBZ0IsaUJBQWlCLG1DQUFtQyxtQ0FBbUMsc0JBQXNCLHdCQUF3QiwyREFBMkQsc0RBQXNELDREQUE0RCw0REFBNEQsR0FBRyxnREFBZ0QsNkJBQTZCLDZFQUE2RSw2RUFBNkUsS0FBSyxVQUFVLGlCQUFpQixtREFBbUQsbURBQW1ELEtBQUssU0FBUyxpQkFBaUIsa0RBQWtELGtEQUFrRCxLQUFLLFNBQVMsaURBQWlELGlEQUFpRCxLQUFLLFNBQVMsaURBQWlELGlEQUFpRCxLQUFLLFFBQVEsOEJBQThCLDhCQUE4QixLQUFLLEdBQUcsd0NBQXdDLDZCQUE2Qiw2RUFBNkUsNkVBQTZFLEtBQUssVUFBVSxpQkFBaUIsbURBQW1ELG1EQUFtRCxLQUFLLFNBQVMsaUJBQWlCLGtEQUFrRCxrREFBa0QsS0FBSyxTQUFTLGlEQUFpRCxpREFBaUQsS0FBSyxTQUFTLGlEQUFpRCxpREFBaUQsS0FBSyxRQUFRLDhCQUE4Qiw4QkFBOEIsS0FBSyxHQUFHLCtDQUErQyxTQUFTLGlCQUFpQixrREFBa0Qsa0RBQWtELEtBQUssUUFBUSxpQkFBaUIsbURBQW1ELG1EQUFtRCxLQUFLLEdBQUcsdUNBQXVDLFNBQVMsaUJBQWlCLGtEQUFrRCxrREFBa0QsS0FBSyxRQUFRLGlCQUFpQixtREFBbUQsbURBQW1ELEtBQUssR0FBRyw2Q0FBNkMsNkJBQTZCLDZFQUE2RSw2RUFBNkUsS0FBSyxRQUFRLGlCQUFpQixvREFBb0Qsb0RBQW9ELEtBQUssU0FBUyxpQkFBaUIsaURBQWlELGlEQUFpRCxLQUFLLFNBQVMsa0RBQWtELGtEQUFrRCxLQUFLLFNBQVMsZ0RBQWdELGdEQUFnRCxLQUFLLFFBQVEsOEJBQThCLDhCQUE4QixLQUFLLEdBQUcscUNBQXFDLDZCQUE2Qiw2RUFBNkUsNkVBQTZFLEtBQUssUUFBUSxpQkFBaUIsb0RBQW9ELG9EQUFvRCxLQUFLLFNBQVMsaUJBQWlCLGlEQUFpRCxpREFBaUQsS0FBSyxTQUFTLGtEQUFrRCxrREFBa0QsS0FBSyxTQUFTLGdEQUFnRCxnREFBZ0QsS0FBSyxRQUFRLDhCQUE4Qiw4QkFBOEIsS0FBSyxHQUFHLDhDQUE4QyxTQUFTLGlCQUFpQixpREFBaUQsaURBQWlELEtBQUssUUFBUSxpQkFBaUIsb0RBQW9ELG9EQUFvRCxLQUFLLEdBQUcsc0NBQXNDLFNBQVMsaUJBQWlCLGlEQUFpRCxpREFBaUQsS0FBSyxRQUFRLGlCQUFpQixvREFBb0Qsb0RBQW9ELEtBQUssR0FBRywyQ0FBMkMsNkJBQTZCLDZFQUE2RSw2RUFBNkUsS0FBSyxVQUFVLGlCQUFpQixtREFBbUQsbURBQW1ELEtBQUssU0FBUyxpQkFBaUIsa0RBQWtELGtEQUFrRCxLQUFLLFNBQVMsaURBQWlELGlEQUFpRCxLQUFLLFNBQVMsaURBQWlELGlEQUFpRCxLQUFLLFFBQVEsOENBQThDLDhDQUE4QyxLQUFLLEdBQUcsbUNBQW1DLDZCQUE2Qiw2RUFBNkUsNkVBQTZFLEtBQUssVUFBVSxpQkFBaUIsbURBQW1ELG1EQUFtRCxLQUFLLFNBQVMsaUJBQWlCLGtEQUFrRCxrREFBa0QsS0FBSyxTQUFTLGlEQUFpRCxpREFBaUQsS0FBSyxTQUFTLGlEQUFpRCxpREFBaUQsS0FBSyxRQUFRLDhDQUE4Qyw4Q0FBOEMsS0FBSyxHQUFHLDRDQUE0QyxTQUFTLGtEQUFrRCxrREFBa0QsS0FBSyxjQUFjLGlCQUFpQixpREFBaUQsaURBQWlELEtBQUssUUFBUSxpQkFBaUIsb0RBQW9ELG9EQUFvRCxLQUFLLEdBQUcsb0NBQW9DLFNBQVMsa0RBQWtELGtEQUFrRCxLQUFLLGNBQWMsaUJBQWlCLGlEQUFpRCxpREFBaUQsS0FBSyxRQUFRLGlCQUFpQixvREFBb0Qsb0RBQW9ELEtBQUssR0FBRyw2Q0FBNkMsNkJBQTZCLDZFQUE2RSw2RUFBNkUsS0FBSyxRQUFRLGlCQUFpQixvREFBb0Qsb0RBQW9ELEtBQUssU0FBUyxpQkFBaUIsaURBQWlELGlEQUFpRCxLQUFLLFNBQVMsa0RBQWtELGtEQUFrRCxLQUFLLFNBQVMsZ0RBQWdELGdEQUFnRCxLQUFLLFFBQVEsOEJBQThCLDhCQUE4QixLQUFLLEdBQUcscUNBQXFDLDZCQUE2Qiw2RUFBNkUsNkVBQTZFLEtBQUssUUFBUSxpQkFBaUIsb0RBQW9ELG9EQUFvRCxLQUFLLFNBQVMsaUJBQWlCLGlEQUFpRCxpREFBaUQsS0FBSyxTQUFTLGtEQUFrRCxrREFBa0QsS0FBSyxTQUFTLGdEQUFnRCxnREFBZ0QsS0FBSyxRQUFRLDhCQUE4Qiw4QkFBOEIsS0FBSyxHQUFHLDhDQUE4QyxTQUFTLGlEQUFpRCxpREFBaUQsS0FBSyxjQUFjLGlCQUFpQixrREFBa0Qsa0RBQWtELEtBQUssUUFBUSxpQkFBaUIsbURBQW1ELG1EQUFtRCxLQUFLLEdBQUcsc0NBQXNDLFNBQVMsaURBQWlELGlEQUFpRCxLQUFLLGNBQWMsaUJBQWlCLGtEQUFrRCxrREFBa0QsS0FBSyxRQUFRLGlCQUFpQixtREFBbUQsbURBQW1ELEtBQUssR0FBRywyRUFBMkUsbURBQW1ELG1EQUFtRCxHQUFHLDZFQUE2RSxvREFBb0Qsb0RBQW9ELEdBQUcsdUNBQXVDLG1EQUFtRCxtREFBbUQsR0FBRywwQ0FBMEMsaURBQWlELGlEQUFpRCxHQUFHLDJFQUEyRSxvREFBb0Qsb0RBQW9ELEdBQUcsMkVBQTJFLHFEQUFxRCxxREFBcUQsR0FBRyxzQ0FBc0Msa0RBQWtELGtEQUFrRCxHQUFHLHlDQUF5QyxvREFBb0Qsb0RBQW9ELEdBQUcseUNBQXlDLFVBQVUsaUJBQWlCLGdEQUFnRCxnREFBZ0QsS0FBSyxTQUFTLGlCQUFpQixLQUFLLEdBQUcsaUNBQWlDLFVBQVUsaUJBQWlCLGdEQUFnRCxnREFBZ0QsS0FBSyxTQUFTLGlCQUFpQixLQUFLLEdBQUcsd0NBQXdDLFVBQVUsaUJBQWlCLEtBQUssU0FBUyxpQkFBaUIsZ0RBQWdELGdEQUFnRCxLQUFLLFFBQVEsaUJBQWlCLEtBQUssR0FBRyxnQ0FBZ0MsVUFBVSxpQkFBaUIsS0FBSyxTQUFTLGlCQUFpQixnREFBZ0QsZ0RBQWdELEtBQUssUUFBUSxpQkFBaUIsS0FBSyxHQUFHLHlCQUF5Qiw2Q0FBNkMsNkNBQTZDLEdBQUcsMEJBQTBCLDhDQUE4Qyw4Q0FBOEMsR0FBRyx5Q0FBeUMsVUFBVSxxRUFBcUUscUVBQXFFLGlEQUFpRCxpREFBaUQsaUJBQWlCLEtBQUssU0FBUyxzRUFBc0Usc0VBQXNFLGlEQUFpRCxpREFBaUQsS0FBSyxTQUFTLHFFQUFxRSxxRUFBcUUsaUJBQWlCLEtBQUssU0FBUyxxRUFBcUUscUVBQXFFLEtBQUssUUFBUSw0Q0FBNEMsNENBQTRDLEtBQUssR0FBRyxpQ0FBaUMsVUFBVSxxRUFBcUUscUVBQXFFLGlEQUFpRCxpREFBaUQsaUJBQWlCLEtBQUssU0FBUyxzRUFBc0Usc0VBQXNFLGlEQUFpRCxpREFBaUQsS0FBSyxTQUFTLHFFQUFxRSxxRUFBcUUsaUJBQWlCLEtBQUssU0FBUyxxRUFBcUUscUVBQXFFLEtBQUssUUFBUSw0Q0FBNEMsNENBQTRDLEtBQUssR0FBRyx3Q0FBd0MsVUFBVSw0Q0FBNEMsNENBQTRDLEtBQUssU0FBUyxzRUFBc0Usc0VBQXNFLGlCQUFpQixLQUFLLFFBQVEscUVBQXFFLHFFQUFxRSxpQkFBaUIsS0FBSyxHQUFHLGdDQUFnQyxVQUFVLDRDQUE0Qyw0Q0FBNEMsS0FBSyxTQUFTLHNFQUFzRSxzRUFBc0UsaUJBQWlCLEtBQUssUUFBUSxxRUFBcUUscUVBQXFFLGlCQUFpQixLQUFLLEdBQUcseUJBQXlCLDZDQUE2Qyw2Q0FBNkMsR0FBRywwQkFBMEIsOENBQThDLDhDQUE4QyxHQUFHLCtDQUErQyxVQUFVLGlEQUFpRCxpREFBaUQsMEJBQTBCLEtBQUssUUFBUSw4Q0FBOEMsOENBQThDLEtBQUssR0FBRyx1Q0FBdUMsVUFBVSxpREFBaUQsaURBQWlELDBCQUEwQixLQUFLLFFBQVEsOENBQThDLDhDQUE4QyxLQUFLLEdBQUcsNENBQTRDLFVBQVUsa0RBQWtELGtEQUFrRCwwQkFBMEIsS0FBSyxRQUFRLDhDQUE4Qyw4Q0FBOEMsS0FBSyxHQUFHLG9DQUFvQyxVQUFVLGtEQUFrRCxrREFBa0QsMEJBQTBCLEtBQUssUUFBUSw4Q0FBOEMsOENBQThDLEtBQUssR0FBRywwQ0FBMEMsVUFBVSxpREFBaUQsaURBQWlELDBCQUEwQixLQUFLLFFBQVEsOENBQThDLDhDQUE4QyxLQUFLLEdBQUcsa0NBQWtDLFVBQVUsaURBQWlELGlEQUFpRCwwQkFBMEIsS0FBSyxRQUFRLDhDQUE4Qyw4Q0FBOEMsS0FBSyxHQUFHLDRDQUE0QyxVQUFVLGtEQUFrRCxrREFBa0QsMEJBQTBCLEtBQUssUUFBUSw4Q0FBOEMsOENBQThDLEtBQUssR0FBRyxvQ0FBb0MsVUFBVSxrREFBa0Qsa0RBQWtELDBCQUEwQixLQUFLLFFBQVEsOENBQThDLDhDQUE4QyxLQUFLLEdBQUcsOENBQThDLFVBQVUsOENBQThDLDhDQUE4QyxLQUFLLFFBQVEseUJBQXlCLGlEQUFpRCxpREFBaUQsS0FBSyxHQUFHLHNDQUFzQyxVQUFVLDhDQUE4Qyw4Q0FBOEMsS0FBSyxRQUFRLHlCQUF5QixpREFBaUQsaURBQWlELEtBQUssR0FBRyw2Q0FBNkMsVUFBVSw4Q0FBOEMsOENBQThDLEtBQUssUUFBUSx5QkFBeUIsa0RBQWtELGtEQUFrRCxLQUFLLEdBQUcscUNBQXFDLFVBQVUsOENBQThDLDhDQUE4QyxLQUFLLFFBQVEseUJBQXlCLGtEQUFrRCxrREFBa0QsS0FBSyxHQUFHLDZDQUE2QyxVQUFVLDhDQUE4Qyw4Q0FBOEMsS0FBSyxRQUFRLHlCQUF5QixrREFBa0Qsa0RBQWtELEtBQUssR0FBRyxxQ0FBcUMsVUFBVSw4Q0FBOEMsOENBQThDLEtBQUssUUFBUSx5QkFBeUIsa0RBQWtELGtEQUFrRCxLQUFLLEdBQUcsMkNBQTJDLFVBQVUsOENBQThDLDhDQUE4QyxLQUFLLFFBQVEseUJBQXlCLG1EQUFtRCxtREFBbUQsS0FBSyxHQUFHLG1DQUFtQyxVQUFVLDhDQUE4Qyw4Q0FBOEMsS0FBSyxRQUFRLHlCQUF5QixtREFBbUQsbURBQW1ELEtBQUssR0FBRyx5RUFBeUUsa0RBQWtELGtEQUFrRCxHQUFHLDJFQUEyRSxtREFBbUQsbURBQW1ELEdBQUcsc0NBQXNDLGtEQUFrRCxrREFBa0QsR0FBRyx5Q0FBeUMsZ0RBQWdELGdEQUFnRCxHQUFHLHlFQUF5RSxtREFBbUQsbURBQW1ELEdBQUcseUVBQXlFLG9EQUFvRCxvREFBb0QsR0FBRyxxQ0FBcUMsaURBQWlELGlEQUFpRCxHQUFHLHdDQUF3QyxtREFBbUQsbURBQW1ELEdBQUcsdUNBQXVDLFVBQVUsc0NBQXNDLHNDQUFzQyxLQUFLLFFBQVEsd0NBQXdDLHdDQUF3QyxLQUFLLEdBQUcsK0JBQStCLFVBQVUsc0NBQXNDLHNDQUFzQyxLQUFLLFFBQVEsd0NBQXdDLHdDQUF3QyxLQUFLLEdBQUcsd0RBQXdELHU0QkFBdTRCLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsWUFBWSxLQUFLLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxNQUFNLE1BQU0sV0FBVyxXQUFXLFVBQVUsVUFBVSxXQUFXLFdBQVcsV0FBVyxVQUFVLE1BQU0sTUFBTSxVQUFVLFVBQVUsTUFBTSxNQUFNLFVBQVUsVUFBVSxXQUFXLFdBQVcsTUFBTSxNQUFNLFVBQVUsVUFBVSxNQUFNLE1BQU0sVUFBVSxVQUFVLE1BQU0sTUFBTSxVQUFVLFVBQVUsV0FBVyxXQUFXLE1BQU0sTUFBTSxVQUFVLFVBQVUsT0FBTyxNQUFNLEtBQUssVUFBVSxVQUFVLFVBQVUsVUFBVSxNQUFNLE1BQU0sVUFBVSxXQUFXLFdBQVcsTUFBTSxNQUFNLFVBQVUsV0FBVyxXQUFXLE1BQU0sTUFBTSxVQUFVLFVBQVUsTUFBTSxLQUFLLE1BQU0sV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFVBQVUsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFVBQVUsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsVUFBVSxVQUFVLE1BQU0sTUFBTSxVQUFVLE1BQU0sTUFBTSxVQUFVLFdBQVcsV0FBVyxVQUFVLFVBQVUsV0FBVyxXQUFXLFVBQVUsV0FBVyxXQUFXLFdBQVcsTUFBTSxNQUFNLFVBQVUsV0FBVyxVQUFVLE1BQU0sTUFBTSxXQUFXLFdBQVcsVUFBVSxXQUFXLFVBQVUsV0FBVyxXQUFXLFVBQVUsT0FBTyxNQUFNLFdBQVcsV0FBVyxXQUFXLFdBQVcsT0FBTyxNQUFNLFdBQVcsV0FBVyxXQUFXLFdBQVcsT0FBTyxNQUFNLEtBQUssV0FBVyxXQUFXLE1BQU0sS0FBSyxNQUFNLFdBQVcsV0FBVyxNQUFNLE1BQU0sV0FBVyxXQUFXLE1BQU0sTUFBTSxXQUFXLFdBQVcsTUFBTSxNQUFNLFdBQVcsV0FBVyxNQUFNLE1BQU0sV0FBVyxXQUFXLE1BQU0sTUFBTSxXQUFXLFdBQVcsTUFBTSxNQUFNLFdBQVcsV0FBVyxPQUFPLE1BQU0sV0FBVyxNQUFNLE1BQU0sV0FBVyxNQUFNLE1BQU0sV0FBVyxNQUFNLE1BQU0sV0FBVyxNQUFNLE1BQU0sV0FBVyxNQUFNLE1BQU0sV0FBVyxNQUFNLE1BQU0sV0FBVyxPQUFPLE1BQU0sVUFBVSxXQUFXLFVBQVUsVUFBVSxVQUFVLFVBQVUsVUFBVSxXQUFXLFdBQVcsV0FBVyxXQUFXLE1BQU0sTUFBTSxVQUFVLFVBQVUsTUFBTSxNQUFNLFdBQVcsVUFBVSxVQUFVLE1BQU0sTUFBTSxVQUFVLE9BQU8sTUFBTSxLQUFLLFdBQVcsV0FBVyxNQUFNLE1BQU0sV0FBVyxXQUFXLE1BQU0sTUFBTSxNQUFNLEtBQUssV0FBVyxXQUFXLE1BQU0sTUFBTSxXQUFXLFdBQVcsTUFBTSxLQUFLLE1BQU0sV0FBVyxVQUFVLFVBQVUsVUFBVSxVQUFVLFdBQVcsVUFBVSxXQUFXLFdBQVcsTUFBTSxNQUFNLFdBQVcsV0FBVyxNQUFNLE1BQU0sV0FBVyxXQUFXLFdBQVcsV0FBVyxNQUFNLE1BQU0sVUFBVSxVQUFVLFdBQVcsV0FBVyxPQUFPLE1BQU0sVUFBVSxVQUFVLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxXQUFXLFdBQVcsV0FBVyxPQUFPLE1BQU0sS0FBSyxXQUFXLFdBQVcsTUFBTSxNQUFNLFVBQVUsV0FBVyxXQUFXLE1BQU0sTUFBTSxVQUFVLFdBQVcsV0FBVyxNQUFNLE1BQU0sV0FBVyxXQUFXLE1BQU0sTUFBTSxXQUFXLFdBQVcsTUFBTSxNQUFNLFdBQVcsVUFBVSxNQUFNLE1BQU0sTUFBTSxLQUFLLFdBQVcsV0FBVyxNQUFNLE1BQU0sVUFBVSxXQUFXLFdBQVcsTUFBTSxNQUFNLFVBQVUsV0FBVyxXQUFXLE1BQU0sTUFBTSxXQUFXLFdBQVcsTUFBTSxNQUFNLFdBQVcsV0FBVyxNQUFNLE1BQU0sV0FBVyxVQUFVLE1BQU0sS0FBSyxNQUFNLEtBQUssVUFBVSxXQUFXLFdBQVcsTUFBTSxNQUFNLFVBQVUsV0FBVyxXQUFXLE1BQU0sS0FBSyxNQUFNLEtBQUssVUFBVSxXQUFXLFdBQVcsTUFBTSxNQUFNLFVBQVUsV0FBVyxXQUFXLE1BQU0sS0FBSyxNQUFNLEtBQUssWUFBWSxXQUFXLE1BQU0sTUFBTSxVQUFVLFdBQVcsV0FBVyxNQUFNLE1BQU0sVUFBVSxXQUFXLFdBQVcsTUFBTSxNQUFNLFdBQVcsV0FBVyxNQUFNLE1BQU0sV0FBVyxXQUFXLE1BQU0sTUFBTSxXQUFXLFVBQVUsTUFBTSxLQUFLLE1BQU0sS0FBSyxZQUFZLFdBQVcsTUFBTSxNQUFNLFVBQVUsV0FBVyxXQUFXLE1BQU0sTUFBTSxVQUFVLFdBQVcsV0FBVyxNQUFNLE1BQU0sV0FBVyxXQUFXLE1BQU0sTUFBTSxXQUFXLFdBQVcsTUFBTSxNQUFNLFdBQVcsVUFBVSxNQUFNLEtBQUssTUFBTSxLQUFLLFVBQVUsV0FBVyxXQUFXLE1BQU0sTUFBTSxVQUFVLFdBQVcsV0FBVyxNQUFNLEtBQUssTUFBTSxLQUFLLFVBQVUsV0FBVyxXQUFXLE1BQU0sTUFBTSxVQUFVLFdBQVcsV0FBVyxNQUFNLEtBQUssTUFBTSxLQUFLLFlBQVksV0FBVyxNQUFNLE1BQU0sVUFBVSxXQUFXLFdBQVcsTUFBTSxNQUFNLFVBQVUsV0FBVyxXQUFXLE1BQU0sTUFBTSxXQUFXLFdBQVcsTUFBTSxNQUFNLFdBQVcsV0FBVyxNQUFNLE1BQU0sV0FBVyxXQUFXLE1BQU0sS0FBSyxNQUFNLEtBQUssWUFBWSxXQUFXLE1BQU0sTUFBTSxVQUFVLFdBQVcsV0FBVyxNQUFNLE1BQU0sVUFBVSxXQUFXLFdBQVcsTUFBTSxNQUFNLFdBQVcsV0FBVyxNQUFNLE1BQU0sV0FBVyxXQUFXLE1BQU0sTUFBTSxXQUFXLFdBQVcsTUFBTSxLQUFLLE1BQU0sS0FBSyxXQUFXLFdBQVcsTUFBTSxNQUFNLFVBQVUsV0FBVyxXQUFXLE1BQU0sTUFBTSxVQUFVLFdBQVcsV0FBVyxNQUFNLEtBQUssTUFBTSxLQUFLLFdBQVcsV0FBVyxNQUFNLE1BQU0sVUFBVSxXQUFXLFdBQVcsTUFBTSxNQUFNLFVBQVUsV0FBVyxXQUFXLE1BQU0sS0FBSyxNQUFNLEtBQUssWUFBWSxXQUFXLE1BQU0sTUFBTSxVQUFVLFdBQVcsV0FBVyxNQUFNLE1BQU0sVUFBVSxXQUFXLFdBQVcsTUFBTSxNQUFNLFdBQVcsV0FBVyxNQUFNLE1BQU0sV0FBVyxXQUFXLE1BQU0sTUFBTSxXQUFXLFVBQVUsTUFBTSxLQUFLLE1BQU0sS0FBSyxZQUFZLFdBQVcsTUFBTSxNQUFNLFVBQVUsV0FBVyxXQUFXLE1BQU0sTUFBTSxVQUFVLFdBQVcsV0FBVyxNQUFNLE1BQU0sV0FBVyxXQUFXLE1BQU0sTUFBTSxXQUFXLFdBQVcsTUFBTSxNQUFNLFdBQVcsVUFBVSxNQUFNLEtBQUssTUFBTSxLQUFLLFdBQVcsV0FBVyxNQUFNLE1BQU0sVUFBVSxXQUFXLFdBQVcsTUFBTSxNQUFNLFVBQVUsV0FBVyxXQUFXLE1BQU0sS0FBSyxNQUFNLEtBQUssV0FBVyxXQUFXLE1BQU0sTUFBTSxVQUFVLFdBQVcsV0FBVyxNQUFNLE1BQU0sVUFBVSxXQUFXLFdBQVcsTUFBTSxLQUFLLE1BQU0sV0FBVyxXQUFXLE1BQU0sTUFBTSxXQUFXLFdBQVcsTUFBTSxNQUFNLFdBQVcsV0FBVyxNQUFNLE1BQU0sV0FBVyxXQUFXLE9BQU8sTUFBTSxXQUFXLFdBQVcsTUFBTSxNQUFNLFdBQVcsV0FBVyxNQUFNLE1BQU0sV0FBVyxXQUFXLE1BQU0sTUFBTSxXQUFXLFdBQVcsT0FBTyxNQUFNLEtBQUssVUFBVSxXQUFXLFdBQVcsTUFBTSxNQUFNLFVBQVUsTUFBTSxNQUFNLE1BQU0sS0FBSyxVQUFVLFdBQVcsV0FBVyxNQUFNLE1BQU0sVUFBVSxNQUFNLEtBQUssTUFBTSxLQUFLLFVBQVUsTUFBTSxNQUFNLFVBQVUsV0FBVyxXQUFXLE1BQU0sTUFBTSxVQUFVLE1BQU0sS0FBSyxNQUFNLEtBQUssVUFBVSxNQUFNLE1BQU0sVUFBVSxXQUFXLFdBQVcsTUFBTSxNQUFNLFVBQVUsTUFBTSxLQUFLLE1BQU0sV0FBVyxXQUFXLE9BQU8sTUFBTSxXQUFXLFdBQVcsT0FBTyxNQUFNLEtBQUssV0FBVyxXQUFXLFdBQVcsV0FBVyxVQUFVLE1BQU0sTUFBTSxXQUFXLFdBQVcsV0FBVyxXQUFXLE1BQU0sTUFBTSxXQUFXLFdBQVcsVUFBVSxNQUFNLE1BQU0sV0FBVyxXQUFXLE1BQU0sTUFBTSxXQUFXLFdBQVcsTUFBTSxNQUFNLE1BQU0sS0FBSyxXQUFXLFdBQVcsV0FBVyxXQUFXLFVBQVUsTUFBTSxNQUFNLFdBQVcsV0FBVyxXQUFXLFdBQVcsTUFBTSxNQUFNLFdBQVcsV0FBVyxVQUFVLE1BQU0sTUFBTSxXQUFXLFdBQVcsTUFBTSxNQUFNLFdBQVcsV0FBVyxNQUFNLEtBQUssTUFBTSxLQUFLLFdBQVcsV0FBVyxNQUFNLE1BQU0sV0FBVyxXQUFXLFVBQVUsTUFBTSxNQUFNLFdBQVcsV0FBVyxVQUFVLE1BQU0sS0FBSyxNQUFNLEtBQUssV0FBVyxXQUFXLE1BQU0sTUFBTSxXQUFXLFdBQVcsVUFBVSxNQUFNLE1BQU0sV0FBVyxXQUFXLFVBQVUsTUFBTSxLQUFLLE1BQU0sV0FBVyxXQUFXLE9BQU8sTUFBTSxXQUFXLFdBQVcsT0FBTyxNQUFNLEtBQUssV0FBVyxXQUFXLFdBQVcsTUFBTSxNQUFNLFdBQVcsV0FBVyxNQUFNLE1BQU0sTUFBTSxLQUFLLFdBQVcsV0FBVyxXQUFXLE1BQU0sTUFBTSxXQUFXLFdBQVcsTUFBTSxLQUFLLE1BQU0sS0FBSyxXQUFXLFdBQVcsV0FBVyxNQUFNLE1BQU0sWUFBWSxXQUFXLE9BQU8sS0FBSyxNQUFNLEtBQUssV0FBVyxXQUFXLFdBQVcsTUFBTSxNQUFNLFlBQVksV0FBVyxPQUFPLEtBQUssTUFBTSxLQUFLLFdBQVcsV0FBVyxXQUFXLE1BQU0sTUFBTSxZQUFZLFdBQVcsT0FBTyxLQUFLLE1BQU0sS0FBSyxXQUFXLFdBQVcsV0FBVyxNQUFNLE1BQU0sWUFBWSxXQUFXLE9BQU8sS0FBSyxNQUFNLEtBQUssV0FBVyxXQUFXLFdBQVcsTUFBTSxNQUFNLFlBQVksV0FBVyxPQUFPLEtBQUssTUFBTSxLQUFLLFdBQVcsV0FBVyxXQUFXLE1BQU0sTUFBTSxZQUFZLFdBQVcsT0FBTyxLQUFLLE1BQU0sS0FBSyxZQUFZLFdBQVcsT0FBTyxNQUFNLFdBQVcsV0FBVyxXQUFXLE1BQU0sS0FBSyxNQUFNLEtBQUssWUFBWSxXQUFXLE9BQU8sTUFBTSxXQUFXLFdBQVcsV0FBVyxNQUFNLEtBQUssTUFBTSxLQUFLLFlBQVksV0FBVyxPQUFPLE1BQU0sV0FBVyxXQUFXLFdBQVcsTUFBTSxLQUFLLE1BQU0sS0FBSyxZQUFZLFdBQVcsT0FBTyxNQUFNLFdBQVcsV0FBVyxXQUFXLE1BQU0sS0FBSyxNQUFNLEtBQUssWUFBWSxXQUFXLE9BQU8sTUFBTSxXQUFXLFdBQVcsV0FBVyxNQUFNLEtBQUssTUFBTSxLQUFLLFlBQVksV0FBVyxPQUFPLE1BQU0sV0FBVyxXQUFXLFdBQVcsTUFBTSxLQUFLLE1BQU0sS0FBSyxZQUFZLFdBQVcsT0FBTyxNQUFNLFdBQVcsV0FBVyxXQUFXLE1BQU0sS0FBSyxNQUFNLEtBQUssWUFBWSxXQUFXLE9BQU8sTUFBTSxXQUFXLFdBQVcsV0FBVyxNQUFNLEtBQUssTUFBTSxXQUFXLFdBQVcsTUFBTSxNQUFNLFdBQVcsV0FBVyxNQUFNLE1BQU0sV0FBVyxXQUFXLE1BQU0sTUFBTSxXQUFXLFdBQVcsT0FBTyxNQUFNLFdBQVcsV0FBVyxNQUFNLE1BQU0sV0FBVyxXQUFXLE1BQU0sTUFBTSxXQUFXLFdBQVcsTUFBTSxNQUFNLFdBQVcsV0FBVyxPQUFPLE9BQU8sS0FBSyxXQUFXLFdBQVcsT0FBTyxPQUFPLFdBQVcsV0FBVyxPQUFPLE1BQU0sT0FBTyxLQUFLLFdBQVcsV0FBVyxPQUFPLE9BQU8sV0FBVyxXQUFXLE9BQU8sTUFBTSw2QkFBNkI7QUFDcHl1QztBQUNBLGlFQUFlLHVCQUF1QixFQUFDOzs7Ozs7Ozs7Ozs7Ozs7QUNQdkM7QUFDQSxpRUFBZTtBQUNmO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsQ0FBQyxFQUFDOzs7Ozs7Ozs7Ozs7Ozs7QUNORjtBQUNBLGlFQUFlO0FBQ2Y7QUFDQSxDQUFDLEVBQUM7Ozs7Ozs7Ozs7Ozs7OztBQ0hGO0FBQ0EsaUVBQWU7QUFDZjtBQUNBLENBQUMsRUFBQzs7Ozs7Ozs7Ozs7Ozs7O0FDSEY7QUFDQSxpRUFBZTtBQUNmO0FBQ0EsQ0FBQyxFQUFDOzs7Ozs7Ozs7Ozs7Ozs7QUNIRjtBQUNBLGlFQUFlO0FBQ2Y7QUFDQSxDQUFDLEVBQUM7Ozs7Ozs7Ozs7Ozs7OztBQ0hGO0FBQ0EsaUVBQWU7QUFDZjtBQUNBLENBQUMsRUFBQzs7Ozs7Ozs7Ozs7Ozs7O0FDSEY7QUFDQSxpRUFBZTtBQUNmO0FBQ0EsQ0FBQyxFQUFDOzs7Ozs7Ozs7Ozs7Ozs7QUNIRjtBQUNBLGlFQUFlO0FBQ2Y7QUFDQSxDQUFDLEVBQUM7Ozs7Ozs7Ozs7Ozs7OztBQ0hGO0FBQ0EsaUVBQWU7QUFDZjtBQUNBLENBQUMsRUFBQzs7Ozs7Ozs7Ozs7Ozs7O0FDSEY7QUFDQSxpRUFBZTtBQUNmO0FBQ0EsQ0FBQyxFQUFDOzs7Ozs7Ozs7OztBQ0hXOztBQUViO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsaUJBQWlCOztBQUVqQjtBQUNBO0FBQ0E7O0FBRUE7QUFDQSw0Q0FBNEMscUJBQXFCO0FBQ2pFOztBQUVBO0FBQ0EsS0FBSztBQUNMLEtBQUs7QUFDTDs7O0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTs7QUFFQTtBQUNBLHNCQUFzQixpQkFBaUI7QUFDdkM7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLHFCQUFxQixxQkFBcUI7QUFDMUM7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsVUFBVTtBQUNWO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7Ozs7Ozs7OztBQ2pFYTs7QUFFYixrQ0FBa0M7O0FBRWxDLDhCQUE4Qjs7QUFFOUIsa0RBQWtELGdCQUFnQixnRUFBZ0Usd0RBQXdELDZEQUE2RCxzREFBc0Q7O0FBRTdTLHVDQUF1Qyx1REFBdUQsdUNBQXVDLFNBQVMsT0FBTyxvQkFBb0I7O0FBRXpLLHlDQUF5Qyw4RkFBOEYsd0JBQXdCLGVBQWUsZUFBZSxnQkFBZ0IsWUFBWSxNQUFNLHdCQUF3QiwrQkFBK0IsYUFBYSxxQkFBcUIsdUNBQXVDLGNBQWMsV0FBVyxZQUFZLFVBQVUsTUFBTSxtREFBbUQsVUFBVSxzQkFBc0I7O0FBRXZlLGdDQUFnQzs7QUFFaEM7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLHVEQUF1RCxjQUFjO0FBQ3JFO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUNBOztBQUVBO0FBQ0E7Ozs7Ozs7Ozs7QUNuQ0E7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUE7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7OztBQ0FBOzs7Ozs7Ozs7O0FDQUE7Ozs7OztVQ0FBO1VBQ0E7O1VBRUE7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7O1VBRUE7VUFDQTs7VUFFQTtVQUNBO1VBQ0E7O1VBRUE7VUFDQTs7Ozs7V0N6QkE7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLGlDQUFpQyxXQUFXO1dBQzVDO1dBQ0E7Ozs7O1dDUEE7V0FDQTtXQUNBO1dBQ0E7V0FDQSx5Q0FBeUMsd0NBQXdDO1dBQ2pGO1dBQ0E7V0FDQTs7Ozs7V0NQQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLEVBQUU7V0FDRjs7Ozs7V0NSQTtXQUNBO1dBQ0E7V0FDQTtXQUNBOzs7OztXQ0pBOzs7OztXQ0FBO1dBQ0E7V0FDQTtXQUNBLHVEQUF1RCxpQkFBaUI7V0FDeEU7V0FDQSxnREFBZ0QsYUFBYTtXQUM3RDs7Ozs7V0NOQTs7V0FFQTtXQUNBO1dBQ0E7V0FDQTtXQUNBOztXQUVBOztXQUVBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQSxnQkFBZ0IscUJBQXFCO1dBQ3JDOztXQUVBOztXQUVBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EsYUFBYTtXQUNiO1dBQ0EsSUFBSTtXQUNKO1dBQ0E7O1dBRUE7O1dBRUE7O1dBRUE7Ozs7O1VFckNBO1VBQ0E7VUFDQTtVQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vaW50cmFuZXQvLi9zcmMvYXBwL2luZGV4LnRzeCIsIndlYnBhY2s6Ly9pbnRyYW5ldC8uL3NyYy9jb21wb25lbnRzL0FkZEVudmllL2luZGV4LnRzeCIsIndlYnBhY2s6Ly9pbnRyYW5ldC8uL3NyYy9jb21wb25lbnRzL0Vycm9yQm91bmRhcnkvaW5kZXgudHN4Iiwid2VicGFjazovL2ludHJhbmV0Ly4vc3JjL2NvbXBvbmVudHMvSmV1SmF2TGlzdC9pbmRleC50c3giLCJ3ZWJwYWNrOi8vaW50cmFuZXQvLi9zcmMvY29tcG9uZW50cy9Mb2FkaW5nL2luZGV4LnRzeCIsIndlYnBhY2s6Ly9pbnRyYW5ldC8uL3NyYy9jb21wb25lbnRzL01lbWJyZUluZm8vaW5kZXgudHN4Iiwid2VicGFjazovL2ludHJhbmV0Ly4vc3JjL2NvbXBvbmVudHMvTWVtYnJlTGlzdC9pbmRleC50c3giLCJ3ZWJwYWNrOi8vaW50cmFuZXQvLi9zcmMvY29tcG9uZW50cy9NZW1icmVTZXQvaW5kZXgudHN4Iiwid2VicGFjazovL2ludHJhbmV0Ly4vc3JjL2NvbXBvbmVudHMvaW5kZXgudHMiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvLi9zcmMvY29uZmlnL2RlZmF1bHQudHMiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvLi9zcmMvY29uZmlnL2luZGV4LnRzIiwid2VicGFjazovL2ludHJhbmV0Ly4vc3JjL2NvbmZpZy9wcm9kLnRzIiwid2VicGFjazovL2ludHJhbmV0Ly4vc3JjL3BhZ2VzL0hvbWUvSG9tZS50c3giLCJ3ZWJwYWNrOi8vaW50cmFuZXQvLi9zcmMvcGFnZXMvSG9tZS9pbmRleC50c3giLCJ3ZWJwYWNrOi8vaW50cmFuZXQvLi9zcmMvcGFnZXMvTG9naW4vaW5kZXgudHN4Iiwid2VicGFjazovL2ludHJhbmV0Ly4vc3JjL3BhZ2VzL01lbWJyZVBhZ2UvTWVtYnJlUGFnZS50c3giLCJ3ZWJwYWNrOi8vaW50cmFuZXQvLi9zcmMvcGFnZXMvTWVtYnJlUGFnZS9pbmRleC50c3giLCJ3ZWJwYWNrOi8vaW50cmFuZXQvLi9zcmMvcGFnZXMvTm90Rm91bmQvaW5kZXgudHN4Iiwid2VicGFjazovL2ludHJhbmV0Ly4vc3JjL3BhZ2VzL1JlZ2lzdGVyL2luZGV4LnRzeCIsIndlYnBhY2s6Ly9pbnRyYW5ldC8uL3NyYy9yb3V0ZXMvY2VydGJvdC50cyIsIndlYnBhY2s6Ly9pbnRyYW5ldC8uL3NyYy9yb3V0ZXMvaW5kZXgudHMiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvLi9zcmMvc2VydmVyL2RldlNlcnZlci50cyIsIndlYnBhY2s6Ly9pbnRyYW5ldC8uL3NyYy9zZXJ2ZXIvZ3NoZWV0cy9EQk1hbmFnZXIudHMiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvLi9zcmMvc2VydmVyL2dzaGVldHMvYWNjZXNzb3JzLnRzIiwid2VicGFjazovL2ludHJhbmV0Ly4vc3JjL3NlcnZlci9nc2hlZXRzL2Vudmllcy50cyIsIndlYnBhY2s6Ly9pbnRyYW5ldC8uL3NyYy9zZXJ2ZXIvZ3NoZWV0cy9leHByZXNzQWNjZXNzb3JzLnRzIiwid2VicGFjazovL2ludHJhbmV0Ly4vc3JjL3NlcnZlci9nc2hlZXRzL2pldUphdi50cyIsIndlYnBhY2s6Ly9pbnRyYW5ldC8uL3NyYy9zZXJ2ZXIvZ3NoZWV0cy9tZW1icmVzLnRzIiwid2VicGFjazovL2ludHJhbmV0Ly4vc3JjL3NlcnZlci9pbmRleC50cyIsIndlYnBhY2s6Ly9pbnRyYW5ldC8uL3NyYy9zZXJ2ZXIvcmVuZGVySHRtbC50cyIsIndlYnBhY2s6Ly9pbnRyYW5ldC8uL3NyYy9zZXJ2ZXIvc2VjdXJlLnRzIiwid2VicGFjazovL2ludHJhbmV0Ly4vc3JjL3NlcnZlci9zc3IudHN4Iiwid2VicGFjazovL2ludHJhbmV0Ly4vc3JjL3NlcnZlci91c2VyTWFuYWdlbWVudC9sb2dpbi50cyIsIndlYnBhY2s6Ly9pbnRyYW5ldC8uL3NyYy9zZXJ2aWNlcy9hY2Nlc3NvcnMudHMiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvLi9zcmMvc2VydmljZXMvYXV0aC50cyIsIndlYnBhY2s6Ly9pbnRyYW5ldC8uL3NyYy9zZXJ2aWNlcy9lbnZpZXMudHMiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvLi9zcmMvc2VydmljZXMvamV1eEphdi50cyIsIndlYnBhY2s6Ly9pbnRyYW5ldC8uL3NyYy9zZXJ2aWNlcy9tZW1icmVzLnRzIiwid2VicGFjazovL2ludHJhbmV0Ly4vc3JjL3N0b3JlL2VudmllQWRkLnRzIiwid2VicGFjazovL2ludHJhbmV0Ly4vc3JjL3N0b3JlL2VudmllTGlzdC50cyIsIndlYnBhY2s6Ly9pbnRyYW5ldC8uL3NyYy9zdG9yZS9pbmRleC50cyIsIndlYnBhY2s6Ly9pbnRyYW5ldC8uL3NyYy9zdG9yZS9qZXVKYXZMaXN0LnRzIiwid2VicGFjazovL2ludHJhbmV0Ly4vc3JjL3N0b3JlL21lbWJyZS50cyIsIndlYnBhY2s6Ly9pbnRyYW5ldC8uL3NyYy9zdG9yZS9tZW1icmVBZGQudHMiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvLi9zcmMvc3RvcmUvbWVtYnJlTGlzdC50cyIsIndlYnBhY2s6Ly9pbnRyYW5ldC8uL3NyYy9zdG9yZS9tZW1icmVTZXQudHMiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvLi9zcmMvc3RvcmUvcm9vdFJlZHVjZXIudHMiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvLi9zcmMvc3RvcmUvdXRpbHMudHMiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvLi9zcmMvdXRpbHMvc3RhbmRhcmRpemF0aW9uLnRzIiwid2VicGFjazovL2ludHJhbmV0Ly4vd2VicGFjay9iYXNlLmNvbmZpZy50cyIsIndlYnBhY2s6Ly9pbnRyYW5ldC8uL3dlYnBhY2svY2xpZW50LmNvbmZpZy50cyIsIndlYnBhY2s6Ly9pbnRyYW5ldC8uL25vZGVfbW9kdWxlcy9ub3JtYWxpemUuY3NzL25vcm1hbGl6ZS5jc3MiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvLi9ub2RlX21vZHVsZXMvcmVhY3QtdG9hc3RpZnkvZGlzdC9SZWFjdFRvYXN0aWZ5LmNzcyIsIndlYnBhY2s6Ly9pbnRyYW5ldC8uL3NyYy9hcHAvc3R5bGVzLm1vZHVsZS5zY3NzIiwid2VicGFjazovL2ludHJhbmV0Ly4vc3JjL2NvbXBvbmVudHMvQWRkRW52aWUvc3R5bGVzLm1vZHVsZS5zY3NzIiwid2VicGFjazovL2ludHJhbmV0Ly4vc3JjL2NvbXBvbmVudHMvSmV1SmF2TGlzdC9zdHlsZXMubW9kdWxlLnNjc3MiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvLi9zcmMvY29tcG9uZW50cy9Mb2FkaW5nL3N0eWxlcy5tb2R1bGUuc2NzcyIsIndlYnBhY2s6Ly9pbnRyYW5ldC8uL3NyYy9jb21wb25lbnRzL01lbWJyZUluZm8vc3R5bGVzLm1vZHVsZS5zY3NzIiwid2VicGFjazovL2ludHJhbmV0Ly4vc3JjL2NvbXBvbmVudHMvTWVtYnJlTGlzdC9zdHlsZXMubW9kdWxlLnNjc3MiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvLi9zcmMvY29tcG9uZW50cy9NZW1icmVTZXQvc3R5bGVzLm1vZHVsZS5zY3NzIiwid2VicGFjazovL2ludHJhbmV0Ly4vc3JjL3BhZ2VzL0hvbWUvc3R5bGVzLm1vZHVsZS5zY3NzIiwid2VicGFjazovL2ludHJhbmV0Ly4vc3JjL3BhZ2VzL01lbWJyZVBhZ2Uvc3R5bGVzLm1vZHVsZS5zY3NzIiwid2VicGFjazovL2ludHJhbmV0Ly4vc3JjL3BhZ2VzL05vdEZvdW5kL3N0eWxlcy5tb2R1bGUuc2NzcyIsIndlYnBhY2s6Ly9pbnRyYW5ldC8uL25vZGVfbW9kdWxlcy9jc3MtbG9hZGVyL2Rpc3QvcnVudGltZS9hcGkuanMiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvLi9ub2RlX21vZHVsZXMvY3NzLWxvYWRlci9kaXN0L3J1bnRpbWUvY3NzV2l0aE1hcHBpbmdUb1N0cmluZy5qcyIsIndlYnBhY2s6Ly9pbnRyYW5ldC9leHRlcm5hbCBjb21tb25qcyBcIkBiYWJlbC9ydW50aW1lL2hlbHBlcnMvYXN5bmNUb0dlbmVyYXRvclwiIiwid2VicGFjazovL2ludHJhbmV0L2V4dGVybmFsIGNvbW1vbmpzIFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9jbGFzc0NhbGxDaGVja1wiIiwid2VicGFjazovL2ludHJhbmV0L2V4dGVybmFsIGNvbW1vbmpzIFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9jcmVhdGVDbGFzc1wiIiwid2VicGFjazovL2ludHJhbmV0L2V4dGVybmFsIGNvbW1vbmpzIFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9kZWZpbmVQcm9wZXJ0eVwiIiwid2VicGFjazovL2ludHJhbmV0L2V4dGVybmFsIGNvbW1vbmpzIFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9nZXRQcm90b3R5cGVPZlwiIiwid2VicGFjazovL2ludHJhbmV0L2V4dGVybmFsIGNvbW1vbmpzIFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9pbmhlcml0c1wiIiwid2VicGFjazovL2ludHJhbmV0L2V4dGVybmFsIGNvbW1vbmpzIFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9wb3NzaWJsZUNvbnN0cnVjdG9yUmV0dXJuXCIiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvZXh0ZXJuYWwgY29tbW9uanMgXCJAYmFiZWwvcnVudGltZS9oZWxwZXJzL3NsaWNlZFRvQXJyYXlcIiIsIndlYnBhY2s6Ly9pbnRyYW5ldC9leHRlcm5hbCBjb21tb25qcyBcIkBiYWJlbC9ydW50aW1lL2hlbHBlcnMvdG9Db25zdW1hYmxlQXJyYXlcIiIsIndlYnBhY2s6Ly9pbnRyYW5ldC9leHRlcm5hbCBjb21tb25qcyBcIkBiYWJlbC9ydW50aW1lL3JlZ2VuZXJhdG9yXCIiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvZXh0ZXJuYWwgY29tbW9uanMgXCJAbG9hZGFibGUvc2VydmVyXCIiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvZXh0ZXJuYWwgY29tbW9uanMgXCJAbG9hZGFibGUvd2VicGFjay1wbHVnaW5cIiIsIndlYnBhY2s6Ly9pbnRyYW5ldC9leHRlcm5hbCBjb21tb25qcyBcIkBwbW1td2gvcmVhY3QtcmVmcmVzaC13ZWJwYWNrLXBsdWdpblwiIiwid2VicGFjazovL2ludHJhbmV0L2V4dGVybmFsIGNvbW1vbmpzIFwiQHJlZHV4anMvdG9vbGtpdFwiIiwid2VicGFjazovL2ludHJhbmV0L2V4dGVybmFsIGNvbW1vbmpzIFwiYXhpb3NcIiIsIndlYnBhY2s6Ly9pbnRyYW5ldC9leHRlcm5hbCBjb21tb25qcyBcImJjcnlwdFwiIiwid2VicGFjazovL2ludHJhbmV0L2V4dGVybmFsIGNvbW1vbmpzIFwiY2hhbGtcIiIsIndlYnBhY2s6Ly9pbnRyYW5ldC9leHRlcm5hbCBjb21tb25qcyBcImNvbXByZXNzaW9uXCIiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvZXh0ZXJuYWwgY29tbW9uanMgXCJjb21wcmVzc2lvbi13ZWJwYWNrLXBsdWdpblwiIiwid2VicGFjazovL2ludHJhbmV0L2V4dGVybmFsIGNvbW1vbmpzIFwiY29ubmVjdGVkLXJlYWN0LXJvdXRlclwiIiwid2VicGFjazovL2ludHJhbmV0L2V4dGVybmFsIGNvbW1vbmpzIFwiY3NzLW1pbmltaXplci13ZWJwYWNrLXBsdWdpblwiIiwid2VicGFjazovL2ludHJhbmV0L2V4dGVybmFsIGNvbW1vbmpzIFwiZXhwcmVzc1wiIiwid2VicGFjazovL2ludHJhbmV0L2V4dGVybmFsIGNvbW1vbmpzIFwiZm9yay10cy1jaGVja2VyLXdlYnBhY2stcGx1Z2luXCIiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvZXh0ZXJuYWwgY29tbW9uanMgXCJmc1wiIiwid2VicGFjazovL2ludHJhbmV0L2V4dGVybmFsIGNvbW1vbmpzIFwiZ29vZ2xlLXNwcmVhZHNoZWV0XCIiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvZXh0ZXJuYWwgY29tbW9uanMgXCJoZWxtZXRcIiIsIndlYnBhY2s6Ly9pbnRyYW5ldC9leHRlcm5hbCBjb21tb25qcyBcImhpc3RvcnlcIiIsIndlYnBhY2s6Ly9pbnRyYW5ldC9leHRlcm5hbCBjb21tb25qcyBcImhwcFwiIiwid2VicGFjazovL2ludHJhbmV0L2V4dGVybmFsIGNvbW1vbmpzIFwiaHRtbC1taW5pZmllclwiIiwid2VicGFjazovL2ludHJhbmV0L2V4dGVybmFsIGNvbW1vbmpzIFwiaHR0cHNcIiIsIndlYnBhY2s6Ly9pbnRyYW5ldC9leHRlcm5hbCBjb21tb25qcyBcImltYWdlLW1pbmltaXplci13ZWJwYWNrLXBsdWdpblwiIiwid2VicGFjazovL2ludHJhbmV0L2V4dGVybmFsIGNvbW1vbmpzIFwianNvbndlYnRva2VuXCIiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvZXh0ZXJuYWwgY29tbW9uanMgXCJsb2Rhc2hcIiIsIndlYnBhY2s6Ly9pbnRyYW5ldC9leHRlcm5hbCBjb21tb25qcyBcIm1pbmktY3NzLWV4dHJhY3QtcGx1Z2luXCIiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvZXh0ZXJuYWwgY29tbW9uanMgXCJtb3JnYW5cIiIsIndlYnBhY2s6Ly9pbnRyYW5ldC9leHRlcm5hbCBjb21tb25qcyBcInJlYWN0XCIiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvZXh0ZXJuYWwgY29tbW9uanMgXCJyZWFjdC1kb20vc2VydmVyXCIiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvZXh0ZXJuYWwgY29tbW9uanMgXCJyZWFjdC1oZWxtZXRcIiIsIndlYnBhY2s6Ly9pbnRyYW5ldC9leHRlcm5hbCBjb21tb25qcyBcInJlYWN0LXJlZHV4XCIiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvZXh0ZXJuYWwgY29tbW9uanMgXCJyZWFjdC1yb3V0ZXItY29uZmlnXCIiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvZXh0ZXJuYWwgY29tbW9uanMgXCJyZWFjdC1yb3V0ZXItZG9tXCIiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvZXh0ZXJuYWwgY29tbW9uanMgXCJyZWFjdC10b2FzdGlmeVwiIiwid2VicGFjazovL2ludHJhbmV0L2V4dGVybmFsIGNvbW1vbmpzIFwicmVhY3QvanN4LXJ1bnRpbWVcIiIsIndlYnBhY2s6Ly9pbnRyYW5ldC9leHRlcm5hbCBjb21tb25qcyBcInNlcmlhbGl6ZS1qYXZhc2NyaXB0XCIiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvZXh0ZXJuYWwgY29tbW9uanMgXCJzZXJ2ZS1mYXZpY29uXCIiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvZXh0ZXJuYWwgY29tbW9uanMgXCJ0ZXJzZXItd2VicGFjay1wbHVnaW5cIiIsIndlYnBhY2s6Ly9pbnRyYW5ldC9leHRlcm5hbCBjb21tb25qcyBcIndlYnBhY2tcIiIsIndlYnBhY2s6Ly9pbnRyYW5ldC9leHRlcm5hbCBjb21tb25qcyBcIndlYnBhY2stYnVuZGxlLWFuYWx5emVyXCIiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvZXh0ZXJuYWwgY29tbW9uanMgXCJ3ZWJwYWNrLWRldi1taWRkbGV3YXJlXCIiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvZXh0ZXJuYWwgY29tbW9uanMgXCJ3ZWJwYWNrLWhvdC1taWRkbGV3YXJlXCIiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvZXh0ZXJuYWwgY29tbW9uanMgXCJ3ZWJwYWNrLW1hbmlmZXN0LXBsdWdpblwiIiwid2VicGFjazovL2ludHJhbmV0L2V4dGVybmFsIGNvbW1vbmpzIFwid2VicGFjay1tZXJnZVwiIiwid2VicGFjazovL2ludHJhbmV0L2V4dGVybmFsIGNvbW1vbmpzMiBcIkBsb2FkYWJsZS9jb21wb25lbnRcIiIsIndlYnBhY2s6Ly9pbnRyYW5ldC9leHRlcm5hbCBub2RlLWNvbW1vbmpzIFwiaHR0cFwiIiwid2VicGFjazovL2ludHJhbmV0L2V4dGVybmFsIG5vZGUtY29tbW9uanMgXCJwYXRoXCIiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvd2VicGFjay9ydW50aW1lL2NvbXBhdCBnZXQgZGVmYXVsdCBleHBvcnQiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvd2VicGFjay9ydW50aW1lL2RlZmluZSBwcm9wZXJ0eSBnZXR0ZXJzIiwid2VicGFjazovL2ludHJhbmV0L3dlYnBhY2svcnVudGltZS9lbnN1cmUgY2h1bmsiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvd2VicGFjay9ydW50aW1lL2dldCBqYXZhc2NyaXB0IGNodW5rIGZpbGVuYW1lIiwid2VicGFjazovL2ludHJhbmV0L3dlYnBhY2svcnVudGltZS9oYXNPd25Qcm9wZXJ0eSBzaG9ydGhhbmQiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvd2VicGFjay9ydW50aW1lL21ha2UgbmFtZXNwYWNlIG9iamVjdCIsIndlYnBhY2s6Ly9pbnRyYW5ldC93ZWJwYWNrL3J1bnRpbWUvcmVxdWlyZSBjaHVuayBsb2FkaW5nIiwid2VicGFjazovL2ludHJhbmV0L3dlYnBhY2svYmVmb3JlLXN0YXJ0dXAiLCJ3ZWJwYWNrOi8vaW50cmFuZXQvd2VicGFjay9zdGFydHVwIiwid2VicGFjazovL2ludHJhbmV0L3dlYnBhY2svYWZ0ZXItc3RhcnR1cCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIlxuaW1wb3J0IHsgUm91dGVDb25maWcsIHJlbmRlclJvdXRlcyB9IGZyb20gXCJyZWFjdC1yb3V0ZXItY29uZmlnXCJcbmltcG9ydCB7IEhlbG1ldCB9IGZyb20gXCJyZWFjdC1oZWxtZXRcIlxuaW1wb3J0IHsgVG9hc3RDb250YWluZXIgfSBmcm9tIFwicmVhY3QtdG9hc3RpZnlcIlxuXG5pbXBvcnQgY29uZmlnIGZyb20gXCIuLi9jb25maWdcIlxuLy8gSW1wb3J0IHlvdXIgZ2xvYmFsIHN0eWxlcyBoZXJlXG5pbXBvcnQgXCJub3JtYWxpemUuY3NzL25vcm1hbGl6ZS5jc3NcIlxuaW1wb3J0IFwicmVhY3QtdG9hc3RpZnkvZGlzdC9SZWFjdFRvYXN0aWZ5LmNzc1wiXG5pbXBvcnQgc3R5bGVzIGZyb20gXCIuL3N0eWxlcy5tb2R1bGUuc2Nzc1wiXG5cbmludGVyZmFjZSBSb3V0ZSB7XG4gICAgcm91dGU6IHsgcm91dGVzOiBSb3V0ZUNvbmZpZ1tdIH1cbn1cblxuY29uc3QgQXBwID0gKHsgcm91dGUgfTogUm91dGUpOiBKU1guRWxlbWVudCA9PiAoXG4gICAgPGRpdj5cbiAgICAgICAgPEhlbG1ldCB7Li4uY29uZmlnLkFQUH0+XG4gICAgICAgICAgICA8bWV0YVxuICAgICAgICAgICAgICAgIG5hbWU9XCJ2aWV3cG9ydFwiXG4gICAgICAgICAgICAgICAgY29udGVudD1cIm1pbmltdW0tc2NhbGU9MSwgaW5pdGlhbC1zY2FsZT0xLCB3aWR0aD1kZXZpY2Utd2lkdGgsIHNocmluay10by1maXQ9bm9cIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgPC9IZWxtZXQ+XG4gICAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPXtzdHlsZXMuaGVhZGVyfT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMubG9nb30gLz5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9e3N0eWxlcy5zaXRlTmFtZX0+XG4gICAgICAgICAgICAgICAgPExpbmsgdG89XCIvXCI+e2NvbmZpZy5BUFAudGl0bGV9PC9MaW5rPlxuICAgICAgICAgICAgPC9oMT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuc2l0ZURlc2NyaXB0aW9ufT57Y29uZmlnLkFQUC5kZXNjcmlwdGlvbn08L2Rpdj5cbiAgICAgICAgPC9oZWFkZXI+XG4gICAgICAgIHsvKiBDaGlsZCByb3V0ZXMgd29uJ3QgcmVuZGVyIHdpdGhvdXQgdGhpcyAqL31cbiAgICAgICAge3JlbmRlclJvdXRlcyhyb3V0ZS5yb3V0ZXMpfVxuICAgICAgICA8VG9hc3RDb250YWluZXIgLz5cbiAgICA8L2Rpdj5cbilcblxuZXhwb3J0IGRlZmF1bHQgQXBwXG4iLCJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIG1lbW8gfSBmcm9tIFwicmVhY3RcIlxuaW1wb3J0IHsgdG9hc3QgfSBmcm9tIFwicmVhY3QtdG9hc3RpZnlcIlxuXG5pbXBvcnQgeyBBcHBEaXNwYXRjaCB9IGZyb20gXCIuLi8uLi9zdG9yZVwiXG5cbmltcG9ydCB7IGZldGNoRW52aWVBZGQgfSBmcm9tIFwiLi4vLi4vc3RvcmUvZW52aWVBZGRcIlxuaW1wb3J0IHN0eWxlcyBmcm9tIFwiLi9zdHlsZXMubW9kdWxlLnNjc3NcIlxuXG5pbnRlcmZhY2UgUHJvcHMge1xuICAgIGRpc3BhdGNoOiBBcHBEaXNwYXRjaFxufVxuXG5jb25zdCBBZGRFbnZpZSA9ICh7IGRpc3BhdGNoIH06IFByb3BzKSA9PiB7XG4gICAgY29uc3QgW2RvbWFpbmUsIHNldERvbWFpbmVdID0gdXNlU3RhdGUoXCJcIilcbiAgICBjb25zdCBbZW52aWVzLCBzZXRFbnZpZXNdID0gdXNlU3RhdGUoXCJcIilcbiAgICBjb25zdCBbcHJlY2lzaW9ucywgc2V0UHJlY2lzaW9uc10gPSB1c2VTdGF0ZShcIlwiKVxuICAgIGNvbnN0IFtlcXVpcGVzLCBzZXRFcXVpcGVzXSA9IHVzZVN0YXRlKFtcIlwiXSlcbiAgICBjb25zdCBbZGF0ZUFqb3V0LCBzZXREYXRlQWpvdXRdID0gdXNlU3RhdGUoXCJcIilcblxuICAgIGNvbnN0IG9uRG9tYWluZUNoYW5nZWQgPSAoZTogUmVhY3QuQ2hhbmdlRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pID0+IHNldERvbWFpbmUoZS50YXJnZXQudmFsdWUpXG4gICAgY29uc3Qgb25FbnZpZXNDaGFuZ2VkID0gKGU6IFJlYWN0LkNoYW5nZUV2ZW50PEhUTUxUZXh0QXJlYUVsZW1lbnQ+KSA9PiBzZXRFbnZpZXMoZS50YXJnZXQudmFsdWUpXG4gICAgY29uc3Qgb25QcmVjaXNpb25zQ2hhbmdlZCA9IChlOiBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MVGV4dEFyZWFFbGVtZW50PikgPT5cbiAgICAgICAgc2V0UHJlY2lzaW9ucyhlLnRhcmdldC52YWx1ZSlcbiAgICBjb25zdCBvbkVxdWlwZXNDaGFuZ2VkID0gKGU6IFJlYWN0LkNoYW5nZUV2ZW50PEhUTUxJbnB1dEVsZW1lbnQ+KSA9PlxuICAgICAgICBzZXRFcXVpcGVzKGUudGFyZ2V0LnZhbHVlLnNwbGl0KC8sID8vKSlcbiAgICBjb25zdCBvbkRhdGVBam91dENoYW5nZWQgPSAoZTogUmVhY3QuQ2hhbmdlRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pID0+XG4gICAgICAgIHNldERhdGVBam91dChlLnRhcmdldC52YWx1ZSlcblxuICAgIGNvbnN0IG9uU2F2ZVBvc3RDbGlja2VkID0gKCkgPT4ge1xuICAgICAgICBpZiAoZG9tYWluZSAmJiBlbnZpZXMpIHtcbiAgICAgICAgICAgIGRpc3BhdGNoKFxuICAgICAgICAgICAgICAgIGZldGNoRW52aWVBZGQoe1xuICAgICAgICAgICAgICAgICAgICBkb21haW5lLFxuICAgICAgICAgICAgICAgICAgICBlbnZpZXMsXG4gICAgICAgICAgICAgICAgICAgIHByZWNpc2lvbnMsXG4gICAgICAgICAgICAgICAgICAgIGVxdWlwZXMsXG4gICAgICAgICAgICAgICAgICAgIGRhdGVBam91dCxcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgKVxuXG4gICAgICAgICAgICBzZXREb21haW5lKFwiXCIpXG4gICAgICAgICAgICBzZXRFbnZpZXMoXCJcIilcbiAgICAgICAgICAgIHNldFByZWNpc2lvbnMoXCJcIilcbiAgICAgICAgICAgIHNldEVxdWlwZXMoW1wiXCJdKVxuICAgICAgICAgICAgc2V0RGF0ZUFqb3V0KFwiXCIpXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0b2FzdC53YXJuaW5nKFwiSWwgZmF1dCBhdSBtb2lucyBwcsOpY2lzZXIgdW4gZG9tYWluZSBldCBsJ2VudmllXCIsIHtcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogXCJ0b3AtY2VudGVyXCIsXG4gICAgICAgICAgICAgICAgYXV0b0Nsb3NlOiA2MDAwLFxuICAgICAgICAgICAgICAgIGhpZGVQcm9ncmVzc0JhcjogdHJ1ZSxcbiAgICAgICAgICAgICAgICBjbG9zZU9uQ2xpY2s6IHRydWUsXG4gICAgICAgICAgICAgICAgcGF1c2VPbkhvdmVyOiB0cnVlLFxuICAgICAgICAgICAgICAgIGRyYWdnYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgICAgICBwcm9ncmVzczogdW5kZWZpbmVkLFxuICAgICAgICAgICAgfSlcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gKFxuICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9e3N0eWxlcy5FbnZpZUxpc3R9PlxuICAgICAgICAgICAgPGgyPkFqb3V0ZXIgdW5lIG5vdXZlbGxlIGVudmllPC9oMj5cbiAgICAgICAgICAgIDxmb3JtPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwicG9zdERvbWFpbmVcIj5cbiAgICAgICAgICAgICAgICAgICAgRG9tYWluZTpcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cInBvc3REb21haW5lXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwb3N0RG9tYWluZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZG9tYWluZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtvbkRvbWFpbmVDaGFuZ2VkfVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJwb3N0RW52aWVzXCI+XG4gICAgICAgICAgICAgICAgICAgIEVudmllczpcbiAgICAgICAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cInBvc3RFbnZpZXNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBvc3RFbnZpZXNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Vudmllc31cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtvbkVudmllc0NoYW5nZWR9XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInBvc3RQcmVjaXNpb25zXCI+XG4gICAgICAgICAgICAgICAgICAgIFByZWNpc2lvbnM6XG4gICAgICAgICAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJwb3N0UHJlY2lzaW9uc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicG9zdFByZWNpc2lvbnNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3ByZWNpc2lvbnN9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17b25QcmVjaXNpb25zQ2hhbmdlZH1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwicG9zdEVxdWlwZXNcIj5cbiAgICAgICAgICAgICAgICAgICAgRXF1aXBlczpcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cInBvc3RFcXVpcGVzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwb3N0RXF1aXBlc1wiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17ZXF1aXBlcy5qb2luKFwiLCBcIil9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17b25FcXVpcGVzQ2hhbmdlZH1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwicG9zdERhdGVBam91dFwiPlxuICAgICAgICAgICAgICAgICAgICBEYXRlQWpvdXQ6XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImRhdGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJwb3N0RGF0ZUFqb3V0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwb3N0RGF0ZUFqb3V0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkYXRlQWpvdXR9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17b25EYXRlQWpvdXRDaGFuZ2VkfVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgb25DbGljaz17b25TYXZlUG9zdENsaWNrZWR9PlxuICAgICAgICAgICAgICAgICAgICBTYXZlIFBvc3RcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgPC9zZWN0aW9uPlxuICAgIClcbn1cbmV4cG9ydCBkZWZhdWx0IG1lbW8oQWRkRW52aWUpXG4iLCJpbXBvcnQgeyBSZWFjdE5vZGUsIFB1cmVDb21wb25lbnQgfSBmcm9tIFwicmVhY3RcIlxuXG5pbnRlcmZhY2UgUHJvcHMge1xuICAgIGNoaWxkcmVuPzogUmVhY3ROb2RlXG59XG5pbnRlcmZhY2UgU3RhdGUge1xuICAgIGVycm9yOiBFcnJvciB8IG51bGxcbiAgICBlcnJvckluZm86IHsgY29tcG9uZW50U3RhY2s6IHN0cmluZyB9IHwgbnVsbFxufVxuXG5jbGFzcyBFcnJvckJvdW5kYXJ5IGV4dGVuZHMgUHVyZUNvbXBvbmVudDxQcm9wcywgU3RhdGU+IHtcbiAgICBjb25zdHJ1Y3Rvcihwcm9wczogUHJvcHMpIHtcbiAgICAgICAgc3VwZXIocHJvcHMpXG5cbiAgICAgICAgdGhpcy5zdGF0ZSA9IHsgZXJyb3I6IG51bGwsIGVycm9ySW5mbzogbnVsbCB9XG4gICAgfVxuXG4gICAgY29tcG9uZW50RGlkQ2F0Y2goZXJyb3I6IEVycm9yLCBlcnJvckluZm86IHsgY29tcG9uZW50U3RhY2s6IHN0cmluZyB9KTogdm9pZCB7XG4gICAgICAgIC8vIENhdGNoIGVycm9ycyBpbiBhbnkgY29tcG9uZW50cyBiZWxvdyBhbmQgcmUtcmVuZGVyIHdpdGggZXJyb3IgbWVzc2FnZVxuICAgICAgICB0aGlzLnNldFN0YXRlKHsgZXJyb3IsIGVycm9ySW5mbyB9KVxuXG4gICAgICAgIC8vIFlvdSBjYW4gYWxzbyBsb2cgZXJyb3IgbWVzc2FnZXMgdG8gYW4gZXJyb3IgcmVwb3J0aW5nIHNlcnZpY2UgaGVyZVxuICAgIH1cblxuICAgIHJlbmRlcigpOiBSZWFjdE5vZGUge1xuICAgICAgICBjb25zdCB7IGNoaWxkcmVuIH0gPSB0aGlzLnByb3BzXG4gICAgICAgIGNvbnN0IHsgZXJyb3JJbmZvLCBlcnJvciB9ID0gdGhpcy5zdGF0ZVxuXG4gICAgICAgIC8vIElmIHRoZXJlJ3MgYW4gZXJyb3IsIHJlbmRlciBlcnJvciBwYXRoXG4gICAgICAgIHJldHVybiBlcnJvckluZm8gPyAoXG4gICAgICAgICAgICA8ZGl2IGRhdGEtdGVzdGlkPVwiZXJyb3Itdmlld1wiPlxuICAgICAgICAgICAgICAgIDxoMj5Tb21ldGhpbmcgd2VudCB3cm9uZy48L2gyPlxuICAgICAgICAgICAgICAgIDxkZXRhaWxzIHN0eWxlPXt7IHdoaXRlU3BhY2U6IFwicHJlLXdyYXBcIiB9fT5cbiAgICAgICAgICAgICAgICAgICAge2Vycm9yICYmIGVycm9yLnRvU3RyaW5nKCl9XG4gICAgICAgICAgICAgICAgICAgIDxiciAvPlxuICAgICAgICAgICAgICAgICAgICB7ZXJyb3JJbmZvLmNvbXBvbmVudFN0YWNrfVxuICAgICAgICAgICAgICAgIDwvZGV0YWlscz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICApIDogKFxuICAgICAgICAgICAgY2hpbGRyZW4gfHwgbnVsbFxuICAgICAgICApXG4gICAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBFcnJvckJvdW5kYXJ5XG4iLCJpbXBvcnQgeyBtZW1vIH0gZnJvbSBcInJlYWN0XCJcbmltcG9ydCB7IHVzZVNlbGVjdG9yLCBzaGFsbG93RXF1YWwgfSBmcm9tIFwicmVhY3QtcmVkdXhcIlxuaW1wb3J0IHsgRW50aXR5SWQgfSBmcm9tIFwiQHJlZHV4anMvdG9vbGtpdFwiXG4vLyBpbXBvcnQgeyBMaW5rIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIlxuXG5pbXBvcnQgeyBBcHBTdGF0ZSB9IGZyb20gXCIuLi8uLi9zdG9yZVwiXG5pbXBvcnQgc3R5bGVzIGZyb20gXCIuL3N0eWxlcy5tb2R1bGUuc2Nzc1wiXG5cbmludGVyZmFjZSBQcm9wcyB7XG4gICAgaWRzOiBFbnRpdHlJZFtdXG59XG5cbmNvbnN0IEpldUphdkxpc3QgPSAoeyBpZHMgfTogUHJvcHMpID0+IHtcbiAgICBjb25zdCB7IGVudGl0aWVzOiBqZXV4SmF2IH0gPSB1c2VTZWxlY3Rvcigoc3RhdGU6IEFwcFN0YXRlKSA9PiBzdGF0ZS5qZXVKYXZMaXN0LCBzaGFsbG93RXF1YWwpXG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5KZXVKYXZMaXN0fT5cbiAgICAgICAgICAgIDxoND5KZXV4IEpBVjwvaDQ+XG4gICAgICAgICAgICA8dWw+XG4gICAgICAgICAgICAgICAge2lkcy5tYXAoKGlkKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGpldSA9IGpldXhKYXZbaWRdXG4gICAgICAgICAgICAgICAgICAgIGlmICghamV1KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gPGxpIGtleT17aWR9PkxlIGpldSAje2lkfSBuJmFwb3M7ZXhpc3RlIHBhczwvbGk+XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgY29uc3QgeyB0aXRyZSwgYmdnSWQgfSA9IGpldVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGxpIGtleT17aWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt0aXRyZX0gLSBbe2JnZ0lkfV1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgIDwvdWw+XG4gICAgICAgIDwvZGl2PlxuICAgIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgbWVtbyhKZXVKYXZMaXN0KVxuIiwiaW1wb3J0IHN0eWxlcyBmcm9tIFwiLi9zdHlsZXMubW9kdWxlLnNjc3NcIlxuXG5jb25zdCBMb2FkaW5nID0gKCk6IEpTWC5FbGVtZW50ID0+IChcbiAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmxvYWRpbmd9PlxuICAgICAgICA8cD5Mb2FkaW5nLi4uPC9wPlxuICAgIDwvZGl2PlxuKVxuXG5leHBvcnQgZGVmYXVsdCBMb2FkaW5nXG4iLCJpbXBvcnQgeyBtZW1vIH0gZnJvbSBcInJlYWN0XCJcblxuaW1wb3J0IHsgTWVtYnJlIH0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL21lbWJyZXNcIlxuaW1wb3J0IHN0eWxlcyBmcm9tIFwiLi9zdHlsZXMubW9kdWxlLnNjc3NcIlxuXG5pbnRlcmZhY2UgUHJvcHMge1xuICAgIGl0ZW06IE1lbWJyZVxufVxuXG5jb25zdCBNZW1icmVJbmZvID0gKHsgaXRlbSB9OiBQcm9wcykgPT4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuTWVtYnJlQ2FyZH0+XG4gICAgICAgIDxoND5NZW1icmUgSW5mbzwvaDQ+XG4gICAgICAgIDx1bD5cbiAgICAgICAgICAgIDxsaT5QcsOpbm9tOiB7aXRlbS5wcmVub219PC9saT5cbiAgICAgICAgICAgIDxsaT5Ob206IHtpdGVtLm5vbX08L2xpPlxuICAgICAgICA8L3VsPlxuICAgIDwvZGl2PlxuKVxuXG5leHBvcnQgZGVmYXVsdCBtZW1vKE1lbWJyZUluZm8pXG4iLCJpbXBvcnQgeyBtZW1vIH0gZnJvbSBcInJlYWN0XCJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiXG5cbmltcG9ydCB7IE1lbWJyZSB9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9tZW1icmVzXCJcbmltcG9ydCBzdHlsZXMgZnJvbSBcIi4vc3R5bGVzLm1vZHVsZS5zY3NzXCJcblxuaW50ZXJmYWNlIFByb3BzIHtcbiAgICBpdGVtczogTWVtYnJlW11cbn1cblxuY29uc3QgTWVtYnJlTGlzdCA9ICh7IGl0ZW1zIH06IFByb3BzKSA9PiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlc1tcInVzZXItbGlzdFwiXX0+XG4gICAgICAgIDxoND5NZW1icmUgTGlzdDwvaDQ+XG4gICAgICAgIDx1bD5cbiAgICAgICAgICAgIHtpdGVtcy5tYXAoKHsgaWQsIG5vbSwgcHJlbm9tIH0pID0+IChcbiAgICAgICAgICAgICAgICA8bGkga2V5PXtpZH0+XG4gICAgICAgICAgICAgICAgICAgIDxMaW5rIHRvPXtgL01lbWJyZS8ke2lkfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGI+e3ByZW5vbX08L2I+IHtub219XG4gICAgICAgICAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgKSl9XG4gICAgICAgIDwvdWw+XG4gICAgPC9kaXY+XG4pXG5cbmV4cG9ydCBkZWZhdWx0IG1lbW8oTWVtYnJlTGlzdClcbiIsImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgbWVtbyB9IGZyb20gXCJyZWFjdFwiXG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gXCJyZWFjdC10b2FzdGlmeVwiXG5cbmltcG9ydCB7IEFwcERpc3BhdGNoIH0gZnJvbSBcIi4uLy4uL3N0b3JlXCJcblxuaW1wb3J0IHsgZmV0Y2hNZW1icmVTZXQgfSBmcm9tIFwiLi4vLi4vc3RvcmUvbWVtYnJlU2V0XCJcbmltcG9ydCB7IE1lbWJyZSB9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9tZW1icmVzXCJcbmltcG9ydCBzdHlsZXMgZnJvbSBcIi4vc3R5bGVzLm1vZHVsZS5zY3NzXCJcblxuaW50ZXJmYWNlIFByb3BzIHtcbiAgICBkaXNwYXRjaDogQXBwRGlzcGF0Y2hcbiAgICBtZW1icmU6IE1lbWJyZVxufVxuXG5jb25zdCBNZW1icmVTZXQgPSAoeyBkaXNwYXRjaCwgbWVtYnJlIH06IFByb3BzKSA9PiB7XG4gICAgY29uc3QgW3ByZW5vbSwgc2V0UHJlbm9tXSA9IHVzZVN0YXRlKG1lbWJyZS5wcmVub20pXG4gICAgY29uc3QgW25vbSwgc2V0Tm9tXSA9IHVzZVN0YXRlKG1lbWJyZS5ub20pXG4gICAgY29uc3QgW21hamV1ciwgc2V0TWFqZXVyXSA9IHVzZVN0YXRlKG1lbWJyZS5tYWpldXIpXG5cbiAgICBjb25zdCBvblByZW5vbUNoYW5nZWQgPSAoZTogUmVhY3QuQ2hhbmdlRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pID0+IHNldFByZW5vbShlLnRhcmdldC52YWx1ZSlcbiAgICBjb25zdCBvbk5vbUNoYW5nZWQgPSAoZTogUmVhY3QuQ2hhbmdlRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pID0+IHNldE5vbShlLnRhcmdldC52YWx1ZSlcbiAgICBjb25zdCBvbk1hamV1ckNoYW5nZWQgPSAoZTogUmVhY3QuQ2hhbmdlRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pID0+IHNldE1hamV1cigrZS50YXJnZXQudmFsdWUpXG5cbiAgICBjb25zdCBvblNhdmVQb3N0Q2xpY2tlZCA9ICgpID0+IHtcbiAgICAgICAgaWYgKHByZW5vbSAmJiBub20pIHtcbiAgICAgICAgICAgIGRpc3BhdGNoKFxuICAgICAgICAgICAgICAgIGZldGNoTWVtYnJlU2V0KHtcbiAgICAgICAgICAgICAgICAgICAgLi4ubWVtYnJlLFxuICAgICAgICAgICAgICAgICAgICBwcmVub20sXG4gICAgICAgICAgICAgICAgICAgIG5vbSxcbiAgICAgICAgICAgICAgICAgICAgbWFqZXVyLFxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICApXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0b2FzdC53YXJuaW5nKFwiSWwgZmF1dCBhdSBtb2lucyBwcsOpY2lzZXIgdW4gcHJlbm9tIGV0IHVuIG5vbVwiLCB7XG4gICAgICAgICAgICAgICAgcG9zaXRpb246IFwidG9wLWNlbnRlclwiLFxuICAgICAgICAgICAgICAgIGF1dG9DbG9zZTogNjAwMCxcbiAgICAgICAgICAgICAgICBoaWRlUHJvZ3Jlc3NCYXI6IHRydWUsXG4gICAgICAgICAgICAgICAgY2xvc2VPbkNsaWNrOiB0cnVlLFxuICAgICAgICAgICAgICAgIHBhdXNlT25Ib3ZlcjogdHJ1ZSxcbiAgICAgICAgICAgICAgICBkcmFnZ2FibGU6IHRydWUsXG4gICAgICAgICAgICAgICAgcHJvZ3Jlc3M6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgIH0pXG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIChcbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPXtzdHlsZXMuTWVtYnJlTGlzdH0+XG4gICAgICAgICAgICA8aDI+TW9kaWZpZXIgdW4gbWVtYnJlPC9oMj5cbiAgICAgICAgICAgIDxmb3JtPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwicG9zdFByZW5vbVwiPlxuICAgICAgICAgICAgICAgICAgICBQcmVub206XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJwb3N0UHJlbm9tXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU9XCJwb3N0UHJlbm9tXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwcmVub219XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17b25QcmVub21DaGFuZ2VkfVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJwb3N0Tm9tXCI+XG4gICAgICAgICAgICAgICAgICAgIE5vbTpcbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cInBvc3ROb21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cInBvc3ROb21cIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e25vbX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtvbk5vbUNoYW5nZWR9XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInBvc3RNYWpldXJcIj5cbiAgICAgICAgICAgICAgICAgICAgTWFqZXVyOlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwicG9zdE1hamV1clwiXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwicG9zdE1hamV1clwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bWFqZXVyfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e29uTWFqZXVyQ2hhbmdlZH1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIG9uQ2xpY2s9e29uU2F2ZVBvc3RDbGlja2VkfT5cbiAgICAgICAgICAgICAgICAgICAgU2F2ZSBjaGFuZ2VzXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgIDwvc2VjdGlvbj5cbiAgICApXG59XG5leHBvcnQgZGVmYXVsdCBtZW1vKE1lbWJyZVNldClcbiIsImltcG9ydCBNZW1icmVMaXN0IGZyb20gXCIuL01lbWJyZUxpc3RcIlxuaW1wb3J0IEpldUphdkxpc3QgZnJvbSBcIi4vSmV1SmF2TGlzdFwiXG5pbXBvcnQgTWVtYnJlSW5mbyBmcm9tIFwiLi9NZW1icmVJbmZvXCJcbmltcG9ydCBNZW1icmVTZXQgZnJvbSBcIi4vTWVtYnJlU2V0XCJcbmltcG9ydCBFcnJvckJvdW5kYXJ5IGZyb20gXCIuL0Vycm9yQm91bmRhcnlcIlxuaW1wb3J0IExvYWRpbmcgZnJvbSBcIi4vTG9hZGluZ1wiXG5pbXBvcnQgQWRkRW52aWUgZnJvbSBcIi4vQWRkRW52aWVcIlxuXG5leHBvcnQgeyBNZW1icmVMaXN0LCBKZXVKYXZMaXN0LCBNZW1icmVJbmZvLCBNZW1icmVTZXQsIEVycm9yQm91bmRhcnksIExvYWRpbmcsIEFkZEVudmllIH1cbiIsImV4cG9ydCBkZWZhdWx0IHtcbiAgICBIT1NUOiBcImxvY2FsaG9zdFwiLFxuICAgIFBPUlQ6IDMwMDAsXG4gICAgQVBJX1VSTDogXCJodHRwOi8vbG9jYWxob3N0OjMwMDBcIixcbiAgICBHT09HTEVfU0hFRVRfSUQ6IFwiMXBNTUtjWXg2TlhMT3FObjZwTEhKVFBNVE9MUllabVNOZzJRUWNBdTctUHdcIixcbiAgICBBUFA6IHtcbiAgICAgICAgaHRtbEF0dHJpYnV0ZXM6IHsgbGFuZzogXCJlblwiIH0sXG4gICAgICAgIHRpdGxlOiBcIkZvcmNlIE9yYW5nZVwiLFxuICAgICAgICBkZXNjcmlwdGlvbjogXCJMZSBzaXRlIGRlcyBiw6luw6l2b2xlc1wiLFxuICAgICAgICB0aXRsZVRlbXBsYXRlOiBcIkZvcmNlIE9yYW5nZSAtICVzXCIsXG4gICAgICAgIG1ldGE6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBuYW1lOiBcImRlc2NyaXB0aW9uXCIsXG4gICAgICAgICAgICAgICAgY29udGVudDogXCJUaGUgYmVzdCByZWFjdCB1bml2ZXJzYWwgc3RhcnRlciBib2lsZXJwbGF0ZSBpbiB0aGUgd29ybGQuXCIsXG4gICAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgIH0sXG4gICAgSldUX1NFQ1JFVDogXCJSYmxRcUE2dUYjbXNxMjMxMmJlYmYyRkxGbjRYeldRNmR0dFhTSndCWCM/Z0wySldmIVwiLFxufVxuIiwiaW1wb3J0IGRlZmF1bHRDb25maWcgZnJvbSBcIi4vZGVmYXVsdFwiXG5pbXBvcnQgcHJvZENvbmZpZyBmcm9tIFwiLi9wcm9kXCJcblxuZXhwb3J0IGRlZmF1bHQgX19ERVZfXyA/IGRlZmF1bHRDb25maWcgOiB7IC4uLmRlZmF1bHRDb25maWcsIC4uLnByb2RDb25maWcgfVxuIiwiY29uc3QgUE9SVCA9IDQwMDBcbmNvbnN0IEFQSV9VUkwgPSBfX0RFVl9fIHx8IF9fTE9DQUxfXyA/IGBodHRwOi8vbG9jYWxob3N0OiR7UE9SVH1gIDogXCJodHRwczovL2ZvLnBhcmlzZXN0bHVkaXF1ZS5mclwiXG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgICBQT1JULFxuICAgIEhPU1Q6IFwiMC4wLjAuMFwiLFxuICAgIEFQSV9VUkwsXG59XG4iLCJpbXBvcnQgeyBGQywgdXNlRWZmZWN0LCBtZW1vIH0gZnJvbSBcInJlYWN0XCJcbmltcG9ydCB7IFJvdXRlQ29tcG9uZW50UHJvcHMgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiXG5pbXBvcnQgeyB1c2VEaXNwYXRjaCwgdXNlU2VsZWN0b3IsIHNoYWxsb3dFcXVhbCB9IGZyb20gXCJyZWFjdC1yZWR1eFwiXG5pbXBvcnQgeyBIZWxtZXQgfSBmcm9tIFwicmVhY3QtaGVsbWV0XCJcblxuaW1wb3J0IHsgQXBwU3RhdGUsIEFwcFRodW5rLCBFbnRpdGllc1JlcXVlc3QgfSBmcm9tIFwiLi4vLi4vc3RvcmVcIlxuaW1wb3J0IHsgZmV0Y2hKZXVKYXZMaXN0SWZOZWVkIH0gZnJvbSBcIi4uLy4uL3N0b3JlL2pldUphdkxpc3RcIlxuaW1wb3J0IHsgZmV0Y2hFbnZpZUxpc3RJZk5lZWQgfSBmcm9tIFwiLi4vLi4vc3RvcmUvZW52aWVMaXN0XCJcbmltcG9ydCB7IEpldUphdkxpc3QsIEFkZEVudmllIH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHNcIlxuaW1wb3J0IHN0eWxlcyBmcm9tIFwiLi9zdHlsZXMubW9kdWxlLnNjc3NcIlxuXG5leHBvcnQgdHlwZSBQcm9wcyA9IFJvdXRlQ29tcG9uZW50UHJvcHNcblxuZnVuY3Rpb24gdXNlTGlzdDxFbnRpdHk+KFxuICAgIHN0YXRlVG9Qcm9wOiAoc3RhdGU6IEFwcFN0YXRlKSA9PiBFbnRpdGllc1JlcXVlc3Q8RW50aXR5PixcbiAgICBmZXRjaERhdGFJZk5lZWQ6ICgpID0+IEFwcFRodW5rXG4pIHtcbiAgICBjb25zdCBkaXNwYXRjaCA9IHVzZURpc3BhdGNoKClcbiAgICBjb25zdCB7IHJlYWR5U3RhdHVzLCBpZHMgfSA9IHVzZVNlbGVjdG9yKHN0YXRlVG9Qcm9wLCBzaGFsbG93RXF1YWwpXG5cbiAgICAvLyBGZXRjaCBjbGllbnQtc2lkZSBkYXRhIGhlcmVcbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBkaXNwYXRjaChmZXRjaERhdGFJZk5lZWQoKSlcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1xuICAgIH0sIFtkaXNwYXRjaF0pXG5cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICBpZiAoIXJlYWR5U3RhdHVzIHx8IHJlYWR5U3RhdHVzID09PSBcImlkbGVcIiB8fCByZWFkeVN0YXR1cyA9PT0gXCJyZXF1ZXN0XCIpXG4gICAgICAgICAgICByZXR1cm4gPHA+TG9hZGluZy4uLjwvcD5cblxuICAgICAgICBpZiAocmVhZHlTdGF0dXMgPT09IFwiZmFpbHVyZVwiKSByZXR1cm4gPHA+T29wcywgRmFpbGVkIHRvIGxvYWQgbGlzdCE8L3A+XG5cbiAgICAgICAgcmV0dXJuIDxKZXVKYXZMaXN0IGlkcz17aWRzfSAvPlxuICAgIH1cbn1cblxuY29uc3QgSG9tZTogRkM8UHJvcHM+ID0gKCk6IEpTWC5FbGVtZW50ID0+IHtcbiAgICBjb25zdCBkaXNwYXRjaCA9IHVzZURpc3BhdGNoKClcbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmhvbWV9PlxuICAgICAgICAgICAgPEhlbG1ldCB0aXRsZT1cIkhvbWVcIiAvPlxuICAgICAgICAgICAgPEFkZEVudmllIGRpc3BhdGNoPXtkaXNwYXRjaH0gLz5cbiAgICAgICAgICAgIHsvKiB7dXNlTGlzdCgoc3RhdGU6IEFwcFN0YXRlKSA9PiBzdGF0ZS5lbnZpZUxpc3QsIGZldGNoRW52aWVMaXN0aWZOZWVkKSgpfSAqL31cbiAgICAgICAgICAgIHt1c2VMaXN0KChzdGF0ZTogQXBwU3RhdGUpID0+IHN0YXRlLmpldUphdkxpc3QsIGZldGNoSmV1SmF2TGlzdElmTmVlZCkoKX1cbiAgICAgICAgICAgIHsvKiA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBvbkNsaWNrPXsoKSA9PiBzZXRMaXN0KFt7aWQ6IDMsIGpvdWV1cnM6IDQsIGR1cmVlOiA1LCBkZXNjcmlwdGlvbjogXCJhYmNkXCJ9XSl9PlxuICAgICAgICAgICAgU2V0IGxpc3QhXG4gICAgICAgIDwvYnV0dG9uPiAqL31cbiAgICAgICAgPC9kaXY+XG4gICAgKVxufVxuXG4vLyBGZXRjaCBzZXJ2ZXItc2lkZSBkYXRhIGhlcmVcbmV4cG9ydCBjb25zdCBsb2FkRGF0YSA9ICgpOiBBcHBUaHVua1tdID0+IFtcbiAgICBmZXRjaEVudmllTGlzdElmTmVlZCgpLFxuICAgIGZldGNoSmV1SmF2TGlzdElmTmVlZCgpLFxuICAgIC8vIE1vcmUgcHJlLWZldGNoZWQgYWN0aW9ucy4uLlxuXVxuXG5leHBvcnQgZGVmYXVsdCBtZW1vKEhvbWUpXG4iLCJpbXBvcnQgbG9hZGFibGUgZnJvbSBcIkBsb2FkYWJsZS9jb21wb25lbnRcIlxuXG5pbXBvcnQgeyBMb2FkaW5nLCBFcnJvckJvdW5kYXJ5IH0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHNcIlxuaW1wb3J0IHsgUHJvcHMsIGxvYWREYXRhIH0gZnJvbSBcIi4vSG9tZVwiXG5cbmNvbnN0IEhvbWUgPSBsb2FkYWJsZSgoKSA9PiBpbXBvcnQoXCIuL0hvbWVcIiksIHtcbiAgICBmYWxsYmFjazogPExvYWRpbmcgLz4sXG59KVxuXG5leHBvcnQgZGVmYXVsdCAocHJvcHM6IFByb3BzKTogSlNYLkVsZW1lbnQgPT4gKFxuICAgIDxFcnJvckJvdW5kYXJ5PlxuICAgICAgICA8SG9tZSB7Li4ucHJvcHN9IC8+XG4gICAgPC9FcnJvckJvdW5kYXJ5PlxuKVxuZXhwb3J0IHsgbG9hZERhdGEgfVxuIiwiaW1wb3J0IGxvYWRhYmxlIGZyb20gXCJAbG9hZGFibGUvY29tcG9uZW50XCJcblxuaW1wb3J0IHsgTG9hZGluZywgRXJyb3JCb3VuZGFyeSB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzXCJcbmltcG9ydCB7IFByb3BzIH0gZnJvbSBcIi4vTG9naW5QYWdlXCJcblxuY29uc3QgTG9naW5QYWdlID0gbG9hZGFibGUoKCkgPT4gaW1wb3J0KFwiLi9Mb2dpblBhZ2VcIiksIHtcbiAgICBmYWxsYmFjazogPExvYWRpbmcgLz4sXG59KVxuXG5leHBvcnQgZGVmYXVsdCAocHJvcHM6IFByb3BzKTogSlNYLkVsZW1lbnQgPT4gKFxuICAgIDxFcnJvckJvdW5kYXJ5PlxuICAgICAgICA8TG9naW5QYWdlIHsuLi5wcm9wc30gLz5cbiAgICA8L0Vycm9yQm91bmRhcnk+XG4pXG4iLCJpbXBvcnQgeyB1c2VFZmZlY3QsIG1lbW8gfSBmcm9tIFwicmVhY3RcIlxuaW1wb3J0IHsgUm91dGVDb21wb25lbnRQcm9wcyB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCJcbmltcG9ydCB7IHVzZURpc3BhdGNoLCB1c2VTZWxlY3Rvciwgc2hhbGxvd0VxdWFsIH0gZnJvbSBcInJlYWN0LXJlZHV4XCJcbmltcG9ydCB7IEhlbG1ldCB9IGZyb20gXCJyZWFjdC1oZWxtZXRcIlxuXG5pbXBvcnQgeyBBcHBTdGF0ZSwgQXBwVGh1bmsgfSBmcm9tIFwiLi4vLi4vc3RvcmVcIlxuaW1wb3J0IHsgZmV0Y2hNZW1icmVJZk5lZWQgfSBmcm9tIFwiLi4vLi4vc3RvcmUvbWVtYnJlXCJcbmltcG9ydCB7IE1lbWJyZUluZm8sIE1lbWJyZVNldCB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzXCJcbmltcG9ydCBzdHlsZXMgZnJvbSBcIi4vc3R5bGVzLm1vZHVsZS5zY3NzXCJcblxuZXhwb3J0IHR5cGUgUHJvcHMgPSBSb3V0ZUNvbXBvbmVudFByb3BzPHsgaWQ6IHN0cmluZyB9PlxuXG5jb25zdCBNZW1icmVQYWdlID0gKHsgbWF0Y2ggfTogUHJvcHMpOiBKU1guRWxlbWVudCA9PiB7XG4gICAgY29uc3QgeyBpZDogcmF3SWQgfSA9IG1hdGNoLnBhcmFtc1xuICAgIGNvbnN0IGlkID0gK3Jhd0lkXG4gICAgY29uc3QgZGlzcGF0Y2ggPSB1c2VEaXNwYXRjaCgpXG4gICAgY29uc3QgbWVtYnJlID0gdXNlU2VsZWN0b3IoKHN0YXRlOiBBcHBTdGF0ZSkgPT4gc3RhdGUubWVtYnJlLCBzaGFsbG93RXF1YWwpXG5cbiAgICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBkaXNwYXRjaChmZXRjaE1lbWJyZUlmTmVlZChpZCkpXG4gICAgfSwgW2Rpc3BhdGNoLCBpZF0pXG5cbiAgICBjb25zdCByZW5kZXJJbmZvID0gKCkgPT4ge1xuICAgICAgICBjb25zdCBtZW1icmVJbmZvID0gbWVtYnJlXG5cbiAgICAgICAgaWYgKCFtZW1icmVJbmZvIHx8IG1lbWJyZUluZm8ucmVhZHlTdGF0dXMgPT09IFwicmVxdWVzdFwiKSByZXR1cm4gPHA+TG9hZGluZy4uLjwvcD5cblxuICAgICAgICBpZiAobWVtYnJlSW5mby5yZWFkeVN0YXR1cyA9PT0gXCJmYWlsdXJlXCIgfHwgIW1lbWJyZUluZm8uZW50aXR5KVxuICAgICAgICAgICAgcmV0dXJuIDxwPk9vcHMhIEZhaWxlZCB0byBsb2FkIGRhdGEuPC9wPlxuXG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxNZW1icmVJbmZvIGl0ZW09e21lbWJyZUluZm8uZW50aXR5fSAvPlxuICAgICAgICAgICAgICAgIDxNZW1icmVTZXQgZGlzcGF0Y2g9e2Rpc3BhdGNofSBtZW1icmU9e21lbWJyZUluZm8uZW50aXR5fSAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIClcbiAgICB9XG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLm1lbWJyZX0+XG4gICAgICAgICAgICA8SGVsbWV0IHRpdGxlPVwiVXNlciBJbmZvXCIgLz5cbiAgICAgICAgICAgIHtyZW5kZXJJbmZvKCl9XG4gICAgICAgIDwvZGl2PlxuICAgIClcbn1cblxuaW50ZXJmYWNlIExvYWREYXRhQXJncyB7XG4gICAgcGFyYW1zOiB7IGlkOiBudW1iZXIgfVxufVxuXG5leHBvcnQgY29uc3QgbG9hZERhdGEgPSAoeyBwYXJhbXMgfTogTG9hZERhdGFBcmdzKTogQXBwVGh1bmtbXSA9PiBbZmV0Y2hNZW1icmVJZk5lZWQocGFyYW1zLmlkKV1cblxuZXhwb3J0IGRlZmF1bHQgbWVtbyhNZW1icmVQYWdlKVxuIiwiaW1wb3J0IGxvYWRhYmxlIGZyb20gXCJAbG9hZGFibGUvY29tcG9uZW50XCJcblxuaW1wb3J0IHsgTG9hZGluZywgRXJyb3JCb3VuZGFyeSB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzXCJcbmltcG9ydCB7IFByb3BzLCBsb2FkRGF0YSB9IGZyb20gXCIuL01lbWJyZVBhZ2VcIlxuXG5jb25zdCBNZW1icmVQYWdlID0gbG9hZGFibGUoKCkgPT4gaW1wb3J0KFwiLi9NZW1icmVQYWdlXCIpLCB7XG4gICAgZmFsbGJhY2s6IDxMb2FkaW5nIC8+LFxufSlcblxuZXhwb3J0IGRlZmF1bHQgKHByb3BzOiBQcm9wcyk6IEpTWC5FbGVtZW50ID0+IChcbiAgICA8RXJyb3JCb3VuZGFyeT5cbiAgICAgICAgPE1lbWJyZVBhZ2Ugey4uLnByb3BzfSAvPlxuICAgIDwvRXJyb3JCb3VuZGFyeT5cbilcbmV4cG9ydCB7IGxvYWREYXRhIH1cbiIsImltcG9ydCB7IG1lbW8gfSBmcm9tIFwicmVhY3RcIlxuaW1wb3J0IHsgUm91dGVDb21wb25lbnRQcm9wcyB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCJcbmltcG9ydCB7IEhlbG1ldCB9IGZyb20gXCJyZWFjdC1oZWxtZXRcIlxuXG5pbXBvcnQgc3R5bGVzIGZyb20gXCIuL3N0eWxlcy5tb2R1bGUuc2Nzc1wiXG5cbnR5cGUgUHJvcHMgPSBSb3V0ZUNvbXBvbmVudFByb3BzXG5cbmNvbnN0IE5vdEZvdW5kID0gKHsgc3RhdGljQ29udGV4dCB9OiBQcm9wcykgPT4ge1xuICAgIC8vIFdlIGhhdmUgdG8gY2hlY2sgaWYgc3RhdGljQ29udGV4dCBleGlzdHNcbiAgICAvLyBiZWNhdXNlIGl0IHdpbGwgYmUgdW5kZWZpbmVkIGlmIHJlbmRlcmVkIHRocm91Z2ggYSBCcm93c2VyUm91dGVcbiAgICAvKiBpc3RhbmJ1bCBpZ25vcmUgbmV4dCAqL1xuICAgIGlmIChzdGF0aWNDb250ZXh0KSBzdGF0aWNDb250ZXh0LnN0YXR1c0NvZGUgPSA0MDRcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXNbXCJub3QtZm91bmRcIl19PlxuICAgICAgICAgICAgPEhlbG1ldCB0aXRsZT1cIk9vcHNcIiAvPlxuICAgICAgICAgICAgPHA+T29wcywgUGFnZSB3YXMgbm90IGZvdW5kITwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBtZW1vKE5vdEZvdW5kKVxuIiwiaW1wb3J0IGxvYWRhYmxlIGZyb20gXCJAbG9hZGFibGUvY29tcG9uZW50XCJcblxuaW1wb3J0IHsgTG9hZGluZywgRXJyb3JCb3VuZGFyeSB9IGZyb20gXCIuLi8uLi9jb21wb25lbnRzXCJcbmltcG9ydCB7IFByb3BzIH0gZnJvbSBcIi4vUmVnaXN0ZXJQYWdlXCJcblxuY29uc3QgUmVnaXN0ZXJQYWdlID0gbG9hZGFibGUoKCkgPT4gaW1wb3J0KFwiLi9SZWdpc3RlclBhZ2VcIiksIHtcbiAgICBmYWxsYmFjazogPExvYWRpbmcgLz4sXG59KVxuXG5leHBvcnQgZGVmYXVsdCAocHJvcHM6IFByb3BzKTogSlNYLkVsZW1lbnQgPT4gKFxuICAgIDxFcnJvckJvdW5kYXJ5PlxuICAgICAgICA8UmVnaXN0ZXJQYWdlIHsuLi5wcm9wc30gLz5cbiAgICA8L0Vycm9yQm91bmRhcnk+XG4pXG4iLCIvKiBDb3B5cmlnaHQgQ29wbGF5LiBBbGwgUmlnaHRzIFJlc2VydmVkLiBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhbiBNSVQtc3R5bGUgbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlIGF0IGh0dHBzOi8vY29wbGF5Lm9yZy9jb2xpY2Vuc2UgKi9cbmltcG9ydCB7IE5leHRGdW5jdGlvbiwgUmVxdWVzdCwgUmVzcG9uc2UsIFJvdXRlciB9IGZyb20gXCJleHByZXNzXCJcbmltcG9ydCAqIGFzIHBhdGggZnJvbSBcInBhdGhcIlxuXG5jb25zdCBjZXJ0Ym90Um91dGVyOiBSb3V0ZXIgPSBSb3V0ZXIoKVxuXG5jZXJ0Ym90Um91dGVyLnVzZSgocmVxdWVzdDogUmVxdWVzdCwgcmVzcG9uc2U6IFJlc3BvbnNlLCBfbmV4dDogTmV4dEZ1bmN0aW9uKSA9PiB7XG4gICAgY29uc3QgZmlsZW5hbWUgPSByZXF1ZXN0Lm9yaWdpbmFsVXJsLnJlcGxhY2UoLy4qXFwvLywgXCJcIilcbiAgICBjb25zdCByZXNvbHZlZFBhdGg6IHN0cmluZyA9IHBhdGgucmVzb2x2ZShgLi4vY2VydGJvdC8ud2VsbC1rbm93bi9hY21lLWNoYWxsZW5nZS8ke2ZpbGVuYW1lfWApXG4gICAgcmVzcG9uc2Uuc2V0SGVhZGVyKFwiQ29udGVudC1UeXBlXCIsIFwidGV4dC9odG1sXCIpXG4gICAgcmV0dXJuIHJlc3BvbnNlLnNlbmRGaWxlKHJlc29sdmVkUGF0aClcbn0pXG5cbmV4cG9ydCBkZWZhdWx0IGNlcnRib3RSb3V0ZXJcbiIsImltcG9ydCB7IFJvdXRlQ29uZmlnIH0gZnJvbSBcInJlYWN0LXJvdXRlci1jb25maWdcIlxuXG5pbXBvcnQgQXBwIGZyb20gXCIuLi9hcHBcIlxuaW1wb3J0IEFzeW5jSG9tZSwgeyBsb2FkRGF0YSBhcyBsb2FkSG9tZURhdGEgfSBmcm9tIFwiLi4vcGFnZXMvSG9tZVwiXG5pbXBvcnQgQXN5bmNNZW1icmVQYWdlLCB7IGxvYWREYXRhIGFzIGxvYWRNZW1icmVQYWdlRGF0YSB9IGZyb20gXCIuLi9wYWdlcy9NZW1icmVQYWdlXCJcbmltcG9ydCBMb2dpbiBmcm9tIFwiLi4vcGFnZXMvTG9naW5cIlxuaW1wb3J0IFJlZ2lzdGVyIGZyb20gXCIuLi9wYWdlcy9SZWdpc3RlclwiXG5pbXBvcnQgTm90Rm91bmQgZnJvbSBcIi4uL3BhZ2VzL05vdEZvdW5kXCJcblxuZXhwb3J0IGRlZmF1bHQgW1xuICAgIHtcbiAgICAgICAgY29tcG9uZW50OiBBcHAsXG4gICAgICAgIHJvdXRlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHBhdGg6IFwiL1wiLFxuICAgICAgICAgICAgICAgIGV4YWN0OiB0cnVlLFxuICAgICAgICAgICAgICAgIGNvbXBvbmVudDogQXN5bmNIb21lLCAvLyBBZGQgeW91ciBwYWdlIGhlcmVcbiAgICAgICAgICAgICAgICBsb2FkRGF0YTogbG9hZEhvbWVEYXRhLCAvLyBBZGQgeW91ciBwcmUtZmV0Y2ggbWV0aG9kIGhlcmVcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgcGF0aDogXCIvTWVtYnJlUGFnZS86aWRcIixcbiAgICAgICAgICAgICAgICBjb21wb25lbnQ6IEFzeW5jTWVtYnJlUGFnZSxcbiAgICAgICAgICAgICAgICBsb2FkRGF0YTogbG9hZE1lbWJyZVBhZ2VEYXRhLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBwYXRoOiBcIi9sb2dpblwiLFxuICAgICAgICAgICAgICAgIGNvbXBvbmVudDogTG9naW4sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHBhdGg6IFwiL3JlZ2lzdGVyXCIsXG4gICAgICAgICAgICAgICAgY29tcG9uZW50OiBSZWdpc3RlcixcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgY29tcG9uZW50OiBOb3RGb3VuZCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgfSxcbl0gYXMgUm91dGVDb25maWdbXVxuIiwiaW1wb3J0IHsgRXhwcmVzcyB9IGZyb20gXCJleHByZXNzXCJcbmltcG9ydCBjaGFsayBmcm9tIFwiY2hhbGtcIlxuXG5leHBvcnQgZGVmYXVsdCAoYXBwOiBFeHByZXNzKTogdm9pZCA9PiB7XG4gICAgY29uc3Qgd2VicGFjayA9IHJlcXVpcmUoXCJ3ZWJwYWNrXCIpXG4gICAgY29uc3Qgd2VicGFja0NvbmZpZyA9IHJlcXVpcmUoXCIuLi8uLi93ZWJwYWNrL2NsaWVudC5jb25maWdcIikuZGVmYXVsdFxuICAgIGNvbnN0IGNvbXBpbGVyID0gd2VicGFjayh3ZWJwYWNrQ29uZmlnKVxuICAgIGNvbnN0IGluc3RhbmNlID0gcmVxdWlyZShcIndlYnBhY2stZGV2LW1pZGRsZXdhcmVcIikoY29tcGlsZXIsIHtcbiAgICAgICAgaGVhZGVyczogeyBcIkFjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpblwiOiBcIipcIiB9LFxuICAgICAgICBzZXJ2ZXJTaWRlUmVuZGVyOiB0cnVlLFxuICAgIH0pXG5cbiAgICBhcHAudXNlKGluc3RhbmNlKVxuICAgIGFwcC51c2UoXG4gICAgICAgIHJlcXVpcmUoXCJ3ZWJwYWNrLWhvdC1taWRkbGV3YXJlXCIpKGNvbXBpbGVyLCB7XG4gICAgICAgICAgICBsb2c6IGZhbHNlLFxuICAgICAgICAgICAgcGF0aDogXCIvX193ZWJwYWNrX2htclwiLFxuICAgICAgICAgICAgaGVhcnRiZWF0OiAxMCAqIDEwMDAsXG4gICAgICAgIH0pXG4gICAgKVxuXG4gICAgaW5zdGFuY2Uud2FpdFVudGlsVmFsaWQoKCkgPT4ge1xuICAgICAgICBjb25zb2xlLmluZm8oY2hhbGsuZ3JlZW4oXCJ3ZWJwYWNrLWRldi1taWRkbGV3YXJlIGFjdGl2YXRlZFwiKSlcbiAgICB9KVxufVxuIiwiY29uc3QgQ0FDSEVfUkVORVdfREVMQVkgPSAxMDAwMFxuXG5jb25zdCBjYWNoZTogeyBbc2hlZXROYW1lOiBzdHJpbmddOiBhbnkgfSA9IHt9XG5jb25zdCBjYWNoZVRpbWU6IHsgW3NoZWV0TmFtZTogc3RyaW5nXTogbnVtYmVyIH0gPSB7fVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBEQk1hbmFnZXI8T3BlcmF0aW9uUmV0dXJuPihzaGVldE5hbWU6IHN0cmluZyk6IGFueSB7XG4gICAgdHlwZSBPcGVyYXRpb25UeXBlID0gXCJhZGRcIiB8IFwibGlzdFwiIHwgXCJzZXRcIlxuXG4gICAgY2FjaGVUaW1lW3NoZWV0TmFtZV0gPSAwXG5cbiAgICBpbnRlcmZhY2UgT3BlcmF0aW9uIHtcbiAgICAgICAgdGFzazogKCkgPT4gUHJvbWlzZTxPcGVyYXRpb25SZXR1cm4+XG4gICAgICAgIHR5cGU6IE9wZXJhdGlvblR5cGVcbiAgICAgICAgcmVzb2x2ZTogKHZhbHVlOiBPcGVyYXRpb25SZXR1cm4pID0+IHZvaWRcbiAgICAgICAgcmVqZWN0OiAocmVhc29uOiB1bmtub3duKSA9PiB2b2lkXG4gICAgfVxuXG4gICAgY29uc3Qgb3BlcmF0aW9uczogT3BlcmF0aW9uW10gPSBbXVxuXG4gICAgYXN5bmMgZnVuY3Rpb24gYWRkREJPcGVyYXRpb24odHlwZTogT3BlcmF0aW9uVHlwZSwgdGFzazogKCkgPT4gUHJvbWlzZTxPcGVyYXRpb25SZXR1cm4+KSB7XG4gICAgICAgIHJldHVybiBuZXcgUHJvbWlzZShcbiAgICAgICAgICAgIChyZXNvbHZlOiAodmFsdWU6IE9wZXJhdGlvblJldHVybikgPT4gdm9pZCwgcmVqZWN0OiAocmVhc29uOiB1bmtub3duKSA9PiB2b2lkKSA9PiB7XG4gICAgICAgICAgICAgICAgb3BlcmF0aW9ucy5wdXNoKHsgdGFzaywgdHlwZSwgcmVzb2x2ZSwgcmVqZWN0IH0pXG4gICAgICAgICAgICAgICAgaWYgKG9wZXJhdGlvbnMubGVuZ3RoID09PSAxKSB7XG4gICAgICAgICAgICAgICAgICAgIHJ1bk9wZXJhdGlvbihvcGVyYXRpb25zWzBdKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgKVxuICAgIH1cblxuICAgIGZ1bmN0aW9uIHJ1bk5leHREQk9wZXJhdGlvbigpOiB2b2lkIHtcbiAgICAgICAgb3BlcmF0aW9ucy5zaGlmdCgpXG4gICAgICAgIGlmIChvcGVyYXRpb25zWzBdKSB7XG4gICAgICAgICAgICBydW5PcGVyYXRpb24ob3BlcmF0aW9uc1swXSlcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGZ1bmN0aW9uIHJ1bk9wZXJhdGlvbihvcGVyYXRpb246IE9wZXJhdGlvbik6IHZvaWQge1xuICAgICAgICBjb25zdCB7IHRhc2ssIHR5cGUsIHJlc29sdmUsIHJlamVjdCB9ID0gb3BlcmF0aW9uXG4gICAgICAgIGlmICh0eXBlID09PSBcImxpc3RcIikge1xuICAgICAgICAgICAgY29uc3Qgbm93ID0gK25ldyBEYXRlKClcbiAgICAgICAgICAgIGlmIChub3cgPCBjYWNoZVRpbWVbc2hlZXROYW1lXSArIENBQ0hFX1JFTkVXX0RFTEFZKSB7XG4gICAgICAgICAgICAgICAgcmVzb2x2ZShjYWNoZVtzaGVldE5hbWVdKVxuICAgICAgICAgICAgICAgIHJ1bk5leHREQk9wZXJhdGlvbigpXG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRhc2soKVxuICAgICAgICAgICAgICAgICAgICAudGhlbigodmFsOiBPcGVyYXRpb25SZXR1cm4pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhY2hlW3NoZWV0TmFtZV0gPSB2YWxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhY2hlVGltZVtzaGVldE5hbWVdID0gbm93XG4gICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKHZhbClcbiAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgLmNhdGNoKHJlamVjdClcbiAgICAgICAgICAgICAgICAgICAgLmZpbmFsbHkocnVuTmV4dERCT3BlcmF0aW9uKVxuICAgICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY2FjaGVUaW1lW3NoZWV0TmFtZV0gPSAwXG4gICAgICAgICAgICB0YXNrKCkudGhlbihyZXNvbHZlKS5jYXRjaChyZWplY3QpLmZpbmFsbHkocnVuTmV4dERCT3BlcmF0aW9uKVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIGFkZERCT3BlcmF0aW9uXG59XG4iLCJpbXBvcnQgcGF0aCBmcm9tIFwicGF0aFwiXG5pbXBvcnQgXyBmcm9tIFwibG9kYXNoXCJcbmltcG9ydCB7IHByb21pc2VzIGFzIGZzIH0gZnJvbSBcImZzXCJcbmltcG9ydCB7IEdvb2dsZVNwcmVhZHNoZWV0LCBHb29nbGVTcHJlYWRzaGVldFdvcmtzaGVldCB9IGZyb20gXCJnb29nbGUtc3ByZWFkc2hlZXRcIlxuXG5pbXBvcnQgREJNYW5hZ2VyIGZyb20gXCIuL0RCTWFuYWdlclwiXG5cbmNvbnN0IENSRURfUEFUSCA9IHBhdGgucmVzb2x2ZShwcm9jZXNzLmN3ZCgpLCBcImFjY2Vzcy9nc2hlZXRzLmpzb25cIilcblxuZXhwb3J0IHR5cGUgRWxlbWVudFdpdGhJZCA9IHVua25vd24gJiB7IGlkOiBudW1iZXIgfVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBnZXRBY2Nlc3NvcnM8XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHlwZXNcbiAgICBFbGVtZW50Tm9JZCBleHRlbmRzIG9iamVjdCxcbiAgICBFbGVtZW50IGV4dGVuZHMgRWxlbWVudE5vSWQgJiBFbGVtZW50V2l0aElkXG4+KHNoZWV0TmFtZTogc3RyaW5nLCBzcGVjaW1lbjogRWxlbWVudCk6IGFueSB7XG4gICAgY29uc3QgYWRkREJPcGVyYXRpb24gPSBEQk1hbmFnZXIoc2hlZXROYW1lKVxuXG4gICAgYXN5bmMgZnVuY3Rpb24gbGlzdEdldCgpOiBQcm9taXNlPEVsZW1lbnRbXT4ge1xuICAgICAgICB0eXBlIFN0cmluZ2lmaWVkRWxlbWVudCA9IFJlY29yZDxrZXlvZiBFbGVtZW50LCBzdHJpbmc+XG4gICAgICAgIHJldHVybiBhZGREQk9wZXJhdGlvbihcImxpc3RcIiwgYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgY29uc3Qgc2hlZXQgPSBhd2FpdCBnZXRHU2hlZXQoKVxuXG4gICAgICAgICAgICAvLyBMb2FkIHNoZWV0IGludG8gYW4gYXJyYXkgb2Ygb2JqZWN0c1xuICAgICAgICAgICAgY29uc3Qgcm93cyA9IChhd2FpdCBzaGVldC5nZXRSb3dzKCkpIGFzIFN0cmluZ2lmaWVkRWxlbWVudFtdXG4gICAgICAgICAgICBjb25zdCBlbGVtZW50czogRWxlbWVudFtdID0gW11cbiAgICAgICAgICAgIGlmICghcm93c1swXSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgTm8gY29sdW1uIHR5cGVzIGRlZmluZWQgaW4gc2hlZXQgJHtzaGVldE5hbWV9YClcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IHR5cGVzID0gXy5waWNrKHJvd3NbMF0sIE9iamVjdC5rZXlzKHNwZWNpbWVuKSkgYXMgUmVjb3JkPGtleW9mIEVsZW1lbnQsIHN0cmluZz5cbiAgICAgICAgICAgIHJvd3Muc2hpZnQoKVxuICAgICAgICAgICAgcm93cy5mb3JFYWNoKChyb3cpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBzdHJpbmdpZmllZEVsZW1lbnQgPSBfLnBpY2socm93LCBPYmplY3Qua2V5cyhzcGVjaW1lbikpIGFzIFJlY29yZDxcbiAgICAgICAgICAgICAgICAgICAga2V5b2YgRWxlbWVudCxcbiAgICAgICAgICAgICAgICAgICAgc3RyaW5nXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIGNvbnN0IGVsZW1lbnQgPSBwYXJzZUVsZW1lbnQoc3RyaW5naWZpZWRFbGVtZW50LCB0eXBlcylcbiAgICAgICAgICAgICAgICBpZiAoZWxlbWVudCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgIGVsZW1lbnRzLnB1c2goZWxlbWVudClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KVxuXG4gICAgICAgICAgICByZXR1cm4gZWxlbWVudHNcbiAgICAgICAgfSlcbiAgICB9XG5cbiAgICBhc3luYyBmdW5jdGlvbiBnZXQobWVtYnJlSWQ6IG51bWJlcik6IFByb21pc2U8RWxlbWVudCB8IHVuZGVmaW5lZD4ge1xuICAgICAgICAvLyBObyBuZWVkIHRvIGFkZERCT3BlcmF0aW9uIGhlcmUsIHNpbmNlIGxpc3RHZXQgZG9lcyBpdCBhbHJlYWR5XG4gICAgICAgIGNvbnN0IGxpc3QgPSBhd2FpdCBsaXN0R2V0KClcbiAgICAgICAgcmV0dXJuIGxpc3QuZmluZCgoZWxlbWVudCkgPT4gZWxlbWVudC5pZCA9PT0gbWVtYnJlSWQpXG4gICAgfVxuXG4gICAgYXN5bmMgZnVuY3Rpb24gc2V0TGlzdChlbGVtZW50czogRWxlbWVudFtdKTogUHJvbWlzZTx0cnVlIHwgdW5kZWZpbmVkPiB7XG4gICAgICAgIHJldHVybiBhZGREQk9wZXJhdGlvbihcImxpc3RTZXRcIiwgYXN5bmMgKCkgPT4ge1xuICAgICAgICAgICAgY29uc3Qgc2hlZXQgPSBhd2FpdCBnZXRHU2hlZXQoKVxuXG4gICAgICAgICAgICAvLyBMb2FkIHNoZWV0IGludG8gYW4gYXJyYXkgb2Ygb2JqZWN0c1xuICAgICAgICAgICAgY29uc3Qgcm93cyA9IGF3YWl0IHNoZWV0LmdldFJvd3MoKVxuICAgICAgICAgICAgaWYgKCFyb3dzWzBdKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBObyBjb2x1bW4gdHlwZXMgZGVmaW5lZCBpbiBzaGVldCAke3NoZWV0TmFtZX1gKVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgdHlwZXMgPSBfLnBpY2socm93c1swXSwgT2JqZWN0LmtleXMoZWxlbWVudHNbMF0gfHwge30pKSBhcyBSZWNvcmQ8XG4gICAgICAgICAgICAgICAga2V5b2YgRWxlbWVudCxcbiAgICAgICAgICAgICAgICBzdHJpbmdcbiAgICAgICAgICAgID5cblxuICAgICAgICAgICAgLy8gVXBkYXRlIHJlY2VpdmVkIHJvd3NcbiAgICAgICAgICAgIGxldCByb3dpZCA9IDFcbiAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1yZXN0cmljdGVkLXN5bnRheFxuICAgICAgICAgICAgZm9yIChjb25zdCBlbGVtZW50IG9mIGVsZW1lbnRzKSB7XG4gICAgICAgICAgICAgICAgY29uc3Qgcm93ID0gcm93c1tyb3dpZF1cbiAgICAgICAgICAgICAgICBjb25zdCBzdHJpbmdpZmllZFJvdyA9IHN0cmluZ2lmeUVsZW1lbnQoZWxlbWVudCwgdHlwZXMpXG5cbiAgICAgICAgICAgICAgICBpZiAoIXJvdykge1xuICAgICAgICAgICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tYXdhaXQtaW4tbG9vcFxuICAgICAgICAgICAgICAgICAgICBhd2FpdCBzaGVldC5hZGRSb3coc3RyaW5naWZpZWRSb3cpXG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKHN0cmluZ2lmaWVkUm93KVxuICAgICAgICAgICAgICAgICAgICBjb25zdCBzYW1lQ2VsbHMgPSBfLmV2ZXJ5KFxuICAgICAgICAgICAgICAgICAgICAgICAga2V5cyxcbiAgICAgICAgICAgICAgICAgICAgICAgIChrZXk6IGtleW9mIEVsZW1lbnQpID0+IHJvd1trZXkgYXMgc3RyaW5nXSA9PT0gc3RyaW5naWZpZWRSb3dba2V5XVxuICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgIGlmICghc2FtZUNlbGxzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBrZXlzLmZvckVhY2goKGtleSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvd1trZXldID0gc3RyaW5naWZpZWRSb3dba2V5IGFzIGtleW9mIEVsZW1lbnRdXG4gICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWF3YWl0LWluLWxvb3BcbiAgICAgICAgICAgICAgICAgICAgICAgIGF3YWl0IHJvdy5zYXZlKClcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHJvd2lkICs9IDFcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gRGVsZXRlIGFsbCBmb2xsb3dpbmcgcm93c1xuICAgICAgICAgICAgZm9yIChsZXQgcm93VG9EZWxldGUgPSBzaGVldC5yb3dDb3VudCAtIDE7IHJvd1RvRGVsZXRlID49IHJvd2lkOyByb3dUb0RlbGV0ZSAtPSAxKSB7XG4gICAgICAgICAgICAgICAgaWYgKHJvd3Nbcm93VG9EZWxldGVdKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1hd2FpdC1pbi1sb29wXG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IHJvd3Nbcm93VG9EZWxldGVdLmRlbGV0ZSgpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICByZXR1cm4gdHJ1ZVxuICAgICAgICB9KVxuICAgIH1cblxuICAgIGFzeW5jIGZ1bmN0aW9uIHNldChlbGVtZW50OiBFbGVtZW50KTogUHJvbWlzZTxFbGVtZW50IHwgdW5kZWZpbmVkPiB7XG4gICAgICAgIGlmICghZWxlbWVudCkge1xuICAgICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZFxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBhZGREQk9wZXJhdGlvbihcInNldFwiLCBhc3luYyAoKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBzaGVldCA9IGF3YWl0IGdldEdTaGVldCgpXG5cbiAgICAgICAgICAgIC8vIExvYWQgc2hlZXQgaW50byBhbiBhcnJheSBvZiBvYmplY3RzXG4gICAgICAgICAgICBjb25zdCByb3dzID0gYXdhaXQgc2hlZXQuZ2V0Um93cygpXG4gICAgICAgICAgICBpZiAoIXJvd3NbMF0pIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYE5vIGNvbHVtbiB0eXBlcyBkZWZpbmVkIGluIHNoZWV0ICR7c2hlZXROYW1lfWApXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCB0eXBlcyA9IF8ucGljayhyb3dzWzBdLCBPYmplY3Qua2V5cyhlbGVtZW50IHx8IHt9KSkgYXMgUmVjb3JkPFxuICAgICAgICAgICAgICAgIGtleW9mIEVsZW1lbnQsXG4gICAgICAgICAgICAgICAgc3RyaW5nXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICByb3dzLnNoaWZ0KClcblxuICAgICAgICAgICAgLy8gUmVwbGFjZSBwcmV2aW91cyByb3dcbiAgICAgICAgICAgIGNvbnN0IHN0cmluZ2lmaWVkUm93ID0gc3RyaW5naWZ5RWxlbWVudChlbGVtZW50LCB0eXBlcylcbiAgICAgICAgICAgIGNvbnN0IHJvdyA9IHJvd3MuZmluZCgocm93SXRlbSkgPT4gK3Jvd0l0ZW0uaWQgPT09IGVsZW1lbnQuaWQpXG4gICAgICAgICAgICBpZiAoIXJvdykge1xuICAgICAgICAgICAgICAgIHJldHVybiB1bmRlZmluZWRcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIE9iamVjdC5hc3NpZ24ocm93LCBzdHJpbmdpZmllZFJvdylcbiAgICAgICAgICAgIGF3YWl0IHJvdy5zYXZlKClcbiAgICAgICAgICAgIHJldHVybiBlbGVtZW50XG4gICAgICAgIH0pXG4gICAgfVxuXG4gICAgYXN5bmMgZnVuY3Rpb24gYWRkKHBhcnRpYWxFbGVtZW50OiBQYXJ0aWFsPEVsZW1lbnROb0lkPik6IFByb21pc2U8RWxlbWVudCB8IHVuZGVmaW5lZD4ge1xuICAgICAgICBpZiAoIXBhcnRpYWxFbGVtZW50KSB7XG4gICAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkXG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGFkZERCT3BlcmF0aW9uKFwiYWRkXCIsIGFzeW5jICgpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHNoZWV0ID0gYXdhaXQgZ2V0R1NoZWV0KClcblxuICAgICAgICAgICAgLy8gTG9hZCBzaGVldCBpbnRvIGFuIGFycmF5IG9mIG9iamVjdHNcbiAgICAgICAgICAgIGNvbnN0IHJvd3MgPSBhd2FpdCBzaGVldC5nZXRSb3dzKClcbiAgICAgICAgICAgIGlmICghcm93c1swXSkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgTm8gY29sdW1uIHR5cGVzIGRlZmluZWQgaW4gc2hlZXQgJHtzaGVldE5hbWV9YClcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IHR5cGVzID0ge1xuICAgICAgICAgICAgICAgIGlkOiBcIm51bWJlclwiLFxuICAgICAgICAgICAgICAgIC4uLihfLnBpY2socm93c1swXSwgT2JqZWN0LmtleXMocGFydGlhbEVsZW1lbnQgfHwge30pKSBhcyBSZWNvcmQ8XG4gICAgICAgICAgICAgICAgICAgIGtleW9mIEVsZW1lbnROb0lkLFxuICAgICAgICAgICAgICAgICAgICBzdHJpbmdcbiAgICAgICAgICAgICAgICA+KSxcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gQ3JlYXRlIGZ1bGwgZWxlbWVudFxuICAgICAgICAgICAgcm93cy5zaGlmdCgpXG4gICAgICAgICAgICBjb25zdCBoaWdoZXN0SWQgPSByb3dzLnJlZHVjZSgoaWQ6IG51bWJlciwgcm93KSA9PiBNYXRoLm1heChpZCwgK3Jvdy5pZCB8fCAwKSwgMClcbiAgICAgICAgICAgIGNvbnN0IGVsZW1lbnQgPSB7IGlkOiBoaWdoZXN0SWQgKyAxLCAuLi5wYXJ0aWFsRWxlbWVudCB9IGFzIEVsZW1lbnRcblxuICAgICAgICAgICAgLy8gQWRkIGVsZW1lbnRcbiAgICAgICAgICAgIGNvbnN0IHN0cmluZ2lmaWVkUm93ID0gc3RyaW5naWZ5RWxlbWVudChlbGVtZW50LCB0eXBlcylcbiAgICAgICAgICAgIGF3YWl0IHNoZWV0LmFkZFJvdyhzdHJpbmdpZmllZFJvdylcblxuICAgICAgICAgICAgcmV0dXJuIGVsZW1lbnRcbiAgICAgICAgfSlcbiAgICB9XG5cbiAgICBhc3luYyBmdW5jdGlvbiBnZXRHU2hlZXQoKTogUHJvbWlzZTxHb29nbGVTcHJlYWRzaGVldFdvcmtzaGVldD4ge1xuICAgICAgICBjb25zdCBkb2MgPSBuZXcgR29vZ2xlU3ByZWFkc2hlZXQoXCIxcE1NS2NZeDZOWExPcU5uNnBMSEpUUE1UT0xSWVptU05nMlFRY0F1Ny1Qd1wiKVxuICAgICAgICBjb25zdCBjcmVkcyA9IGF3YWl0IGZzLnJlYWRGaWxlKENSRURfUEFUSClcbiAgICAgICAgLy8gQXV0aGVudGljYXRpb25cbiAgICAgICAgYXdhaXQgZG9jLnVzZVNlcnZpY2VBY2NvdW50QXV0aChKU09OLnBhcnNlKGNyZWRzLnRvU3RyaW5nKCkpKVxuICAgICAgICBhd2FpdCBkb2MubG9hZEluZm8oKVxuICAgICAgICByZXR1cm4gZG9jLnNoZWV0c0J5VGl0bGVbc2hlZXROYW1lXVxuICAgIH1cblxuICAgIGZ1bmN0aW9uIHBhcnNlRWxlbWVudChcbiAgICAgICAgcmF3RWxlbWVudDogUmVjb3JkPGtleW9mIEVsZW1lbnQsIHN0cmluZz4sXG4gICAgICAgIHR5cGVzOiBSZWNvcmQ8a2V5b2YgRWxlbWVudCwgc3RyaW5nPlxuICAgICk6IEVsZW1lbnQge1xuICAgICAgICBjb25zdCBmdWxsRWxlbWVudCA9IF8ucmVkdWNlKFxuICAgICAgICAgICAgdHlwZXMsXG4gICAgICAgICAgICAoZWxlbWVudDogYW55LCB0eXBlOiBzdHJpbmcsIHByb3A6IHN0cmluZykgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHJhd1Byb3A6IHN0cmluZyA9IHJhd0VsZW1lbnRbcHJvcCBhcyBrZXlvZiBFbGVtZW50XVxuICAgICAgICAgICAgICAgIHN3aXRjaCAodHlwZSkge1xuICAgICAgICAgICAgICAgICAgICBjYXNlIFwic3RyaW5nXCI6XG4gICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50W3Byb3BdID0gcmF3UHJvcFxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWtcblxuICAgICAgICAgICAgICAgICAgICBjYXNlIFwibnVtYmVyXCI6XG4gICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50W3Byb3BdID0gK3Jhd1Byb3BcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrXG5cbiAgICAgICAgICAgICAgICAgICAgY2FzZSBcImJvb2xlYW5cIjpcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnRbcHJvcF0gPSByYXdQcm9wICE9PSBcIjBcIiAmJiByYXdQcm9wICE9PSBcIlwiXG4gICAgICAgICAgICAgICAgICAgICAgICBicmVha1xuXG4gICAgICAgICAgICAgICAgICAgIGNhc2UgXCJkYXRlXCI6XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tY2FzZS1kZWNsYXJhdGlvbnNcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG1hdGNoRGF0ZSA9IHJhd1Byb3AubWF0Y2goL14oWzAtOV0rKVxcLyhbMC05XSspXFwvKFswLTldKykkLylcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChtYXRjaERhdGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50W3Byb3BdID0gbmV3IERhdGUoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICttYXRjaERhdGVbM10sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICttYXRjaERhdGVbMl0gLSAxLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICArbWF0Y2hEYXRlWzFdXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFVuYWJsZSB0byByZWFkIGRhdGUgZnJvbSAke3Jhd1Byb3B9YClcblxuICAgICAgICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWNhc2UtZGVjbGFyYXRpb25zXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBtYXRjaEFycmF5VHlwZSA9IHR5cGUubWF0Y2goXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgL14obnVtYmVyfHN0cmluZ3xib29sZWFufGRhdGUpXFxbKFteXFxdXSspXFxdJC9cbiAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghbWF0Y2hBcnJheVR5cGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFVua25vd24gYXJyYXkgdHlwZSBmb3IgJHt0eXBlfWApXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIXJhd1Byb3ApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50W3Byb3BdID0gW11cbiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYXJyYXlUeXBlID0gbWF0Y2hBcnJheVR5cGVbMV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBkZWxpbWl0ZXIgPSBtYXRjaEFycmF5VHlwZVsyXVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3dpdGNoIChhcnJheVR5cGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBcInN0cmluZ1wiOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudFtwcm9wXSA9IHJhd1Byb3Auc3BsaXQoZGVsaW1pdGVyKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIFwibnVtYmVyXCI6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50W3Byb3BdID0gXy5tYXAocmF3UHJvcC5zcGxpdChkZWxpbWl0ZXIpLCAodmFsKSA9PiArdmFsKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIFwiYm9vbGVhblwiOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudFtwcm9wXSA9IF8ubWFwKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJhd1Byb3Auc3BsaXQoZGVsaW1pdGVyKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAodmFsKSA9PiB2YWwgIT09IFwiMFwiICYmIHZhbCAhPT0gXCJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXNlIFwiZGF0ZVwiOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWNhc2UtZGVjbGFyYXRpb25zXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCByYXdEYXRlcyA9IHJhd1Byb3Auc3BsaXQoZGVsaW1pdGVyKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudFtwcm9wXSA9IFtdXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tY2FzZS1kZWNsYXJhdGlvbnNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHJpZ2h0Rm9ybWF0ID0gcmF3RGF0ZXMuZXZlcnkoKHJhd0RhdGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBtYXRjaERhdGVBcnJheSA9IHJhd0RhdGUubWF0Y2goXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC9eKFswLTldKylcXC8oWzAtOV0rKVxcLyhbMC05XSspJC9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFtYXRjaERhdGVBcnJheSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudFtwcm9wXS5wdXNoKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuZXcgRGF0ZShcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICttYXRjaERhdGVBcnJheVszXSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICttYXRjaERhdGVBcnJheVsyXSAtIDEsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICArbWF0Y2hEYXRlQXJyYXlbMV1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghcmlnaHRGb3JtYXQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGBPbmUgYXJyYXkgaXRlbSBpcyBub3QgYSBkYXRlIGluICR7cmF3UHJvcH1gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVW5rbm93biBhcnJheSB0eXBlICR7YXJyYXlUeXBlfWApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gZWxlbWVudFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkoc3BlY2ltZW4pKVxuICAgICAgICApXG4gICAgICAgIHJldHVybiBmdWxsRWxlbWVudFxuICAgIH1cblxuICAgIGZ1bmN0aW9uIHN0cmluZ2lmeUVsZW1lbnQoXG4gICAgICAgIGVsZW1lbnQ6IEVsZW1lbnQsXG4gICAgICAgIHR5cGVzOiB7IGlkOiBzdHJpbmcgfSAmIFJlY29yZDxrZXlvZiBFbGVtZW50Tm9JZCwgc3RyaW5nPlxuICAgICk6IFJlY29yZDxrZXlvZiBFbGVtZW50LCBzdHJpbmc+IHtcbiAgICAgICAgY29uc3QgcmF3RWxlbWVudDogUmVjb3JkPGtleW9mIEVsZW1lbnQsIHN0cmluZz4gPSBfLnJlZHVjZShcbiAgICAgICAgICAgIHR5cGVzLFxuICAgICAgICAgICAgKHN0cmluZ2lmaWVkRWxlbWVudDogUmVjb3JkPGtleW9mIEVsZW1lbnQsIHN0cmluZz4sIHR5cGU6IHN0cmluZywgcHJvcDogc3RyaW5nKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBlbGVtZW50W3Byb3AgYXMga2V5b2YgRWxlbWVudF1cbiAgICAgICAgICAgICAgICBzd2l0Y2ggKHR5cGUpIHtcbiAgICAgICAgICAgICAgICAgICAgY2FzZSBcInN0cmluZ1wiOlxuICAgICAgICAgICAgICAgICAgICAgICAgc3RyaW5naWZpZWRFbGVtZW50W3Byb3AgYXMga2V5b2YgRWxlbWVudF0gPSBmb3JtdWxhU2FmZShgJHt2YWx1ZX1gKVxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWtcblxuICAgICAgICAgICAgICAgICAgICBjYXNlIFwibnVtYmVyXCI6XG4gICAgICAgICAgICAgICAgICAgICAgICBzdHJpbmdpZmllZEVsZW1lbnRbcHJvcCBhcyBrZXlvZiBFbGVtZW50XSA9IGAke3ZhbHVlfWBcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrXG5cbiAgICAgICAgICAgICAgICAgICAgY2FzZSBcImJvb2xlYW5cIjpcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0cmluZ2lmaWVkRWxlbWVudFtwcm9wIGFzIGtleW9mIEVsZW1lbnRdID0gdmFsdWUgPyBcIlhcIiA6IFwiXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrXG5cbiAgICAgICAgICAgICAgICAgICAgY2FzZSBcImRhdGVcIjpcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0cmluZ2lmaWVkRWxlbWVudFtwcm9wIGFzIGtleW9mIEVsZW1lbnRdID0gc3RyaW5naWZpZWREYXRlKHZhbHVlKVxuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWtcblxuICAgICAgICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWNhc2UtZGVjbGFyYXRpb25zXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBtYXRjaEFycmF5VHlwZSA9IHR5cGUubWF0Y2goXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgL14obnVtYmVyfHN0cmluZ3xib29sZWFufGRhdGUpXFxbKFteXFxdXSspXFxdJC9cbiAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghbWF0Y2hBcnJheVR5cGUgfHwgIV8uaXNBcnJheSh2YWx1ZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiVW5rbm93biBtYXRjaEFycmF5VHlwZSBvciBub3QgYW4gYXJyYXkgaW4gc3RyaW5naWZ5RWxlbWVudFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWNhc2UtZGVjbGFyYXRpb25zXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBhcnJheVR5cGUgPSBtYXRjaEFycmF5VHlwZVsxXVxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWNhc2UtZGVjbGFyYXRpb25zXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBkZWxpbWl0ZXIgPSBtYXRjaEFycmF5VHlwZVsyXVxuXG4gICAgICAgICAgICAgICAgICAgICAgICBzd2l0Y2ggKGFycmF5VHlwZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgXCJzdHJpbmdcIjpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFfLmV2ZXJ5KHZhbHVlLCBfLmlzU3RyaW5nKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBFYWNoIGRhdGUgb2YgJHt2YWx1ZX0gaXMgbm90IGEgc3RyaW5nYClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJpbmdpZmllZEVsZW1lbnRbcHJvcCBhcyBrZXlvZiBFbGVtZW50XSA9IGZvcm11bGFTYWZlKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWUuam9pbihkZWxpbWl0ZXIpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgXCJudW1iZXJcIjpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFfLmV2ZXJ5KHZhbHVlLCBfLmlzTnVtYmVyKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBFYWNoIGRhdGUgb2YgJHt2YWx1ZX0gaXMgbm90IGEgbnVtYmVyYClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJpbmdpZmllZEVsZW1lbnRbcHJvcCBhcyBrZXlvZiBFbGVtZW50XSA9IHZhbHVlLmpvaW4oZGVsaW1pdGVyKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVha1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBcImJvb2xlYW5cIjpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFfLmV2ZXJ5KHZhbHVlLCBfLmlzQm9vbGVhbikpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgRWFjaCBkYXRlIG9mICR7dmFsdWV9IGlzIG5vdCBhIGJvb2xlYW5gKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cmluZ2lmaWVkRWxlbWVudFtwcm9wIGFzIGtleW9mIEVsZW1lbnRdID0gXy5tYXAodmFsdWUsICh2YWwpID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWwgPyBcIlhcIiA6IFwiXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKS5qb2luKGRlbGltaXRlcilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgXCJkYXRlXCI6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghXy5ldmVyeSh2YWx1ZSwgXy5pc0RhdGUpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEVhY2ggZGF0ZSBvZiAke3ZhbHVlfSBpcyBub3QgYSBkYXRlYClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJpbmdpZmllZEVsZW1lbnRbcHJvcCBhcyBrZXlvZiBFbGVtZW50XSA9IF8ubWFwKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAodmFsKSA9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGAke3ZhbC5nZXREYXRlKCl9LyR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbC5nZXRNb250aCgpICsgMVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0vJHt2YWwuZ2V0RnVsbFllYXIoKX1gXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkuam9pbihkZWxpbWl0ZXIpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrXG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFVua25vd24gYXJyYXkgdHlwZSAke2FycmF5VHlwZX1gKVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHJldHVybiBzdHJpbmdpZmllZEVsZW1lbnRcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KGVsZW1lbnQpKVxuICAgICAgICApXG5cbiAgICAgICAgcmV0dXJuIHJhd0VsZW1lbnRcbiAgICB9XG5cbiAgICBmdW5jdGlvbiBmb3JtdWxhU2FmZSh2YWx1ZTogc3RyaW5nKTogc3RyaW5nIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlLnJlcGxhY2UoL149Ky8sIFwiXCIpXG4gICAgfVxuXG4gICAgZnVuY3Rpb24gc3RyaW5naWZpZWREYXRlKHZhbHVlOiB1bmtub3duKTogc3RyaW5nIHtcbiAgICAgICAgbGV0IGRhdGU6IERhdGVcbiAgICAgICAgaWYgKHZhbHVlIGluc3RhbmNlb2YgRGF0ZSkge1xuICAgICAgICAgICAgZGF0ZSA9IHZhbHVlXG4gICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIHZhbHVlID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGRhdGUgPSBuZXcgRGF0ZSh2YWx1ZSlcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJXcm9uZyBkYXRlIHN0cmluZyBmb3JtYXQgaW4gc3RyaW5naWZ5RWxlbWVudFwiKVxuICAgICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiV3JvbmcgZGF0ZSBmb3JtYXQgaW4gc3RyaW5naWZ5RWxlbWVudFwiKVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBgJHtkYXRlLmdldERhdGUoKX0vJHtkYXRlLmdldE1vbnRoKCkgKyAxfS8ke2RhdGUuZ2V0RnVsbFllYXIoKX1gXG4gICAgfVxuXG4gICAgcmV0dXJuIHsgbGlzdEdldCwgZ2V0LCBzZXRMaXN0LCBzZXQsIGFkZCB9XG59XG4iLCJpbXBvcnQgZ2V0RXhwcmVzc0FjY2Vzc29ycyBmcm9tIFwiLi9leHByZXNzQWNjZXNzb3JzXCJcbmltcG9ydCB7IEVudmllLCBFbnZpZVdpdGhvdXRJZCB9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9lbnZpZXNcIlxuXG5jb25zdCB7IGxpc3RHZXRSZXF1ZXN0LCBnZXRSZXF1ZXN0LCBzZXRSZXF1ZXN0LCBhZGRSZXF1ZXN0IH0gPSBnZXRFeHByZXNzQWNjZXNzb3JzPFxuICAgIEVudmllV2l0aG91dElkLFxuICAgIEVudmllXG4+KFwiRW52aWVzIGQnYWlkZXJcIiwgbmV3IEVudmllKCkpXG5cbmV4cG9ydCBjb25zdCBlbnZpZUxpc3RHZXQgPSBsaXN0R2V0UmVxdWVzdCgpXG5cbmV4cG9ydCBjb25zdCBlbnZpZUdldCA9IGdldFJlcXVlc3QoKVxuXG5leHBvcnQgY29uc3QgZW52aWVBZGQgPSBhZGRSZXF1ZXN0KClcblxuZXhwb3J0IGNvbnN0IGVudmllU2V0ID0gc2V0UmVxdWVzdCgpXG4iLCJpbXBvcnQgeyBSZXF1ZXN0LCBSZXNwb25zZSwgTmV4dEZ1bmN0aW9uIH0gZnJvbSBcImV4cHJlc3NcIlxuaW1wb3J0IGdldEFjY2Vzc29ycywgeyBFbGVtZW50V2l0aElkIH0gZnJvbSBcIi4vYWNjZXNzb3JzXCJcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gZ2V0RXhwcmVzc0FjY2Vzc29yczxcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2Jhbi10eXBlc1xuICAgIEVsZW1lbnROb0lkIGV4dGVuZHMgb2JqZWN0LFxuICAgIEVsZW1lbnQgZXh0ZW5kcyBFbGVtZW50Tm9JZCAmIEVsZW1lbnRXaXRoSWRcbj4oc2hlZXROYW1lOiBzdHJpbmcsIHNwZWNpbWVuOiBFbGVtZW50KTogYW55IHtcbiAgICBjb25zdCB7IGdldCwgbGlzdEdldCwgYWRkLCBzZXQgfSA9IGdldEFjY2Vzc29ycyhzaGVldE5hbWUsIHNwZWNpbWVuKVxuXG4gICAgZnVuY3Rpb24gbGlzdEdldFJlcXVlc3QoKSB7XG4gICAgICAgIHJldHVybiBhc3luYyAoXG4gICAgICAgICAgICBfcmVxdWVzdDogUmVxdWVzdCxcbiAgICAgICAgICAgIHJlc3BvbnNlOiBSZXNwb25zZSxcbiAgICAgICAgICAgIF9uZXh0OiBOZXh0RnVuY3Rpb25cbiAgICAgICAgKTogUHJvbWlzZTx2b2lkPiA9PiB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGVsZW1lbnRzID0gYXdhaXQgbGlzdEdldCgpXG4gICAgICAgICAgICAgICAgaWYgKGVsZW1lbnRzKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlLnN0YXR1cygyMDApLmpzb24oZWxlbWVudHMpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBjYXRjaCAoZTogdW5rbm93bikge1xuICAgICAgICAgICAgICAgIHJlc3BvbnNlLnN0YXR1cyg0MDApLmpzb24oZSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIGZ1bmN0aW9uIGdldFJlcXVlc3QoKSB7XG4gICAgICAgIHJldHVybiBhc3luYyAocmVxdWVzdDogUmVxdWVzdCwgcmVzcG9uc2U6IFJlc3BvbnNlLCBfbmV4dDogTmV4dEZ1bmN0aW9uKTogUHJvbWlzZTx2b2lkPiA9PiB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGlkID0gcGFyc2VJbnQocmVxdWVzdC5xdWVyeS5pZCBhcyBzdHJpbmcsIDEwKSB8fCAtMVxuICAgICAgICAgICAgICAgIGNvbnN0IGVsZW1lbnRzID0gYXdhaXQgZ2V0KGlkKVxuICAgICAgICAgICAgICAgIGlmIChlbGVtZW50cykge1xuICAgICAgICAgICAgICAgICAgICByZXNwb25zZS5zdGF0dXMoMjAwKS5qc29uKGVsZW1lbnRzKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gY2F0Y2ggKGU6IHVua25vd24pIHtcbiAgICAgICAgICAgICAgICByZXNwb25zZS5zdGF0dXMoNDAwKS5qc29uKGUpXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBmdW5jdGlvbiBhZGRSZXF1ZXN0KCkge1xuICAgICAgICByZXR1cm4gYXN5bmMgKHJlcXVlc3Q6IFJlcXVlc3QsIHJlc3BvbnNlOiBSZXNwb25zZSwgX25leHQ6IE5leHRGdW5jdGlvbik6IFByb21pc2U8dm9pZD4gPT4ge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBjb25zdCBlbGVtZW50ID0gYXdhaXQgYWRkKHJlcXVlc3QuYm9keSlcbiAgICAgICAgICAgICAgICBpZiAoZWxlbWVudCkge1xuICAgICAgICAgICAgICAgICAgICByZXNwb25zZS5zdGF0dXMoMjAwKS5qc29uKGVsZW1lbnQpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBjYXRjaCAoZTogdW5rbm93bikge1xuICAgICAgICAgICAgICAgIHJlc3BvbnNlLnN0YXR1cyg0MDApLmpzb24oZSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cblxuICAgIGZ1bmN0aW9uIHNldFJlcXVlc3QoKSB7XG4gICAgICAgIHJldHVybiBhc3luYyAocmVxdWVzdDogUmVxdWVzdCwgcmVzcG9uc2U6IFJlc3BvbnNlLCBfbmV4dDogTmV4dEZ1bmN0aW9uKTogUHJvbWlzZTx2b2lkPiA9PiB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGVsZW1lbnQgPSBhd2FpdCBzZXQocmVxdWVzdC5ib2R5KVxuICAgICAgICAgICAgICAgIGlmIChlbGVtZW50KSB7XG4gICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlLnN0YXR1cygyMDApLmpzb24oZWxlbWVudClcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGNhdGNoIChlOiB1bmtub3duKSB7XG4gICAgICAgICAgICAgICAgcmVzcG9uc2Uuc3RhdHVzKDQwMCkuanNvbihlKVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHsgZ2V0UmVxdWVzdCwgYWRkUmVxdWVzdCwgbGlzdEdldFJlcXVlc3QsIHNldFJlcXVlc3QgfVxufVxuIiwiaW1wb3J0IGdldEV4cHJlc3NBY2Nlc3NvcnMgZnJvbSBcIi4vZXhwcmVzc0FjY2Vzc29yc1wiXG5pbXBvcnQgeyBKZXVKYXYsIEpldUphdldpdGhvdXRJZCB9IGZyb20gXCIuLi8uLi9zZXJ2aWNlcy9qZXV4SmF2XCJcblxuY29uc3QgeyBsaXN0R2V0UmVxdWVzdCwgZ2V0UmVxdWVzdCwgc2V0UmVxdWVzdCwgYWRkUmVxdWVzdCB9ID0gZ2V0RXhwcmVzc0FjY2Vzc29yczxcbiAgICBKZXVKYXZXaXRob3V0SWQsXG4gICAgSmV1SmF2XG4+KFwiSmV1eCBKQVZcIiwgbmV3IEpldUphdigpKVxuXG5leHBvcnQgY29uc3QgamV1SmF2TGlzdEdldCA9IGxpc3RHZXRSZXF1ZXN0KClcblxuZXhwb3J0IGNvbnN0IGpldUphdkdldCA9IGdldFJlcXVlc3QoKVxuXG5leHBvcnQgY29uc3QgamV1SmF2QWRkID0gYWRkUmVxdWVzdCgpXG5cbmV4cG9ydCBjb25zdCBqZXVKYXZTZXQgPSBzZXRSZXF1ZXN0KClcbiIsImltcG9ydCBnZXRFeHByZXNzQWNjZXNzb3JzIGZyb20gXCIuL2V4cHJlc3NBY2Nlc3NvcnNcIlxuaW1wb3J0IHsgTWVtYnJlLCBNZW1icmVXaXRob3V0SWQgfSBmcm9tIFwiLi4vLi4vc2VydmljZXMvbWVtYnJlc1wiXG5cbmNvbnN0IHsgbGlzdEdldFJlcXVlc3QsIGdldFJlcXVlc3QsIHNldFJlcXVlc3QsIGFkZFJlcXVlc3QgfSA9IGdldEV4cHJlc3NBY2Nlc3NvcnM8XG4gICAgTWVtYnJlV2l0aG91dElkLFxuICAgIE1lbWJyZVxuPihcIk1lbWJyZXNcIiwgbmV3IE1lbWJyZSgpKVxuXG5leHBvcnQgY29uc3QgbWVtYnJlTGlzdEdldCA9IGxpc3RHZXRSZXF1ZXN0KClcblxuZXhwb3J0IGNvbnN0IG1lbWJyZUdldCA9IGdldFJlcXVlc3QoKVxuXG5leHBvcnQgY29uc3QgbWVtYnJlQWRkID0gYWRkUmVxdWVzdCgpXG5cbmV4cG9ydCBjb25zdCBtZW1icmVTZXQgPSBzZXRSZXF1ZXN0KClcbiIsImltcG9ydCBwYXRoIGZyb20gXCJwYXRoXCJcbmltcG9ydCBleHByZXNzLCB7IFJlcXVlc3RIYW5kbGVyIH0gZnJvbSBcImV4cHJlc3NcIlxuaW1wb3J0IGxvZ2dlciBmcm9tIFwibW9yZ2FuXCJcbmltcG9ydCBjb21wcmVzc2lvbiBmcm9tIFwiY29tcHJlc3Npb25cIlxuaW1wb3J0IGhlbG1ldCBmcm9tIFwiaGVsbWV0XCJcbmltcG9ydCBocHAgZnJvbSBcImhwcFwiXG5pbXBvcnQgZmF2aWNvbiBmcm9tIFwic2VydmUtZmF2aWNvblwiXG5pbXBvcnQgY2hhbGsgZnJvbSBcImNoYWxrXCJcbmltcG9ydCAqIGFzIGh0dHAgZnJvbSBcImh0dHBcIlxuaW1wb3J0ICogYXMgaHR0cHMgZnJvbSBcImh0dHBzXCJcbmltcG9ydCAqIGFzIGZzIGZyb20gXCJmc1wiXG5pbXBvcnQgXyBmcm9tIFwibG9kYXNoXCJcblxuaW1wb3J0IGRldlNlcnZlciBmcm9tIFwiLi9kZXZTZXJ2ZXJcIlxuaW1wb3J0IHNzciBmcm9tIFwiLi9zc3JcIlxuXG5pbXBvcnQgY2VydGJvdFJvdXRlciBmcm9tIFwiLi4vcm91dGVzL2NlcnRib3RcIlxuaW1wb3J0IHsgc2VjdXJlIH0gZnJvbSBcIi4vc2VjdXJlXCJcbmltcG9ydCB7IGpldUphdkxpc3RHZXQgfSBmcm9tIFwiLi9nc2hlZXRzL2pldUphdlwiXG5pbXBvcnQgeyBlbnZpZUxpc3RHZXQsIGVudmllQWRkIH0gZnJvbSBcIi4vZ3NoZWV0cy9lbnZpZXNcIlxuaW1wb3J0IHsgbWVtYnJlR2V0LCBtZW1icmVTZXQgfSBmcm9tIFwiLi9nc2hlZXRzL21lbWJyZXNcIlxuaW1wb3J0IGxvZ2luSGFuZGxlciBmcm9tIFwiLi91c2VyTWFuYWdlbWVudC9sb2dpblwiXG5pbXBvcnQgY29uZmlnIGZyb20gXCIuLi9jb25maWdcIlxuXG5jb25zdCBhcHAgPSBleHByZXNzKClcblxuLy8gVXNlIGhlbG1ldCB0byBzZWN1cmUgRXhwcmVzcyB3aXRoIHZhcmlvdXMgSFRUUCBoZWFkZXJzXG5hcHAudXNlKGhlbG1ldCh7IGNvbnRlbnRTZWN1cml0eVBvbGljeTogZmFsc2UgfSkpXG4vLyBQcmV2ZW50IEhUVFAgcGFyYW1ldGVyIHBvbGx1dGlvblxuYXBwLnVzZShocHAoKSlcbi8vIENvbXByZXNzIGFsbCByZXF1ZXN0c1xuYXBwLnVzZShjb21wcmVzc2lvbigpKVxuXG4vLyBIdHRwcyB3aXRoIGNlcnRib3QgYW5kIExldCdzIEVuY3J5cHRcbmlmICghX19ERVZfXykge1xuICAgIGFwcC51c2UoXCIvLndlbGwta25vd24vYWNtZS1jaGFsbGVuZ2VcIiwgY2VydGJvdFJvdXRlcilcbn1cblxuLy8gVXNlIGZvciBodHRwIHJlcXVlc3QgZGVidWcgKHNob3cgZXJyb3JzIG9ubHkpXG5hcHAudXNlKGxvZ2dlcihcImRldlwiLCB7IHNraXA6IChfcmVxLCByZXMpID0+IHJlcy5zdGF0dXNDb2RlIDwgNDAwIH0pKVxuYXBwLnVzZShmYXZpY29uKHBhdGgucmVzb2x2ZShwcm9jZXNzLmN3ZCgpLCBcInB1YmxpYy9mYXZpY29uLmljb1wiKSkpXG5hcHAudXNlKGV4cHJlc3Muc3RhdGljKHBhdGgucmVzb2x2ZShwcm9jZXNzLmN3ZCgpLCBcInB1YmxpY1wiKSkpXG5cbi8vIEVuYWJsZSBkZXYtc2VydmVyIGluIGRldmVsb3BtZW50XG5pZiAoX19ERVZfXykgZGV2U2VydmVyKGFwcClcblxuYXBwLnVzZShleHByZXNzLmpzb24oKSlcblxuLy8gU2lnbiBpbiAmIHVwIEFQSVxuYXBwLnBvc3QoXCIvYXBpL3VzZXIvbG9naW5cIiwgbG9naW5IYW5kbGVyKVxuXG4vKipcbiAqIEFQSXNcbiAqL1xuLy8gR29vZ2xlIFNoZWV0cyBBUElcbmFwcC5nZXQoXCIvSmV1SmF2TGlzdEdldFwiLCBqZXVKYXZMaXN0R2V0KVxuYXBwLmdldChcIi9FbnZpZUxpc3RHZXRcIiwgZW52aWVMaXN0R2V0KVxuYXBwLnBvc3QoXCIvRW52aWVBZGRcIiwgZW52aWVBZGQpXG5cbi8vIFNlY3VyZWQgQVBJc1xuYXBwLmdldChcIi9NZW1icmVHZXRcIiwgc2VjdXJlIGFzIFJlcXVlc3RIYW5kbGVyLCBtZW1icmVHZXQpXG5hcHAucG9zdChcIi9NZW1icmVTZXRcIiwgc2VjdXJlIGFzIFJlcXVlc3RIYW5kbGVyLCBtZW1icmVTZXQpXG5cbi8vIFVzZSBSZWFjdCBzZXJ2ZXItc2lkZSByZW5kZXJpbmcgbWlkZGxld2FyZVxuYXBwLmdldChcIipcIiwgc3NyKVxuXG4vKipcbiAqIENyZWF0ZSBIVFRQIGFuZCBIVFRQUyBzZXJ2ZXIuXG4gKi9cblxuY29uc3Qgc2VydmVycyA9IFt7IHByb3RvY29sOiBcImh0dHBcIiwgc2VydmVyOiBodHRwLmNyZWF0ZVNlcnZlcihhcHApIH1dXG5cbmludGVyZmFjZSBDZXJ0IHtcbiAgICBrZXk6IHN0cmluZ1xuICAgIGNlcnQ6IHN0cmluZ1xufVxuY29uc3QgY2VydFBhdGhzOiBDZXJ0W10gPSBbXG4gICAge1xuICAgICAgICAvLyBQcm9kXG4gICAgICAgIGtleTogXCIvcm9vdC9jZXJ0Ym90L2NvbmZpZy9saXZlL2ZvLnBhcmlzZXN0bHVkaXF1ZS5mci9wcml2a2V5LnBlbVwiLFxuICAgICAgICBjZXJ0OiBcIi9yb290L2NlcnRib3QvY29uZmlnL2xpdmUvZm8ucGFyaXNlc3RsdWRpcXVlLmZyL2Z1bGxjaGFpbi5wZW1cIixcbiAgICB9LFxuICAgIHtcbiAgICAgICAgLy8gTG9jYWxcbiAgICAgICAga2V5OiBcIi4uL2NlcnRib3Qva2V5LnBlbVwiLFxuICAgICAgICBjZXJ0OiBcIi4uL2NlcnRib3QvY2VydC5wZW1cIixcbiAgICB9LFxuXVxuY29uc3QgdmFsaWRDZXJ0UGF0aDogQ2VydCB8IHVuZGVmaW5lZCA9IGNlcnRQYXRocy5maW5kKChjZXJ0UGF0aDogQ2VydCkgPT5cbiAgICBfLmV2ZXJ5KGNlcnRQYXRoLCAocGVtUGF0aDogc3RyaW5nKSA9PiBmcy5leGlzdHNTeW5jKHBlbVBhdGgpKVxuKVxuaWYgKHZhbGlkQ2VydFBhdGgpIHtcbiAgICBjb25zdCBodHRwc09wdGlvbnMgPSBfLm1hcFZhbHVlcyh2YWxpZENlcnRQYXRoLCAocGVtUGF0aDogc3RyaW5nKSA9PiBmcy5yZWFkRmlsZVN5bmMocGVtUGF0aCkpXG5cbiAgICBzZXJ2ZXJzLnB1c2goeyBwcm90b2NvbDogXCJodHRwc1wiLCBzZXJ2ZXI6IGh0dHBzLmNyZWF0ZVNlcnZlcihodHRwc09wdGlvbnMsIGFwcCkgfSlcbn1cblxuLyoqXG4gKiBMaXN0ZW4gb24gcHJvdmlkZWQgcG9ydCwgb24gYWxsIG5ldHdvcmsgaW50ZXJmYWNlcy5cbiAqL1xuc2VydmVycy5mb3JFYWNoKCh7IHByb3RvY29sLCBzZXJ2ZXIgfSkgPT4ge1xuICAgIHNlcnZlci5saXN0ZW4ocHJvdG9jb2wgPT09IFwiaHR0cFwiID8gY29uZmlnLlBPUlQgOiA8bnVtYmVyPmNvbmZpZy5QT1JUICsgMilcbiAgICBzZXJ2ZXIub24oXCJlcnJvclwiLCBvbkVycm9yKVxuICAgIHNlcnZlci5vbihcImxpc3RlbmluZ1wiLCAoKSA9PiBvbkxpc3RlbmluZyhzZXJ2ZXIpKVxufSlcblxuLyoqXG4gKiBFdmVudCBsaXN0ZW5lciBmb3IgSFRUUCBzZXJ2ZXIgJ2Vycm9yJyBldmVudC5cbiAqL1xuXG5mdW5jdGlvbiBvbkVycm9yKGVycm9yOiBhbnkpIHtcbiAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihjaGFsay5yZWQoYD09PiDwn5itICBPTUchISEgJHtlcnJvcn1gKSlcbiAgICB9XG59XG5cbi8qKlxuICogRXZlbnQgbGlzdGVuZXIgZm9yIEhUVFAgc2VydmVyICdsaXN0ZW5pbmcnIGV2ZW50LlxuICovXG5cbmZ1bmN0aW9uIG9uTGlzdGVuaW5nKHNlcnZlcjogYW55KSB7XG4gICAgY29uc3QgYWRkciA9IHNlcnZlci5hZGRyZXNzKClcbiAgICBjb25zdCBiaW5kID0gdHlwZW9mIGFkZHIgPT09IFwic3RyaW5nXCIgPyBgcGlwZSAke2FkZHJ9YCA6IGBwb3J0ICR7YWRkci5wb3J0fWBcbiAgICBjb25zb2xlLmVycm9yKGNoYWxrLmdyZWVuKGBcXG5TZXJ2ZXIgbGlzdGVuaW5nIG9uICR7YmluZH1gKSlcbn1cbiIsImltcG9ydCB7IENodW5rRXh0cmFjdG9yIH0gZnJvbSBcIkBsb2FkYWJsZS9zZXJ2ZXJcIlxuaW1wb3J0IHsgSGVsbWV0RGF0YSB9IGZyb20gXCJyZWFjdC1oZWxtZXRcIlxuaW1wb3J0IHNlcmlhbGl6ZSBmcm9tIFwic2VyaWFsaXplLWphdmFzY3JpcHRcIlxuaW1wb3J0IHsgbWluaWZ5IH0gZnJvbSBcImh0bWwtbWluaWZpZXJcIlxuXG5leHBvcnQgZGVmYXVsdCAoXG4gICAgaGVhZDogSGVsbWV0RGF0YSxcbiAgICBleHRyYWN0b3I6IENodW5rRXh0cmFjdG9yLFxuICAgIGh0bWxDb250ZW50OiBzdHJpbmcsXG4gICAgaW5pdGlhbFN0YXRlOiB0eXBlb2Ygd2luZG93Ll9fSU5JVElBTF9TVEFURV9fXG4pOiBhbnkgPT4ge1xuICAgIGNvbnN0IGh0bWwgPSBgXG4gICAgPCFkb2N0eXBlIGh0bWw+XG4gICAgPGh0bWwgJHtoZWFkLmh0bWxBdHRyaWJ1dGVzLnRvU3RyaW5nKCl9PlxuICAgICAgPGhlYWQ+XG4gICAgICAgIDxtZXRhIGNoYXJzZXQ9XCJ1dGYtOFwiIC8+XG4gICAgICAgIDxtZXRhIG5hbWU9XCJ2aWV3cG9ydFwiIGNvbnRlbnQ9XCJ3aWR0aD1kZXZpY2Utd2lkdGgsIGluaXRpYWwtc2NhbGU9MVwiIC8+XG4gICAgICAgIDxtZXRhIG5hbWU9XCJ0aGVtZS1jb2xvclwiIGNvbnRlbnQ9XCIjMDAwXCIgLz5cblxuICAgICAgICA8bGluayByZWw9XCJpY29uXCIgaHJlZj1cIi9mYXZpY29uLmljb1wiIC8+XG4gICAgICAgIDxsaW5rIHJlbD1cImFwcGxlLXRvdWNoLWljb25cIiBocmVmPVwiL2xvZ28xOTIucG5nXCIgLz5cbiAgICAgICAgPGxpbmsgcmVsPVwibWFuaWZlc3RcIiBocmVmPVwiL21hbmlmZXN0Lmpzb25cIiAvPlxuXG4gICAgICAgICR7aGVhZC50aXRsZS50b1N0cmluZygpfVxuICAgICAgICAke2hlYWQuYmFzZS50b1N0cmluZygpfVxuICAgICAgICAke2hlYWQubWV0YS50b1N0cmluZygpfVxuICAgICAgICAke2hlYWQubGluay50b1N0cmluZygpfVxuXG4gICAgICAgIDwhLS0gSW5zZXJ0IGJ1bmRsZWQgc3R5bGVzIGludG8gPGxpbms+IHRhZyAtLT5cbiAgICAgICAgJHtleHRyYWN0b3IuZ2V0TGlua1RhZ3MoKX1cbiAgICAgICAgJHtleHRyYWN0b3IuZ2V0U3R5bGVUYWdzKCl9XG4gICAgICA8L2hlYWQ+XG4gICAgICA8Ym9keT5cbiAgICAgICAgPCEtLSBJbnNlcnQgdGhlIHJvdXRlciwgd2hpY2ggcGFzc2VkIGZyb20gc2VydmVyLXNpZGUgLS0+XG4gICAgICAgIDxkaXYgaWQ9XCJyZWFjdC12aWV3XCI+JHtodG1sQ29udGVudH08L2Rpdj5cblxuICAgICAgICA8IS0tIFN0b3JlIHRoZSBpbml0aWFsIHN0YXRlIGludG8gd2luZG93IC0tPlxuICAgICAgICA8c2NyaXB0PlxuICAgICAgICAgIC8vIFVzZSBzZXJpYWxpemUtamF2YXNjcmlwdCBmb3IgbWl0aWdhdGluZyBYU1MgYXR0YWNrcy4gU2VlIHRoZSBmb2xsb3dpbmcgc2VjdXJpdHkgaXNzdWVzOlxuICAgICAgICAgIC8vIGh0dHA6Ly9yZWR1eC5qcy5vcmcvZG9jcy9yZWNpcGVzL1NlcnZlclJlbmRlcmluZy5odG1sI3NlY3VyaXR5LWNvbnNpZGVyYXRpb25zXG4gICAgICAgICAgd2luZG93Ll9fSU5JVElBTF9TVEFURV9fPSR7c2VyaWFsaXplKGluaXRpYWxTdGF0ZSl9O1xuICAgICAgICA8L3NjcmlwdD5cblxuICAgICAgICA8IS0tIEluc2VydCBidW5kbGVkIHNjcmlwdHMgaW50byA8c2NyaXB0PiB0YWcgLS0+XG4gICAgICAgICR7ZXh0cmFjdG9yLmdldFNjcmlwdFRhZ3MoKX1cbiAgICAgICAgJHtoZWFkLnNjcmlwdC50b1N0cmluZygpfVxuICAgICAgPC9ib2R5PlxuICAgIDwvaHRtbD5cbiAgYFxuXG4gICAgLy8gaHRtbC1taW5pZmllciBjb25maWd1cmF0aW9uLCByZWZlciB0byBcImh0dHBzOi8vZ2l0aHViLmNvbS9rYW5nYXgvaHRtbC1taW5pZmllclwiIGZvciBtb3JlIGNvbmZpZ3VyYXRpb25cbiAgICBjb25zdCBtaW5pZnlDb25maWcgPSB7XG4gICAgICAgIGNvbGxhcHNlV2hpdGVzcGFjZTogdHJ1ZSxcbiAgICAgICAgcmVtb3ZlQ29tbWVudHM6IHRydWUsXG4gICAgICAgIHRyaW1DdXN0b21GcmFnbWVudHM6IHRydWUsXG4gICAgICAgIG1pbmlmeUNTUzogdHJ1ZSxcbiAgICAgICAgbWluaWZ5SlM6IHRydWUsXG4gICAgICAgIG1pbmlmeVVSTHM6IHRydWUsXG4gICAgfVxuXG4gICAgLy8gTWluaWZ5IEhUTUwgaW4gcHJvZHVjdGlvblxuICAgIHJldHVybiBfX0RFVl9fID8gaHRtbCA6IG1pbmlmeShodG1sLCBtaW5pZnlDb25maWcpXG59XG4iLCJpbXBvcnQgeyBOZXh0RnVuY3Rpb24sIFJlcXVlc3QsIFJlc3BvbnNlIH0gZnJvbSBcImV4cHJlc3NcIlxuaW1wb3J0IHBhdGggZnJvbSBcInBhdGhcIlxuaW1wb3J0IHsgcHJvbWlzZXMgYXMgZnMgfSBmcm9tIFwiZnNcIlxuaW1wb3J0IHsgdmVyaWZ5LCBzaWduIH0gZnJvbSBcImpzb253ZWJ0b2tlblwiXG5pbXBvcnQgeyBjYW5vbmljYWxFbWFpbCB9IGZyb20gXCIuLi91dGlscy9zdGFuZGFyZGl6YXRpb25cIlxuXG5pbXBvcnQgY29uZmlnIGZyb20gXCIuLi9jb25maWdcIlxuXG50eXBlIEF1dGhvcml6ZWRSZXF1ZXN0ID0gUmVxdWVzdCAmIHsgaGVhZGVyczogeyBhdXRob3JpemF0aW9uOiBzdHJpbmcgfSB9XG5cbmxldCBjYWNoZWRTZWNyZXQ6IHN0cmluZ1xuZ2V0U2VjcmV0KCkgLy8gTmVjZXNzYXJ5IHVudGlsIHdlIGNhbiBtYWtlIGFzeW5jIGV4cHJlc3MgbWlkZGxld2FyZVxuXG5leHBvcnQgZnVuY3Rpb24gc2VjdXJlKHJlcXVlc3Q6IEF1dGhvcml6ZWRSZXF1ZXN0LCByZXNwb25zZTogUmVzcG9uc2UsIG5leHQ6IE5leHRGdW5jdGlvbik6IHZvaWQge1xuICAgIGlmICghY2FjaGVkU2VjcmV0KSB7XG4gICAgICAgIHJlc3BvbnNlLnN0YXR1cyg0MDgpLmpzb24oe1xuICAgICAgICAgICAgZXJyb3I6IFwiU2VydmVyIHN0aWxsIGxvYWRpbmdcIixcbiAgICAgICAgfSlcbiAgICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgY29uc3QgcmF3VG9rZW4gPSByZXF1ZXN0LmhlYWRlcnMuYXV0aG9yaXphdGlvblxuICAgIGNvbnN0IHRva2VuID0gcmF3VG9rZW4gJiYgcmF3VG9rZW4uc3BsaXQoL1xccy8pWzFdXG5cbiAgICB2ZXJpZnkodG9rZW4sIGNhY2hlZFNlY3JldCwgKHRva2VuRXJyb3I6IGFueSwgZGVjb2RlZDogYW55KSA9PiB7XG4gICAgICAgIGlmICh0b2tlbkVycm9yKSB7XG4gICAgICAgICAgICByZXNwb25zZS5zdGF0dXMoNDAzKS5qc29uKHtcbiAgICAgICAgICAgICAgICBlcnJvcjogXCJJbnZhbGlkIHRva2VuLCBwbGVhc2UgTG9nIGluIGZpcnN0LCBjcml0ZXJpb24gYXV0aFwiLFxuICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIHJldHVyblxuICAgICAgICB9XG4gICAgICAgIGRlY29kZWQudXNlci5yZXBsYWNlKC9AZ21haWxjb20kLywgXCJAZ21haWwuY29tXCIpXG4gICAgICAgIHJlc3BvbnNlLmxvY2Fscy5qd3QgPSBkZWNvZGVkXG4gICAgICAgIG5leHQoKVxuICAgIH0pXG59XG5cbmFzeW5jIGZ1bmN0aW9uIGdldFNlY3JldCgpIHtcbiAgICBpZiAoIWNhY2hlZFNlY3JldCkge1xuICAgICAgICBjb25zdCBTRUNSRVRfUEFUSCA9IHBhdGgucmVzb2x2ZShwcm9jZXNzLmN3ZCgpLCBcImFjY2Vzcy9qd3Rfc2VjcmV0Lmpzb25cIilcblxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3Qgc2VjcmV0Q29udGVudCA9IGF3YWl0IGZzLnJlYWRGaWxlKFNFQ1JFVF9QQVRIKVxuICAgICAgICAgICAgY2FjaGVkU2VjcmV0ID0gc2VjcmV0Q29udGVudCAmJiBKU09OLnBhcnNlKHNlY3JldENvbnRlbnQudG9TdHJpbmcoKSkuc2VjcmV0XG4gICAgICAgIH0gY2F0Y2ggKGU6IGFueSkge1xuICAgICAgICAgICAgY2FjaGVkU2VjcmV0ID0gY29uZmlnLkpXVF9TRUNSRVRcbiAgICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBjYWNoZWRTZWNyZXRcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEp3dChlbWFpbDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBjb25zdCBqd3QgPSBzaWduKFxuICAgICAgICB7IHVzZXI6IGNhbm9uaWNhbEVtYWlsKGVtYWlsKSwgcGVybWlzc2lvbnM6IFtdIH0sXG4gICAgICAgIGF3YWl0IGdldFNlY3JldCgpLFxuICAgICAgICBfX1RFU1RfX1xuICAgICAgICAgICAgPyB1bmRlZmluZWRcbiAgICAgICAgICAgIDoge1xuICAgICAgICAgICAgICAgICAgZXhwaXJlc0luOiBcIjM2NWRcIixcbiAgICAgICAgICAgICAgfVxuICAgIClcbiAgICByZXR1cm4gand0XG59XG4iLCJpbXBvcnQgcGF0aCBmcm9tIFwicGF0aFwiXG5pbXBvcnQgeyByZW5kZXJUb1N0cmluZyB9IGZyb20gXCJyZWFjdC1kb20vc2VydmVyXCJcbmltcG9ydCB7IFN0YXRpY1JvdXRlciB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCJcbmltcG9ydCB7IHJlbmRlclJvdXRlcywgbWF0Y2hSb3V0ZXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWNvbmZpZ1wiXG5pbXBvcnQgeyBQcm92aWRlciB9IGZyb20gXCJyZWFjdC1yZWR1eFwiXG5pbXBvcnQgeyBDaHVua0V4dHJhY3RvciB9IGZyb20gXCJAbG9hZGFibGUvc2VydmVyXCJcbmltcG9ydCB7IEhlbG1ldCB9IGZyb20gXCJyZWFjdC1oZWxtZXRcIlxuaW1wb3J0IGNoYWxrIGZyb20gXCJjaGFsa1wiXG5pbXBvcnQgeyBSZXF1ZXN0LCBSZXNwb25zZSwgTmV4dEZ1bmN0aW9uIH0gZnJvbSBcImV4cHJlc3NcIlxuaW1wb3J0IHsgQWN0aW9uIH0gZnJvbSBcIkByZWR1eGpzL3Rvb2xraXRcIlxuXG5pbXBvcnQgY3JlYXRlU3RvcmUgZnJvbSBcIi4uL3N0b3JlXCJcbmltcG9ydCByZW5kZXJIdG1sIGZyb20gXCIuL3JlbmRlckh0bWxcIlxuaW1wb3J0IHJvdXRlcyBmcm9tIFwiLi4vcm91dGVzXCJcblxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgKHJlcTogUmVxdWVzdCwgcmVzOiBSZXNwb25zZSwgbmV4dDogTmV4dEZ1bmN0aW9uKTogUHJvbWlzZTx2b2lkPiA9PiB7XG4gICAgY29uc3QgeyBzdG9yZSB9ID0gY3JlYXRlU3RvcmUoeyB1cmw6IHJlcS51cmwgfSlcblxuICAgIC8vIFRoZSBtZXRob2QgZm9yIGxvYWRpbmcgZGF0YSBmcm9tIHNlcnZlci1zaWRlXG4gICAgY29uc3QgbG9hZEJyYW5jaERhdGEgPSAoKTogUHJvbWlzZTxhbnk+ID0+IHtcbiAgICAgICAgY29uc3QgYnJhbmNoID0gbWF0Y2hSb3V0ZXMocm91dGVzLCByZXEucGF0aClcbiAgICAgICAgY29uc3QgcHJvbWlzZXMgPSBicmFuY2gubWFwKCh7IHJvdXRlLCBtYXRjaCB9KSA9PiB7XG4gICAgICAgICAgICBpZiAocm91dGUubG9hZERhdGEpXG4gICAgICAgICAgICAgICAgcmV0dXJuIFByb21pc2UuYWxsKFxuICAgICAgICAgICAgICAgICAgICByb3V0ZVxuICAgICAgICAgICAgICAgICAgICAgICAgLmxvYWREYXRhKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXJhbXM6IG1hdGNoLnBhcmFtcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBnZXRTdGF0ZTogc3RvcmUuZ2V0U3RhdGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVxLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcyxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAubWFwKChpdGVtOiBBY3Rpb24pID0+IHN0b3JlLmRpc3BhdGNoKGl0ZW0pKVxuICAgICAgICAgICAgICAgIClcblxuICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShudWxsKVxuICAgICAgICB9KVxuXG4gICAgICAgIHJldHVybiBQcm9taXNlLmFsbChwcm9taXNlcylcbiAgICB9XG5cbiAgICB0cnkge1xuICAgICAgICAvLyBMb2FkIGRhdGEgZnJvbSBzZXJ2ZXItc2lkZSBmaXJzdFxuICAgICAgICBhd2FpdCBsb2FkQnJhbmNoRGF0YSgpXG5cbiAgICAgICAgY29uc3Qgc3RhdHNGaWxlID0gcGF0aC5yZXNvbHZlKHByb2Nlc3MuY3dkKCksIFwicHVibGljL2xvYWRhYmxlLXN0YXRzXCIpXG4gICAgICAgIGNvbnN0IGV4dHJhY3RvciA9IG5ldyBDaHVua0V4dHJhY3Rvcih7IHN0YXRzRmlsZSB9KVxuXG4gICAgICAgIGNvbnN0IHN0YXRpY0NvbnRleHQ6IFJlY29yZDxzdHJpbmcsIGFueT4gPSB7fVxuICAgICAgICBjb25zdCBBcHAgPSBleHRyYWN0b3IuY29sbGVjdENodW5rcyhcbiAgICAgICAgICAgIDxQcm92aWRlciBzdG9yZT17c3RvcmV9PlxuICAgICAgICAgICAgICAgIHsvKiBTZXR1cCBSZWFjdC1Sb3V0ZXIgc2VydmVyLXNpZGUgcmVuZGVyaW5nICovfVxuICAgICAgICAgICAgICAgIDxTdGF0aWNSb3V0ZXIgbG9jYXRpb249e3JlcS5wYXRofSBjb250ZXh0PXtzdGF0aWNDb250ZXh0fT5cbiAgICAgICAgICAgICAgICAgICAge3JlbmRlclJvdXRlcyhyb3V0ZXMpfVxuICAgICAgICAgICAgICAgIDwvU3RhdGljUm91dGVyPlxuICAgICAgICAgICAgPC9Qcm92aWRlcj5cbiAgICAgICAgKVxuXG4gICAgICAgIGNvbnN0IGluaXRpYWxTdGF0ZSA9IHN0b3JlLmdldFN0YXRlKClcbiAgICAgICAgY29uc3QgaHRtbENvbnRlbnQgPSByZW5kZXJUb1N0cmluZyhBcHApXG4gICAgICAgIC8vIGhlYWQgbXVzdCBiZSBwbGFjZWQgYWZ0ZXIgXCJyZW5kZXJUb1N0cmluZ1wiXG4gICAgICAgIC8vIHNlZTogaHR0cHM6Ly9naXRodWIuY29tL25mbC9yZWFjdC1oZWxtZXQjc2VydmVyLXVzYWdlXG4gICAgICAgIGNvbnN0IGhlYWQgPSBIZWxtZXQucmVuZGVyU3RhdGljKClcblxuICAgICAgICAvLyBDaGVjayBpZiB0aGUgcmVuZGVyIHJlc3VsdCBjb250YWlucyBhIHJlZGlyZWN0LCBpZiBzbyB3ZSBuZWVkIHRvIHNldFxuICAgICAgICAvLyB0aGUgc3BlY2lmaWMgc3RhdHVzIGFuZCByZWRpcmVjdCBoZWFkZXIgYW5kIGVuZCB0aGUgcmVzcG9uc2VcbiAgICAgICAgaWYgKHN0YXRpY0NvbnRleHQudXJsKSB7XG4gICAgICAgICAgICByZXMuc3RhdHVzKDMwMSkuc2V0SGVhZGVyKFwiTG9jYXRpb25cIiwgc3RhdGljQ29udGV4dC51cmwpXG4gICAgICAgICAgICByZXMuZW5kKClcblxuICAgICAgICAgICAgcmV0dXJuXG4gICAgICAgIH1cblxuICAgICAgICAvLyBQYXNzIHRoZSByb3V0ZSBhbmQgaW5pdGlhbCBzdGF0ZSBpbnRvIGh0bWwgdGVtcGxhdGUsIHRoZSBcInN0YXR1c0NvZGVcIiBjb21lcyBmcm9tIDxOb3RGb3VuZCAvPlxuICAgICAgICByZXMuc3RhdHVzKHN0YXRpY0NvbnRleHQuc3RhdHVzQ29kZSA9PT0gXCI0MDRcIiA/IDQwNCA6IDIwMCkuc2VuZChcbiAgICAgICAgICAgIHJlbmRlckh0bWwoaGVhZCwgZXh0cmFjdG9yLCBodG1sQ29udGVudCwgaW5pdGlhbFN0YXRlKVxuICAgICAgICApXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgcmVzLnN0YXR1cyg0MDQpLnNlbmQoXCJOb3QgRm91bmQgOihcIilcbiAgICAgICAgY29uc29sZS5lcnJvcihjaGFsay5yZWQoYD09PiDwn5itICBSZW5kZXJpbmcgcm91dGVzIGVycm9yOiAke2Vycm9yfWApKVxuICAgIH1cblxuICAgIG5leHQoKVxufVxuIiwiaW1wb3J0IHsgUmVxdWVzdCwgUmVzcG9uc2UsIE5leHRGdW5jdGlvbiB9IGZyb20gXCJleHByZXNzXCJcbmltcG9ydCBiY3J5cHQgZnJvbSBcImJjcnlwdFwiXG5pbXBvcnQgeyBNZW1icmUsIE1lbWJlckxvZ2luLCBlbWFpbFJlZ2V4cCwgcGFzc3dvcmRNaW5MZW5ndGggfSBmcm9tIFwiLi4vLi4vc2VydmljZXMvbWVtYnJlc1wiXG5pbXBvcnQgZ2V0QWNjZXNzb3JzIGZyb20gXCIuLi9nc2hlZXRzL2FjY2Vzc29yc1wiXG5pbXBvcnQgeyBnZXRKd3QgfSBmcm9tIFwiLi4vc2VjdXJlXCJcblxuY29uc3QgeyBsaXN0R2V0IH0gPSBnZXRBY2Nlc3NvcnMoXCJNZW1icmVzXCIsIG5ldyBNZW1icmUoKSlcblxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24gbG9naW5IYW5kbGVyKFxuICAgIHJlcXVlc3Q6IFJlcXVlc3QsXG4gICAgcmVzcG9uc2U6IFJlc3BvbnNlLFxuICAgIF9uZXh0OiBOZXh0RnVuY3Rpb25cbik6IFByb21pc2U8dm9pZD4ge1xuICAgIHRyeSB7XG4gICAgICAgIGlmICh0eXBlb2YgcmVxdWVzdC5ib2R5LmVtYWlsICE9PSBcInN0cmluZ1wiIHx8IHR5cGVvZiByZXF1ZXN0LmJvZHkucGFzc3dvcmQgIT09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgICAgIHRocm93IEVycm9yKClcbiAgICAgICAgfVxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBsb2dpbihyZXF1ZXN0LmJvZHkuZW1haWwsIHJlcXVlc3QuYm9keS5wYXNzd29yZClcbiAgICAgICAgcmVzcG9uc2Uuc3RhdHVzKDIwMCkuanNvbihyZXMpXG4gICAgfSBjYXRjaCAoZTogYW55KSB7XG4gICAgICAgIGlmIChlLm1lc3NhZ2UpIHtcbiAgICAgICAgICAgIHJlc3BvbnNlLnN0YXR1cygyMDApLmpzb24oeyBlcnJvcjogZS5tZXNzYWdlIH0pXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXNwb25zZS5zdGF0dXMoNDAwKS5qc29uKGUpXG4gICAgICAgIH1cbiAgICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBsb2dpbihyYXdFbWFpbDogc3RyaW5nLCByYXdQYXNzd29yZDogc3RyaW5nKTogUHJvbWlzZTxNZW1iZXJMb2dpbj4ge1xuICAgIGNvbnN0IGVtYWlsID0gcmF3RW1haWwucmVwbGFjZSgvXlxccyovLCBcIlwiKS5yZXBsYWNlKC9cXHMqJC8sIFwiXCIpXG4gICAgaWYgKCFlbWFpbFJlZ2V4cC50ZXN0KGVtYWlsKSkge1xuICAgICAgICB0aHJvdyBFcnJvcihcIkVtYWlsIGludmFsaWRcIilcbiAgICB9XG5cbiAgICBjb25zdCBwYXNzd29yZCA9IHJhd1Bhc3N3b3JkLnJlcGxhY2UoL15cXHMqLywgXCJcIikucmVwbGFjZSgvXFxzKiQvLCBcIlwiKVxuICAgIGlmIChwYXNzd29yZC5sZW5ndGggPT09IDApIHtcbiAgICAgICAgdGhyb3cgRXJyb3IoXCJNb3QgZGUgcGFzc2UgbsOpY2Vzc2FpcmVcIilcbiAgICB9XG4gICAgaWYgKHBhc3N3b3JkLmxlbmd0aCA8IHBhc3N3b3JkTWluTGVuZ3RoKSB7XG4gICAgICAgIHRocm93IEVycm9yKFwiTW90IGRlIHBhc3NlIHRyb3AgY291cnRcIilcbiAgICB9XG5cbiAgICBjb25zdCBtZW1icmVzOiBNZW1icmVbXSA9IGF3YWl0IGxpc3RHZXQoKVxuICAgIGNvbnN0IG1lbWJyZSA9IG1lbWJyZXMuZmluZCgobSkgPT4gbS5tYWlsID09PSBlbWFpbClcbiAgICBpZiAoIW1lbWJyZSkge1xuICAgICAgICB0aHJvdyBFcnJvcihcIkNldCBlbWFpbCBuZSBjb3JyZXNwb25kIMOgIGF1Y3VuIHV0aWxpc2F0ZXVyXCIpXG4gICAgfVxuXG4gICAgY29uc3QgcGFzc3dvcmRNYXRjaCA9IGF3YWl0IGJjcnlwdC5jb21wYXJlKHBhc3N3b3JkLCBtZW1icmUucGFzc2UucmVwbGFjZSgvXlxcJDJ5LywgXCIkMmFcIikpXG4gICAgaWYgKCFwYXNzd29yZE1hdGNoKSB7XG4gICAgICAgIHRocm93IEVycm9yKFwiTWF1dmFpcyBtb3QgZGUgcGFzc2UgcG91ciBjZXQgZW1haWxcIilcbiAgICB9XG5cbiAgICBjb25zdCBqd3QgPSBhd2FpdCBnZXRKd3QoZW1haWwpXG5cbiAgICByZXR1cm4ge1xuICAgICAgICBtZW1icmU6IHtcbiAgICAgICAgICAgIHByZW5vbTogbWVtYnJlLnByZW5vbSxcbiAgICAgICAgfSxcbiAgICAgICAgand0LFxuICAgIH1cbn1cbiIsImltcG9ydCBheGlvcyBmcm9tIFwiYXhpb3NcIlxuXG5pbXBvcnQgY29uZmlnIGZyb20gXCIuLi9jb25maWdcIlxuaW1wb3J0IHsgYXhpb3NDb25maWcgfSBmcm9tIFwiLi9hdXRoXCJcblxuZXhwb3J0IHR5cGUgRWxlbWVudFdpdGhJZCA9IHVua25vd24gJiB7IGlkOiBudW1iZXIgfVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0PEVsZW1lbnQ+KGVsZW1lbnROYW1lOiBzdHJpbmcpOiAoaWQ6IG51bWJlcikgPT4gUHJvbWlzZTx7XG4gICAgZGF0YT86IEVsZW1lbnRcbiAgICBlcnJvcj86IEVycm9yXG59PiB7XG4gICAgaW50ZXJmYWNlIEVsZW1lbnRHZXRSZXNwb25zZSB7XG4gICAgICAgIGRhdGE/OiBFbGVtZW50XG4gICAgICAgIGVycm9yPzogRXJyb3JcbiAgICB9XG4gICAgcmV0dXJuIGFzeW5jIChpZDogbnVtYmVyKTogUHJvbWlzZTxFbGVtZW50R2V0UmVzcG9uc2U+ID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXhpb3MuZ2V0KGAke2NvbmZpZy5BUElfVVJMfS8ke2VsZW1lbnROYW1lfUdldGAsIHtcbiAgICAgICAgICAgICAgICAuLi5heGlvc0NvbmZpZyxcbiAgICAgICAgICAgICAgICBwYXJhbXM6IHsgaWQgfSxcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICByZXR1cm4geyBkYXRhIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIHJldHVybiB7IGVycm9yOiBlcnJvciBhcyBFcnJvciB9XG4gICAgICAgIH1cbiAgICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBsaXN0R2V0PEVsZW1lbnQ+KGVsZW1lbnROYW1lOiBzdHJpbmcpOiAoKSA9PiBQcm9taXNlPHtcbiAgICBkYXRhPzogRWxlbWVudFtdXG4gICAgZXJyb3I/OiBFcnJvclxufT4ge1xuICAgIGludGVyZmFjZSBFbGVtZW50TGlzdEdldFJlc3BvbnNlIHtcbiAgICAgICAgZGF0YT86IEVsZW1lbnRbXVxuICAgICAgICBlcnJvcj86IEVycm9yXG4gICAgfVxuICAgIHJldHVybiBhc3luYyAoKTogUHJvbWlzZTxFbGVtZW50TGlzdEdldFJlc3BvbnNlPiA9PiB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IGF4aW9zLmdldChgJHtjb25maWcuQVBJX1VSTH0vJHtlbGVtZW50TmFtZX1MaXN0R2V0YCwgYXhpb3NDb25maWcpXG4gICAgICAgICAgICByZXR1cm4geyBkYXRhIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIHJldHVybiB7IGVycm9yOiBlcnJvciBhcyBFcnJvciB9XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvYmFuLXR5cGVzXG5leHBvcnQgZnVuY3Rpb24gYWRkPEVsZW1lbnROb0lkIGV4dGVuZHMgb2JqZWN0LCBFbGVtZW50IGV4dGVuZHMgRWxlbWVudE5vSWQgJiBFbGVtZW50V2l0aElkPihcbiAgICBlbGVtZW50TmFtZTogc3RyaW5nXG4pOiAobWVtYnJlV2l0aG91dElkOiBFbGVtZW50Tm9JZCkgPT4gUHJvbWlzZTx7XG4gICAgZGF0YT86IEVsZW1lbnRcbiAgICBlcnJvcj86IEVycm9yXG59PiB7XG4gICAgaW50ZXJmYWNlIEVsZW1lbnRHZXRSZXNwb25zZSB7XG4gICAgICAgIGRhdGE/OiBFbGVtZW50XG4gICAgICAgIGVycm9yPzogRXJyb3JcbiAgICB9XG4gICAgcmV0dXJuIGFzeW5jIChtZW1icmVXaXRob3V0SWQ6IEVsZW1lbnROb0lkKTogUHJvbWlzZTxFbGVtZW50R2V0UmVzcG9uc2U+ID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXhpb3MucG9zdChcbiAgICAgICAgICAgICAgICBgJHtjb25maWcuQVBJX1VSTH0vJHtlbGVtZW50TmFtZX1BZGRgLFxuICAgICAgICAgICAgICAgIG1lbWJyZVdpdGhvdXRJZCxcbiAgICAgICAgICAgICAgICBheGlvc0NvbmZpZ1xuICAgICAgICAgICAgKVxuICAgICAgICAgICAgcmV0dXJuIHsgZGF0YSB9XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICByZXR1cm4geyBlcnJvcjogZXJyb3IgYXMgRXJyb3IgfVxuICAgICAgICB9XG4gICAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gc2V0PEVsZW1lbnQ+KGVsZW1lbnROYW1lOiBzdHJpbmcpOiAobWVtYnJlOiBFbGVtZW50KSA9PiBQcm9taXNlPHtcbiAgICBkYXRhPzogRWxlbWVudFxuICAgIGVycm9yPzogRXJyb3Jcbn0+IHtcbiAgICBpbnRlcmZhY2UgRWxlbWVudEdldFJlc3BvbnNlIHtcbiAgICAgICAgZGF0YT86IEVsZW1lbnRcbiAgICAgICAgZXJyb3I/OiBFcnJvclxuICAgIH1cbiAgICByZXR1cm4gYXN5bmMgKG1lbWJyZTogRWxlbWVudCk6IFByb21pc2U8RWxlbWVudEdldFJlc3BvbnNlPiA9PiB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCB7IGRhdGEgfSA9IGF3YWl0IGF4aW9zLnBvc3QoXG4gICAgICAgICAgICAgICAgYCR7Y29uZmlnLkFQSV9VUkx9LyR7ZWxlbWVudE5hbWV9U2V0YCxcbiAgICAgICAgICAgICAgICBtZW1icmUsXG4gICAgICAgICAgICAgICAgYXhpb3NDb25maWdcbiAgICAgICAgICAgIClcbiAgICAgICAgICAgIHJldHVybiB7IGRhdGEgfVxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgcmV0dXJuIHsgZXJyb3I6IGVycm9yIGFzIEVycm9yIH1cbiAgICAgICAgfVxuICAgIH1cbn1cbiIsImltcG9ydCB7IEF4aW9zUmVxdWVzdENvbmZpZyB9IGZyb20gXCJheGlvc1wiXG5cbmNvbnN0IHN0b3JhZ2U6IGFueSA9IGxvY2FsU3RvcmFnZVxuXG5jb25zdCBqd3Q6IHN0cmluZyB8IG51bGwgPSBzdG9yYWdlPy5nZXRJdGVtKFwiaWRfdG9rZW5cIilcbmlmIChqd3QpIHtcbiAgICBzZXRKV1Qoand0KVxufVxuXG5leHBvcnQgY29uc3QgYXhpb3NDb25maWc6IEF4aW9zUmVxdWVzdENvbmZpZyA9IHtcbiAgICBoZWFkZXJzOiB7fSxcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHNldEpXVCh0b2tlbjogc3RyaW5nKTogdm9pZCB7XG4gICAgYXhpb3NDb25maWcuaGVhZGVycy5BdXRob3JpemF0aW9uID0gYEJlYXJlciAke3Rva2VufWBcbiAgICBzdG9yYWdlPy5zZXRJdGVtKFwiaWRfdG9rZW5cIiwgdG9rZW4pXG59XG5cbmV4cG9ydCBmdW5jdGlvbiB1bnNldEpXVCgpOiB2b2lkIHtcbiAgICBkZWxldGUgYXhpb3NDb25maWcuaGVhZGVycy5BdXRob3JpemF0aW9uXG4gICAgc3RvcmFnZT8ucmVtb3ZlSXRlbShcImlkX3Rva2VuXCIpXG59XG4iLCJpbXBvcnQgeyBnZXQsIGxpc3RHZXQsIGFkZCwgc2V0IH0gZnJvbSBcIi4vYWNjZXNzb3JzXCJcblxuZXhwb3J0IGNsYXNzIEVudmllIHtcbiAgICBpZCA9IDBcblxuICAgIGRvbWFpbmUgPSBcIlwiXG5cbiAgICBlbnZpZXMgPSBcIlwiXG5cbiAgICBwcmVjaXNpb25zID0gXCJcIlxuXG4gICAgZXF1aXBlczogc3RyaW5nW10gPSBbXVxuXG4gICAgZGF0ZUFqb3V0ID0gXCJcIlxufVxuXG5leHBvcnQgdHlwZSBFbnZpZVdpdGhvdXRJZCA9IE9taXQ8RW52aWUsIFwiaWRcIj5cblxuZXhwb3J0IGNvbnN0IGVudmllR2V0ID0gZ2V0PEVudmllPihcIkVudmllXCIpXG5cbmV4cG9ydCBjb25zdCBlbnZpZUxpc3RHZXQgPSBsaXN0R2V0PEVudmllPihcIkVudmllXCIpXG5cbmV4cG9ydCBjb25zdCBlbnZpZUFkZCA9IGFkZDxFbnZpZVdpdGhvdXRJZCwgRW52aWU+KFwiRW52aWVcIilcblxuZXhwb3J0IGNvbnN0IGVudmllU2V0ID0gc2V0PEVudmllPihcIkVudmllXCIpXG4iLCJpbXBvcnQgeyBnZXQsIGxpc3RHZXQsIGFkZCwgc2V0IH0gZnJvbSBcIi4vYWNjZXNzb3JzXCJcblxuZXhwb3J0IGNsYXNzIEpldUphdiB7XG4gICAgaWQgPSAwXG5cbiAgICB0aXRyZSA9IFwiXCJcblxuICAgIGF1dGV1ciA9IFwiXCJcblxuICAgIGVkaXRldXIgPSBcIlwiXG5cbiAgICBtaW5Kb3VldXJzID0gMFxuXG4gICAgbWF4Sm91ZXVycyA9IDBcblxuICAgIGR1cmVlID0gMFxuXG4gICAgdHlwZTogXCJBbWJpYW5jZVwiIHwgXCJGYW1pbGxlXCIgfCBcIkV4cGVydFwiIHwgXCJcIiA9IFwiXCJcblxuICAgIHBvdWZwYWYgPSBcIlwiXG5cbiAgICBiZ2dJZCA9IDBcblxuICAgIGV4ZW1wbGFpcmVzID0gMVxuXG4gICAgZGlzcG9QcmV0ID0gMFxuXG4gICAgbm9uUmFuZ2VlID0gMFxuXG4gICAgZWFuID0gXCJcIlxuXG4gICAgYmdnUGhvdG8gPSBcIlwiXG59XG5cbmV4cG9ydCB0eXBlIEpldUphdldpdGhvdXRJZCA9IE9taXQ8SmV1SmF2LCBcImlkXCI+XG5cbmV4cG9ydCBjb25zdCBqZXVKYXZHZXQgPSBnZXQ8SmV1SmF2PihcIkpldUphdlwiKVxuXG5leHBvcnQgY29uc3QgamV1SmF2TGlzdEdldCA9IGxpc3RHZXQ8SmV1SmF2PihcIkpldUphdlwiKVxuXG5leHBvcnQgY29uc3QgamV1SmF2QWRkID0gYWRkPEpldUphdldpdGhvdXRJZCwgSmV1SmF2PihcIkpldUphdlwiKVxuXG5leHBvcnQgY29uc3QgamV1SmF2U2V0ID0gc2V0PEpldUphdj4oXCJKZXVKYXZcIilcbiIsImltcG9ydCB7IGdldCwgbGlzdEdldCwgYWRkLCBzZXQgfSBmcm9tIFwiLi9hY2Nlc3NvcnNcIlxuXG5leHBvcnQgY2xhc3MgTWVtYnJlIHtcbiAgICBpZCA9IDBcblxuICAgIG5vbSA9IFwiXCJcblxuICAgIHByZW5vbSA9IFwiXCJcblxuICAgIG1haWwgPSBcIlwiXG5cbiAgICB0ZWxlcGhvbmUgPSBcIlwiXG5cbiAgICBwaG90byA9IFwiXCJcblxuICAgIGFsaW1lbnRhdGlvbiA9IFwiXCJcblxuICAgIG1hamV1ciA9IDFcblxuICAgIHByaXZpbGVnZSA9IDBcblxuICAgIGFjdGlmID0gMFxuXG4gICAgY29tbWVudGFpcmUgPSBcIlwiXG5cbiAgICBob3JvZGF0YWdlID0gXCJcIlxuXG4gICAgcGFzc2UgPSBcIlwiXG59XG5cbmV4cG9ydCBjb25zdCBlbWFpbFJlZ2V4cCA9XG4gICAgL14oKFtePD4oKVtcXF0uLDs6XFxzQFwiXSsoXFwuW148PigpW1xcXS4sOzpcXHNAXCJdKykqKXwoXCIuK1wiKSlAKChbXjw+KClbXFxdLiw7Olxcc0BcIl0rXFwuKStbXjw+KClbXFxdLiw7Olxcc0BcIl17Mix9KSQvaVxuZXhwb3J0IGNvbnN0IHBhc3N3b3JkTWluTGVuZ3RoID0gNFxuXG5leHBvcnQgaW50ZXJmYWNlIE1lbWJlckxvZ2luIHtcbiAgICBtZW1icmU/OiB7XG4gICAgICAgIHByZW5vbTogc3RyaW5nXG4gICAgfVxuICAgIGp3dD86IHN0cmluZ1xuICAgIGVycm9yPzogc3RyaW5nXG59XG5cbmV4cG9ydCB0eXBlIE1lbWJyZVdpdGhvdXRJZCA9IE9taXQ8TWVtYnJlLCBcImlkXCI+XG5cbmV4cG9ydCBjb25zdCBtZW1icmVHZXQgPSBnZXQ8TWVtYnJlPihcIk1lbWJyZVwiKVxuXG5leHBvcnQgY29uc3QgbWVtYnJlTGlzdEdldCA9IGxpc3RHZXQ8TWVtYnJlPihcIk1lbWJyZVwiKVxuXG5leHBvcnQgY29uc3QgbWVtYnJlQWRkID0gYWRkPE1lbWJyZVdpdGhvdXRJZCwgTWVtYnJlPihcIk1lbWJyZVwiKVxuXG5leHBvcnQgY29uc3QgbWVtYnJlU2V0ID0gc2V0PE1lbWJyZT4oXCJNZW1icmVcIilcbiIsImltcG9ydCB7IFBheWxvYWRBY3Rpb24sIGNyZWF0ZVNsaWNlLCBjcmVhdGVFbnRpdHlBZGFwdGVyIH0gZnJvbSBcIkByZWR1eGpzL3Rvb2xraXRcIlxuXG5pbXBvcnQgeyBTdGF0ZVJlcXVlc3QsIHRvYXN0RXJyb3IsIHRvYXN0U3VjY2VzcywgZWxlbWVudEFkZEZldGNoIH0gZnJvbSBcIi4vdXRpbHNcIlxuaW1wb3J0IHsgRW52aWUsIGVudmllQWRkIH0gZnJvbSBcIi4uL3NlcnZpY2VzL2Vudmllc1wiXG5cbmNvbnN0IGVudmllQWRhcHRlciA9IGNyZWF0ZUVudGl0eUFkYXB0ZXI8RW52aWU+KClcblxuY29uc3QgZW52aWVBZGRTbGljZSA9IGNyZWF0ZVNsaWNlKHtcbiAgICBuYW1lOiBcImFkZEVudmllXCIsXG4gICAgaW5pdGlhbFN0YXRlOiBlbnZpZUFkYXB0ZXIuZ2V0SW5pdGlhbFN0YXRlKHtcbiAgICAgICAgcmVhZHlTdGF0dXM6IFwiaWRsZVwiLFxuICAgIH0gYXMgU3RhdGVSZXF1ZXN0KSxcbiAgICByZWR1Y2Vyczoge1xuICAgICAgICBnZXRSZXF1ZXN0aW5nOiAoc3RhdGUpID0+IHtcbiAgICAgICAgICAgIHN0YXRlLnJlYWR5U3RhdHVzID0gXCJyZXF1ZXN0XCJcbiAgICAgICAgfSxcbiAgICAgICAgZ2V0U3VjY2VzczogKHN0YXRlLCB7IHBheWxvYWQgfTogUGF5bG9hZEFjdGlvbjxFbnZpZT4pID0+IHtcbiAgICAgICAgICAgIHN0YXRlLnJlYWR5U3RhdHVzID0gXCJzdWNjZXNzXCJcbiAgICAgICAgICAgIGVudmllQWRhcHRlci5hZGRPbmUoc3RhdGUsIHBheWxvYWQpXG4gICAgICAgIH0sXG4gICAgICAgIGdldEZhaWx1cmU6IChzdGF0ZSwgeyBwYXlsb2FkIH06IFBheWxvYWRBY3Rpb248c3RyaW5nPikgPT4ge1xuICAgICAgICAgICAgc3RhdGUucmVhZHlTdGF0dXMgPSBcImZhaWx1cmVcIlxuICAgICAgICAgICAgc3RhdGUuZXJyb3IgPSBwYXlsb2FkXG4gICAgICAgIH0sXG4gICAgfSxcbn0pXG5cbmV4cG9ydCBkZWZhdWx0IGVudmllQWRkU2xpY2UucmVkdWNlclxuZXhwb3J0IGNvbnN0IHsgZ2V0UmVxdWVzdGluZywgZ2V0U3VjY2VzcywgZ2V0RmFpbHVyZSB9ID0gZW52aWVBZGRTbGljZS5hY3Rpb25zXG5cbmV4cG9ydCBjb25zdCBmZXRjaEVudmllQWRkID0gZWxlbWVudEFkZEZldGNoKFxuICAgIGVudmllQWRkLFxuICAgIGdldFJlcXVlc3RpbmcsXG4gICAgZ2V0U3VjY2VzcyxcbiAgICBnZXRGYWlsdXJlLFxuICAgIChlcnJvcjogRXJyb3IpID0+IHRvYXN0RXJyb3IoYEVycmV1ciBsb3JzIGRlIGwnYWpvdXQgZCd1bmUgZW52aWU6ICR7ZXJyb3IubWVzc2FnZX1gKSxcbiAgICAoKSA9PiB0b2FzdFN1Y2Nlc3MoXCJFbnZpZSBham91dMOpZSAhXCIpXG4pXG4iLCJpbXBvcnQgeyBQYXlsb2FkQWN0aW9uLCBjcmVhdGVTbGljZSwgY3JlYXRlRW50aXR5QWRhcHRlciB9IGZyb20gXCJAcmVkdXhqcy90b29sa2l0XCJcblxuaW1wb3J0IHsgU3RhdGVSZXF1ZXN0LCB0b2FzdEVycm9yLCBlbGVtZW50TGlzdEZldGNoIH0gZnJvbSBcIi4vdXRpbHNcIlxuaW1wb3J0IHsgRW52aWUsIGVudmllTGlzdEdldCB9IGZyb20gXCIuLi9zZXJ2aWNlcy9lbnZpZXNcIlxuaW1wb3J0IHsgQXBwVGh1bmssIEFwcFN0YXRlIH0gZnJvbSBcIi5cIlxuXG5jb25zdCBlbnZpZUFkYXB0ZXIgPSBjcmVhdGVFbnRpdHlBZGFwdGVyPEVudmllPigpXG5cbmNvbnN0IGVudmllTGlzdCA9IGNyZWF0ZVNsaWNlKHtcbiAgICBuYW1lOiBcImdldEVudmllTGlzdFwiLFxuICAgIGluaXRpYWxTdGF0ZTogZW52aWVBZGFwdGVyLmdldEluaXRpYWxTdGF0ZSh7XG4gICAgICAgIHJlYWR5U3RhdHVzOiBcImlkbGVcIixcbiAgICB9IGFzIFN0YXRlUmVxdWVzdCksXG4gICAgcmVkdWNlcnM6IHtcbiAgICAgICAgZ2V0UmVxdWVzdGluZzogKHN0YXRlKSA9PiB7XG4gICAgICAgICAgICBzdGF0ZS5yZWFkeVN0YXR1cyA9IFwicmVxdWVzdFwiXG4gICAgICAgIH0sXG4gICAgICAgIGdldFN1Y2Nlc3M6IChzdGF0ZSwgeyBwYXlsb2FkIH06IFBheWxvYWRBY3Rpb248RW52aWVbXT4pID0+IHtcbiAgICAgICAgICAgIHN0YXRlLnJlYWR5U3RhdHVzID0gXCJzdWNjZXNzXCJcbiAgICAgICAgICAgIGVudmllQWRhcHRlci5zZXRBbGwoc3RhdGUsIHBheWxvYWQpXG4gICAgICAgIH0sXG4gICAgICAgIGdldEZhaWx1cmU6IChzdGF0ZSwgeyBwYXlsb2FkIH06IFBheWxvYWRBY3Rpb248c3RyaW5nPikgPT4ge1xuICAgICAgICAgICAgc3RhdGUucmVhZHlTdGF0dXMgPSBcImZhaWx1cmVcIlxuICAgICAgICAgICAgc3RhdGUuZXJyb3IgPSBwYXlsb2FkXG4gICAgICAgIH0sXG4gICAgfSxcbn0pXG5cbmV4cG9ydCBkZWZhdWx0IGVudmllTGlzdC5yZWR1Y2VyXG5leHBvcnQgY29uc3QgeyBnZXRSZXF1ZXN0aW5nLCBnZXRTdWNjZXNzLCBnZXRGYWlsdXJlIH0gPSBlbnZpZUxpc3QuYWN0aW9uc1xuXG5leHBvcnQgY29uc3QgZmV0Y2hFbnZpZUxpc3QgPSBlbGVtZW50TGlzdEZldGNoKFxuICAgIGVudmllTGlzdEdldCxcbiAgICBnZXRSZXF1ZXN0aW5nLFxuICAgIGdldFN1Y2Nlc3MsXG4gICAgZ2V0RmFpbHVyZSxcbiAgICAoZXJyb3I6IEVycm9yKSA9PiB0b2FzdEVycm9yKGBFcnJldXIgbG9ycyBkdSBjaGFyZ2VtZW50IGRlcyBlbnZpZXM6ICR7ZXJyb3IubWVzc2FnZX1gKVxuKVxuXG5jb25zdCBzaG91bGRGZXRjaEVudmllTGlzdCA9IChzdGF0ZTogQXBwU3RhdGUpID0+IHN0YXRlLmVudmllTGlzdC5yZWFkeVN0YXR1cyAhPT0gXCJzdWNjZXNzXCJcblxuZXhwb3J0IGNvbnN0IGZldGNoRW52aWVMaXN0SWZOZWVkID0gKCk6IEFwcFRodW5rID0+IChkaXNwYXRjaCwgZ2V0U3RhdGUpID0+IHtcbiAgICBpZiAoc2hvdWxkRmV0Y2hFbnZpZUxpc3QoZ2V0U3RhdGUoKSkpIHJldHVybiBkaXNwYXRjaChmZXRjaEVudmllTGlzdCgpKVxuXG4gICAgcmV0dXJuIG51bGxcbn1cbiIsImltcG9ydCB7IGNyZWF0ZU1lbW9yeUhpc3RvcnksIGNyZWF0ZUJyb3dzZXJIaXN0b3J5IH0gZnJvbSBcImhpc3RvcnlcIlxuaW1wb3J0IHsgQWN0aW9uLCBjb25maWd1cmVTdG9yZSwgRW50aXR5U3RhdGUgfSBmcm9tIFwiQHJlZHV4anMvdG9vbGtpdFwiXG5pbXBvcnQgeyBUaHVua0FjdGlvbiB9IGZyb20gXCJyZWR1eC10aHVua1wiXG5pbXBvcnQgeyByb3V0ZXJNaWRkbGV3YXJlIH0gZnJvbSBcImNvbm5lY3RlZC1yZWFjdC1yb3V0ZXJcIlxuXG5pbXBvcnQgY3JlYXRlUm9vdFJlZHVjZXIgZnJvbSBcIi4vcm9vdFJlZHVjZXJcIlxuaW1wb3J0IHsgU3RhdGVSZXF1ZXN0IH0gZnJvbSBcIi4vdXRpbHNcIlxuXG5pbnRlcmZhY2UgQXJnIHtcbiAgICBpbml0aWFsU3RhdGU/OiB0eXBlb2Ygd2luZG93Ll9fSU5JVElBTF9TVEFURV9fXG4gICAgdXJsPzogc3RyaW5nXG59XG5cbi8vIFVzZSBpbmZlcnJlZCByZXR1cm4gdHlwZSBmb3IgbWFraW5nIGNvcnJlY3RseSBSZWR1eCB0eXBlc1xuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9leHBsaWNpdC1tb2R1bGUtYm91bmRhcnktdHlwZXNcbmNvbnN0IGNyZWF0ZVN0b3JlID0gKHsgaW5pdGlhbFN0YXRlLCB1cmwgfTogQXJnID0ge30pID0+IHtcbiAgICBjb25zdCBoaXN0b3J5ID0gX19TRVJWRVJfX1xuICAgICAgICA/IGNyZWF0ZU1lbW9yeUhpc3RvcnkoeyBpbml0aWFsRW50cmllczogW3VybCB8fCBcIi9cIl0gfSlcbiAgICAgICAgOiBjcmVhdGVCcm93c2VySGlzdG9yeSgpXG4gICAgY29uc3Qgc3RvcmUgPSBjb25maWd1cmVTdG9yZSh7XG4gICAgICAgIHByZWxvYWRlZFN0YXRlOiBpbml0aWFsU3RhdGUsXG4gICAgICAgIHJlZHVjZXI6IGNyZWF0ZVJvb3RSZWR1Y2VyKGhpc3RvcnkpLFxuICAgICAgICBtaWRkbGV3YXJlOiAoZ2V0RGVmYXVsdE1pZGRsZXdhcmUpID0+IFtcbiAgICAgICAgICAgIC8vIEluY2x1ZGVkIGRlZmF1bHQgbWlkZGxld2FyZXM6IGh0dHBzOi8vcmVkdXgtdG9vbGtpdC5qcy5vcmcvYXBpL2dldERlZmF1bHRNaWRkbGV3YXJlI2luY2x1ZGVkLWRlZmF1bHQtbWlkZGxld2FyZVxuICAgICAgICAgICAgLi4uZ2V0RGVmYXVsdE1pZGRsZXdhcmUoKSxcbiAgICAgICAgICAgIHJvdXRlck1pZGRsZXdhcmUoaGlzdG9yeSksXG4gICAgICAgIF0sXG4gICAgICAgIGRldlRvb2xzOiBfX0RFVl9fLFxuICAgIH0pXG5cbiAgICByZXR1cm4geyBzdG9yZSwgaGlzdG9yeSB9XG59XG5cbmNvbnN0IHsgc3RvcmUgfSA9IGNyZWF0ZVN0b3JlKClcblxuZXhwb3J0IHR5cGUgQXBwU3RhdGUgPSBSZXR1cm5UeXBlPHR5cGVvZiBzdG9yZS5nZXRTdGF0ZT5cblxuZXhwb3J0IHR5cGUgQXBwRGlzcGF0Y2ggPSB0eXBlb2Ygc3RvcmUuZGlzcGF0Y2hcblxuZXhwb3J0IHR5cGUgQXBwVGh1bmsgPSBUaHVua0FjdGlvbjx2b2lkLCBBcHBTdGF0ZSwgdW5rbm93biwgQWN0aW9uPHN0cmluZz4+XG5cbmV4cG9ydCB0eXBlIEVudGl0aWVzUmVxdWVzdDxUPiA9IEVudGl0eVN0YXRlPFQ+ICYgU3RhdGVSZXF1ZXN0XG5cbmV4cG9ydCBkZWZhdWx0IGNyZWF0ZVN0b3JlXG4iLCJpbXBvcnQgeyBQYXlsb2FkQWN0aW9uLCBjcmVhdGVTbGljZSwgY3JlYXRlRW50aXR5QWRhcHRlciB9IGZyb20gXCJAcmVkdXhqcy90b29sa2l0XCJcblxuaW1wb3J0IHsgU3RhdGVSZXF1ZXN0LCB0b2FzdEVycm9yLCBlbGVtZW50TGlzdEZldGNoIH0gZnJvbSBcIi4vdXRpbHNcIlxuaW1wb3J0IHsgSmV1SmF2LCBqZXVKYXZMaXN0R2V0IH0gZnJvbSBcIi4uL3NlcnZpY2VzL2pldXhKYXZcIlxuaW1wb3J0IHsgQXBwVGh1bmssIEFwcFN0YXRlIH0gZnJvbSBcIi5cIlxuXG5jb25zdCBqZXVKYXZBZGFwdGVyID0gY3JlYXRlRW50aXR5QWRhcHRlcjxKZXVKYXY+KClcblxuZXhwb3J0IGNvbnN0IGluaXRpYWxTdGF0ZSA9IGpldUphdkFkYXB0ZXIuZ2V0SW5pdGlhbFN0YXRlKHtcbiAgICByZWFkeVN0YXR1czogXCJpZGxlXCIsXG59IGFzIFN0YXRlUmVxdWVzdClcblxuY29uc3QgamV1SmF2TGlzdCA9IGNyZWF0ZVNsaWNlKHtcbiAgICBuYW1lOiBcImpldUphdkxpc3RcIixcbiAgICBpbml0aWFsU3RhdGUsXG4gICAgcmVkdWNlcnM6IHtcbiAgICAgICAgZ2V0UmVxdWVzdGluZzogKHN0YXRlKSA9PiB7XG4gICAgICAgICAgICBzdGF0ZS5yZWFkeVN0YXR1cyA9IFwicmVxdWVzdFwiXG4gICAgICAgIH0sXG4gICAgICAgIGdldFN1Y2Nlc3M6IChzdGF0ZSwgeyBwYXlsb2FkIH06IFBheWxvYWRBY3Rpb248SmV1SmF2W10+KSA9PiB7XG4gICAgICAgICAgICBzdGF0ZS5yZWFkeVN0YXR1cyA9IFwic3VjY2Vzc1wiXG4gICAgICAgICAgICBqZXVKYXZBZGFwdGVyLnNldEFsbChzdGF0ZSwgcGF5bG9hZClcbiAgICAgICAgfSxcbiAgICAgICAgZ2V0RmFpbHVyZTogKHN0YXRlLCB7IHBheWxvYWQgfTogUGF5bG9hZEFjdGlvbjxzdHJpbmc+KSA9PiB7XG4gICAgICAgICAgICBzdGF0ZS5yZWFkeVN0YXR1cyA9IFwiZmFpbHVyZVwiXG4gICAgICAgICAgICBzdGF0ZS5lcnJvciA9IHBheWxvYWRcbiAgICAgICAgfSxcbiAgICB9LFxufSlcblxuZXhwb3J0IGRlZmF1bHQgamV1SmF2TGlzdC5yZWR1Y2VyXG5leHBvcnQgY29uc3QgeyBnZXRSZXF1ZXN0aW5nLCBnZXRTdWNjZXNzLCBnZXRGYWlsdXJlIH0gPSBqZXVKYXZMaXN0LmFjdGlvbnNcblxuZXhwb3J0IGNvbnN0IGZldGNoSmV1SmF2TGlzdCA9IGVsZW1lbnRMaXN0RmV0Y2goXG4gICAgamV1SmF2TGlzdEdldCxcbiAgICBnZXRSZXF1ZXN0aW5nLFxuICAgIGdldFN1Y2Nlc3MsXG4gICAgZ2V0RmFpbHVyZSxcbiAgICAoZXJyb3I6IEVycm9yKSA9PiB0b2FzdEVycm9yKGBFcnJldXIgbG9ycyBkdSBjaGFyZ2VtZW50IGRlcyBqZXV4IEpBVjogJHtlcnJvci5tZXNzYWdlfWApXG4pXG5cbmNvbnN0IHNob3VsZEZldGNoSmV1SmF2TGlzdCA9IChzdGF0ZTogQXBwU3RhdGUpID0+IHN0YXRlLmpldUphdkxpc3QucmVhZHlTdGF0dXMgIT09IFwic3VjY2Vzc1wiXG5cbmV4cG9ydCBjb25zdCBmZXRjaEpldUphdkxpc3RJZk5lZWQgPSAoKTogQXBwVGh1bmsgPT4gKGRpc3BhdGNoLCBnZXRTdGF0ZSkgPT4ge1xuICAgIGlmIChzaG91bGRGZXRjaEpldUphdkxpc3QoZ2V0U3RhdGUoKSkpIHJldHVybiBkaXNwYXRjaChmZXRjaEpldUphdkxpc3QoKSlcblxuICAgIHJldHVybiBudWxsXG59XG4iLCJpbXBvcnQgeyBQYXlsb2FkQWN0aW9uLCBjcmVhdGVTbGljZSB9IGZyb20gXCJAcmVkdXhqcy90b29sa2l0XCJcblxuaW1wb3J0IHsgU3RhdGVSZXF1ZXN0LCB0b2FzdEVycm9yLCBlbGVtZW50RmV0Y2ggfSBmcm9tIFwiLi91dGlsc1wiXG5pbXBvcnQgeyBNZW1icmUsIG1lbWJyZUdldCB9IGZyb20gXCIuLi9zZXJ2aWNlcy9tZW1icmVzXCJcbmltcG9ydCB7IEFwcFRodW5rLCBBcHBTdGF0ZSB9IGZyb20gXCIuXCJcblxudHlwZSBTdGF0ZU1lbWJyZSA9IHsgZW50aXR5PzogTWVtYnJlIH0gJiBTdGF0ZVJlcXVlc3RcblxuZXhwb3J0IGNvbnN0IGluaXRpYWxTdGF0ZTogU3RhdGVNZW1icmUgPSB7XG4gICAgcmVhZHlTdGF0dXM6IFwiaWRsZVwiLFxufVxuXG5jb25zdCBtZW1icmUgPSBjcmVhdGVTbGljZSh7XG4gICAgbmFtZTogXCJtZW1icmVcIixcbiAgICBpbml0aWFsU3RhdGUsXG4gICAgcmVkdWNlcnM6IHtcbiAgICAgICAgZ2V0UmVxdWVzdGluZzogKF8pID0+ICh7XG4gICAgICAgICAgICByZWFkeVN0YXR1czogXCJyZXF1ZXN0XCIsXG4gICAgICAgIH0pLFxuICAgICAgICBnZXRTdWNjZXNzOiAoXywgeyBwYXlsb2FkIH06IFBheWxvYWRBY3Rpb248TWVtYnJlPikgPT4gKHtcbiAgICAgICAgICAgIHJlYWR5U3RhdHVzOiBcInN1Y2Nlc3NcIixcbiAgICAgICAgICAgIGVudGl0eTogcGF5bG9hZCxcbiAgICAgICAgfSksXG4gICAgICAgIGdldEZhaWx1cmU6IChfLCB7IHBheWxvYWQgfTogUGF5bG9hZEFjdGlvbjxzdHJpbmc+KSA9PiAoe1xuICAgICAgICAgICAgcmVhZHlTdGF0dXM6IFwiZmFpbHVyZVwiLFxuICAgICAgICAgICAgZXJyb3I6IHBheWxvYWQsXG4gICAgICAgIH0pLFxuICAgIH0sXG59KVxuXG5leHBvcnQgZGVmYXVsdCBtZW1icmUucmVkdWNlclxuZXhwb3J0IGNvbnN0IHsgZ2V0UmVxdWVzdGluZywgZ2V0U3VjY2VzcywgZ2V0RmFpbHVyZSB9ID0gbWVtYnJlLmFjdGlvbnNcblxuZXhwb3J0IGNvbnN0IGZldGNoTWVtYnJlID0gZWxlbWVudEZldGNoKFxuICAgIG1lbWJyZUdldCxcbiAgICBnZXRSZXF1ZXN0aW5nLFxuICAgIGdldFN1Y2Nlc3MsXG4gICAgZ2V0RmFpbHVyZSxcbiAgICAoZXJyb3I6IEVycm9yKSA9PiB0b2FzdEVycm9yKGBFcnJldXIgbG9ycyBkdSBjaGFyZ2VtZW50IGQndW4gbWVtYnJlOiAke2Vycm9yLm1lc3NhZ2V9YClcbilcblxuY29uc3Qgc2hvdWxkRmV0Y2hNZW1icmUgPSAoc3RhdGU6IEFwcFN0YXRlLCBpZDogbnVtYmVyKSA9PlxuICAgIHN0YXRlLm1lbWJyZS5yZWFkeVN0YXR1cyAhPT0gXCJzdWNjZXNzXCIgfHwgKHN0YXRlLm1lbWJyZS5lbnRpdHkgJiYgc3RhdGUubWVtYnJlLmVudGl0eS5pZCAhPT0gaWQpXG5cbmV4cG9ydCBjb25zdCBmZXRjaE1lbWJyZUlmTmVlZCA9XG4gICAgKGlkOiBudW1iZXIpOiBBcHBUaHVuayA9PlxuICAgIChkaXNwYXRjaCwgZ2V0U3RhdGUpID0+IHtcbiAgICAgICAgaWYgKHNob3VsZEZldGNoTWVtYnJlKGdldFN0YXRlKCksIGlkKSkgcmV0dXJuIGRpc3BhdGNoKGZldGNoTWVtYnJlKGlkKSlcblxuICAgICAgICByZXR1cm4gbnVsbFxuICAgIH1cbiIsImltcG9ydCB7IFBheWxvYWRBY3Rpb24sIGNyZWF0ZVNsaWNlLCBjcmVhdGVFbnRpdHlBZGFwdGVyIH0gZnJvbSBcIkByZWR1eGpzL3Rvb2xraXRcIlxuXG5pbXBvcnQgeyBTdGF0ZVJlcXVlc3QsIHRvYXN0RXJyb3IsIHRvYXN0U3VjY2VzcywgZWxlbWVudEFkZEZldGNoIH0gZnJvbSBcIi4vdXRpbHNcIlxuaW1wb3J0IHsgTWVtYnJlLCBtZW1icmVBZGQgfSBmcm9tIFwiLi4vc2VydmljZXMvbWVtYnJlc1wiXG5cbmNvbnN0IG1lbWJyZUFkYXB0ZXIgPSBjcmVhdGVFbnRpdHlBZGFwdGVyPE1lbWJyZT4oKVxuXG5jb25zdCBtZW1icmVBZGRTbGljZSA9IGNyZWF0ZVNsaWNlKHtcbiAgICBuYW1lOiBcImFkZE1lbWJyZVwiLFxuICAgIGluaXRpYWxTdGF0ZTogbWVtYnJlQWRhcHRlci5nZXRJbml0aWFsU3RhdGUoe1xuICAgICAgICByZWFkeVN0YXR1czogXCJpZGxlXCIsXG4gICAgfSBhcyBTdGF0ZVJlcXVlc3QpLFxuICAgIHJlZHVjZXJzOiB7XG4gICAgICAgIGdldFJlcXVlc3Rpbmc6IChzdGF0ZSkgPT4ge1xuICAgICAgICAgICAgc3RhdGUucmVhZHlTdGF0dXMgPSBcInJlcXVlc3RcIlxuICAgICAgICB9LFxuICAgICAgICBnZXRTdWNjZXNzOiAoc3RhdGUsIHsgcGF5bG9hZCB9OiBQYXlsb2FkQWN0aW9uPE1lbWJyZT4pID0+IHtcbiAgICAgICAgICAgIHN0YXRlLnJlYWR5U3RhdHVzID0gXCJzdWNjZXNzXCJcbiAgICAgICAgICAgIG1lbWJyZUFkYXB0ZXIuYWRkT25lKHN0YXRlLCBwYXlsb2FkKVxuICAgICAgICB9LFxuICAgICAgICBnZXRGYWlsdXJlOiAoc3RhdGUsIHsgcGF5bG9hZCB9OiBQYXlsb2FkQWN0aW9uPHN0cmluZz4pID0+IHtcbiAgICAgICAgICAgIHN0YXRlLnJlYWR5U3RhdHVzID0gXCJmYWlsdXJlXCJcbiAgICAgICAgICAgIHN0YXRlLmVycm9yID0gcGF5bG9hZFxuICAgICAgICB9LFxuICAgIH0sXG59KVxuXG5leHBvcnQgZGVmYXVsdCBtZW1icmVBZGRTbGljZS5yZWR1Y2VyXG5leHBvcnQgY29uc3QgeyBnZXRSZXF1ZXN0aW5nLCBnZXRTdWNjZXNzLCBnZXRGYWlsdXJlIH0gPSBtZW1icmVBZGRTbGljZS5hY3Rpb25zXG5cbmV4cG9ydCBjb25zdCBmZXRjaE1lbWJyZUFkZCA9IGVsZW1lbnRBZGRGZXRjaChcbiAgICBtZW1icmVBZGQsXG4gICAgZ2V0UmVxdWVzdGluZyxcbiAgICBnZXRTdWNjZXNzLFxuICAgIGdldEZhaWx1cmUsXG4gICAgKGVycm9yOiBFcnJvcikgPT4gdG9hc3RFcnJvcihgRXJyZXVyIGxvcnMgZGUgbCdham91dCBkJ3VuZSBtZW1icmU6ICR7ZXJyb3IubWVzc2FnZX1gKSxcbiAgICAoKSA9PiB0b2FzdFN1Y2Nlc3MoXCJNZW1icmUgYWpvdXTDqWUgIVwiKVxuKVxuIiwiaW1wb3J0IHsgUGF5bG9hZEFjdGlvbiwgY3JlYXRlU2xpY2UsIGNyZWF0ZUVudGl0eUFkYXB0ZXIgfSBmcm9tIFwiQHJlZHV4anMvdG9vbGtpdFwiXG5cbmltcG9ydCB7IFN0YXRlUmVxdWVzdCwgdG9hc3RFcnJvciwgZWxlbWVudExpc3RGZXRjaCB9IGZyb20gXCIuL3V0aWxzXCJcbmltcG9ydCB7IE1lbWJyZSwgbWVtYnJlTGlzdEdldCB9IGZyb20gXCIuLi9zZXJ2aWNlcy9tZW1icmVzXCJcbmltcG9ydCB7IEFwcFRodW5rLCBBcHBTdGF0ZSB9IGZyb20gXCIuXCJcblxuY29uc3QgbWVtYnJlQWRhcHRlciA9IGNyZWF0ZUVudGl0eUFkYXB0ZXI8TWVtYnJlPigpXG5cbmV4cG9ydCBjb25zdCBpbml0aWFsU3RhdGUgPSBtZW1icmVBZGFwdGVyLmdldEluaXRpYWxTdGF0ZSh7XG4gICAgcmVhZHlTdGF0dXM6IFwiaWRsZVwiLFxufSBhcyBTdGF0ZVJlcXVlc3QpXG5cbmNvbnN0IG1lbWJyZUxpc3QgPSBjcmVhdGVTbGljZSh7XG4gICAgbmFtZTogXCJtZW1icmVMaXN0XCIsXG4gICAgaW5pdGlhbFN0YXRlLFxuICAgIHJlZHVjZXJzOiB7XG4gICAgICAgIGdldFJlcXVlc3Rpbmc6IChzdGF0ZSkgPT4ge1xuICAgICAgICAgICAgc3RhdGUucmVhZHlTdGF0dXMgPSBcInJlcXVlc3RcIlxuICAgICAgICB9LFxuICAgICAgICBnZXRTdWNjZXNzOiAoc3RhdGUsIHsgcGF5bG9hZCB9OiBQYXlsb2FkQWN0aW9uPE1lbWJyZVtdPikgPT4ge1xuICAgICAgICAgICAgc3RhdGUucmVhZHlTdGF0dXMgPSBcInN1Y2Nlc3NcIlxuICAgICAgICAgICAgbWVtYnJlQWRhcHRlci5zZXRBbGwoc3RhdGUsIHBheWxvYWQpXG4gICAgICAgIH0sXG4gICAgICAgIGdldEZhaWx1cmU6IChzdGF0ZSwgeyBwYXlsb2FkIH06IFBheWxvYWRBY3Rpb248c3RyaW5nPikgPT4ge1xuICAgICAgICAgICAgc3RhdGUucmVhZHlTdGF0dXMgPSBcImZhaWx1cmVcIlxuICAgICAgICAgICAgc3RhdGUuZXJyb3IgPSBwYXlsb2FkXG4gICAgICAgIH0sXG4gICAgfSxcbn0pXG5cbmV4cG9ydCBkZWZhdWx0IG1lbWJyZUxpc3QucmVkdWNlclxuZXhwb3J0IGNvbnN0IHsgZ2V0UmVxdWVzdGluZywgZ2V0U3VjY2VzcywgZ2V0RmFpbHVyZSB9ID0gbWVtYnJlTGlzdC5hY3Rpb25zXG5cbmV4cG9ydCBjb25zdCBmZXRjaE1lbWJyZUxpc3QgPSBlbGVtZW50TGlzdEZldGNoKFxuICAgIG1lbWJyZUxpc3RHZXQsXG4gICAgZ2V0UmVxdWVzdGluZyxcbiAgICBnZXRTdWNjZXNzLFxuICAgIGdldEZhaWx1cmUsXG4gICAgKGVycm9yOiBFcnJvcikgPT4gdG9hc3RFcnJvcihgRXJyZXVyIGxvcnMgZHUgY2hhcmdlbWVudCBkZXMgbWVtYnJlczogJHtlcnJvci5tZXNzYWdlfWApXG4pXG5cbmNvbnN0IHNob3VsZEZldGNoTWVtYnJlTGlzdCA9IChzdGF0ZTogQXBwU3RhdGUpID0+IHN0YXRlLm1lbWJyZUxpc3QucmVhZHlTdGF0dXMgIT09IFwic3VjY2Vzc1wiXG5cbmV4cG9ydCBjb25zdCBmZXRjaE1lbWJyZUxpc3RJZk5lZWQgPSAoKTogQXBwVGh1bmsgPT4gKGRpc3BhdGNoLCBnZXRTdGF0ZSkgPT4ge1xuICAgIGlmIChzaG91bGRGZXRjaE1lbWJyZUxpc3QoZ2V0U3RhdGUoKSkpIHJldHVybiBkaXNwYXRjaChmZXRjaE1lbWJyZUxpc3QoKSlcblxuICAgIHJldHVybiBudWxsXG59XG4iLCJpbXBvcnQgeyBQYXlsb2FkQWN0aW9uLCBjcmVhdGVTbGljZSwgY3JlYXRlRW50aXR5QWRhcHRlciB9IGZyb20gXCJAcmVkdXhqcy90b29sa2l0XCJcblxuaW1wb3J0IHsgU3RhdGVSZXF1ZXN0LCB0b2FzdEVycm9yLCB0b2FzdFN1Y2Nlc3MsIGVsZW1lbnRTZXQgfSBmcm9tIFwiLi91dGlsc1wiXG5pbXBvcnQgeyBNZW1icmUsIG1lbWJyZVNldCB9IGZyb20gXCIuLi9zZXJ2aWNlcy9tZW1icmVzXCJcblxuY29uc3QgbWVtYnJlQWRhcHRlciA9IGNyZWF0ZUVudGl0eUFkYXB0ZXI8TWVtYnJlPigpXG5cbmNvbnN0IG1lbWJyZVNldFNsaWNlID0gY3JlYXRlU2xpY2Uoe1xuICAgIG5hbWU6IFwibWVtYnJlU2V0XCIsXG4gICAgaW5pdGlhbFN0YXRlOiBtZW1icmVBZGFwdGVyLmdldEluaXRpYWxTdGF0ZSh7XG4gICAgICAgIHJlYWR5U3RhdHVzOiBcImlkbGVcIixcbiAgICB9IGFzIFN0YXRlUmVxdWVzdCksXG4gICAgcmVkdWNlcnM6IHtcbiAgICAgICAgZ2V0UmVxdWVzdGluZzogKHN0YXRlKSA9PiB7XG4gICAgICAgICAgICBzdGF0ZS5yZWFkeVN0YXR1cyA9IFwicmVxdWVzdFwiXG4gICAgICAgIH0sXG4gICAgICAgIGdldFN1Y2Nlc3M6IChzdGF0ZSwgeyBwYXlsb2FkIH06IFBheWxvYWRBY3Rpb248TWVtYnJlPikgPT4ge1xuICAgICAgICAgICAgc3RhdGUucmVhZHlTdGF0dXMgPSBcInN1Y2Nlc3NcIlxuICAgICAgICAgICAgbWVtYnJlQWRhcHRlci5zZXRPbmUoc3RhdGUsIHBheWxvYWQpXG4gICAgICAgIH0sXG4gICAgICAgIGdldEZhaWx1cmU6IChzdGF0ZSwgeyBwYXlsb2FkIH06IFBheWxvYWRBY3Rpb248c3RyaW5nPikgPT4ge1xuICAgICAgICAgICAgc3RhdGUucmVhZHlTdGF0dXMgPSBcImZhaWx1cmVcIlxuICAgICAgICAgICAgc3RhdGUuZXJyb3IgPSBwYXlsb2FkXG4gICAgICAgIH0sXG4gICAgfSxcbn0pXG5cbmV4cG9ydCBkZWZhdWx0IG1lbWJyZVNldFNsaWNlLnJlZHVjZXJcbmV4cG9ydCBjb25zdCB7IGdldFJlcXVlc3RpbmcsIGdldFN1Y2Nlc3MsIGdldEZhaWx1cmUgfSA9IG1lbWJyZVNldFNsaWNlLmFjdGlvbnNcblxuZXhwb3J0IGNvbnN0IGZldGNoTWVtYnJlU2V0ID0gZWxlbWVudFNldChcbiAgICBtZW1icmVTZXQsXG4gICAgZ2V0UmVxdWVzdGluZyxcbiAgICBnZXRTdWNjZXNzLFxuICAgIGdldEZhaWx1cmUsXG4gICAgKGVycm9yOiBFcnJvcikgPT4gdG9hc3RFcnJvcihgRXJyZXVyIGxvcnMgZGUgbGEgbW9kaWZpY2F0aW9uIGQndW4gbWVtYnJlOiAke2Vycm9yLm1lc3NhZ2V9YCksXG4gICAgKCkgPT4gdG9hc3RTdWNjZXNzKFwiTWVtYnJlIG1vZGlmacOpICFcIilcbilcbiIsImltcG9ydCB7IEhpc3RvcnkgfSBmcm9tIFwiaGlzdG9yeVwiXG5pbXBvcnQgeyBjb25uZWN0Um91dGVyIH0gZnJvbSBcImNvbm5lY3RlZC1yZWFjdC1yb3V0ZXJcIlxuXG5pbXBvcnQgZW52aWVBZGQgZnJvbSBcIi4vZW52aWVBZGRcIlxuaW1wb3J0IGVudmllTGlzdCBmcm9tIFwiLi9lbnZpZUxpc3RcIlxuaW1wb3J0IGpldUphdkxpc3QgZnJvbSBcIi4vamV1SmF2TGlzdFwiXG5pbXBvcnQgbWVtYnJlIGZyb20gXCIuL21lbWJyZVwiXG5pbXBvcnQgbWVtYnJlQWRkIGZyb20gXCIuL21lbWJyZUFkZFwiXG5pbXBvcnQgbWVtYnJlTGlzdCBmcm9tIFwiLi9tZW1icmVMaXN0XCJcbmltcG9ydCBtZW1icmVTZXQgZnJvbSBcIi4vbWVtYnJlU2V0XCJcblxuLy8gVXNlIGluZmVycmVkIHJldHVybiB0eXBlIGZvciBtYWtpbmcgY29ycmVjdGx5IFJlZHV4IHR5cGVzXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L2V4cGxpY2l0LW1vZHVsZS1ib3VuZGFyeS10eXBlc1xuZXhwb3J0IGRlZmF1bHQgKGhpc3Rvcnk6IEhpc3RvcnkpID0+ICh7XG4gICAgZW52aWVBZGQsXG4gICAgZW52aWVMaXN0LFxuICAgIGpldUphdkxpc3QsXG4gICAgbWVtYnJlLFxuICAgIG1lbWJyZUFkZCxcbiAgICBtZW1icmVMaXN0LFxuICAgIG1lbWJyZVNldCxcbiAgICByb3V0ZXI6IGNvbm5lY3RSb3V0ZXIoaGlzdG9yeSkgYXMgYW55LFxuICAgIC8vIFJlZ2lzdGVyIG1vcmUgcmVkdWNlcnMuLi5cbn0pXG4iLCJpbXBvcnQgeyBBY3Rpb25DcmVhdG9yV2l0aG91dFBheWxvYWQsIEFjdGlvbkNyZWF0b3JXaXRoUGF5bG9hZCB9IGZyb20gXCJAcmVkdXhqcy90b29sa2l0XCJcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSBcInJlYWN0LXRvYXN0aWZ5XCJcblxuaW1wb3J0IHsgQXBwVGh1bmsgfSBmcm9tIFwiLlwiXG5cbmV4cG9ydCBpbnRlcmZhY2UgU3RhdGVSZXF1ZXN0IHtcbiAgICByZWFkeVN0YXR1czogXCJpZGxlXCIgfCBcInJlcXVlc3RcIiB8IFwic3VjY2Vzc1wiIHwgXCJmYWlsdXJlXCJcbiAgICBlcnJvcj86IHN0cmluZ1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdG9hc3RFcnJvcihtZXNzYWdlOiBzdHJpbmcpOiB2b2lkIHtcbiAgICB0b2FzdC5lcnJvcihtZXNzYWdlLCB7XG4gICAgICAgIHBvc2l0aW9uOiBcInRvcC1jZW50ZXJcIixcbiAgICAgICAgYXV0b0Nsb3NlOiA2MDAwLFxuICAgICAgICBoaWRlUHJvZ3Jlc3NCYXI6IHRydWUsXG4gICAgICAgIGNsb3NlT25DbGljazogdHJ1ZSxcbiAgICAgICAgcGF1c2VPbkhvdmVyOiB0cnVlLFxuICAgICAgICBkcmFnZ2FibGU6IHRydWUsXG4gICAgICAgIHByb2dyZXNzOiB1bmRlZmluZWQsXG4gICAgfSlcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHRvYXN0U3VjY2VzcyhtZXNzYWdlOiBzdHJpbmcpOiB2b2lkIHtcbiAgICB0b2FzdC5zdWNjZXNzKG1lc3NhZ2UsIHtcbiAgICAgICAgcG9zaXRpb246IFwidG9wLWNlbnRlclwiLFxuICAgICAgICBhdXRvQ2xvc2U6IDMwMDAsXG4gICAgICAgIGhpZGVQcm9ncmVzc0JhcjogdHJ1ZSxcbiAgICAgICAgY2xvc2VPbkNsaWNrOiB0cnVlLFxuICAgICAgICBwYXVzZU9uSG92ZXI6IHRydWUsXG4gICAgICAgIGRyYWdnYWJsZTogdHJ1ZSxcbiAgICAgICAgcHJvZ3Jlc3M6IHVuZGVmaW5lZCxcbiAgICB9KVxufVxuXG5leHBvcnQgZnVuY3Rpb24gZWxlbWVudEZldGNoPEVsZW1lbnQ+KFxuICAgIGVsZW1lbnRTZXJ2aWNlOiAoaWQ6IG51bWJlcikgPT4gUHJvbWlzZTx7XG4gICAgICAgIGRhdGE/OiBFbGVtZW50IHwgdW5kZWZpbmVkXG4gICAgICAgIGVycm9yPzogRXJyb3IgfCB1bmRlZmluZWRcbiAgICB9PixcbiAgICBnZXRSZXF1ZXN0aW5nOiBBY3Rpb25DcmVhdG9yV2l0aG91dFBheWxvYWQ8c3RyaW5nPixcbiAgICBnZXRTdWNjZXNzOiBBY3Rpb25DcmVhdG9yV2l0aFBheWxvYWQ8RWxlbWVudCwgc3RyaW5nPixcbiAgICBnZXRGYWlsdXJlOiBBY3Rpb25DcmVhdG9yV2l0aFBheWxvYWQ8c3RyaW5nLCBzdHJpbmc+LFxuICAgIGVycm9yTWVzc2FnZTogKGVycm9yOiBFcnJvcikgPT4gdm9pZCA9IChfZXJyb3IpID0+IHtcbiAgICAgICAgLyogTWVhbnQgdG8gYmUgZW1wdHkgKi9cbiAgICB9LFxuICAgIHN1Y2Nlc3NNZXNzYWdlOiAoKSA9PiB2b2lkID0gKCkgPT4ge1xuICAgICAgICAvKiBNZWFudCB0byBiZSBlbXB0eSAqL1xuICAgIH1cbik6IChpZDogbnVtYmVyKSA9PiBBcHBUaHVuayB7XG4gICAgcmV0dXJuIChpZDogbnVtYmVyKTogQXBwVGh1bmsgPT5cbiAgICAgICAgYXN5bmMgKGRpc3BhdGNoKSA9PiB7XG4gICAgICAgICAgICBkaXNwYXRjaChnZXRSZXF1ZXN0aW5nKCkpXG5cbiAgICAgICAgICAgIGNvbnN0IHsgZXJyb3IsIGRhdGEgfSA9IGF3YWl0IGVsZW1lbnRTZXJ2aWNlKGlkKVxuXG4gICAgICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICBkaXNwYXRjaChnZXRGYWlsdXJlKGVycm9yLm1lc3NhZ2UpKVxuICAgICAgICAgICAgICAgIGVycm9yTWVzc2FnZShlcnJvcilcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgZGlzcGF0Y2goZ2V0U3VjY2VzcyhkYXRhIGFzIEVsZW1lbnQpKVxuICAgICAgICAgICAgICAgIHN1Y2Nlc3NNZXNzYWdlKClcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gZWxlbWVudEFkZEZldGNoPEVsZW1lbnQ+KFxuICAgIGVsZW1lbnRBZGRTZXJ2aWNlOiAobWVtYnJlV2l0aG91dElkOiBPbWl0PEVsZW1lbnQsIFwiaWRcIj4pID0+IFByb21pc2U8e1xuICAgICAgICBkYXRhPzogRWxlbWVudCB8IHVuZGVmaW5lZFxuICAgICAgICBlcnJvcj86IEVycm9yIHwgdW5kZWZpbmVkXG4gICAgfT4sXG4gICAgZ2V0UmVxdWVzdGluZzogQWN0aW9uQ3JlYXRvcldpdGhvdXRQYXlsb2FkPHN0cmluZz4sXG4gICAgZ2V0U3VjY2VzczogQWN0aW9uQ3JlYXRvcldpdGhQYXlsb2FkPEVsZW1lbnQsIHN0cmluZz4sXG4gICAgZ2V0RmFpbHVyZTogQWN0aW9uQ3JlYXRvcldpdGhQYXlsb2FkPHN0cmluZywgc3RyaW5nPixcbiAgICBlcnJvck1lc3NhZ2U6IChlcnJvcjogRXJyb3IpID0+IHZvaWQgPSAoX2Vycm9yKSA9PiB7XG4gICAgICAgIC8qIE1lYW50IHRvIGJlIGVtcHR5ICovXG4gICAgfSxcbiAgICBzdWNjZXNzTWVzc2FnZTogKCkgPT4gdm9pZCA9ICgpID0+IHtcbiAgICAgICAgLyogTWVhbnQgdG8gYmUgZW1wdHkgKi9cbiAgICB9XG4pOiAobWVtYnJlV2l0aG91dElkOiBPbWl0PEVsZW1lbnQsIFwiaWRcIj4pID0+IEFwcFRodW5rIHtcbiAgICByZXR1cm4gKG1lbWJyZVdpdGhvdXRJZDogT21pdDxFbGVtZW50LCBcImlkXCI+KTogQXBwVGh1bmsgPT5cbiAgICAgICAgYXN5bmMgKGRpc3BhdGNoKSA9PiB7XG4gICAgICAgICAgICBkaXNwYXRjaChnZXRSZXF1ZXN0aW5nKCkpXG5cbiAgICAgICAgICAgIGNvbnN0IHsgZXJyb3IsIGRhdGEgfSA9IGF3YWl0IGVsZW1lbnRBZGRTZXJ2aWNlKG1lbWJyZVdpdGhvdXRJZClcblxuICAgICAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgZGlzcGF0Y2goZ2V0RmFpbHVyZShlcnJvci5tZXNzYWdlKSlcbiAgICAgICAgICAgICAgICBlcnJvck1lc3NhZ2UoZXJyb3IpXG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIGRpc3BhdGNoKGdldFN1Y2Nlc3MoZGF0YSBhcyBFbGVtZW50KSlcbiAgICAgICAgICAgICAgICBzdWNjZXNzTWVzc2FnZSgpXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGVsZW1lbnRMaXN0RmV0Y2g8RWxlbWVudD4oXG4gICAgZWxlbWVudExpc3RTZXJ2aWNlOiAoKSA9PiBQcm9taXNlPHtcbiAgICAgICAgZGF0YT86IEVsZW1lbnRbXSB8IHVuZGVmaW5lZFxuICAgICAgICBlcnJvcj86IEVycm9yIHwgdW5kZWZpbmVkXG4gICAgfT4sXG4gICAgZ2V0UmVxdWVzdGluZzogQWN0aW9uQ3JlYXRvcldpdGhvdXRQYXlsb2FkPHN0cmluZz4sXG4gICAgZ2V0U3VjY2VzczogQWN0aW9uQ3JlYXRvcldpdGhQYXlsb2FkPEVsZW1lbnRbXSwgc3RyaW5nPixcbiAgICBnZXRGYWlsdXJlOiBBY3Rpb25DcmVhdG9yV2l0aFBheWxvYWQ8c3RyaW5nLCBzdHJpbmc+LFxuICAgIGVycm9yTWVzc2FnZTogKGVycm9yOiBFcnJvcikgPT4gdm9pZCA9IChfZXJyb3IpID0+IHtcbiAgICAgICAgLyogTWVhbnQgdG8gYmUgZW1wdHkgKi9cbiAgICB9LFxuICAgIHN1Y2Nlc3NNZXNzYWdlOiAoKSA9PiB2b2lkID0gKCkgPT4ge1xuICAgICAgICAvKiBNZWFudCB0byBiZSBlbXB0eSAqL1xuICAgIH1cbik6ICgpID0+IEFwcFRodW5rIHtcbiAgICByZXR1cm4gKCk6IEFwcFRodW5rID0+IGFzeW5jIChkaXNwYXRjaCkgPT4ge1xuICAgICAgICBkaXNwYXRjaChnZXRSZXF1ZXN0aW5nKCkpXG5cbiAgICAgICAgY29uc3QgeyBlcnJvciwgZGF0YSB9ID0gYXdhaXQgZWxlbWVudExpc3RTZXJ2aWNlKClcblxuICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAgIGRpc3BhdGNoKGdldEZhaWx1cmUoZXJyb3IubWVzc2FnZSkpXG4gICAgICAgICAgICBlcnJvck1lc3NhZ2UoZXJyb3IpXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBkaXNwYXRjaChnZXRTdWNjZXNzKGRhdGEgYXMgRWxlbWVudFtdKSlcbiAgICAgICAgICAgIHN1Y2Nlc3NNZXNzYWdlKClcbiAgICAgICAgfVxuICAgIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGVsZW1lbnRTZXQ8RWxlbWVudD4oXG4gICAgZWxlbWVudFNldFNlcnZpY2U6IChtZW1icmU6IEVsZW1lbnQpID0+IFByb21pc2U8e1xuICAgICAgICBkYXRhPzogRWxlbWVudCB8IHVuZGVmaW5lZFxuICAgICAgICBlcnJvcj86IEVycm9yIHwgdW5kZWZpbmVkXG4gICAgfT4sXG4gICAgZ2V0UmVxdWVzdGluZzogQWN0aW9uQ3JlYXRvcldpdGhvdXRQYXlsb2FkPHN0cmluZz4sXG4gICAgZ2V0U3VjY2VzczogQWN0aW9uQ3JlYXRvcldpdGhQYXlsb2FkPEVsZW1lbnQsIHN0cmluZz4sXG4gICAgZ2V0RmFpbHVyZTogQWN0aW9uQ3JlYXRvcldpdGhQYXlsb2FkPHN0cmluZywgc3RyaW5nPixcbiAgICBlcnJvck1lc3NhZ2U6IChlcnJvcjogRXJyb3IpID0+IHZvaWQgPSAoX2Vycm9yKSA9PiB7XG4gICAgICAgIC8qIE1lYW50IHRvIGJlIGVtcHR5ICovXG4gICAgfSxcbiAgICBzdWNjZXNzTWVzc2FnZTogKCkgPT4gdm9pZCA9ICgpID0+IHtcbiAgICAgICAgLyogTWVhbnQgdG8gYmUgZW1wdHkgKi9cbiAgICB9XG4pOiAoZWxlbWVudDogRWxlbWVudCkgPT4gQXBwVGh1bmsge1xuICAgIHJldHVybiAoZWxlbWVudDogRWxlbWVudCk6IEFwcFRodW5rID0+XG4gICAgICAgIGFzeW5jIChkaXNwYXRjaCkgPT4ge1xuICAgICAgICAgICAgZGlzcGF0Y2goZ2V0UmVxdWVzdGluZygpKVxuXG4gICAgICAgICAgICBjb25zdCB7IGVycm9yLCBkYXRhIH0gPSBhd2FpdCBlbGVtZW50U2V0U2VydmljZShlbGVtZW50KVxuXG4gICAgICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICBkaXNwYXRjaChnZXRGYWlsdXJlKGVycm9yLm1lc3NhZ2UpKVxuICAgICAgICAgICAgICAgIGVycm9yTWVzc2FnZShlcnJvcilcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgZGlzcGF0Y2goZ2V0U3VjY2VzcyhkYXRhIGFzIEVsZW1lbnQpKVxuICAgICAgICAgICAgICAgIHN1Y2Nlc3NNZXNzYWdlKClcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxufVxuIiwiZXhwb3J0IGZ1bmN0aW9uIGNhbm9uaWNhbEVtYWlsKGVtYWlsOiBzdHJpbmcpOiBzdHJpbmcge1xuICAgIGVtYWlsID0gZW1haWwucmVwbGFjZSgvXlxccyt8XFxzKyQvZywgXCJcIilcbiAgICBpZiAoL0BnbWFpbC5jb20kLy50ZXN0KGVtYWlsKSkge1xuICAgICAgICBsZXQgZG9tYWluID0gZW1haWwucmVwbGFjZSgvXi4qQC8sIFwiXCIpXG4gICAgICAgIGRvbWFpbiA9IGRvbWFpbi5yZXBsYWNlKC9eZ29vZ2xlbWFpbCUuY29tJC8sIFwiZ21haWwuY29tXCIpXG4gICAgICAgIGVtYWlsID0gZW1haWxcbiAgICAgICAgICAgIC5yZXBsYWNlKC9cXC4vZywgXCJcIilcbiAgICAgICAgICAgIC5yZXBsYWNlKC9eW15AXSsvLCAobWF0Y2gpID0+IG1hdGNoLnRvTG93ZXJDYXNlKCkpXG4gICAgICAgICAgICAucmVwbGFjZSgvQC4qJC8sIGBAJHtkb21haW59YClcbiAgICB9XG4gICAgcmV0dXJuIGVtYWlsLnRvTG93ZXJDYXNlKClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHZhbGlkRW1haWwoZW1haWw6IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgIHJldHVybiAvXig/PS57MSwyNTR9JCkoPz0uezEsNjR9QClbLSEjJCUmJyorLzAtOT0/QS1aXl9gYS16e3x9fl0rKFxcLlstISMkJSYnKisvMC05PT9BLVpeX2BhLXp7fH1+XSspKkBbQS1aYS16MC05XShbQS1aYS16MC05LV17MCw2MX1bQS1aYS16MC05XSk/KFxcLltBLVphLXowLTldKFtBLVphLXowLTktXXswLDYxfVtBLVphLXowLTldKT8pKiQvLnRlc3QoXG4gICAgICAgIGVtYWlsXG4gICAgKVxufVxuIiwiaW1wb3J0IHBhdGggZnJvbSBcInBhdGhcIlxuaW1wb3J0IHdlYnBhY2ssIHsgQ29uZmlndXJhdGlvbiwgV2VicGFja1BsdWdpbkluc3RhbmNlLCBSdWxlU2V0VXNlSXRlbSB9IGZyb20gXCJ3ZWJwYWNrXCJcbmltcG9ydCB7IFdlYnBhY2tNYW5pZmVzdFBsdWdpbiB9IGZyb20gXCJ3ZWJwYWNrLW1hbmlmZXN0LXBsdWdpblwiXG5pbXBvcnQgVGVyc2VyUGx1Z2luIGZyb20gXCJ0ZXJzZXItd2VicGFjay1wbHVnaW5cIlxuaW1wb3J0IE1pbmlDc3NFeHRyYWN0UGx1Z2luIGZyb20gXCJtaW5pLWNzcy1leHRyYWN0LXBsdWdpblwiXG5pbXBvcnQgRm9ya1RzQ2hlY2tlcldlYnBhY2tQbHVnaW4gZnJvbSBcImZvcmstdHMtY2hlY2tlci13ZWJwYWNrLXBsdWdpblwiXG5pbXBvcnQgTG9hZGFibGVQbHVnaW4gZnJvbSBcIkBsb2FkYWJsZS93ZWJwYWNrLXBsdWdpblwiXG5pbXBvcnQgeyBCdW5kbGVBbmFseXplclBsdWdpbiB9IGZyb20gXCJ3ZWJwYWNrLWJ1bmRsZS1hbmFseXplclwiXG5cbmV4cG9ydCBjb25zdCBpc0RldiA9IHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcImRldmVsb3BtZW50XCJcbmNvbnN0IGlzTG9jYWwgPSBwcm9jZXNzLmVudi5MT0NBTCA9PT0gXCJ0cnVlXCJcbmNvbnN0IGdldFN0eWxlTG9hZGVycyA9IChpc1dlYjogYm9vbGVhbiwgaXNTYXNzPzogYm9vbGVhbikgPT4ge1xuICAgIGxldCBsb2FkZXJzOiBSdWxlU2V0VXNlSXRlbVtdID0gW1xuICAgICAgICB7XG4gICAgICAgICAgICBsb2FkZXI6IFwiY3NzLWxvYWRlclwiLFxuICAgICAgICAgICAgb3B0aW9uczoge1xuICAgICAgICAgICAgICAgIGltcG9ydExvYWRlcnM6IGlzU2FzcyA/IDIgOiAxLFxuICAgICAgICAgICAgICAgIG1vZHVsZXM6IHtcbiAgICAgICAgICAgICAgICAgICAgYXV0bzogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgbG9jYWxJZGVudE5hbWU6IFwiW3BhdGhdW25hbWVdX19bbG9jYWxdXCIsIC8vIERvbid0IHVzZSBoYXNoOmJhc2U2NCwgYSBidWcgbWFrZXMgaXQgZ2VuZXJhdGUgZGlmZmVyZW50IGhhc2hlcyBpbiB0aGUgLmpzIGFuZCB0aGUgLmNzcyBmaWxlc1xuICAgICAgICAgICAgICAgICAgICBleHBvcnRPbmx5TG9jYWxzOiAhaXNXZWIsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIHsgbG9hZGVyOiBcInBvc3Rjc3MtbG9hZGVyXCIgfSxcbiAgICBdXG5cbiAgICBpZiAoaXNXZWIpIGxvYWRlcnMgPSBbTWluaUNzc0V4dHJhY3RQbHVnaW4ubG9hZGVyLCAuLi5sb2FkZXJzXVxuXG4gICAgaWYgKGlzU2FzcykgbG9hZGVycyA9IFsuLi5sb2FkZXJzLCB7IGxvYWRlcjogXCJzYXNzLWxvYWRlclwiIH1dXG5cbiAgICByZXR1cm4gbG9hZGVyc1xufVxuXG5jb25zdCBnZXRQbHVnaW5zID0gKGlzV2ViOiBib29sZWFuKSA9PiB7XG4gICAgbGV0IHBsdWdpbnMgPSBbXG4gICAgICAgIG5ldyB3ZWJwYWNrLlByb2dyZXNzUGx1Z2luKCksXG4gICAgICAgIG5ldyBXZWJwYWNrTWFuaWZlc3RQbHVnaW4oe1xuICAgICAgICAgICAgZmlsZU5hbWU6IHBhdGgucmVzb2x2ZShwcm9jZXNzLmN3ZCgpLCBcInB1YmxpYy93ZWJwYWNrLWFzc2V0cy5qc29uXCIpLFxuICAgICAgICAgICAgZmlsdGVyOiAoZmlsZSkgPT4gZmlsZS5pc0luaXRpYWwsXG4gICAgICAgIH0pLFxuICAgICAgICBuZXcgTG9hZGFibGVQbHVnaW4oe1xuICAgICAgICAgICAgd3JpdGVUb0Rpc2s6IHRydWUsXG4gICAgICAgICAgICBmaWxlbmFtZTogXCIuLi9sb2FkYWJsZS1zdGF0cy5qc29uXCIsXG4gICAgICAgIH0pLFxuICAgICAgICAvLyBTZXR0aW5nIGdsb2JhbCB2YXJpYWJsZXNcbiAgICAgICAgbmV3IHdlYnBhY2suRGVmaW5lUGx1Z2luKHtcbiAgICAgICAgICAgIF9fQ0xJRU5UX186IGlzV2ViLFxuICAgICAgICAgICAgX19TRVJWRVJfXzogIWlzV2ViLFxuICAgICAgICAgICAgX19ERVZfXzogaXNEZXYsXG4gICAgICAgICAgICBfX0xPQ0FMX186IGlzTG9jYWwsXG4gICAgICAgIH0pLFxuICAgIF1cblxuICAgIGlmIChpc0RldilcbiAgICAgICAgcGx1Z2lucyA9IFtcbiAgICAgICAgICAgIC4uLnBsdWdpbnMsXG4gICAgICAgICAgICAvLyBSdW5zIFR5cGVTY3JpcHQgdHlwZSBjaGVja2VyIG9uIGEgc2VwYXJhdGUgcHJvY2Vzc1xuICAgICAgICAgICAgbmV3IEZvcmtUc0NoZWNrZXJXZWJwYWNrUGx1Z2luKHtcbiAgICAgICAgICAgICAgICAvLyAoUmVxdWlyZWQpIFNhbWUgYXMgZXNsaW50IGNvbW1hbmRcbiAgICAgICAgICAgICAgICBlc2xpbnQ6IHsgZmlsZXM6IFwiLi9zcmMvKiovKi57anMsanN4LHRzLHRzeH1cIiB9LFxuICAgICAgICAgICAgfSksXG4gICAgICAgIF1cblxuICAgIGlmICghaXNEZXYpXG4gICAgICAgIHBsdWdpbnMgPSBbXG4gICAgICAgICAgICAuLi5wbHVnaW5zLFxuICAgICAgICAgICAgLy8gVmlzdWFsaXplIHNpemUgb2Ygd2VicGFjayBvdXRwdXQgZmlsZXMsIHNlZTogaHR0cHM6Ly9naXRodWIuY29tL3dlYnBhY2stY29udHJpYi93ZWJwYWNrLWJ1bmRsZS1hbmFseXplclxuICAgICAgICAgICAgbmV3IEJ1bmRsZUFuYWx5emVyUGx1Z2luKHtcbiAgICAgICAgICAgICAgICBhbmFseXplck1vZGU6IHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcImFuYWx5emVcIiA/IFwic2VydmVyXCIgOiBcImRpc2FibGVkXCIsXG4gICAgICAgICAgICB9KSxcbiAgICAgICAgXVxuXG4gICAgcmV0dXJuIHBsdWdpbnNcbn1cblxuY29uc3QgY29uZmlnID0gKGlzV2ViID0gZmFsc2UpOiBDb25maWd1cmF0aW9uID0+ICh7XG4gICAgbW9kZTogaXNEZXYgPyBcImRldmVsb3BtZW50XCIgOiBcInByb2R1Y3Rpb25cIixcbiAgICBzdGF0czogXCJtaW5pbWFsXCIsXG4gICAgY29udGV4dDogcGF0aC5yZXNvbHZlKHByb2Nlc3MuY3dkKCkpLFxuICAgIG91dHB1dDogeyBjbGVhbjogdHJ1ZSB9LFxuICAgIG9wdGltaXphdGlvbjoge1xuICAgICAgICBtaW5pbWl6ZXI6IFtcbiAgICAgICAgICAgIG5ldyBUZXJzZXJQbHVnaW4oe1xuICAgICAgICAgICAgICAgIC8vIFNlZSBtb3JlIG9wdGlvbnM6IGh0dHBzOi8vZ2l0aHViLmNvbS93ZWJwYWNrLWNvbnRyaWIvdGVyc2VyLXdlYnBhY2stcGx1Z2luI3RlcnNlcm9wdGlvbnNcbiAgICAgICAgICAgICAgICB0ZXJzZXJPcHRpb25zOiB7IGNvbXByZXNzOiB7IGRyb3BfY29uc29sZTogdHJ1ZSB9IH0sXG4gICAgICAgICAgICB9KSxcbiAgICAgICAgXSxcbiAgICB9LFxuICAgIHBsdWdpbnM6IGdldFBsdWdpbnMoaXNXZWIpIGFzIFdlYnBhY2tQbHVnaW5JbnN0YW5jZVtdLFxuICAgIG1vZHVsZToge1xuICAgICAgICBydWxlczogW1xuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHRlc3Q6IC9cXC4odHxqKXN4PyQvLFxuICAgICAgICAgICAgICAgIGV4Y2x1ZGU6IC9ub2RlX21vZHVsZXMvLFxuICAgICAgICAgICAgICAgIGxvYWRlcjogXCJiYWJlbC1sb2FkZXJcIixcbiAgICAgICAgICAgICAgICBvcHRpb25zOiB7XG4gICAgICAgICAgICAgICAgICAgIGNhbGxlcjogeyB0YXJnZXQ6IGlzV2ViID8gXCJ3ZWJcIiA6IFwibm9kZVwiIH0sXG4gICAgICAgICAgICAgICAgICAgIGNhY2hlRGlyZWN0b3J5OiBpc0RldixcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICB0ZXN0OiAvXFwuY3NzJC8sXG4gICAgICAgICAgICAgICAgdXNlOiBnZXRTdHlsZUxvYWRlcnMoaXNXZWIpLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICB0ZXN0OiAvXFwuKHNjc3N8c2FzcykkLyxcbiAgICAgICAgICAgICAgICB1c2U6IGdldFN0eWxlTG9hZGVycyhpc1dlYiwgdHJ1ZSksXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHRlc3Q6IC9cXC4od29mZjI/fGVvdHx0dGZ8b3RmKSQvaSxcbiAgICAgICAgICAgICAgICB0eXBlOiBcImFzc2V0XCIsXG4gICAgICAgICAgICAgICAgZ2VuZXJhdG9yOiB7IGVtaXQ6IGlzV2ViIH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHRlc3Q6IC9cXC4ocG5nfHN2Z3xqcGU/Z3xnaWYpJC9pLFxuICAgICAgICAgICAgICAgIHR5cGU6IFwiYXNzZXRcIixcbiAgICAgICAgICAgICAgICBnZW5lcmF0b3I6IHsgZW1pdDogaXNXZWIgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgfSxcbiAgICByZXNvbHZlOiB7XG4gICAgICAgIG1vZHVsZXM6IFtcInNyY1wiLCBcIm5vZGVfbW9kdWxlc1wiXSxcbiAgICAgICAgZXh0ZW5zaW9uczogW1wiLnRzXCIsIFwiLnRzeFwiLCBcIi5qc1wiLCBcIi5qc3hcIiwgXCIuanNvblwiXSxcbiAgICB9LFxufSlcblxuZXhwb3J0IGRlZmF1bHQgY29uZmlnXG4iLCJpbXBvcnQgcGF0aCBmcm9tIFwicGF0aFwiXG5pbXBvcnQgd2VicGFjaywgeyBDb25maWd1cmF0aW9uIH0gZnJvbSBcIndlYnBhY2tcIlxuaW1wb3J0IFJlYWN0UmVmcmVzaFdlYnBhY2tQbHVnaW4gZnJvbSBcIkBwbW1td2gvcmVhY3QtcmVmcmVzaC13ZWJwYWNrLXBsdWdpblwiXG5pbXBvcnQgTWluaUNzc0V4dHJhY3RQbHVnaW4gZnJvbSBcIm1pbmktY3NzLWV4dHJhY3QtcGx1Z2luXCJcbmltcG9ydCBDc3NNaW5pbWl6ZXJQbHVnaW4gZnJvbSBcImNzcy1taW5pbWl6ZXItd2VicGFjay1wbHVnaW5cIlxuaW1wb3J0IENvbXByZXNzaW9uUGx1Z2luIGZyb20gXCJjb21wcmVzc2lvbi13ZWJwYWNrLXBsdWdpblwiXG5pbXBvcnQgSW1hZ2VNaW5pbWl6ZXJQbHVnaW4gZnJvbSBcImltYWdlLW1pbmltaXplci13ZWJwYWNrLXBsdWdpblwiXG5pbXBvcnQgbWVyZ2UgZnJvbSBcIndlYnBhY2stbWVyZ2VcIlxuXG5pbXBvcnQgYmFzZUNvbmZpZywgeyBpc0RldiB9IGZyb20gXCIuL2Jhc2UuY29uZmlnXCJcblxuY29uc3QgZ2V0UGx1Z2lucyA9ICgpID0+IHtcbiAgICBsZXQgcGx1Z2lucyA9IFtcbiAgICAgICAgbmV3IE1pbmlDc3NFeHRyYWN0UGx1Z2luKHtcbiAgICAgICAgICAgIC8vIERvbid0IHVzZSBoYXNoIGluIGRldmVsb3BtZW50LCB3ZSBuZWVkIHRoZSBwZXJzaXN0ZW50IGZvciBcInJlbmRlckh0bWwudHNcIlxuICAgICAgICAgICAgZmlsZW5hbWU6IGlzRGV2ID8gXCJbbmFtZV0uY3NzXCIgOiBcIltuYW1lXS5bY29udGVudGhhc2hdLmNzc1wiLFxuICAgICAgICAgICAgY2h1bmtGaWxlbmFtZTogaXNEZXYgPyBcIltpZF0uY3NzXCIgOiBcIltpZF0uW2NvbnRlbnRoYXNoXS5jc3NcIixcbiAgICAgICAgfSksXG4gICAgXVxuXG4gICAgaWYgKGlzRGV2KVxuICAgICAgICBwbHVnaW5zID0gW1xuICAgICAgICAgICAgLi4ucGx1Z2lucyxcbiAgICAgICAgICAgIG5ldyB3ZWJwYWNrLkhvdE1vZHVsZVJlcGxhY2VtZW50UGx1Z2luKCksXG4gICAgICAgICAgICBuZXcgUmVhY3RSZWZyZXNoV2VicGFja1BsdWdpbih7IG92ZXJsYXk6IHsgc29ja0ludGVncmF0aW9uOiBcIndobVwiIH0gfSksXG4gICAgICAgICAgICBuZXcgd2VicGFjay5EZWZpbmVQbHVnaW4oe1xuICAgICAgICAgICAgICAgIHByb2Nlc3M6IFwicHJvY2Vzcy9icm93c2VyXCIsXG4gICAgICAgICAgICB9KSxcbiAgICAgICAgXVxuXG4gICAgaWYgKCFpc0RldilcbiAgICAgICAgcGx1Z2lucyA9IFtcbiAgICAgICAgICAgIC4uLnBsdWdpbnMsXG4gICAgICAgICAgICAvLyBQcmVwYXJlIGNvbXByZXNzZWQgdmVyc2lvbnMgb2YgYXNzZXRzIHRvIHNlcnZlIHRoZW0gd2l0aCBDb250ZW50LUVuY29kaW5nXG4gICAgICAgICAgICBuZXcgQ29tcHJlc3Npb25QbHVnaW4oKSxcbiAgICAgICAgICAgIG5ldyBJbWFnZU1pbmltaXplclBsdWdpbih7XG4gICAgICAgICAgICAgICAgLy8gTG9zc2xlc3Mgb3B0aW1pemF0aW9uIHdpdGggZGVmYXVsdCBvcHRpb24sIGZlZWwgZnJlZSB0byBleHBlcmltZW50IHdpdGggb3B0aW9ucyBmb3IgYmV0dGVyIHJlc3VsdCBmb3IgeW91XG4gICAgICAgICAgICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS93ZWJwYWNrLWNvbnRyaWIvaW1hZ2UtbWluaW1pemVyLXdlYnBhY2stcGx1Z2luI2dldHRpbmctc3RhcnRlZFxuICAgICAgICAgICAgICAgIG1pbmltaXplck9wdGlvbnM6IHtcbiAgICAgICAgICAgICAgICAgICAgcGx1Z2luczogW1tcImdpZnNpY2xlXCJdLCBbXCJqcGVndHJhblwiXSwgW1wib3B0aXBuZ1wiXSwgW1wic3Znb1wiXV0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0pLFxuICAgICAgICBdXG5cbiAgICByZXR1cm4gcGx1Z2luc1xufVxuXG5jb25zdCBjb25maWc6IENvbmZpZ3VyYXRpb24gPSB7XG4gICAgZGV2dG9vbDogaXNEZXYgPyBcImlubGluZS1zb3VyY2UtbWFwXCIgOiBcImhpZGRlbi1zb3VyY2UtbWFwXCIsXG4gICAgZW50cnk6IGlzRGV2ID8gW1wid2VicGFjay1ob3QtbWlkZGxld2FyZS9jbGllbnQ/cmVsb2FkPXRydWVcIiwgXCIuL3NyYy9jbGllbnRcIl0gOiBcIi4vc3JjL2NsaWVudFwiLFxuICAgIG91dHB1dDoge1xuICAgICAgICBmaWxlbmFtZTogaXNEZXYgPyBcIltuYW1lXS5qc1wiIDogXCJbbmFtZV0uW2NvbnRlbnRoYXNoXS5qc1wiLFxuICAgICAgICBjaHVua0ZpbGVuYW1lOiBpc0RldiA/IFwiW2lkXS5qc1wiIDogXCJbaWRdLltjb250ZW50aGFzaF0uanNcIixcbiAgICAgICAgcGF0aDogcGF0aC5yZXNvbHZlKHByb2Nlc3MuY3dkKCksIFwicHVibGljL2Fzc2V0c1wiKSxcbiAgICAgICAgcHVibGljUGF0aDogXCIvYXNzZXRzL1wiLFxuICAgIH0sXG4gICAgb3B0aW1pemF0aW9uOiB7IG1pbmltaXplcjogW25ldyBDc3NNaW5pbWl6ZXJQbHVnaW4oKV0gfSxcbiAgICBwbHVnaW5zOiBnZXRQbHVnaW5zKCksXG4gICAgcGVyZm9ybWFuY2U6IHtcbiAgICAgICAgbWF4QXNzZXRTaXplOiA1MTIwMDAsXG4gICAgICAgIG1heEVudHJ5cG9pbnRTaXplOiA1MTIwMDAsXG4gICAgfSxcbn1cblxuZXhwb3J0IGRlZmF1bHQgbWVyZ2UoYmFzZUNvbmZpZyh0cnVlKSwgY29uZmlnKVxuIiwiLy8gSW1wb3J0c1xuaW1wb3J0IF9fX0NTU19MT0FERVJfQVBJX1NPVVJDRU1BUF9JTVBPUlRfX18gZnJvbSBcIi4uL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL2Nzc1dpdGhNYXBwaW5nVG9TdHJpbmcuanNcIjtcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18gZnJvbSBcIi4uL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL2FwaS5qc1wiO1xudmFyIF9fX0NTU19MT0FERVJfRVhQT1JUX19fID0gX19fQ1NTX0xPQURFUl9BUElfSU1QT1JUX19fKF9fX0NTU19MT0FERVJfQVBJX1NPVVJDRU1BUF9JTVBPUlRfX18pO1xuLy8gTW9kdWxlXG5fX19DU1NfTE9BREVSX0VYUE9SVF9fXy5wdXNoKFttb2R1bGUuaWQsIFwiLyohIG5vcm1hbGl6ZS5jc3MgdjguMC4xIHwgTUlUIExpY2Vuc2UgfCBnaXRodWIuY29tL25lY29sYXMvbm9ybWFsaXplLmNzcyAqL1xcblxcbi8qIERvY3VtZW50XFxuICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi9cXG5cXG4vKipcXG4gKiAxLiBDb3JyZWN0IHRoZSBsaW5lIGhlaWdodCBpbiBhbGwgYnJvd3NlcnMuXFxuICogMi4gUHJldmVudCBhZGp1c3RtZW50cyBvZiBmb250IHNpemUgYWZ0ZXIgb3JpZW50YXRpb24gY2hhbmdlcyBpbiBpT1MuXFxuICovXFxuXFxuaHRtbCB7XFxuICBsaW5lLWhlaWdodDogMS4xNTsgLyogMSAqL1xcbiAgLXdlYmtpdC10ZXh0LXNpemUtYWRqdXN0OiAxMDAlOyAvKiAyICovXFxufVxcblxcbi8qIFNlY3Rpb25zXFxuICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi9cXG5cXG4vKipcXG4gKiBSZW1vdmUgdGhlIG1hcmdpbiBpbiBhbGwgYnJvd3NlcnMuXFxuICovXFxuXFxuYm9keSB7XFxuICBtYXJnaW46IDA7XFxufVxcblxcbi8qKlxcbiAqIFJlbmRlciB0aGUgYG1haW5gIGVsZW1lbnQgY29uc2lzdGVudGx5IGluIElFLlxcbiAqL1xcblxcbm1haW4ge1xcbiAgZGlzcGxheTogYmxvY2s7XFxufVxcblxcbi8qKlxcbiAqIENvcnJlY3QgdGhlIGZvbnQgc2l6ZSBhbmQgbWFyZ2luIG9uIGBoMWAgZWxlbWVudHMgd2l0aGluIGBzZWN0aW9uYCBhbmRcXG4gKiBgYXJ0aWNsZWAgY29udGV4dHMgaW4gQ2hyb21lLCBGaXJlZm94LCBhbmQgU2FmYXJpLlxcbiAqL1xcblxcbmgxIHtcXG4gIGZvbnQtc2l6ZTogMmVtO1xcbiAgbWFyZ2luOiAwLjY3ZW0gMDtcXG59XFxuXFxuLyogR3JvdXBpbmcgY29udGVudFxcbiAgID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovXFxuXFxuLyoqXFxuICogMS4gQWRkIHRoZSBjb3JyZWN0IGJveCBzaXppbmcgaW4gRmlyZWZveC5cXG4gKiAyLiBTaG93IHRoZSBvdmVyZmxvdyBpbiBFZGdlIGFuZCBJRS5cXG4gKi9cXG5cXG5ociB7XFxuICAtd2Via2l0LWJveC1zaXppbmc6IGNvbnRlbnQtYm94O1xcbiAgICAgICAgICBib3gtc2l6aW5nOiBjb250ZW50LWJveDsgLyogMSAqL1xcbiAgaGVpZ2h0OiAwOyAvKiAxICovXFxuICBvdmVyZmxvdzogdmlzaWJsZTsgLyogMiAqL1xcbn1cXG5cXG4vKipcXG4gKiAxLiBDb3JyZWN0IHRoZSBpbmhlcml0YW5jZSBhbmQgc2NhbGluZyBvZiBmb250IHNpemUgaW4gYWxsIGJyb3dzZXJzLlxcbiAqIDIuIENvcnJlY3QgdGhlIG9kZCBgZW1gIGZvbnQgc2l6aW5nIGluIGFsbCBicm93c2Vycy5cXG4gKi9cXG5cXG5wcmUge1xcbiAgZm9udC1mYW1pbHk6IG1vbm9zcGFjZSwgbW9ub3NwYWNlOyAvKiAxICovXFxuICBmb250LXNpemU6IDFlbTsgLyogMiAqL1xcbn1cXG5cXG4vKiBUZXh0LWxldmVsIHNlbWFudGljc1xcbiAgID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovXFxuXFxuLyoqXFxuICogUmVtb3ZlIHRoZSBncmF5IGJhY2tncm91bmQgb24gYWN0aXZlIGxpbmtzIGluIElFIDEwLlxcbiAqL1xcblxcbmEge1xcbiAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XFxufVxcblxcbi8qKlxcbiAqIDEuIFJlbW92ZSB0aGUgYm90dG9tIGJvcmRlciBpbiBDaHJvbWUgNTctXFxuICogMi4gQWRkIHRoZSBjb3JyZWN0IHRleHQgZGVjb3JhdGlvbiBpbiBDaHJvbWUsIEVkZ2UsIElFLCBPcGVyYSwgYW5kIFNhZmFyaS5cXG4gKi9cXG5cXG5hYmJyW3RpdGxlXSB7XFxuICBib3JkZXItYm90dG9tOiBub25lOyAvKiAxICovXFxuICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTsgLyogMiAqL1xcbiAgLXdlYmtpdC10ZXh0LWRlY29yYXRpb246IHVuZGVybGluZSBkb3R0ZWQ7XFxuICAgICAgICAgIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lIGRvdHRlZDsgLyogMiAqL1xcbn1cXG5cXG4vKipcXG4gKiBBZGQgdGhlIGNvcnJlY3QgZm9udCB3ZWlnaHQgaW4gQ2hyb21lLCBFZGdlLCBhbmQgU2FmYXJpLlxcbiAqL1xcblxcbmIsXFxuc3Ryb25nIHtcXG4gIGZvbnQtd2VpZ2h0OiBib2xkZXI7XFxufVxcblxcbi8qKlxcbiAqIDEuIENvcnJlY3QgdGhlIGluaGVyaXRhbmNlIGFuZCBzY2FsaW5nIG9mIGZvbnQgc2l6ZSBpbiBhbGwgYnJvd3NlcnMuXFxuICogMi4gQ29ycmVjdCB0aGUgb2RkIGBlbWAgZm9udCBzaXppbmcgaW4gYWxsIGJyb3dzZXJzLlxcbiAqL1xcblxcbmNvZGUsXFxua2JkLFxcbnNhbXAge1xcbiAgZm9udC1mYW1pbHk6IG1vbm9zcGFjZSwgbW9ub3NwYWNlOyAvKiAxICovXFxuICBmb250LXNpemU6IDFlbTsgLyogMiAqL1xcbn1cXG5cXG4vKipcXG4gKiBBZGQgdGhlIGNvcnJlY3QgZm9udCBzaXplIGluIGFsbCBicm93c2Vycy5cXG4gKi9cXG5cXG5zbWFsbCB7XFxuICBmb250LXNpemU6IDgwJTtcXG59XFxuXFxuLyoqXFxuICogUHJldmVudCBgc3ViYCBhbmQgYHN1cGAgZWxlbWVudHMgZnJvbSBhZmZlY3RpbmcgdGhlIGxpbmUgaGVpZ2h0IGluXFxuICogYWxsIGJyb3dzZXJzLlxcbiAqL1xcblxcbnN1YixcXG5zdXAge1xcbiAgZm9udC1zaXplOiA3NSU7XFxuICBsaW5lLWhlaWdodDogMDtcXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG4gIHZlcnRpY2FsLWFsaWduOiBiYXNlbGluZTtcXG59XFxuXFxuc3ViIHtcXG4gIGJvdHRvbTogLTAuMjVlbTtcXG59XFxuXFxuc3VwIHtcXG4gIHRvcDogLTAuNWVtO1xcbn1cXG5cXG4vKiBFbWJlZGRlZCBjb250ZW50XFxuICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi9cXG5cXG4vKipcXG4gKiBSZW1vdmUgdGhlIGJvcmRlciBvbiBpbWFnZXMgaW5zaWRlIGxpbmtzIGluIElFIDEwLlxcbiAqL1xcblxcbmltZyB7XFxuICBib3JkZXItc3R5bGU6IG5vbmU7XFxufVxcblxcbi8qIEZvcm1zXFxuICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi9cXG5cXG4vKipcXG4gKiAxLiBDaGFuZ2UgdGhlIGZvbnQgc3R5bGVzIGluIGFsbCBicm93c2Vycy5cXG4gKiAyLiBSZW1vdmUgdGhlIG1hcmdpbiBpbiBGaXJlZm94IGFuZCBTYWZhcmkuXFxuICovXFxuXFxuYnV0dG9uLFxcbmlucHV0LFxcbm9wdGdyb3VwLFxcbnNlbGVjdCxcXG50ZXh0YXJlYSB7XFxuICBmb250LWZhbWlseTogaW5oZXJpdDsgLyogMSAqL1xcbiAgZm9udC1zaXplOiAxMDAlOyAvKiAxICovXFxuICBsaW5lLWhlaWdodDogMS4xNTsgLyogMSAqL1xcbiAgbWFyZ2luOiAwOyAvKiAyICovXFxufVxcblxcbi8qKlxcbiAqIFNob3cgdGhlIG92ZXJmbG93IGluIElFLlxcbiAqIDEuIFNob3cgdGhlIG92ZXJmbG93IGluIEVkZ2UuXFxuICovXFxuXFxuYnV0dG9uLFxcbmlucHV0IHsgLyogMSAqL1xcbiAgb3ZlcmZsb3c6IHZpc2libGU7XFxufVxcblxcbi8qKlxcbiAqIFJlbW92ZSB0aGUgaW5oZXJpdGFuY2Ugb2YgdGV4dCB0cmFuc2Zvcm0gaW4gRWRnZSwgRmlyZWZveCwgYW5kIElFLlxcbiAqIDEuIFJlbW92ZSB0aGUgaW5oZXJpdGFuY2Ugb2YgdGV4dCB0cmFuc2Zvcm0gaW4gRmlyZWZveC5cXG4gKi9cXG5cXG5idXR0b24sXFxuc2VsZWN0IHsgLyogMSAqL1xcbiAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XFxufVxcblxcbi8qKlxcbiAqIENvcnJlY3QgdGhlIGluYWJpbGl0eSB0byBzdHlsZSBjbGlja2FibGUgdHlwZXMgaW4gaU9TIGFuZCBTYWZhcmkuXFxuICovXFxuXFxuYnV0dG9uLFxcblt0eXBlPVxcXCJidXR0b25cXFwiXSxcXG5bdHlwZT1cXFwicmVzZXRcXFwiXSxcXG5bdHlwZT1cXFwic3VibWl0XFxcIl0ge1xcbiAgLXdlYmtpdC1hcHBlYXJhbmNlOiBidXR0b247XFxufVxcblxcbi8qKlxcbiAqIFJlbW92ZSB0aGUgaW5uZXIgYm9yZGVyIGFuZCBwYWRkaW5nIGluIEZpcmVmb3guXFxuICovXFxuXFxuYnV0dG9uOjotbW96LWZvY3VzLWlubmVyLFxcblt0eXBlPVxcXCJidXR0b25cXFwiXTo6LW1vei1mb2N1cy1pbm5lcixcXG5bdHlwZT1cXFwicmVzZXRcXFwiXTo6LW1vei1mb2N1cy1pbm5lcixcXG5bdHlwZT1cXFwic3VibWl0XFxcIl06Oi1tb3otZm9jdXMtaW5uZXIge1xcbiAgYm9yZGVyLXN0eWxlOiBub25lO1xcbiAgcGFkZGluZzogMDtcXG59XFxuXFxuLyoqXFxuICogUmVzdG9yZSB0aGUgZm9jdXMgc3R5bGVzIHVuc2V0IGJ5IHRoZSBwcmV2aW91cyBydWxlLlxcbiAqL1xcblxcbmJ1dHRvbjotbW96LWZvY3VzcmluZyxcXG5bdHlwZT1cXFwiYnV0dG9uXFxcIl06LW1vei1mb2N1c3JpbmcsXFxuW3R5cGU9XFxcInJlc2V0XFxcIl06LW1vei1mb2N1c3JpbmcsXFxuW3R5cGU9XFxcInN1Ym1pdFxcXCJdOi1tb3otZm9jdXNyaW5nIHtcXG4gIG91dGxpbmU6IDFweCBkb3R0ZWQgQnV0dG9uVGV4dDtcXG59XFxuXFxuLyoqXFxuICogQ29ycmVjdCB0aGUgcGFkZGluZyBpbiBGaXJlZm94LlxcbiAqL1xcblxcbmZpZWxkc2V0IHtcXG4gIHBhZGRpbmc6IDAuMzVlbSAwLjc1ZW0gMC42MjVlbTtcXG59XFxuXFxuLyoqXFxuICogMS4gQ29ycmVjdCB0aGUgdGV4dCB3cmFwcGluZyBpbiBFZGdlIGFuZCBJRS5cXG4gKiAyLiBDb3JyZWN0IHRoZSBjb2xvciBpbmhlcml0YW5jZSBmcm9tIGBmaWVsZHNldGAgZWxlbWVudHMgaW4gSUUuXFxuICogMy4gUmVtb3ZlIHRoZSBwYWRkaW5nIHNvIGRldmVsb3BlcnMgYXJlIG5vdCBjYXVnaHQgb3V0IHdoZW4gdGhleSB6ZXJvIG91dFxcbiAqICAgIGBmaWVsZHNldGAgZWxlbWVudHMgaW4gYWxsIGJyb3dzZXJzLlxcbiAqL1xcblxcbmxlZ2VuZCB7XFxuICAtd2Via2l0LWJveC1zaXppbmc6IGJvcmRlci1ib3g7XFxuICAgICAgICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7IC8qIDEgKi9cXG4gIGNvbG9yOiBpbmhlcml0OyAvKiAyICovXFxuICBkaXNwbGF5OiB0YWJsZTsgLyogMSAqL1xcbiAgbWF4LXdpZHRoOiAxMDAlOyAvKiAxICovXFxuICBwYWRkaW5nOiAwOyAvKiAzICovXFxuICB3aGl0ZS1zcGFjZTogbm9ybWFsOyAvKiAxICovXFxufVxcblxcbi8qKlxcbiAqIEFkZCB0aGUgY29ycmVjdCB2ZXJ0aWNhbCBhbGlnbm1lbnQgaW4gQ2hyb21lLCBGaXJlZm94LCBhbmQgT3BlcmEuXFxuICovXFxuXFxucHJvZ3Jlc3Mge1xcbiAgdmVydGljYWwtYWxpZ246IGJhc2VsaW5lO1xcbn1cXG5cXG4vKipcXG4gKiBSZW1vdmUgdGhlIGRlZmF1bHQgdmVydGljYWwgc2Nyb2xsYmFyIGluIElFIDEwKy5cXG4gKi9cXG5cXG50ZXh0YXJlYSB7XFxuICBvdmVyZmxvdzogYXV0bztcXG59XFxuXFxuLyoqXFxuICogMS4gQWRkIHRoZSBjb3JyZWN0IGJveCBzaXppbmcgaW4gSUUgMTAuXFxuICogMi4gUmVtb3ZlIHRoZSBwYWRkaW5nIGluIElFIDEwLlxcbiAqL1xcblxcblt0eXBlPVxcXCJjaGVja2JveFxcXCJdLFxcblt0eXBlPVxcXCJyYWRpb1xcXCJdIHtcXG4gIC13ZWJraXQtYm94LXNpemluZzogYm9yZGVyLWJveDtcXG4gICAgICAgICAgYm94LXNpemluZzogYm9yZGVyLWJveDsgLyogMSAqL1xcbiAgcGFkZGluZzogMDsgLyogMiAqL1xcbn1cXG5cXG4vKipcXG4gKiBDb3JyZWN0IHRoZSBjdXJzb3Igc3R5bGUgb2YgaW5jcmVtZW50IGFuZCBkZWNyZW1lbnQgYnV0dG9ucyBpbiBDaHJvbWUuXFxuICovXFxuXFxuW3R5cGU9XFxcIm51bWJlclxcXCJdOjotd2Via2l0LWlubmVyLXNwaW4tYnV0dG9uLFxcblt0eXBlPVxcXCJudW1iZXJcXFwiXTo6LXdlYmtpdC1vdXRlci1zcGluLWJ1dHRvbiB7XFxuICBoZWlnaHQ6IGF1dG87XFxufVxcblxcbi8qKlxcbiAqIDEuIENvcnJlY3QgdGhlIG9kZCBhcHBlYXJhbmNlIGluIENocm9tZSBhbmQgU2FmYXJpLlxcbiAqIDIuIENvcnJlY3QgdGhlIG91dGxpbmUgc3R5bGUgaW4gU2FmYXJpLlxcbiAqL1xcblxcblt0eXBlPVxcXCJzZWFyY2hcXFwiXSB7XFxuICAtd2Via2l0LWFwcGVhcmFuY2U6IHRleHRmaWVsZDsgLyogMSAqL1xcbiAgb3V0bGluZS1vZmZzZXQ6IC0ycHg7IC8qIDIgKi9cXG59XFxuXFxuLyoqXFxuICogUmVtb3ZlIHRoZSBpbm5lciBwYWRkaW5nIGluIENocm9tZSBhbmQgU2FmYXJpIG9uIG1hY09TLlxcbiAqL1xcblxcblt0eXBlPVxcXCJzZWFyY2hcXFwiXTo6LXdlYmtpdC1zZWFyY2gtZGVjb3JhdGlvbiB7XFxuICAtd2Via2l0LWFwcGVhcmFuY2U6IG5vbmU7XFxufVxcblxcbi8qKlxcbiAqIDEuIENvcnJlY3QgdGhlIGluYWJpbGl0eSB0byBzdHlsZSBjbGlja2FibGUgdHlwZXMgaW4gaU9TIGFuZCBTYWZhcmkuXFxuICogMi4gQ2hhbmdlIGZvbnQgcHJvcGVydGllcyB0byBgaW5oZXJpdGAgaW4gU2FmYXJpLlxcbiAqL1xcblxcbjo6LXdlYmtpdC1maWxlLXVwbG9hZC1idXR0b24ge1xcbiAgLXdlYmtpdC1hcHBlYXJhbmNlOiBidXR0b247IC8qIDEgKi9cXG4gIGZvbnQ6IGluaGVyaXQ7IC8qIDIgKi9cXG59XFxuXFxuLyogSW50ZXJhY3RpdmVcXG4gICA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL1xcblxcbi8qXFxuICogQWRkIHRoZSBjb3JyZWN0IGRpc3BsYXkgaW4gRWRnZSwgSUUgMTArLCBhbmQgRmlyZWZveC5cXG4gKi9cXG5cXG5kZXRhaWxzIHtcXG4gIGRpc3BsYXk6IGJsb2NrO1xcbn1cXG5cXG4vKlxcbiAqIEFkZCB0aGUgY29ycmVjdCBkaXNwbGF5IGluIGFsbCBicm93c2Vycy5cXG4gKi9cXG5cXG5zdW1tYXJ5IHtcXG4gIGRpc3BsYXk6IGxpc3QtaXRlbTtcXG59XFxuXFxuLyogTWlzY1xcbiAgID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovXFxuXFxuLyoqXFxuICogQWRkIHRoZSBjb3JyZWN0IGRpc3BsYXkgaW4gSUUgMTArLlxcbiAqL1xcblxcbnRlbXBsYXRlIHtcXG4gIGRpc3BsYXk6IG5vbmU7XFxufVxcblxcbi8qKlxcbiAqIEFkZCB0aGUgY29ycmVjdCBkaXNwbGF5IGluIElFIDEwLlxcbiAqL1xcblxcbltoaWRkZW5dIHtcXG4gIGRpc3BsYXk6IG5vbmU7XFxufVxcblwiLCBcIlwiLHtcInZlcnNpb25cIjozLFwic291cmNlc1wiOltcIndlYnBhY2s6Ly8uL25vZGVfbW9kdWxlcy9ub3JtYWxpemUuY3NzL25vcm1hbGl6ZS5jc3NcIl0sXCJuYW1lc1wiOltdLFwibWFwcGluZ3NcIjpcIkFBQUEsMkVBQTJFOztBQUUzRTsrRUFDK0U7O0FBRS9FOzs7RUFHRTs7QUFFRjtFQUNFLGlCQUFpQixFQUFFLE1BQU07RUFDekIsOEJBQThCLEVBQUUsTUFBTTtBQUN4Qzs7QUFFQTsrRUFDK0U7O0FBRS9FOztFQUVFOztBQUVGO0VBQ0UsU0FBUztBQUNYOztBQUVBOztFQUVFOztBQUVGO0VBQ0UsY0FBYztBQUNoQjs7QUFFQTs7O0VBR0U7O0FBRUY7RUFDRSxjQUFjO0VBQ2QsZ0JBQWdCO0FBQ2xCOztBQUVBOytFQUMrRTs7QUFFL0U7OztFQUdFOztBQUVGO0VBQ0UsK0JBQXVCO1VBQXZCLHVCQUF1QixFQUFFLE1BQU07RUFDL0IsU0FBUyxFQUFFLE1BQU07RUFDakIsaUJBQWlCLEVBQUUsTUFBTTtBQUMzQjs7QUFFQTs7O0VBR0U7O0FBRUY7RUFDRSxpQ0FBaUMsRUFBRSxNQUFNO0VBQ3pDLGNBQWMsRUFBRSxNQUFNO0FBQ3hCOztBQUVBOytFQUMrRTs7QUFFL0U7O0VBRUU7O0FBRUY7RUFDRSw2QkFBNkI7QUFDL0I7O0FBRUE7OztFQUdFOztBQUVGO0VBQ0UsbUJBQW1CLEVBQUUsTUFBTTtFQUMzQiwwQkFBMEIsRUFBRSxNQUFNO0VBQ2xDLHlDQUFpQztVQUFqQyxpQ0FBaUMsRUFBRSxNQUFNO0FBQzNDOztBQUVBOztFQUVFOztBQUVGOztFQUVFLG1CQUFtQjtBQUNyQjs7QUFFQTs7O0VBR0U7O0FBRUY7OztFQUdFLGlDQUFpQyxFQUFFLE1BQU07RUFDekMsY0FBYyxFQUFFLE1BQU07QUFDeEI7O0FBRUE7O0VBRUU7O0FBRUY7RUFDRSxjQUFjO0FBQ2hCOztBQUVBOzs7RUFHRTs7QUFFRjs7RUFFRSxjQUFjO0VBQ2QsY0FBYztFQUNkLGtCQUFrQjtFQUNsQix3QkFBd0I7QUFDMUI7O0FBRUE7RUFDRSxlQUFlO0FBQ2pCOztBQUVBO0VBQ0UsV0FBVztBQUNiOztBQUVBOytFQUMrRTs7QUFFL0U7O0VBRUU7O0FBRUY7RUFDRSxrQkFBa0I7QUFDcEI7O0FBRUE7K0VBQytFOztBQUUvRTs7O0VBR0U7O0FBRUY7Ozs7O0VBS0Usb0JBQW9CLEVBQUUsTUFBTTtFQUM1QixlQUFlLEVBQUUsTUFBTTtFQUN2QixpQkFBaUIsRUFBRSxNQUFNO0VBQ3pCLFNBQVMsRUFBRSxNQUFNO0FBQ25COztBQUVBOzs7RUFHRTs7QUFFRjtRQUNRLE1BQU07RUFDWixpQkFBaUI7QUFDbkI7O0FBRUE7OztFQUdFOztBQUVGO1NBQ1MsTUFBTTtFQUNiLG9CQUFvQjtBQUN0Qjs7QUFFQTs7RUFFRTs7QUFFRjs7OztFQUlFLDBCQUEwQjtBQUM1Qjs7QUFFQTs7RUFFRTs7QUFFRjs7OztFQUlFLGtCQUFrQjtFQUNsQixVQUFVO0FBQ1o7O0FBRUE7O0VBRUU7O0FBRUY7Ozs7RUFJRSw4QkFBOEI7QUFDaEM7O0FBRUE7O0VBRUU7O0FBRUY7RUFDRSw4QkFBOEI7QUFDaEM7O0FBRUE7Ozs7O0VBS0U7O0FBRUY7RUFDRSw4QkFBc0I7VUFBdEIsc0JBQXNCLEVBQUUsTUFBTTtFQUM5QixjQUFjLEVBQUUsTUFBTTtFQUN0QixjQUFjLEVBQUUsTUFBTTtFQUN0QixlQUFlLEVBQUUsTUFBTTtFQUN2QixVQUFVLEVBQUUsTUFBTTtFQUNsQixtQkFBbUIsRUFBRSxNQUFNO0FBQzdCOztBQUVBOztFQUVFOztBQUVGO0VBQ0Usd0JBQXdCO0FBQzFCOztBQUVBOztFQUVFOztBQUVGO0VBQ0UsY0FBYztBQUNoQjs7QUFFQTs7O0VBR0U7O0FBRUY7O0VBRUUsOEJBQXNCO1VBQXRCLHNCQUFzQixFQUFFLE1BQU07RUFDOUIsVUFBVSxFQUFFLE1BQU07QUFDcEI7O0FBRUE7O0VBRUU7O0FBRUY7O0VBRUUsWUFBWTtBQUNkOztBQUVBOzs7RUFHRTs7QUFFRjtFQUNFLDZCQUE2QixFQUFFLE1BQU07RUFDckMsb0JBQW9CLEVBQUUsTUFBTTtBQUM5Qjs7QUFFQTs7RUFFRTs7QUFFRjtFQUNFLHdCQUF3QjtBQUMxQjs7QUFFQTs7O0VBR0U7O0FBRUY7RUFDRSwwQkFBMEIsRUFBRSxNQUFNO0VBQ2xDLGFBQWEsRUFBRSxNQUFNO0FBQ3ZCOztBQUVBOytFQUMrRTs7QUFFL0U7O0VBRUU7O0FBRUY7RUFDRSxjQUFjO0FBQ2hCOztBQUVBOztFQUVFOztBQUVGO0VBQ0Usa0JBQWtCO0FBQ3BCOztBQUVBOytFQUMrRTs7QUFFL0U7O0VBRUU7O0FBRUY7RUFDRSxhQUFhO0FBQ2Y7O0FBRUE7O0VBRUU7O0FBRUY7RUFDRSxhQUFhO0FBQ2ZcIixcInNvdXJjZXNDb250ZW50XCI6W1wiLyohIG5vcm1hbGl6ZS5jc3MgdjguMC4xIHwgTUlUIExpY2Vuc2UgfCBnaXRodWIuY29tL25lY29sYXMvbm9ybWFsaXplLmNzcyAqL1xcblxcbi8qIERvY3VtZW50XFxuICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi9cXG5cXG4vKipcXG4gKiAxLiBDb3JyZWN0IHRoZSBsaW5lIGhlaWdodCBpbiBhbGwgYnJvd3NlcnMuXFxuICogMi4gUHJldmVudCBhZGp1c3RtZW50cyBvZiBmb250IHNpemUgYWZ0ZXIgb3JpZW50YXRpb24gY2hhbmdlcyBpbiBpT1MuXFxuICovXFxuXFxuaHRtbCB7XFxuICBsaW5lLWhlaWdodDogMS4xNTsgLyogMSAqL1xcbiAgLXdlYmtpdC10ZXh0LXNpemUtYWRqdXN0OiAxMDAlOyAvKiAyICovXFxufVxcblxcbi8qIFNlY3Rpb25zXFxuICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi9cXG5cXG4vKipcXG4gKiBSZW1vdmUgdGhlIG1hcmdpbiBpbiBhbGwgYnJvd3NlcnMuXFxuICovXFxuXFxuYm9keSB7XFxuICBtYXJnaW46IDA7XFxufVxcblxcbi8qKlxcbiAqIFJlbmRlciB0aGUgYG1haW5gIGVsZW1lbnQgY29uc2lzdGVudGx5IGluIElFLlxcbiAqL1xcblxcbm1haW4ge1xcbiAgZGlzcGxheTogYmxvY2s7XFxufVxcblxcbi8qKlxcbiAqIENvcnJlY3QgdGhlIGZvbnQgc2l6ZSBhbmQgbWFyZ2luIG9uIGBoMWAgZWxlbWVudHMgd2l0aGluIGBzZWN0aW9uYCBhbmRcXG4gKiBgYXJ0aWNsZWAgY29udGV4dHMgaW4gQ2hyb21lLCBGaXJlZm94LCBhbmQgU2FmYXJpLlxcbiAqL1xcblxcbmgxIHtcXG4gIGZvbnQtc2l6ZTogMmVtO1xcbiAgbWFyZ2luOiAwLjY3ZW0gMDtcXG59XFxuXFxuLyogR3JvdXBpbmcgY29udGVudFxcbiAgID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovXFxuXFxuLyoqXFxuICogMS4gQWRkIHRoZSBjb3JyZWN0IGJveCBzaXppbmcgaW4gRmlyZWZveC5cXG4gKiAyLiBTaG93IHRoZSBvdmVyZmxvdyBpbiBFZGdlIGFuZCBJRS5cXG4gKi9cXG5cXG5ociB7XFxuICBib3gtc2l6aW5nOiBjb250ZW50LWJveDsgLyogMSAqL1xcbiAgaGVpZ2h0OiAwOyAvKiAxICovXFxuICBvdmVyZmxvdzogdmlzaWJsZTsgLyogMiAqL1xcbn1cXG5cXG4vKipcXG4gKiAxLiBDb3JyZWN0IHRoZSBpbmhlcml0YW5jZSBhbmQgc2NhbGluZyBvZiBmb250IHNpemUgaW4gYWxsIGJyb3dzZXJzLlxcbiAqIDIuIENvcnJlY3QgdGhlIG9kZCBgZW1gIGZvbnQgc2l6aW5nIGluIGFsbCBicm93c2Vycy5cXG4gKi9cXG5cXG5wcmUge1xcbiAgZm9udC1mYW1pbHk6IG1vbm9zcGFjZSwgbW9ub3NwYWNlOyAvKiAxICovXFxuICBmb250LXNpemU6IDFlbTsgLyogMiAqL1xcbn1cXG5cXG4vKiBUZXh0LWxldmVsIHNlbWFudGljc1xcbiAgID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09ICovXFxuXFxuLyoqXFxuICogUmVtb3ZlIHRoZSBncmF5IGJhY2tncm91bmQgb24gYWN0aXZlIGxpbmtzIGluIElFIDEwLlxcbiAqL1xcblxcbmEge1xcbiAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XFxufVxcblxcbi8qKlxcbiAqIDEuIFJlbW92ZSB0aGUgYm90dG9tIGJvcmRlciBpbiBDaHJvbWUgNTctXFxuICogMi4gQWRkIHRoZSBjb3JyZWN0IHRleHQgZGVjb3JhdGlvbiBpbiBDaHJvbWUsIEVkZ2UsIElFLCBPcGVyYSwgYW5kIFNhZmFyaS5cXG4gKi9cXG5cXG5hYmJyW3RpdGxlXSB7XFxuICBib3JkZXItYm90dG9tOiBub25lOyAvKiAxICovXFxuICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTsgLyogMiAqL1xcbiAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmUgZG90dGVkOyAvKiAyICovXFxufVxcblxcbi8qKlxcbiAqIEFkZCB0aGUgY29ycmVjdCBmb250IHdlaWdodCBpbiBDaHJvbWUsIEVkZ2UsIGFuZCBTYWZhcmkuXFxuICovXFxuXFxuYixcXG5zdHJvbmcge1xcbiAgZm9udC13ZWlnaHQ6IGJvbGRlcjtcXG59XFxuXFxuLyoqXFxuICogMS4gQ29ycmVjdCB0aGUgaW5oZXJpdGFuY2UgYW5kIHNjYWxpbmcgb2YgZm9udCBzaXplIGluIGFsbCBicm93c2Vycy5cXG4gKiAyLiBDb3JyZWN0IHRoZSBvZGQgYGVtYCBmb250IHNpemluZyBpbiBhbGwgYnJvd3NlcnMuXFxuICovXFxuXFxuY29kZSxcXG5rYmQsXFxuc2FtcCB7XFxuICBmb250LWZhbWlseTogbW9ub3NwYWNlLCBtb25vc3BhY2U7IC8qIDEgKi9cXG4gIGZvbnQtc2l6ZTogMWVtOyAvKiAyICovXFxufVxcblxcbi8qKlxcbiAqIEFkZCB0aGUgY29ycmVjdCBmb250IHNpemUgaW4gYWxsIGJyb3dzZXJzLlxcbiAqL1xcblxcbnNtYWxsIHtcXG4gIGZvbnQtc2l6ZTogODAlO1xcbn1cXG5cXG4vKipcXG4gKiBQcmV2ZW50IGBzdWJgIGFuZCBgc3VwYCBlbGVtZW50cyBmcm9tIGFmZmVjdGluZyB0aGUgbGluZSBoZWlnaHQgaW5cXG4gKiBhbGwgYnJvd3NlcnMuXFxuICovXFxuXFxuc3ViLFxcbnN1cCB7XFxuICBmb250LXNpemU6IDc1JTtcXG4gIGxpbmUtaGVpZ2h0OiAwO1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbiAgdmVydGljYWwtYWxpZ246IGJhc2VsaW5lO1xcbn1cXG5cXG5zdWIge1xcbiAgYm90dG9tOiAtMC4yNWVtO1xcbn1cXG5cXG5zdXAge1xcbiAgdG9wOiAtMC41ZW07XFxufVxcblxcbi8qIEVtYmVkZGVkIGNvbnRlbnRcXG4gICA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL1xcblxcbi8qKlxcbiAqIFJlbW92ZSB0aGUgYm9yZGVyIG9uIGltYWdlcyBpbnNpZGUgbGlua3MgaW4gSUUgMTAuXFxuICovXFxuXFxuaW1nIHtcXG4gIGJvcmRlci1zdHlsZTogbm9uZTtcXG59XFxuXFxuLyogRm9ybXNcXG4gICA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL1xcblxcbi8qKlxcbiAqIDEuIENoYW5nZSB0aGUgZm9udCBzdHlsZXMgaW4gYWxsIGJyb3dzZXJzLlxcbiAqIDIuIFJlbW92ZSB0aGUgbWFyZ2luIGluIEZpcmVmb3ggYW5kIFNhZmFyaS5cXG4gKi9cXG5cXG5idXR0b24sXFxuaW5wdXQsXFxub3B0Z3JvdXAsXFxuc2VsZWN0LFxcbnRleHRhcmVhIHtcXG4gIGZvbnQtZmFtaWx5OiBpbmhlcml0OyAvKiAxICovXFxuICBmb250LXNpemU6IDEwMCU7IC8qIDEgKi9cXG4gIGxpbmUtaGVpZ2h0OiAxLjE1OyAvKiAxICovXFxuICBtYXJnaW46IDA7IC8qIDIgKi9cXG59XFxuXFxuLyoqXFxuICogU2hvdyB0aGUgb3ZlcmZsb3cgaW4gSUUuXFxuICogMS4gU2hvdyB0aGUgb3ZlcmZsb3cgaW4gRWRnZS5cXG4gKi9cXG5cXG5idXR0b24sXFxuaW5wdXQgeyAvKiAxICovXFxuICBvdmVyZmxvdzogdmlzaWJsZTtcXG59XFxuXFxuLyoqXFxuICogUmVtb3ZlIHRoZSBpbmhlcml0YW5jZSBvZiB0ZXh0IHRyYW5zZm9ybSBpbiBFZGdlLCBGaXJlZm94LCBhbmQgSUUuXFxuICogMS4gUmVtb3ZlIHRoZSBpbmhlcml0YW5jZSBvZiB0ZXh0IHRyYW5zZm9ybSBpbiBGaXJlZm94LlxcbiAqL1xcblxcbmJ1dHRvbixcXG5zZWxlY3QgeyAvKiAxICovXFxuICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcXG59XFxuXFxuLyoqXFxuICogQ29ycmVjdCB0aGUgaW5hYmlsaXR5IHRvIHN0eWxlIGNsaWNrYWJsZSB0eXBlcyBpbiBpT1MgYW5kIFNhZmFyaS5cXG4gKi9cXG5cXG5idXR0b24sXFxuW3R5cGU9XFxcImJ1dHRvblxcXCJdLFxcblt0eXBlPVxcXCJyZXNldFxcXCJdLFxcblt0eXBlPVxcXCJzdWJtaXRcXFwiXSB7XFxuICAtd2Via2l0LWFwcGVhcmFuY2U6IGJ1dHRvbjtcXG59XFxuXFxuLyoqXFxuICogUmVtb3ZlIHRoZSBpbm5lciBib3JkZXIgYW5kIHBhZGRpbmcgaW4gRmlyZWZveC5cXG4gKi9cXG5cXG5idXR0b246Oi1tb3otZm9jdXMtaW5uZXIsXFxuW3R5cGU9XFxcImJ1dHRvblxcXCJdOjotbW96LWZvY3VzLWlubmVyLFxcblt0eXBlPVxcXCJyZXNldFxcXCJdOjotbW96LWZvY3VzLWlubmVyLFxcblt0eXBlPVxcXCJzdWJtaXRcXFwiXTo6LW1vei1mb2N1cy1pbm5lciB7XFxuICBib3JkZXItc3R5bGU6IG5vbmU7XFxuICBwYWRkaW5nOiAwO1xcbn1cXG5cXG4vKipcXG4gKiBSZXN0b3JlIHRoZSBmb2N1cyBzdHlsZXMgdW5zZXQgYnkgdGhlIHByZXZpb3VzIHJ1bGUuXFxuICovXFxuXFxuYnV0dG9uOi1tb3otZm9jdXNyaW5nLFxcblt0eXBlPVxcXCJidXR0b25cXFwiXTotbW96LWZvY3VzcmluZyxcXG5bdHlwZT1cXFwicmVzZXRcXFwiXTotbW96LWZvY3VzcmluZyxcXG5bdHlwZT1cXFwic3VibWl0XFxcIl06LW1vei1mb2N1c3Jpbmcge1xcbiAgb3V0bGluZTogMXB4IGRvdHRlZCBCdXR0b25UZXh0O1xcbn1cXG5cXG4vKipcXG4gKiBDb3JyZWN0IHRoZSBwYWRkaW5nIGluIEZpcmVmb3guXFxuICovXFxuXFxuZmllbGRzZXQge1xcbiAgcGFkZGluZzogMC4zNWVtIDAuNzVlbSAwLjYyNWVtO1xcbn1cXG5cXG4vKipcXG4gKiAxLiBDb3JyZWN0IHRoZSB0ZXh0IHdyYXBwaW5nIGluIEVkZ2UgYW5kIElFLlxcbiAqIDIuIENvcnJlY3QgdGhlIGNvbG9yIGluaGVyaXRhbmNlIGZyb20gYGZpZWxkc2V0YCBlbGVtZW50cyBpbiBJRS5cXG4gKiAzLiBSZW1vdmUgdGhlIHBhZGRpbmcgc28gZGV2ZWxvcGVycyBhcmUgbm90IGNhdWdodCBvdXQgd2hlbiB0aGV5IHplcm8gb3V0XFxuICogICAgYGZpZWxkc2V0YCBlbGVtZW50cyBpbiBhbGwgYnJvd3NlcnMuXFxuICovXFxuXFxubGVnZW5kIHtcXG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7IC8qIDEgKi9cXG4gIGNvbG9yOiBpbmhlcml0OyAvKiAyICovXFxuICBkaXNwbGF5OiB0YWJsZTsgLyogMSAqL1xcbiAgbWF4LXdpZHRoOiAxMDAlOyAvKiAxICovXFxuICBwYWRkaW5nOiAwOyAvKiAzICovXFxuICB3aGl0ZS1zcGFjZTogbm9ybWFsOyAvKiAxICovXFxufVxcblxcbi8qKlxcbiAqIEFkZCB0aGUgY29ycmVjdCB2ZXJ0aWNhbCBhbGlnbm1lbnQgaW4gQ2hyb21lLCBGaXJlZm94LCBhbmQgT3BlcmEuXFxuICovXFxuXFxucHJvZ3Jlc3Mge1xcbiAgdmVydGljYWwtYWxpZ246IGJhc2VsaW5lO1xcbn1cXG5cXG4vKipcXG4gKiBSZW1vdmUgdGhlIGRlZmF1bHQgdmVydGljYWwgc2Nyb2xsYmFyIGluIElFIDEwKy5cXG4gKi9cXG5cXG50ZXh0YXJlYSB7XFxuICBvdmVyZmxvdzogYXV0bztcXG59XFxuXFxuLyoqXFxuICogMS4gQWRkIHRoZSBjb3JyZWN0IGJveCBzaXppbmcgaW4gSUUgMTAuXFxuICogMi4gUmVtb3ZlIHRoZSBwYWRkaW5nIGluIElFIDEwLlxcbiAqL1xcblxcblt0eXBlPVxcXCJjaGVja2JveFxcXCJdLFxcblt0eXBlPVxcXCJyYWRpb1xcXCJdIHtcXG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7IC8qIDEgKi9cXG4gIHBhZGRpbmc6IDA7IC8qIDIgKi9cXG59XFxuXFxuLyoqXFxuICogQ29ycmVjdCB0aGUgY3Vyc29yIHN0eWxlIG9mIGluY3JlbWVudCBhbmQgZGVjcmVtZW50IGJ1dHRvbnMgaW4gQ2hyb21lLlxcbiAqL1xcblxcblt0eXBlPVxcXCJudW1iZXJcXFwiXTo6LXdlYmtpdC1pbm5lci1zcGluLWJ1dHRvbixcXG5bdHlwZT1cXFwibnVtYmVyXFxcIl06Oi13ZWJraXQtb3V0ZXItc3Bpbi1idXR0b24ge1xcbiAgaGVpZ2h0OiBhdXRvO1xcbn1cXG5cXG4vKipcXG4gKiAxLiBDb3JyZWN0IHRoZSBvZGQgYXBwZWFyYW5jZSBpbiBDaHJvbWUgYW5kIFNhZmFyaS5cXG4gKiAyLiBDb3JyZWN0IHRoZSBvdXRsaW5lIHN0eWxlIGluIFNhZmFyaS5cXG4gKi9cXG5cXG5bdHlwZT1cXFwic2VhcmNoXFxcIl0ge1xcbiAgLXdlYmtpdC1hcHBlYXJhbmNlOiB0ZXh0ZmllbGQ7IC8qIDEgKi9cXG4gIG91dGxpbmUtb2Zmc2V0OiAtMnB4OyAvKiAyICovXFxufVxcblxcbi8qKlxcbiAqIFJlbW92ZSB0aGUgaW5uZXIgcGFkZGluZyBpbiBDaHJvbWUgYW5kIFNhZmFyaSBvbiBtYWNPUy5cXG4gKi9cXG5cXG5bdHlwZT1cXFwic2VhcmNoXFxcIl06Oi13ZWJraXQtc2VhcmNoLWRlY29yYXRpb24ge1xcbiAgLXdlYmtpdC1hcHBlYXJhbmNlOiBub25lO1xcbn1cXG5cXG4vKipcXG4gKiAxLiBDb3JyZWN0IHRoZSBpbmFiaWxpdHkgdG8gc3R5bGUgY2xpY2thYmxlIHR5cGVzIGluIGlPUyBhbmQgU2FmYXJpLlxcbiAqIDIuIENoYW5nZSBmb250IHByb3BlcnRpZXMgdG8gYGluaGVyaXRgIGluIFNhZmFyaS5cXG4gKi9cXG5cXG46Oi13ZWJraXQtZmlsZS11cGxvYWQtYnV0dG9uIHtcXG4gIC13ZWJraXQtYXBwZWFyYW5jZTogYnV0dG9uOyAvKiAxICovXFxuICBmb250OiBpbmhlcml0OyAvKiAyICovXFxufVxcblxcbi8qIEludGVyYWN0aXZlXFxuICAgPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0gKi9cXG5cXG4vKlxcbiAqIEFkZCB0aGUgY29ycmVjdCBkaXNwbGF5IGluIEVkZ2UsIElFIDEwKywgYW5kIEZpcmVmb3guXFxuICovXFxuXFxuZGV0YWlscyB7XFxuICBkaXNwbGF5OiBibG9jaztcXG59XFxuXFxuLypcXG4gKiBBZGQgdGhlIGNvcnJlY3QgZGlzcGxheSBpbiBhbGwgYnJvd3NlcnMuXFxuICovXFxuXFxuc3VtbWFyeSB7XFxuICBkaXNwbGF5OiBsaXN0LWl0ZW07XFxufVxcblxcbi8qIE1pc2NcXG4gICA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PSAqL1xcblxcbi8qKlxcbiAqIEFkZCB0aGUgY29ycmVjdCBkaXNwbGF5IGluIElFIDEwKy5cXG4gKi9cXG5cXG50ZW1wbGF0ZSB7XFxuICBkaXNwbGF5OiBub25lO1xcbn1cXG5cXG4vKipcXG4gKiBBZGQgdGhlIGNvcnJlY3QgZGlzcGxheSBpbiBJRSAxMC5cXG4gKi9cXG5cXG5baGlkZGVuXSB7XFxuICBkaXNwbGF5OiBub25lO1xcbn1cXG5cIl0sXCJzb3VyY2VSb290XCI6XCJcIn1dKTtcbi8vIEV4cG9ydHNcbmV4cG9ydCBkZWZhdWx0IF9fX0NTU19MT0FERVJfRVhQT1JUX19fO1xuIiwiLy8gSW1wb3J0c1xuaW1wb3J0IF9fX0NTU19MT0FERVJfQVBJX1NPVVJDRU1BUF9JTVBPUlRfX18gZnJvbSBcIi4uLy4uL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL2Nzc1dpdGhNYXBwaW5nVG9TdHJpbmcuanNcIjtcbmltcG9ydCBfX19DU1NfTE9BREVSX0FQSV9JTVBPUlRfX18gZnJvbSBcIi4uLy4uL2Nzcy1sb2FkZXIvZGlzdC9ydW50aW1lL2FwaS5qc1wiO1xudmFyIF9fX0NTU19MT0FERVJfRVhQT1JUX19fID0gX19fQ1NTX0xPQURFUl9BUElfSU1QT1JUX19fKF9fX0NTU19MT0FERVJfQVBJX1NPVVJDRU1BUF9JTVBPUlRfX18pO1xuLy8gTW9kdWxlXG5fX19DU1NfTE9BREVSX0VYUE9SVF9fXy5wdXNoKFttb2R1bGUuaWQsIFwiOnJvb3Qge1xcbiAgLS10b2FzdGlmeS1jb2xvci1saWdodDogI2ZmZjtcXG4gIC0tdG9hc3RpZnktY29sb3ItZGFyazogIzEyMTIxMjtcXG4gIC0tdG9hc3RpZnktY29sb3ItaW5mbzogIzM0OThkYjtcXG4gIC0tdG9hc3RpZnktY29sb3Itc3VjY2VzczogIzA3YmMwYztcXG4gIC0tdG9hc3RpZnktY29sb3Itd2FybmluZzogI2YxYzQwZjtcXG4gIC0tdG9hc3RpZnktY29sb3ItZXJyb3I6ICNlNzRjM2M7XFxuICAtLXRvYXN0aWZ5LWNvbG9yLXRyYW5zcGFyZW50OiByZ2JhKDI1NSwgMjU1LCAyNTUsIDAuNyk7XFxuICAtLXRvYXN0aWZ5LWljb24tY29sb3ItaW5mbzogdmFyKC0tdG9hc3RpZnktY29sb3ItaW5mbyk7XFxuICAtLXRvYXN0aWZ5LWljb24tY29sb3Itc3VjY2VzczogdmFyKC0tdG9hc3RpZnktY29sb3Itc3VjY2Vzcyk7XFxuICAtLXRvYXN0aWZ5LWljb24tY29sb3Itd2FybmluZzogdmFyKC0tdG9hc3RpZnktY29sb3Itd2FybmluZyk7XFxuICAtLXRvYXN0aWZ5LWljb24tY29sb3ItZXJyb3I6IHZhcigtLXRvYXN0aWZ5LWNvbG9yLWVycm9yKTtcXG4gIC0tdG9hc3RpZnktdG9hc3Qtd2lkdGg6IDMyMHB4O1xcbiAgLS10b2FzdGlmeS10b2FzdC1iYWNrZ3JvdW5kOiAjZmZmO1xcbiAgLS10b2FzdGlmeS10b2FzdC1taW4taGVpZ2h0OiA2NHB4O1xcbiAgLS10b2FzdGlmeS10b2FzdC1tYXgtaGVpZ2h0OiA4MDBweDtcXG4gIC0tdG9hc3RpZnktZm9udC1mYW1pbHk6IHNhbnMtc2VyaWY7XFxuICAtLXRvYXN0aWZ5LXotaW5kZXg6IDk5OTk7XFxuICAtLXRvYXN0aWZ5LXRleHQtY29sb3ItbGlnaHQ6ICM3NTc1NzU7XFxuICAtLXRvYXN0aWZ5LXRleHQtY29sb3ItZGFyazogI2ZmZjtcXG4gIC0tdG9hc3RpZnktdGV4dC1jb2xvci1pbmZvOiAjZmZmO1xcbiAgLS10b2FzdGlmeS10ZXh0LWNvbG9yLXN1Y2Nlc3M6ICNmZmY7XFxuICAtLXRvYXN0aWZ5LXRleHQtY29sb3Itd2FybmluZzogI2ZmZjtcXG4gIC0tdG9hc3RpZnktdGV4dC1jb2xvci1lcnJvcjogI2ZmZjtcXG4gIC0tdG9hc3RpZnktc3Bpbm5lci1jb2xvcjogIzYxNjE2MTtcXG4gIC0tdG9hc3RpZnktc3Bpbm5lci1jb2xvci1lbXB0eS1hcmVhOiAjZTBlMGUwO1xcbiAgLS10b2FzdGlmeS1jb2xvci1wcm9ncmVzcy1saWdodDogbGluZWFyLWdyYWRpZW50KFxcbiAgICB0byByaWdodCxcXG4gICAgIzRjZDk2NCxcXG4gICAgIzVhYzhmYSxcXG4gICAgIzAwN2FmZixcXG4gICAgIzM0YWFkYyxcXG4gICAgIzU4NTZkNixcXG4gICAgI2ZmMmQ1NVxcbiAgKTtcXG4gIC0tdG9hc3RpZnktY29sb3ItcHJvZ3Jlc3MtZGFyazogI2JiODZmYztcXG4gIC0tdG9hc3RpZnktY29sb3ItcHJvZ3Jlc3MtaW5mbzogdmFyKC0tdG9hc3RpZnktY29sb3ItaW5mbyk7XFxuICAtLXRvYXN0aWZ5LWNvbG9yLXByb2dyZXNzLXN1Y2Nlc3M6IHZhcigtLXRvYXN0aWZ5LWNvbG9yLXN1Y2Nlc3MpO1xcbiAgLS10b2FzdGlmeS1jb2xvci1wcm9ncmVzcy13YXJuaW5nOiB2YXIoLS10b2FzdGlmeS1jb2xvci13YXJuaW5nKTtcXG4gIC0tdG9hc3RpZnktY29sb3ItcHJvZ3Jlc3MtZXJyb3I6IHZhcigtLXRvYXN0aWZ5LWNvbG9yLWVycm9yKTtcXG59XFxuXFxuLlRvYXN0aWZ5X190b2FzdC1jb250YWluZXIge1xcbiAgei1pbmRleDogdmFyKC0tdG9hc3RpZnktei1pbmRleCk7XFxuICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMCwgdmFyKC0tdG9hc3RpZnktei1pbmRleCkgcHgpO1xcbiAgcG9zaXRpb246IGZpeGVkO1xcbiAgcGFkZGluZzogNHB4O1xcbiAgd2lkdGg6IHZhcigtLXRvYXN0aWZ5LXRvYXN0LXdpZHRoKTtcXG4gIC13ZWJraXQtYm94LXNpemluZzogYm9yZGVyLWJveDtcXG4gICAgICAgICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcXG4gIGNvbG9yOiAjZmZmO1xcbn1cXG4uVG9hc3RpZnlfX3RvYXN0LWNvbnRhaW5lci0tdG9wLWxlZnQge1xcbiAgdG9wOiAxZW07XFxuICBsZWZ0OiAxZW07XFxufVxcbi5Ub2FzdGlmeV9fdG9hc3QtY29udGFpbmVyLS10b3AtY2VudGVyIHtcXG4gIHRvcDogMWVtO1xcbiAgbGVmdDogNTAlO1xcbiAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVgoLTUwJSk7XFxuICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtNTAlKTtcXG59XFxuLlRvYXN0aWZ5X190b2FzdC1jb250YWluZXItLXRvcC1yaWdodCB7XFxuICB0b3A6IDFlbTtcXG4gIHJpZ2h0OiAxZW07XFxufVxcbi5Ub2FzdGlmeV9fdG9hc3QtY29udGFpbmVyLS1ib3R0b20tbGVmdCB7XFxuICBib3R0b206IDFlbTtcXG4gIGxlZnQ6IDFlbTtcXG59XFxuLlRvYXN0aWZ5X190b2FzdC1jb250YWluZXItLWJvdHRvbS1jZW50ZXIge1xcbiAgYm90dG9tOiAxZW07XFxuICBsZWZ0OiA1MCU7XFxuICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlWCgtNTAlKTtcXG4gICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC01MCUpO1xcbn1cXG4uVG9hc3RpZnlfX3RvYXN0LWNvbnRhaW5lci0tYm90dG9tLXJpZ2h0IHtcXG4gIGJvdHRvbTogMWVtO1xcbiAgcmlnaHQ6IDFlbTtcXG59XFxuXFxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoIDogNDgwcHgpIHtcXG4gIC5Ub2FzdGlmeV9fdG9hc3QtY29udGFpbmVyIHtcXG4gICAgd2lkdGg6IDEwMHZ3O1xcbiAgICBwYWRkaW5nOiAwO1xcbiAgICBsZWZ0OiAwO1xcbiAgICBtYXJnaW46IDA7XFxuICB9XFxuICAuVG9hc3RpZnlfX3RvYXN0LWNvbnRhaW5lci0tdG9wLWxlZnQsIC5Ub2FzdGlmeV9fdG9hc3QtY29udGFpbmVyLS10b3AtY2VudGVyLCAuVG9hc3RpZnlfX3RvYXN0LWNvbnRhaW5lci0tdG9wLXJpZ2h0IHtcXG4gICAgdG9wOiAwO1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlWCgwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoMCk7XFxuICB9XFxuICAuVG9hc3RpZnlfX3RvYXN0LWNvbnRhaW5lci0tYm90dG9tLWxlZnQsIC5Ub2FzdGlmeV9fdG9hc3QtY29udGFpbmVyLS1ib3R0b20tY2VudGVyLCAuVG9hc3RpZnlfX3RvYXN0LWNvbnRhaW5lci0tYm90dG9tLXJpZ2h0IHtcXG4gICAgYm90dG9tOiAwO1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlWCgwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoMCk7XFxuICB9XFxuICAuVG9hc3RpZnlfX3RvYXN0LWNvbnRhaW5lci0tcnRsIHtcXG4gICAgcmlnaHQ6IDA7XFxuICAgIGxlZnQ6IGluaXRpYWw7XFxuICB9XFxufVxcbi5Ub2FzdGlmeV9fdG9hc3Qge1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbiAgbWluLWhlaWdodDogdmFyKC0tdG9hc3RpZnktdG9hc3QtbWluLWhlaWdodCk7XFxuICAtd2Via2l0LWJveC1zaXppbmc6IGJvcmRlci1ib3g7XFxuICAgICAgICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XFxuICBtYXJnaW4tYm90dG9tOiAxcmVtO1xcbiAgcGFkZGluZzogOHB4O1xcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDFweCAxMHB4IDAgcmdiYSgwLCAwLCAwLCAwLjEpLCAwIDJweCAxNXB4IDAgcmdiYSgwLCAwLCAwLCAwLjA1KTtcXG4gICAgICAgICAgYm94LXNoYWRvdzogMCAxcHggMTBweCAwIHJnYmEoMCwgMCwgMCwgMC4xKSwgMCAycHggMTVweCAwIHJnYmEoMCwgMCwgMCwgMC4wNSk7XFxuICBkaXNwbGF5OiAtbXMtZmxleGJveDtcXG4gIGRpc3BsYXk6IC13ZWJraXQtYm94O1xcbiAgZGlzcGxheTogZmxleDtcXG4gIC1tcy1mbGV4LXBhY2s6IGp1c3RpZnk7XFxuICAgICAgLXdlYmtpdC1ib3gtcGFjazoganVzdGlmeTtcXG4gICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xcbiAgbWF4LWhlaWdodDogdmFyKC0tdG9hc3RpZnktdG9hc3QtbWF4LWhlaWdodCk7XFxuICBvdmVyZmxvdzogaGlkZGVuO1xcbiAgZm9udC1mYW1pbHk6IHZhcigtLXRvYXN0aWZ5LWZvbnQtZmFtaWx5KTtcXG4gIGN1cnNvcjogcG9pbnRlcjtcXG4gIGRpcmVjdGlvbjogbHRyO1xcbn1cXG4uVG9hc3RpZnlfX3RvYXN0LS1ydGwge1xcbiAgZGlyZWN0aW9uOiBydGw7XFxufVxcbi5Ub2FzdGlmeV9fdG9hc3QtYm9keSB7XFxuICBtYXJnaW46IGF1dG8gMDtcXG4gIC1tcy1mbGV4OiAxIDEgYXV0bztcXG4gICAgICAtd2Via2l0LWJveC1mbGV4OiAxO1xcbiAgICAgICAgICBmbGV4OiAxIDEgYXV0bztcXG4gIHBhZGRpbmc6IDZweDtcXG4gIGRpc3BsYXk6IC1tcy1mbGV4Ym94O1xcbiAgZGlzcGxheTogLXdlYmtpdC1ib3g7XFxuICBkaXNwbGF5OiBmbGV4O1xcbiAgLW1zLWZsZXgtYWxpZ246IGNlbnRlcjtcXG4gICAgICAtd2Via2l0LWJveC1hbGlnbjogY2VudGVyO1xcbiAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xcbn1cXG4uVG9hc3RpZnlfX3RvYXN0LWJvZHkgPiBkaXY6bGFzdC1jaGlsZCB7XFxuICAtbXMtZmxleDogMTtcXG4gICAgICAtd2Via2l0LWJveC1mbGV4OiAxO1xcbiAgICAgICAgICBmbGV4OiAxO1xcbn1cXG4uVG9hc3RpZnlfX3RvYXN0LWljb24ge1xcbiAgLXdlYmtpdC1tYXJnaW4tZW5kOiAxMHB4O1xcbiAgICAgICAgICBtYXJnaW4taW5saW5lLWVuZDogMTBweDtcXG4gIHdpZHRoOiAyMHB4O1xcbiAgLW1zLWZsZXgtbmVnYXRpdmU6IDA7XFxuICAgICAgZmxleC1zaHJpbms6IDA7XFxuICBkaXNwbGF5OiAtbXMtZmxleGJveDtcXG4gIGRpc3BsYXk6IC13ZWJraXQtYm94O1xcbiAgZGlzcGxheTogZmxleDtcXG59XFxuXFxuLlRvYXN0aWZ5LS1hbmltYXRlIHtcXG4gIC13ZWJraXQtYW5pbWF0aW9uLWZpbGwtbW9kZTogYm90aDtcXG4gICAgICAgICAgYW5pbWF0aW9uLWZpbGwtbW9kZTogYm90aDtcXG4gIC13ZWJraXQtYW5pbWF0aW9uLWR1cmF0aW9uOiAwLjdzO1xcbiAgICAgICAgICBhbmltYXRpb24tZHVyYXRpb246IDAuN3M7XFxufVxcblxcbi5Ub2FzdGlmeS0tYW5pbWF0ZS1pY29uIHtcXG4gIC13ZWJraXQtYW5pbWF0aW9uLWZpbGwtbW9kZTogYm90aDtcXG4gICAgICAgICAgYW5pbWF0aW9uLWZpbGwtbW9kZTogYm90aDtcXG4gIC13ZWJraXQtYW5pbWF0aW9uLWR1cmF0aW9uOiAwLjNzO1xcbiAgICAgICAgICBhbmltYXRpb24tZHVyYXRpb246IDAuM3M7XFxufVxcblxcbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1heC13aWR0aCA6IDQ4MHB4KSB7XFxuICAuVG9hc3RpZnlfX3RvYXN0IHtcXG4gICAgbWFyZ2luLWJvdHRvbTogMDtcXG4gICAgYm9yZGVyLXJhZGl1czogMDtcXG4gIH1cXG59XFxuLlRvYXN0aWZ5X190b2FzdC10aGVtZS0tZGFyayB7XFxuICBiYWNrZ3JvdW5kOiB2YXIoLS10b2FzdGlmeS1jb2xvci1kYXJrKTtcXG4gIGNvbG9yOiB2YXIoLS10b2FzdGlmeS10ZXh0LWNvbG9yLWRhcmspO1xcbn1cXG4uVG9hc3RpZnlfX3RvYXN0LXRoZW1lLS1saWdodCB7XFxuICBiYWNrZ3JvdW5kOiB2YXIoLS10b2FzdGlmeS1jb2xvci1saWdodCk7XFxuICBjb2xvcjogdmFyKC0tdG9hc3RpZnktdGV4dC1jb2xvci1saWdodCk7XFxufVxcbi5Ub2FzdGlmeV9fdG9hc3QtdGhlbWUtLWNvbG9yZWQuVG9hc3RpZnlfX3RvYXN0LS1kZWZhdWx0IHtcXG4gIGJhY2tncm91bmQ6IHZhcigtLXRvYXN0aWZ5LWNvbG9yLWxpZ2h0KTtcXG4gIGNvbG9yOiB2YXIoLS10b2FzdGlmeS10ZXh0LWNvbG9yLWxpZ2h0KTtcXG59XFxuLlRvYXN0aWZ5X190b2FzdC10aGVtZS0tY29sb3JlZC5Ub2FzdGlmeV9fdG9hc3QtLWluZm8ge1xcbiAgY29sb3I6IHZhcigtLXRvYXN0aWZ5LXRleHQtY29sb3ItaW5mbyk7XFxuICBiYWNrZ3JvdW5kOiB2YXIoLS10b2FzdGlmeS1jb2xvci1pbmZvKTtcXG59XFxuLlRvYXN0aWZ5X190b2FzdC10aGVtZS0tY29sb3JlZC5Ub2FzdGlmeV9fdG9hc3QtLXN1Y2Nlc3Mge1xcbiAgY29sb3I6IHZhcigtLXRvYXN0aWZ5LXRleHQtY29sb3Itc3VjY2Vzcyk7XFxuICBiYWNrZ3JvdW5kOiB2YXIoLS10b2FzdGlmeS1jb2xvci1zdWNjZXNzKTtcXG59XFxuLlRvYXN0aWZ5X190b2FzdC10aGVtZS0tY29sb3JlZC5Ub2FzdGlmeV9fdG9hc3QtLXdhcm5pbmcge1xcbiAgY29sb3I6IHZhcigtLXRvYXN0aWZ5LXRleHQtY29sb3Itd2FybmluZyk7XFxuICBiYWNrZ3JvdW5kOiB2YXIoLS10b2FzdGlmeS1jb2xvci13YXJuaW5nKTtcXG59XFxuLlRvYXN0aWZ5X190b2FzdC10aGVtZS0tY29sb3JlZC5Ub2FzdGlmeV9fdG9hc3QtLWVycm9yIHtcXG4gIGNvbG9yOiB2YXIoLS10b2FzdGlmeS10ZXh0LWNvbG9yLWVycm9yKTtcXG4gIGJhY2tncm91bmQ6IHZhcigtLXRvYXN0aWZ5LWNvbG9yLWVycm9yKTtcXG59XFxuXFxuLlRvYXN0aWZ5X19wcm9ncmVzcy1iYXItdGhlbWUtLWxpZ2h0IHtcXG4gIGJhY2tncm91bmQ6IHZhcigtLXRvYXN0aWZ5LWNvbG9yLXByb2dyZXNzLWxpZ2h0KTtcXG59XFxuLlRvYXN0aWZ5X19wcm9ncmVzcy1iYXItdGhlbWUtLWRhcmsge1xcbiAgYmFja2dyb3VuZDogdmFyKC0tdG9hc3RpZnktY29sb3ItcHJvZ3Jlc3MtZGFyayk7XFxufVxcbi5Ub2FzdGlmeV9fcHJvZ3Jlc3MtYmFyLS1pbmZvIHtcXG4gIGJhY2tncm91bmQ6IHZhcigtLXRvYXN0aWZ5LWNvbG9yLXByb2dyZXNzLWluZm8pO1xcbn1cXG4uVG9hc3RpZnlfX3Byb2dyZXNzLWJhci0tc3VjY2VzcyB7XFxuICBiYWNrZ3JvdW5kOiB2YXIoLS10b2FzdGlmeS1jb2xvci1wcm9ncmVzcy1zdWNjZXNzKTtcXG59XFxuLlRvYXN0aWZ5X19wcm9ncmVzcy1iYXItLXdhcm5pbmcge1xcbiAgYmFja2dyb3VuZDogdmFyKC0tdG9hc3RpZnktY29sb3ItcHJvZ3Jlc3Mtd2FybmluZyk7XFxufVxcbi5Ub2FzdGlmeV9fcHJvZ3Jlc3MtYmFyLS1lcnJvciB7XFxuICBiYWNrZ3JvdW5kOiB2YXIoLS10b2FzdGlmeS1jb2xvci1wcm9ncmVzcy1lcnJvcik7XFxufVxcbi5Ub2FzdGlmeV9fcHJvZ3Jlc3MtYmFyLXRoZW1lLS1jb2xvcmVkLlRvYXN0aWZ5X19wcm9ncmVzcy1iYXItLWluZm8sIC5Ub2FzdGlmeV9fcHJvZ3Jlc3MtYmFyLXRoZW1lLS1jb2xvcmVkLlRvYXN0aWZ5X19wcm9ncmVzcy1iYXItLXN1Y2Nlc3MsIC5Ub2FzdGlmeV9fcHJvZ3Jlc3MtYmFyLXRoZW1lLS1jb2xvcmVkLlRvYXN0aWZ5X19wcm9ncmVzcy1iYXItLXdhcm5pbmcsIC5Ub2FzdGlmeV9fcHJvZ3Jlc3MtYmFyLXRoZW1lLS1jb2xvcmVkLlRvYXN0aWZ5X19wcm9ncmVzcy1iYXItLWVycm9yIHtcXG4gIGJhY2tncm91bmQ6IHZhcigtLXRvYXN0aWZ5LWNvbG9yLXRyYW5zcGFyZW50KTtcXG59XFxuXFxuLlRvYXN0aWZ5X19jbG9zZS1idXR0b24ge1xcbiAgY29sb3I6ICNmZmY7XFxuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcXG4gIG91dGxpbmU6IG5vbmU7XFxuICBib3JkZXI6IG5vbmU7XFxuICBwYWRkaW5nOiAwO1xcbiAgY3Vyc29yOiBwb2ludGVyO1xcbiAgb3BhY2l0eTogMC43O1xcbiAgLXdlYmtpdC10cmFuc2l0aW9uOiAwLjNzIGVhc2U7XFxuICB0cmFuc2l0aW9uOiAwLjNzIGVhc2U7XFxuICAtbXMtZmxleC1pdGVtLWFsaWduOiBzdGFydDtcXG4gICAgICBhbGlnbi1zZWxmOiBmbGV4LXN0YXJ0O1xcbn1cXG4uVG9hc3RpZnlfX2Nsb3NlLWJ1dHRvbi0tbGlnaHQge1xcbiAgY29sb3I6ICMwMDA7XFxuICBvcGFjaXR5OiAwLjM7XFxufVxcbi5Ub2FzdGlmeV9fY2xvc2UtYnV0dG9uID4gc3ZnIHtcXG4gIGZpbGw6IGN1cnJlbnRDb2xvcjtcXG4gIGhlaWdodDogMTZweDtcXG4gIHdpZHRoOiAxNHB4O1xcbn1cXG4uVG9hc3RpZnlfX2Nsb3NlLWJ1dHRvbjpob3ZlciwgLlRvYXN0aWZ5X19jbG9zZS1idXR0b246Zm9jdXMge1xcbiAgb3BhY2l0eTogMTtcXG59XFxuXFxuQC13ZWJraXQta2V5ZnJhbWVzIFRvYXN0aWZ5X190cmFja1Byb2dyZXNzIHtcXG4gIDAlIHtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHNjYWxlWCgxKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlWCgxKTtcXG4gIH1cXG4gIDEwMCUge1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogc2NhbGVYKDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGVYKDApO1xcbiAgfVxcbn1cXG5cXG5Aa2V5ZnJhbWVzIFRvYXN0aWZ5X190cmFja1Byb2dyZXNzIHtcXG4gIDAlIHtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHNjYWxlWCgxKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlWCgxKTtcXG4gIH1cXG4gIDEwMCUge1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogc2NhbGVYKDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGVYKDApO1xcbiAgfVxcbn1cXG4uVG9hc3RpZnlfX3Byb2dyZXNzLWJhciB7XFxuICBwb3NpdGlvbjogYWJzb2x1dGU7XFxuICBib3R0b206IDA7XFxuICBsZWZ0OiAwO1xcbiAgd2lkdGg6IDEwMCU7XFxuICBoZWlnaHQ6IDVweDtcXG4gIHotaW5kZXg6IHZhcigtLXRvYXN0aWZ5LXotaW5kZXgpO1xcbiAgb3BhY2l0eTogMC43O1xcbiAgLXdlYmtpdC10cmFuc2Zvcm0tb3JpZ2luOiBsZWZ0O1xcbiAgICAgICAgICB0cmFuc2Zvcm0tb3JpZ2luOiBsZWZ0O1xcbn1cXG4uVG9hc3RpZnlfX3Byb2dyZXNzLWJhci0tYW5pbWF0ZWQge1xcbiAgLXdlYmtpdC1hbmltYXRpb246IFRvYXN0aWZ5X190cmFja1Byb2dyZXNzIGxpbmVhciAxIGZvcndhcmRzO1xcbiAgICAgICAgICBhbmltYXRpb246IFRvYXN0aWZ5X190cmFja1Byb2dyZXNzIGxpbmVhciAxIGZvcndhcmRzO1xcbn1cXG4uVG9hc3RpZnlfX3Byb2dyZXNzLWJhci0tY29udHJvbGxlZCB7XFxuICAtd2Via2l0LXRyYW5zaXRpb246IC13ZWJraXQtdHJhbnNmb3JtIDAuMnM7XFxuICB0cmFuc2l0aW9uOiAtd2Via2l0LXRyYW5zZm9ybSAwLjJzO1xcbiAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDAuMnM7XFxuICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gMC4ycywgLXdlYmtpdC10cmFuc2Zvcm0gMC4ycztcXG59XFxuLlRvYXN0aWZ5X19wcm9ncmVzcy1iYXItLXJ0bCB7XFxuICByaWdodDogMDtcXG4gIGxlZnQ6IGluaXRpYWw7XFxuICAtd2Via2l0LXRyYW5zZm9ybS1vcmlnaW46IHJpZ2h0O1xcbiAgICAgICAgICB0cmFuc2Zvcm0tb3JpZ2luOiByaWdodDtcXG59XFxuXFxuLlRvYXN0aWZ5X19zcGlubmVyIHtcXG4gIHdpZHRoOiAyMHB4O1xcbiAgaGVpZ2h0OiAyMHB4O1xcbiAgLXdlYmtpdC1ib3gtc2l6aW5nOiBib3JkZXItYm94O1xcbiAgICAgICAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xcbiAgYm9yZGVyOiAycHggc29saWQ7XFxuICBib3JkZXItcmFkaXVzOiAxMDAlO1xcbiAgYm9yZGVyLWNvbG9yOiB2YXIoLS10b2FzdGlmeS1zcGlubmVyLWNvbG9yLWVtcHR5LWFyZWEpO1xcbiAgYm9yZGVyLXJpZ2h0LWNvbG9yOiB2YXIoLS10b2FzdGlmeS1zcGlubmVyLWNvbG9yKTtcXG4gIC13ZWJraXQtYW5pbWF0aW9uOiBUb2FzdGlmeV9fc3BpbiAwLjY1cyBsaW5lYXIgaW5maW5pdGU7XFxuICAgICAgICAgIGFuaW1hdGlvbjogVG9hc3RpZnlfX3NwaW4gMC42NXMgbGluZWFyIGluZmluaXRlO1xcbn1cXG5cXG5ALXdlYmtpdC1rZXlmcmFtZXMgVG9hc3RpZnlfX2JvdW5jZUluUmlnaHQge1xcbiAgZnJvbSwgNjAlLCA3NSUsIDkwJSwgdG8ge1xcbiAgICAtd2Via2l0LWFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246IGN1YmljLWJlemllcigwLjIxNSwgMC42MSwgMC4zNTUsIDEpO1xcbiAgICAgICAgICAgIGFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246IGN1YmljLWJlemllcigwLjIxNSwgMC42MSwgMC4zNTUsIDEpO1xcbiAgfVxcbiAgZnJvbSB7XFxuICAgIG9wYWNpdHk6IDA7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgzMDAwcHgsIDAsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMzAwMHB4LCAwLCAwKTtcXG4gIH1cXG4gIDYwJSB7XFxuICAgIG9wYWNpdHk6IDE7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgtMjVweCwgMCwgMCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgtMjVweCwgMCwgMCk7XFxuICB9XFxuICA3NSUge1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMTBweCwgMCwgMCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgxMHB4LCAwLCAwKTtcXG4gIH1cXG4gIDkwJSB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgtNXB4LCAwLCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKC01cHgsIDAsIDApO1xcbiAgfVxcbiAgdG8ge1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogbm9uZTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IG5vbmU7XFxuICB9XFxufVxcblxcbkBrZXlmcmFtZXMgVG9hc3RpZnlfX2JvdW5jZUluUmlnaHQge1xcbiAgZnJvbSwgNjAlLCA3NSUsIDkwJSwgdG8ge1xcbiAgICAtd2Via2l0LWFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246IGN1YmljLWJlemllcigwLjIxNSwgMC42MSwgMC4zNTUsIDEpO1xcbiAgICAgICAgICAgIGFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246IGN1YmljLWJlemllcigwLjIxNSwgMC42MSwgMC4zNTUsIDEpO1xcbiAgfVxcbiAgZnJvbSB7XFxuICAgIG9wYWNpdHk6IDA7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgzMDAwcHgsIDAsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMzAwMHB4LCAwLCAwKTtcXG4gIH1cXG4gIDYwJSB7XFxuICAgIG9wYWNpdHk6IDE7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgtMjVweCwgMCwgMCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgtMjVweCwgMCwgMCk7XFxuICB9XFxuICA3NSUge1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMTBweCwgMCwgMCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgxMHB4LCAwLCAwKTtcXG4gIH1cXG4gIDkwJSB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgtNXB4LCAwLCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKC01cHgsIDAsIDApO1xcbiAgfVxcbiAgdG8ge1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogbm9uZTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IG5vbmU7XFxuICB9XFxufVxcbkAtd2Via2l0LWtleWZyYW1lcyBUb2FzdGlmeV9fYm91bmNlT3V0UmlnaHQge1xcbiAgMjAlIHtcXG4gICAgb3BhY2l0eTogMTtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKC0yMHB4LCAwLCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKC0yMHB4LCAwLCAwKTtcXG4gIH1cXG4gIHRvIHtcXG4gICAgb3BhY2l0eTogMDtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDIwMDBweCwgMCwgMCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgyMDAwcHgsIDAsIDApO1xcbiAgfVxcbn1cXG5Aa2V5ZnJhbWVzIFRvYXN0aWZ5X19ib3VuY2VPdXRSaWdodCB7XFxuICAyMCUge1xcbiAgICBvcGFjaXR5OiAxO1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoLTIwcHgsIDAsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoLTIwcHgsIDAsIDApO1xcbiAgfVxcbiAgdG8ge1xcbiAgICBvcGFjaXR5OiAwO1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMjAwMHB4LCAwLCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDIwMDBweCwgMCwgMCk7XFxuICB9XFxufVxcbkAtd2Via2l0LWtleWZyYW1lcyBUb2FzdGlmeV9fYm91bmNlSW5MZWZ0IHtcXG4gIGZyb20sIDYwJSwgNzUlLCA5MCUsIHRvIHtcXG4gICAgLXdlYmtpdC1hbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBjdWJpYy1iZXppZXIoMC4yMTUsIDAuNjEsIDAuMzU1LCAxKTtcXG4gICAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBjdWJpYy1iZXppZXIoMC4yMTUsIDAuNjEsIDAuMzU1LCAxKTtcXG4gIH1cXG4gIDAlIHtcXG4gICAgb3BhY2l0eTogMDtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKC0zMDAwcHgsIDAsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoLTMwMDBweCwgMCwgMCk7XFxuICB9XFxuICA2MCUge1xcbiAgICBvcGFjaXR5OiAxO1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMjVweCwgMCwgMCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgyNXB4LCAwLCAwKTtcXG4gIH1cXG4gIDc1JSB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgtMTBweCwgMCwgMCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgtMTBweCwgMCwgMCk7XFxuICB9XFxuICA5MCUge1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoNXB4LCAwLCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDVweCwgMCwgMCk7XFxuICB9XFxuICB0byB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiBub25lO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogbm9uZTtcXG4gIH1cXG59XFxuQGtleWZyYW1lcyBUb2FzdGlmeV9fYm91bmNlSW5MZWZ0IHtcXG4gIGZyb20sIDYwJSwgNzUlLCA5MCUsIHRvIHtcXG4gICAgLXdlYmtpdC1hbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBjdWJpYy1iZXppZXIoMC4yMTUsIDAuNjEsIDAuMzU1LCAxKTtcXG4gICAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBjdWJpYy1iZXppZXIoMC4yMTUsIDAuNjEsIDAuMzU1LCAxKTtcXG4gIH1cXG4gIDAlIHtcXG4gICAgb3BhY2l0eTogMDtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKC0zMDAwcHgsIDAsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoLTMwMDBweCwgMCwgMCk7XFxuICB9XFxuICA2MCUge1xcbiAgICBvcGFjaXR5OiAxO1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMjVweCwgMCwgMCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgyNXB4LCAwLCAwKTtcXG4gIH1cXG4gIDc1JSB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgtMTBweCwgMCwgMCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgtMTBweCwgMCwgMCk7XFxuICB9XFxuICA5MCUge1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoNXB4LCAwLCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDVweCwgMCwgMCk7XFxuICB9XFxuICB0byB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiBub25lO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogbm9uZTtcXG4gIH1cXG59XFxuQC13ZWJraXQta2V5ZnJhbWVzIFRvYXN0aWZ5X19ib3VuY2VPdXRMZWZ0IHtcXG4gIDIwJSB7XFxuICAgIG9wYWNpdHk6IDE7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgyMHB4LCAwLCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDIwcHgsIDAsIDApO1xcbiAgfVxcbiAgdG8ge1xcbiAgICBvcGFjaXR5OiAwO1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoLTIwMDBweCwgMCwgMCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgtMjAwMHB4LCAwLCAwKTtcXG4gIH1cXG59XFxuQGtleWZyYW1lcyBUb2FzdGlmeV9fYm91bmNlT3V0TGVmdCB7XFxuICAyMCUge1xcbiAgICBvcGFjaXR5OiAxO1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMjBweCwgMCwgMCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgyMHB4LCAwLCAwKTtcXG4gIH1cXG4gIHRvIHtcXG4gICAgb3BhY2l0eTogMDtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKC0yMDAwcHgsIDAsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoLTIwMDBweCwgMCwgMCk7XFxuICB9XFxufVxcbkAtd2Via2l0LWtleWZyYW1lcyBUb2FzdGlmeV9fYm91bmNlSW5VcCB7XFxuICBmcm9tLCA2MCUsIDc1JSwgOTAlLCB0byB7XFxuICAgIC13ZWJraXQtYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogY3ViaWMtYmV6aWVyKDAuMjE1LCAwLjYxLCAwLjM1NSwgMSk7XFxuICAgICAgICAgICAgYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogY3ViaWMtYmV6aWVyKDAuMjE1LCAwLjYxLCAwLjM1NSwgMSk7XFxuICB9XFxuICBmcm9tIHtcXG4gICAgb3BhY2l0eTogMDtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDMwMDBweCwgMCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAzMDAwcHgsIDApO1xcbiAgfVxcbiAgNjAlIHtcXG4gICAgb3BhY2l0eTogMTtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIC0yMHB4LCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIC0yMHB4LCAwKTtcXG4gIH1cXG4gIDc1JSB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAxMHB4LCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDEwcHgsIDApO1xcbiAgfVxcbiAgOTAlIHtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIC01cHgsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgLTVweCwgMCk7XFxuICB9XFxuICB0byB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAwLCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDAsIDApO1xcbiAgfVxcbn1cXG5Aa2V5ZnJhbWVzIFRvYXN0aWZ5X19ib3VuY2VJblVwIHtcXG4gIGZyb20sIDYwJSwgNzUlLCA5MCUsIHRvIHtcXG4gICAgLXdlYmtpdC1hbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBjdWJpYy1iZXppZXIoMC4yMTUsIDAuNjEsIDAuMzU1LCAxKTtcXG4gICAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBjdWJpYy1iZXppZXIoMC4yMTUsIDAuNjEsIDAuMzU1LCAxKTtcXG4gIH1cXG4gIGZyb20ge1xcbiAgICBvcGFjaXR5OiAwO1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMzAwMHB4LCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDMwMDBweCwgMCk7XFxuICB9XFxuICA2MCUge1xcbiAgICBvcGFjaXR5OiAxO1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgLTIwcHgsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgLTIwcHgsIDApO1xcbiAgfVxcbiAgNzUlIHtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDEwcHgsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMTBweCwgMCk7XFxuICB9XFxuICA5MCUge1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgLTVweCwgMCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAtNXB4LCAwKTtcXG4gIH1cXG4gIHRvIHtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDAsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMCwgMCk7XFxuICB9XFxufVxcbkAtd2Via2l0LWtleWZyYW1lcyBUb2FzdGlmeV9fYm91bmNlT3V0VXAge1xcbiAgMjAlIHtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIC0xMHB4LCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIC0xMHB4LCAwKTtcXG4gIH1cXG4gIDQwJSwgNDUlIHtcXG4gICAgb3BhY2l0eTogMTtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDIwcHgsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMjBweCwgMCk7XFxuICB9XFxuICB0byB7XFxuICAgIG9wYWNpdHk6IDA7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAtMjAwMHB4LCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIC0yMDAwcHgsIDApO1xcbiAgfVxcbn1cXG5Aa2V5ZnJhbWVzIFRvYXN0aWZ5X19ib3VuY2VPdXRVcCB7XFxuICAyMCUge1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgLTEwcHgsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgLTEwcHgsIDApO1xcbiAgfVxcbiAgNDAlLCA0NSUge1xcbiAgICBvcGFjaXR5OiAxO1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMjBweCwgMCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAyMHB4LCAwKTtcXG4gIH1cXG4gIHRvIHtcXG4gICAgb3BhY2l0eTogMDtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIC0yMDAwcHgsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgLTIwMDBweCwgMCk7XFxuICB9XFxufVxcbkAtd2Via2l0LWtleWZyYW1lcyBUb2FzdGlmeV9fYm91bmNlSW5Eb3duIHtcXG4gIGZyb20sIDYwJSwgNzUlLCA5MCUsIHRvIHtcXG4gICAgLXdlYmtpdC1hbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBjdWJpYy1iZXppZXIoMC4yMTUsIDAuNjEsIDAuMzU1LCAxKTtcXG4gICAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBjdWJpYy1iZXppZXIoMC4yMTUsIDAuNjEsIDAuMzU1LCAxKTtcXG4gIH1cXG4gIDAlIHtcXG4gICAgb3BhY2l0eTogMDtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIC0zMDAwcHgsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgLTMwMDBweCwgMCk7XFxuICB9XFxuICA2MCUge1xcbiAgICBvcGFjaXR5OiAxO1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMjVweCwgMCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAyNXB4LCAwKTtcXG4gIH1cXG4gIDc1JSB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAtMTBweCwgMCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAtMTBweCwgMCk7XFxuICB9XFxuICA5MCUge1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgNXB4LCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDVweCwgMCk7XFxuICB9XFxuICB0byB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiBub25lO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogbm9uZTtcXG4gIH1cXG59XFxuQGtleWZyYW1lcyBUb2FzdGlmeV9fYm91bmNlSW5Eb3duIHtcXG4gIGZyb20sIDYwJSwgNzUlLCA5MCUsIHRvIHtcXG4gICAgLXdlYmtpdC1hbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBjdWJpYy1iZXppZXIoMC4yMTUsIDAuNjEsIDAuMzU1LCAxKTtcXG4gICAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBjdWJpYy1iZXppZXIoMC4yMTUsIDAuNjEsIDAuMzU1LCAxKTtcXG4gIH1cXG4gIDAlIHtcXG4gICAgb3BhY2l0eTogMDtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIC0zMDAwcHgsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgLTMwMDBweCwgMCk7XFxuICB9XFxuICA2MCUge1xcbiAgICBvcGFjaXR5OiAxO1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMjVweCwgMCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAyNXB4LCAwKTtcXG4gIH1cXG4gIDc1JSB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAtMTBweCwgMCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAtMTBweCwgMCk7XFxuICB9XFxuICA5MCUge1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgNXB4LCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDVweCwgMCk7XFxuICB9XFxuICB0byB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiBub25lO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogbm9uZTtcXG4gIH1cXG59XFxuQC13ZWJraXQta2V5ZnJhbWVzIFRvYXN0aWZ5X19ib3VuY2VPdXREb3duIHtcXG4gIDIwJSB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAxMHB4LCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDEwcHgsIDApO1xcbiAgfVxcbiAgNDAlLCA0NSUge1xcbiAgICBvcGFjaXR5OiAxO1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgLTIwcHgsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgLTIwcHgsIDApO1xcbiAgfVxcbiAgdG8ge1xcbiAgICBvcGFjaXR5OiAwO1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMjAwMHB4LCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDIwMDBweCwgMCk7XFxuICB9XFxufVxcbkBrZXlmcmFtZXMgVG9hc3RpZnlfX2JvdW5jZU91dERvd24ge1xcbiAgMjAlIHtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDEwcHgsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMTBweCwgMCk7XFxuICB9XFxuICA0MCUsIDQ1JSB7XFxuICAgIG9wYWNpdHk6IDE7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAtMjBweCwgMCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAtMjBweCwgMCk7XFxuICB9XFxuICB0byB7XFxuICAgIG9wYWNpdHk6IDA7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAyMDAwcHgsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMjAwMHB4LCAwKTtcXG4gIH1cXG59XFxuLlRvYXN0aWZ5X19ib3VuY2UtZW50ZXItLXRvcC1sZWZ0LCAuVG9hc3RpZnlfX2JvdW5jZS1lbnRlci0tYm90dG9tLWxlZnQge1xcbiAgLXdlYmtpdC1hbmltYXRpb24tbmFtZTogVG9hc3RpZnlfX2JvdW5jZUluTGVmdDtcXG4gICAgICAgICAgYW5pbWF0aW9uLW5hbWU6IFRvYXN0aWZ5X19ib3VuY2VJbkxlZnQ7XFxufVxcbi5Ub2FzdGlmeV9fYm91bmNlLWVudGVyLS10b3AtcmlnaHQsIC5Ub2FzdGlmeV9fYm91bmNlLWVudGVyLS1ib3R0b20tcmlnaHQge1xcbiAgLXdlYmtpdC1hbmltYXRpb24tbmFtZTogVG9hc3RpZnlfX2JvdW5jZUluUmlnaHQ7XFxuICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBUb2FzdGlmeV9fYm91bmNlSW5SaWdodDtcXG59XFxuLlRvYXN0aWZ5X19ib3VuY2UtZW50ZXItLXRvcC1jZW50ZXIge1xcbiAgLXdlYmtpdC1hbmltYXRpb24tbmFtZTogVG9hc3RpZnlfX2JvdW5jZUluRG93bjtcXG4gICAgICAgICAgYW5pbWF0aW9uLW5hbWU6IFRvYXN0aWZ5X19ib3VuY2VJbkRvd247XFxufVxcbi5Ub2FzdGlmeV9fYm91bmNlLWVudGVyLS1ib3R0b20tY2VudGVyIHtcXG4gIC13ZWJraXQtYW5pbWF0aW9uLW5hbWU6IFRvYXN0aWZ5X19ib3VuY2VJblVwO1xcbiAgICAgICAgICBhbmltYXRpb24tbmFtZTogVG9hc3RpZnlfX2JvdW5jZUluVXA7XFxufVxcblxcbi5Ub2FzdGlmeV9fYm91bmNlLWV4aXQtLXRvcC1sZWZ0LCAuVG9hc3RpZnlfX2JvdW5jZS1leGl0LS1ib3R0b20tbGVmdCB7XFxuICAtd2Via2l0LWFuaW1hdGlvbi1uYW1lOiBUb2FzdGlmeV9fYm91bmNlT3V0TGVmdDtcXG4gICAgICAgICAgYW5pbWF0aW9uLW5hbWU6IFRvYXN0aWZ5X19ib3VuY2VPdXRMZWZ0O1xcbn1cXG4uVG9hc3RpZnlfX2JvdW5jZS1leGl0LS10b3AtcmlnaHQsIC5Ub2FzdGlmeV9fYm91bmNlLWV4aXQtLWJvdHRvbS1yaWdodCB7XFxuICAtd2Via2l0LWFuaW1hdGlvbi1uYW1lOiBUb2FzdGlmeV9fYm91bmNlT3V0UmlnaHQ7XFxuICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBUb2FzdGlmeV9fYm91bmNlT3V0UmlnaHQ7XFxufVxcbi5Ub2FzdGlmeV9fYm91bmNlLWV4aXQtLXRvcC1jZW50ZXIge1xcbiAgLXdlYmtpdC1hbmltYXRpb24tbmFtZTogVG9hc3RpZnlfX2JvdW5jZU91dFVwO1xcbiAgICAgICAgICBhbmltYXRpb24tbmFtZTogVG9hc3RpZnlfX2JvdW5jZU91dFVwO1xcbn1cXG4uVG9hc3RpZnlfX2JvdW5jZS1leGl0LS1ib3R0b20tY2VudGVyIHtcXG4gIC13ZWJraXQtYW5pbWF0aW9uLW5hbWU6IFRvYXN0aWZ5X19ib3VuY2VPdXREb3duO1xcbiAgICAgICAgICBhbmltYXRpb24tbmFtZTogVG9hc3RpZnlfX2JvdW5jZU91dERvd247XFxufVxcblxcbkAtd2Via2l0LWtleWZyYW1lcyBUb2FzdGlmeV9fem9vbUluIHtcXG4gIGZyb20ge1xcbiAgICBvcGFjaXR5OiAwO1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogc2NhbGUzZCgwLjMsIDAuMywgMC4zKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlM2QoMC4zLCAwLjMsIDAuMyk7XFxuICB9XFxuICA1MCUge1xcbiAgICBvcGFjaXR5OiAxO1xcbiAgfVxcbn1cXG5cXG5Aa2V5ZnJhbWVzIFRvYXN0aWZ5X196b29tSW4ge1xcbiAgZnJvbSB7XFxuICAgIG9wYWNpdHk6IDA7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiBzY2FsZTNkKDAuMywgMC4zLCAwLjMpO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUzZCgwLjMsIDAuMywgMC4zKTtcXG4gIH1cXG4gIDUwJSB7XFxuICAgIG9wYWNpdHk6IDE7XFxuICB9XFxufVxcbkAtd2Via2l0LWtleWZyYW1lcyBUb2FzdGlmeV9fem9vbU91dCB7XFxuICBmcm9tIHtcXG4gICAgb3BhY2l0eTogMTtcXG4gIH1cXG4gIDUwJSB7XFxuICAgIG9wYWNpdHk6IDA7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiBzY2FsZTNkKDAuMywgMC4zLCAwLjMpO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUzZCgwLjMsIDAuMywgMC4zKTtcXG4gIH1cXG4gIHRvIHtcXG4gICAgb3BhY2l0eTogMDtcXG4gIH1cXG59XFxuQGtleWZyYW1lcyBUb2FzdGlmeV9fem9vbU91dCB7XFxuICBmcm9tIHtcXG4gICAgb3BhY2l0eTogMTtcXG4gIH1cXG4gIDUwJSB7XFxuICAgIG9wYWNpdHk6IDA7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiBzY2FsZTNkKDAuMywgMC4zLCAwLjMpO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUzZCgwLjMsIDAuMywgMC4zKTtcXG4gIH1cXG4gIHRvIHtcXG4gICAgb3BhY2l0eTogMDtcXG4gIH1cXG59XFxuLlRvYXN0aWZ5X196b29tLWVudGVyIHtcXG4gIC13ZWJraXQtYW5pbWF0aW9uLW5hbWU6IFRvYXN0aWZ5X196b29tSW47XFxuICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBUb2FzdGlmeV9fem9vbUluO1xcbn1cXG5cXG4uVG9hc3RpZnlfX3pvb20tZXhpdCB7XFxuICAtd2Via2l0LWFuaW1hdGlvbi1uYW1lOiBUb2FzdGlmeV9fem9vbU91dDtcXG4gICAgICAgICAgYW5pbWF0aW9uLW5hbWU6IFRvYXN0aWZ5X196b29tT3V0O1xcbn1cXG5cXG5ALXdlYmtpdC1rZXlmcmFtZXMgVG9hc3RpZnlfX2ZsaXBJbiB7XFxuICBmcm9tIHtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHBlcnNwZWN0aXZlKDQwMHB4KSByb3RhdGUzZCgxLCAwLCAwLCA5MGRlZyk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiBwZXJzcGVjdGl2ZSg0MDBweCkgcm90YXRlM2QoMSwgMCwgMCwgOTBkZWcpO1xcbiAgICAtd2Via2l0LWFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246IGVhc2UtaW47XFxuICAgICAgICAgICAgYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogZWFzZS1pbjtcXG4gICAgb3BhY2l0eTogMDtcXG4gIH1cXG4gIDQwJSB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiBwZXJzcGVjdGl2ZSg0MDBweCkgcm90YXRlM2QoMSwgMCwgMCwgLTIwZGVnKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHBlcnNwZWN0aXZlKDQwMHB4KSByb3RhdGUzZCgxLCAwLCAwLCAtMjBkZWcpO1xcbiAgICAtd2Via2l0LWFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246IGVhc2UtaW47XFxuICAgICAgICAgICAgYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogZWFzZS1pbjtcXG4gIH1cXG4gIDYwJSB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiBwZXJzcGVjdGl2ZSg0MDBweCkgcm90YXRlM2QoMSwgMCwgMCwgMTBkZWcpO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogcGVyc3BlY3RpdmUoNDAwcHgpIHJvdGF0ZTNkKDEsIDAsIDAsIDEwZGVnKTtcXG4gICAgb3BhY2l0eTogMTtcXG4gIH1cXG4gIDgwJSB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiBwZXJzcGVjdGl2ZSg0MDBweCkgcm90YXRlM2QoMSwgMCwgMCwgLTVkZWcpO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogcGVyc3BlY3RpdmUoNDAwcHgpIHJvdGF0ZTNkKDEsIDAsIDAsIC01ZGVnKTtcXG4gIH1cXG4gIHRvIHtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHBlcnNwZWN0aXZlKDQwMHB4KTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHBlcnNwZWN0aXZlKDQwMHB4KTtcXG4gIH1cXG59XFxuXFxuQGtleWZyYW1lcyBUb2FzdGlmeV9fZmxpcEluIHtcXG4gIGZyb20ge1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogcGVyc3BlY3RpdmUoNDAwcHgpIHJvdGF0ZTNkKDEsIDAsIDAsIDkwZGVnKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHBlcnNwZWN0aXZlKDQwMHB4KSByb3RhdGUzZCgxLCAwLCAwLCA5MGRlZyk7XFxuICAgIC13ZWJraXQtYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogZWFzZS1pbjtcXG4gICAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluO1xcbiAgICBvcGFjaXR5OiAwO1xcbiAgfVxcbiAgNDAlIHtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHBlcnNwZWN0aXZlKDQwMHB4KSByb3RhdGUzZCgxLCAwLCAwLCAtMjBkZWcpO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogcGVyc3BlY3RpdmUoNDAwcHgpIHJvdGF0ZTNkKDEsIDAsIDAsIC0yMGRlZyk7XFxuICAgIC13ZWJraXQtYW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjogZWFzZS1pbjtcXG4gICAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluO1xcbiAgfVxcbiAgNjAlIHtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHBlcnNwZWN0aXZlKDQwMHB4KSByb3RhdGUzZCgxLCAwLCAwLCAxMGRlZyk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiBwZXJzcGVjdGl2ZSg0MDBweCkgcm90YXRlM2QoMSwgMCwgMCwgMTBkZWcpO1xcbiAgICBvcGFjaXR5OiAxO1xcbiAgfVxcbiAgODAlIHtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHBlcnNwZWN0aXZlKDQwMHB4KSByb3RhdGUzZCgxLCAwLCAwLCAtNWRlZyk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiBwZXJzcGVjdGl2ZSg0MDBweCkgcm90YXRlM2QoMSwgMCwgMCwgLTVkZWcpO1xcbiAgfVxcbiAgdG8ge1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogcGVyc3BlY3RpdmUoNDAwcHgpO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogcGVyc3BlY3RpdmUoNDAwcHgpO1xcbiAgfVxcbn1cXG5ALXdlYmtpdC1rZXlmcmFtZXMgVG9hc3RpZnlfX2ZsaXBPdXQge1xcbiAgZnJvbSB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiBwZXJzcGVjdGl2ZSg0MDBweCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiBwZXJzcGVjdGl2ZSg0MDBweCk7XFxuICB9XFxuICAzMCUge1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogcGVyc3BlY3RpdmUoNDAwcHgpIHJvdGF0ZTNkKDEsIDAsIDAsIC0yMGRlZyk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiBwZXJzcGVjdGl2ZSg0MDBweCkgcm90YXRlM2QoMSwgMCwgMCwgLTIwZGVnKTtcXG4gICAgb3BhY2l0eTogMTtcXG4gIH1cXG4gIHRvIHtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHBlcnNwZWN0aXZlKDQwMHB4KSByb3RhdGUzZCgxLCAwLCAwLCA5MGRlZyk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiBwZXJzcGVjdGl2ZSg0MDBweCkgcm90YXRlM2QoMSwgMCwgMCwgOTBkZWcpO1xcbiAgICBvcGFjaXR5OiAwO1xcbiAgfVxcbn1cXG5Aa2V5ZnJhbWVzIFRvYXN0aWZ5X19mbGlwT3V0IHtcXG4gIGZyb20ge1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogcGVyc3BlY3RpdmUoNDAwcHgpO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogcGVyc3BlY3RpdmUoNDAwcHgpO1xcbiAgfVxcbiAgMzAlIHtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHBlcnNwZWN0aXZlKDQwMHB4KSByb3RhdGUzZCgxLCAwLCAwLCAtMjBkZWcpO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogcGVyc3BlY3RpdmUoNDAwcHgpIHJvdGF0ZTNkKDEsIDAsIDAsIC0yMGRlZyk7XFxuICAgIG9wYWNpdHk6IDE7XFxuICB9XFxuICB0byB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiBwZXJzcGVjdGl2ZSg0MDBweCkgcm90YXRlM2QoMSwgMCwgMCwgOTBkZWcpO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogcGVyc3BlY3RpdmUoNDAwcHgpIHJvdGF0ZTNkKDEsIDAsIDAsIDkwZGVnKTtcXG4gICAgb3BhY2l0eTogMDtcXG4gIH1cXG59XFxuLlRvYXN0aWZ5X19mbGlwLWVudGVyIHtcXG4gIC13ZWJraXQtYW5pbWF0aW9uLW5hbWU6IFRvYXN0aWZ5X19mbGlwSW47XFxuICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBUb2FzdGlmeV9fZmxpcEluO1xcbn1cXG5cXG4uVG9hc3RpZnlfX2ZsaXAtZXhpdCB7XFxuICAtd2Via2l0LWFuaW1hdGlvbi1uYW1lOiBUb2FzdGlmeV9fZmxpcE91dDtcXG4gICAgICAgICAgYW5pbWF0aW9uLW5hbWU6IFRvYXN0aWZ5X19mbGlwT3V0O1xcbn1cXG5cXG5ALXdlYmtpdC1rZXlmcmFtZXMgVG9hc3RpZnlfX3NsaWRlSW5SaWdodCB7XFxuICBmcm9tIHtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDExMCUsIDAsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMTEwJSwgMCwgMCk7XFxuICAgIHZpc2liaWxpdHk6IHZpc2libGU7XFxuICB9XFxuICB0byB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAwLCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDAsIDApO1xcbiAgfVxcbn1cXG5cXG5Aa2V5ZnJhbWVzIFRvYXN0aWZ5X19zbGlkZUluUmlnaHQge1xcbiAgZnJvbSB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgxMTAlLCAwLCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDExMCUsIDAsIDApO1xcbiAgICB2aXNpYmlsaXR5OiB2aXNpYmxlO1xcbiAgfVxcbiAgdG8ge1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMCwgMCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAwLCAwKTtcXG4gIH1cXG59XFxuQC13ZWJraXQta2V5ZnJhbWVzIFRvYXN0aWZ5X19zbGlkZUluTGVmdCB7XFxuICBmcm9tIHtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKC0xMTAlLCAwLCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKC0xMTAlLCAwLCAwKTtcXG4gICAgdmlzaWJpbGl0eTogdmlzaWJsZTtcXG4gIH1cXG4gIHRvIHtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDAsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMCwgMCk7XFxuICB9XFxufVxcbkBrZXlmcmFtZXMgVG9hc3RpZnlfX3NsaWRlSW5MZWZ0IHtcXG4gIGZyb20ge1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoLTExMCUsIDAsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoLTExMCUsIDAsIDApO1xcbiAgICB2aXNpYmlsaXR5OiB2aXNpYmxlO1xcbiAgfVxcbiAgdG8ge1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMCwgMCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAwLCAwKTtcXG4gIH1cXG59XFxuQC13ZWJraXQta2V5ZnJhbWVzIFRvYXN0aWZ5X19zbGlkZUluVXAge1xcbiAgZnJvbSB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAxMTAlLCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDExMCUsIDApO1xcbiAgICB2aXNpYmlsaXR5OiB2aXNpYmxlO1xcbiAgfVxcbiAgdG8ge1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMCwgMCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAwLCAwKTtcXG4gIH1cXG59XFxuQGtleWZyYW1lcyBUb2FzdGlmeV9fc2xpZGVJblVwIHtcXG4gIGZyb20ge1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMTEwJSwgMCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAxMTAlLCAwKTtcXG4gICAgdmlzaWJpbGl0eTogdmlzaWJsZTtcXG4gIH1cXG4gIHRvIHtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDAsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMCwgMCk7XFxuICB9XFxufVxcbkAtd2Via2l0LWtleWZyYW1lcyBUb2FzdGlmeV9fc2xpZGVJbkRvd24ge1xcbiAgZnJvbSB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAtMTEwJSwgMCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAtMTEwJSwgMCk7XFxuICAgIHZpc2liaWxpdHk6IHZpc2libGU7XFxuICB9XFxuICB0byB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAwLCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDAsIDApO1xcbiAgfVxcbn1cXG5Aa2V5ZnJhbWVzIFRvYXN0aWZ5X19zbGlkZUluRG93biB7XFxuICBmcm9tIHtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIC0xMTAlLCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIC0xMTAlLCAwKTtcXG4gICAgdmlzaWJpbGl0eTogdmlzaWJsZTtcXG4gIH1cXG4gIHRvIHtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDAsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMCwgMCk7XFxuICB9XFxufVxcbkAtd2Via2l0LWtleWZyYW1lcyBUb2FzdGlmeV9fc2xpZGVPdXRSaWdodCB7XFxuICBmcm9tIHtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDAsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMCwgMCk7XFxuICB9XFxuICB0byB7XFxuICAgIHZpc2liaWxpdHk6IGhpZGRlbjtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDExMCUsIDAsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMTEwJSwgMCwgMCk7XFxuICB9XFxufVxcbkBrZXlmcmFtZXMgVG9hc3RpZnlfX3NsaWRlT3V0UmlnaHQge1xcbiAgZnJvbSB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAwLCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDAsIDApO1xcbiAgfVxcbiAgdG8ge1xcbiAgICB2aXNpYmlsaXR5OiBoaWRkZW47XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgxMTAlLCAwLCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDExMCUsIDAsIDApO1xcbiAgfVxcbn1cXG5ALXdlYmtpdC1rZXlmcmFtZXMgVG9hc3RpZnlfX3NsaWRlT3V0TGVmdCB7XFxuICBmcm9tIHtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDAsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMCwgMCk7XFxuICB9XFxuICB0byB7XFxuICAgIHZpc2liaWxpdHk6IGhpZGRlbjtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKC0xMTAlLCAwLCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKC0xMTAlLCAwLCAwKTtcXG4gIH1cXG59XFxuQGtleWZyYW1lcyBUb2FzdGlmeV9fc2xpZGVPdXRMZWZ0IHtcXG4gIGZyb20ge1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMCwgMCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAwLCAwKTtcXG4gIH1cXG4gIHRvIHtcXG4gICAgdmlzaWJpbGl0eTogaGlkZGVuO1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoLTExMCUsIDAsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoLTExMCUsIDAsIDApO1xcbiAgfVxcbn1cXG5ALXdlYmtpdC1rZXlmcmFtZXMgVG9hc3RpZnlfX3NsaWRlT3V0RG93biB7XFxuICBmcm9tIHtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDAsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMCwgMCk7XFxuICB9XFxuICB0byB7XFxuICAgIHZpc2liaWxpdHk6IGhpZGRlbjtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDUwMHB4LCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDUwMHB4LCAwKTtcXG4gIH1cXG59XFxuQGtleWZyYW1lcyBUb2FzdGlmeV9fc2xpZGVPdXREb3duIHtcXG4gIGZyb20ge1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMCwgMCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAwLCAwKTtcXG4gIH1cXG4gIHRvIHtcXG4gICAgdmlzaWJpbGl0eTogaGlkZGVuO1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgNTAwcHgsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgNTAwcHgsIDApO1xcbiAgfVxcbn1cXG5ALXdlYmtpdC1rZXlmcmFtZXMgVG9hc3RpZnlfX3NsaWRlT3V0VXAge1xcbiAgZnJvbSB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAwLCAwKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDAsIDApO1xcbiAgfVxcbiAgdG8ge1xcbiAgICB2aXNpYmlsaXR5OiBoaWRkZW47XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAtNTAwcHgsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgLTUwMHB4LCAwKTtcXG4gIH1cXG59XFxuQGtleWZyYW1lcyBUb2FzdGlmeV9fc2xpZGVPdXRVcCB7XFxuICBmcm9tIHtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDAsIDApO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMCwgMCk7XFxuICB9XFxuICB0byB7XFxuICAgIHZpc2liaWxpdHk6IGhpZGRlbjtcXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIC01MDBweCwgMCk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAtNTAwcHgsIDApO1xcbiAgfVxcbn1cXG4uVG9hc3RpZnlfX3NsaWRlLWVudGVyLS10b3AtbGVmdCwgLlRvYXN0aWZ5X19zbGlkZS1lbnRlci0tYm90dG9tLWxlZnQge1xcbiAgLXdlYmtpdC1hbmltYXRpb24tbmFtZTogVG9hc3RpZnlfX3NsaWRlSW5MZWZ0O1xcbiAgICAgICAgICBhbmltYXRpb24tbmFtZTogVG9hc3RpZnlfX3NsaWRlSW5MZWZ0O1xcbn1cXG4uVG9hc3RpZnlfX3NsaWRlLWVudGVyLS10b3AtcmlnaHQsIC5Ub2FzdGlmeV9fc2xpZGUtZW50ZXItLWJvdHRvbS1yaWdodCB7XFxuICAtd2Via2l0LWFuaW1hdGlvbi1uYW1lOiBUb2FzdGlmeV9fc2xpZGVJblJpZ2h0O1xcbiAgICAgICAgICBhbmltYXRpb24tbmFtZTogVG9hc3RpZnlfX3NsaWRlSW5SaWdodDtcXG59XFxuLlRvYXN0aWZ5X19zbGlkZS1lbnRlci0tdG9wLWNlbnRlciB7XFxuICAtd2Via2l0LWFuaW1hdGlvbi1uYW1lOiBUb2FzdGlmeV9fc2xpZGVJbkRvd247XFxuICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBUb2FzdGlmeV9fc2xpZGVJbkRvd247XFxufVxcbi5Ub2FzdGlmeV9fc2xpZGUtZW50ZXItLWJvdHRvbS1jZW50ZXIge1xcbiAgLXdlYmtpdC1hbmltYXRpb24tbmFtZTogVG9hc3RpZnlfX3NsaWRlSW5VcDtcXG4gICAgICAgICAgYW5pbWF0aW9uLW5hbWU6IFRvYXN0aWZ5X19zbGlkZUluVXA7XFxufVxcblxcbi5Ub2FzdGlmeV9fc2xpZGUtZXhpdC0tdG9wLWxlZnQsIC5Ub2FzdGlmeV9fc2xpZGUtZXhpdC0tYm90dG9tLWxlZnQge1xcbiAgLXdlYmtpdC1hbmltYXRpb24tbmFtZTogVG9hc3RpZnlfX3NsaWRlT3V0TGVmdDtcXG4gICAgICAgICAgYW5pbWF0aW9uLW5hbWU6IFRvYXN0aWZ5X19zbGlkZU91dExlZnQ7XFxufVxcbi5Ub2FzdGlmeV9fc2xpZGUtZXhpdC0tdG9wLXJpZ2h0LCAuVG9hc3RpZnlfX3NsaWRlLWV4aXQtLWJvdHRvbS1yaWdodCB7XFxuICAtd2Via2l0LWFuaW1hdGlvbi1uYW1lOiBUb2FzdGlmeV9fc2xpZGVPdXRSaWdodDtcXG4gICAgICAgICAgYW5pbWF0aW9uLW5hbWU6IFRvYXN0aWZ5X19zbGlkZU91dFJpZ2h0O1xcbn1cXG4uVG9hc3RpZnlfX3NsaWRlLWV4aXQtLXRvcC1jZW50ZXIge1xcbiAgLXdlYmtpdC1hbmltYXRpb24tbmFtZTogVG9hc3RpZnlfX3NsaWRlT3V0VXA7XFxuICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBUb2FzdGlmeV9fc2xpZGVPdXRVcDtcXG59XFxuLlRvYXN0aWZ5X19zbGlkZS1leGl0LS1ib3R0b20tY2VudGVyIHtcXG4gIC13ZWJraXQtYW5pbWF0aW9uLW5hbWU6IFRvYXN0aWZ5X19zbGlkZU91dERvd247XFxuICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBUb2FzdGlmeV9fc2xpZGVPdXREb3duO1xcbn1cXG5cXG5ALXdlYmtpdC1rZXlmcmFtZXMgVG9hc3RpZnlfX3NwaW4ge1xcbiAgZnJvbSB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiByb3RhdGUoMGRlZyk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiByb3RhdGUoMGRlZyk7XFxuICB9XFxuICB0byB7XFxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiByb3RhdGUoMzYwZGVnKTtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHJvdGF0ZSgzNjBkZWcpO1xcbiAgfVxcbn1cXG5cXG5Aa2V5ZnJhbWVzIFRvYXN0aWZ5X19zcGluIHtcXG4gIGZyb20ge1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKDBkZWcpO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogcm90YXRlKDBkZWcpO1xcbiAgfVxcbiAgdG8ge1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKDM2MGRlZyk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiByb3RhdGUoMzYwZGVnKTtcXG4gIH1cXG59XFxuXFxuLyojIHNvdXJjZU1hcHBpbmdVUkw9UmVhY3RUb2FzdGlmeS5jc3MubWFwICovXCIsIFwiXCIse1widmVyc2lvblwiOjMsXCJzb3VyY2VzXCI6W1wid2VicGFjazovLy4vbm9kZV9tb2R1bGVzL3JlYWN0LXRvYXN0aWZ5L3Njc3MvX3ZhcmlhYmxlcy5zY3NzXCIsXCJ3ZWJwYWNrOi8vLi9ub2RlX21vZHVsZXMvcmVhY3QtdG9hc3RpZnkvZGlzdC9SZWFjdFRvYXN0aWZ5LmNzc1wiLFwid2VicGFjazovLy4vbm9kZV9tb2R1bGVzL3JlYWN0LXRvYXN0aWZ5L3Njc3MvX3RvYXN0Q29udGFpbmVyLnNjc3NcIixcIndlYnBhY2s6Ly8uL25vZGVfbW9kdWxlcy9yZWFjdC10b2FzdGlmeS9zY3NzL190b2FzdC5zY3NzXCIsXCJ3ZWJwYWNrOi8vLi9ub2RlX21vZHVsZXMvcmVhY3QtdG9hc3RpZnkvc2Nzcy9fdGhlbWUuc2Nzc1wiLFwid2VicGFjazovLy4vbm9kZV9tb2R1bGVzL3JlYWN0LXRvYXN0aWZ5L3Njc3MvX2Nsb3NlQnV0dG9uLnNjc3NcIixcIndlYnBhY2s6Ly8uL25vZGVfbW9kdWxlcy9yZWFjdC10b2FzdGlmeS9zY3NzL19wcm9ncmVzc0Jhci5zY3NzXCIsXCJ3ZWJwYWNrOi8vLi9ub2RlX21vZHVsZXMvcmVhY3QtdG9hc3RpZnkvc2Nzcy9faWNvbnMuc2Nzc1wiLFwid2VicGFjazovLy4vbm9kZV9tb2R1bGVzL3JlYWN0LXRvYXN0aWZ5L3Njc3MvYW5pbWF0aW9ucy9fYm91bmNlLnNjc3NcIixcIndlYnBhY2s6Ly8uL25vZGVfbW9kdWxlcy9yZWFjdC10b2FzdGlmeS9zY3NzL2FuaW1hdGlvbnMvX3pvb20uc2Nzc1wiLFwid2VicGFjazovLy4vbm9kZV9tb2R1bGVzL3JlYWN0LXRvYXN0aWZ5L3Njc3MvYW5pbWF0aW9ucy9fZmxpcC5zY3NzXCIsXCJ3ZWJwYWNrOi8vLi9ub2RlX21vZHVsZXMvcmVhY3QtdG9hc3RpZnkvc2Nzcy9hbmltYXRpb25zL19zbGlkZS5zY3NzXCIsXCJ3ZWJwYWNrOi8vLi9ub2RlX21vZHVsZXMvcmVhY3QtdG9hc3RpZnkvc2Nzcy9hbmltYXRpb25zL19zcGluLnNjc3NcIl0sXCJuYW1lc1wiOltdLFwibWFwcGluZ3NcIjpcIkFBR0E7RUFDRSw0QkFBQTtFQUNBLDhCQUFBO0VBQ0EsOEJBQUE7RUFDQSxpQ0FBQTtFQUNBLGlDQUFBO0VBQ0EsK0JBQUE7RUFDQSxzREFBQTtFQUVBLHNEQUFBO0VBQ0EsNERBQUE7RUFDQSw0REFBQTtFQUNBLHdEQUFBO0VBRUEsNkJBQUE7RUFDQSxpQ0FBQTtFQUNBLGlDQUFBO0VBQ0Esa0NBQUE7RUFDQSxrQ0FBQTtFQUNBLHdCQUFBO0VBRUEsb0NBQUE7RUFDQSxnQ0FBQTtFQUdBLGdDQUFBO0VBQ0EsbUNBQUE7RUFDQSxtQ0FBQTtFQUNBLGlDQUFBO0VBRUEsaUNBQUE7RUFDQSw0Q0FBQTtFQUdBOzs7Ozs7OztHQUFBO0VBVUEsdUNBQUE7RUFDQSwwREFBQTtFQUNBLGdFQUFBO0VBQ0EsZ0VBQUE7RUFDQSw0REFBQTtBQ1hGOztBQ3hDQTtFQUNFLGdDQUFBO0VBQ0EsZ0VBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGtDQUFBO0VBQ0EsOEJBQUE7VUFBQSxzQkFBQTtFQUNBLFdBQUE7QUQyQ0Y7QUMxQ0U7RUFDRSxRQUFBO0VBQ0EsU0FBQTtBRDRDSjtBQzFDRTtFQUNFLFFBQUE7RUFDQSxTQUFBO0VBQ0EsbUNBQUE7VUFBQSwyQkFBQTtBRDRDSjtBQzFDRTtFQUNFLFFBQUE7RUFDQSxVQUFBO0FENENKO0FDMUNFO0VBQ0UsV0FBQTtFQUNBLFNBQUE7QUQ0Q0o7QUMxQ0U7RUFDRSxXQUFBO0VBQ0EsU0FBQTtFQUNBLG1DQUFBO1VBQUEsMkJBQUE7QUQ0Q0o7QUMxQ0U7RUFDRSxXQUFBO0VBQ0EsVUFBQTtBRDRDSjs7QUN4Q0E7RUFDRTtJQUNFLFlBQUE7SUFDQSxVQUFBO0lBQ0EsT0FBQTtJQUNBLFNBQUE7RUQyQ0Y7RUMxQ0U7SUFHRSxNQUFBO0lBQ0EsZ0NBQUE7WUFBQSx3QkFBQTtFRDBDSjtFQ3hDRTtJQUdFLFNBQUE7SUFDQSxnQ0FBQTtZQUFBLHdCQUFBO0VEd0NKO0VDdENFO0lBQ0UsUUFBQTtJQUNBLGFBQUE7RUR3Q0o7QUFDRjtBRWpHQTtFQUNFLGtCQUFBO0VBQ0EsNENBQUE7RUFDQSw4QkFBQTtVQUFBLHNCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxxRkFBQTtVQUFBLDZFQUFBO0VBQ0Esb0JBQUE7RUFBQSxvQkFBQTtFQUFBLGFBQUE7RUFDQSxzQkFBQTtNQUFBLHlCQUFBO1VBQUEsOEJBQUE7RUFDQSw0Q0FBQTtFQUNBLGdCQUFBO0VBQ0Esd0NBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtBRm1HRjtBRWxHRTtFQUNFLGNBQUE7QUZvR0o7QUVsR0U7RUFDRSxjQUFBO0VBQ0Esa0JBQUE7TUFBQSxtQkFBQTtVQUFBLGNBQUE7RUFDQSxZQUFBO0VBQ0Esb0JBQUE7RUFBQSxvQkFBQTtFQUFBLGFBQUE7RUFDQSxzQkFBQTtNQUFBLHlCQUFBO1VBQUEsbUJBQUE7QUZvR0o7QUVuR0k7RUFDRSxXQUFBO01BQUEsbUJBQUE7VUFBQSxPQUFBO0FGcUdOO0FFbEdFO0VBQ0Usd0JBQUE7VUFBQSx1QkFBQTtFQUNBLFdBQUE7RUFDQSxvQkFBQTtNQUFBLGNBQUE7RUFDQSxvQkFBQTtFQUFBLG9CQUFBO0VBQUEsYUFBQTtBRm9HSjs7QUVoR0E7RUFDRSxpQ0FBQTtVQUFBLHlCQUFBO0VBQ0EsZ0NBQUE7VUFBQSx3QkFBQTtBRm1HRjs7QUVoR0E7RUFDRSxpQ0FBQTtVQUFBLHlCQUFBO0VBQ0EsZ0NBQUE7VUFBQSx3QkFBQTtBRm1HRjs7QUVoR0E7RUFDRTtJQUNFLGdCQUFBO0lBQ0EsZ0JBQUE7RUZtR0Y7QUFDRjtBR3BKRTtFQUNFLHNDQUFBO0VBQ0Esc0NBQUE7QUhzSko7QUdwSkU7RUFDRSx1Q0FBQTtFQUNBLHVDQUFBO0FIc0pKO0FHcEpFO0VBQ0UsdUNBQUE7RUFDQSx1Q0FBQTtBSHNKSjtBR3BKRTtFQUNFLHNDQUFBO0VBQ0Esc0NBQUE7QUhzSko7QUdwSkU7RUFDRSx5Q0FBQTtFQUNBLHlDQUFBO0FIc0pKO0FHcEpFO0VBQ0UseUNBQUE7RUFDQSx5Q0FBQTtBSHNKSjtBR3BKRTtFQUNFLHVDQUFBO0VBQ0EsdUNBQUE7QUhzSko7O0FHakpFO0VBQ0UsZ0RBQUE7QUhvSko7QUdsSkU7RUFDRSwrQ0FBQTtBSG9KSjtBR2xKRTtFQUNFLCtDQUFBO0FIb0pKO0FHbEpFO0VBQ0Usa0RBQUE7QUhvSko7QUdsSkU7RUFDRSxrREFBQTtBSG9KSjtBR2xKRTtFQUNFLGdEQUFBO0FIb0pKO0FHbEpFO0VBSUUsNkNBQUE7QUhpSko7O0FJdk1BO0VBQ0UsV0FBQTtFQUNBLHVCQUFBO0VBQ0EsYUFBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7RUFDQSw2QkFBQTtFQUFBLHFCQUFBO0VBQ0EsMEJBQUE7TUFBQSxzQkFBQTtBSjBNRjtBSXhNRTtFQUNFLFdBQUE7RUFDQSxZQUFBO0FKME1KO0FJdk1FO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtBSnlNSjtBSXRNRTtFQUNFLFVBQUE7QUp3TUo7O0FLL05BO0VBQ0U7SUFDRSw0QkFBQTtZQUFBLG9CQUFBO0VMa09GO0VLaE9BO0lBQ0UsNEJBQUE7WUFBQSxvQkFBQTtFTGtPRjtBQUNGOztBS3hPQTtFQUNFO0lBQ0UsNEJBQUE7WUFBQSxvQkFBQTtFTGtPRjtFS2hPQTtJQUNFLDRCQUFBO1lBQUEsb0JBQUE7RUxrT0Y7QUFDRjtBSy9OQTtFQUNFLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLE9BQUE7RUFDQSxXQUFBO0VBQ0EsV0FBQTtFQUNBLGdDQUFBO0VBQ0EsWUFBQTtFQUNBLDhCQUFBO1VBQUEsc0JBQUE7QUxpT0Y7QUsvTkU7RUFDRSw0REFBQTtVQUFBLG9EQUFBO0FMaU9KO0FLOU5FO0VBQ0UsMENBQUE7RUFBQSxrQ0FBQTtFQUFBLDBCQUFBO0VBQUEsa0RBQUE7QUxnT0o7QUs3TkU7RUFDRSxRQUFBO0VBQ0EsYUFBQTtFQUNBLCtCQUFBO1VBQUEsdUJBQUE7QUwrTko7O0FNN1BBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSw4QkFBQTtVQUFBLHNCQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLHNEQUFBO0VBQ0EsaURBQUE7RUFDQSx1REFBQTtVQUFBLCtDQUFBO0FOZ1FGOztBT3BRQTtFQUNJO0lBSkEsc0VBQUE7WUFBQSw4REFBQTtFUDRRRjtFT2pRRTtJQUNJLFVBQUE7SUFDQSw0Q0FBQTtZQUFBLG9DQUFBO0VQbVFOO0VPalFFO0lBQ0ksVUFBQTtJQUNBLDJDQUFBO1lBQUEsbUNBQUE7RVBtUU47RU9qUUU7SUFDSSwwQ0FBQTtZQUFBLGtDQUFBO0VQbVFOO0VPalFFO0lBQ0ksMENBQUE7WUFBQSxrQ0FBQTtFUG1RTjtFT2pRRTtJQUNJLHVCQUFBO1lBQUEsZUFBQTtFUG1RTjtBQUNGOztBTzNSQTtFQUNJO0lBSkEsc0VBQUE7WUFBQSw4REFBQTtFUDRRRjtFT2pRRTtJQUNJLFVBQUE7SUFDQSw0Q0FBQTtZQUFBLG9DQUFBO0VQbVFOO0VPalFFO0lBQ0ksVUFBQTtJQUNBLDJDQUFBO1lBQUEsbUNBQUE7RVBtUU47RU9qUUU7SUFDSSwwQ0FBQTtZQUFBLGtDQUFBO0VQbVFOO0VPalFFO0lBQ0ksMENBQUE7WUFBQSxrQ0FBQTtFUG1RTjtFT2pRRTtJQUNJLHVCQUFBO1lBQUEsZUFBQTtFUG1RTjtBQUNGO0FPaFFBO0VBQ0k7SUFDSSxVQUFBO0lBQ0EsMkNBQUE7WUFBQSxtQ0FBQTtFUGtRTjtFT2hRRTtJQUNJLFVBQUE7SUFDQSw0Q0FBQTtZQUFBLG9DQUFBO0VQa1FOO0FBQ0Y7QU8xUUE7RUFDSTtJQUNJLFVBQUE7SUFDQSwyQ0FBQTtZQUFBLG1DQUFBO0VQa1FOO0VPaFFFO0lBQ0ksVUFBQTtJQUNBLDRDQUFBO1lBQUEsb0NBQUE7RVBrUU47QUFDRjtBTy9QQTtFQUNJO0lBMUNBLHNFQUFBO1lBQUEsOERBQUE7RVA0U0Y7RU8zUEU7SUFDSSxVQUFBO0lBQ0EsNkNBQUE7WUFBQSxxQ0FBQTtFUDZQTjtFTzNQRTtJQUNJLFVBQUE7SUFDQSwwQ0FBQTtZQUFBLGtDQUFBO0VQNlBOO0VPM1BFO0lBQ0ksMkNBQUE7WUFBQSxtQ0FBQTtFUDZQTjtFTzNQRTtJQUNJLHlDQUFBO1lBQUEsaUNBQUE7RVA2UE47RU8zUEU7SUFDSSx1QkFBQTtZQUFBLGVBQUE7RVA2UE47QUFDRjtBT3JSQTtFQUNJO0lBMUNBLHNFQUFBO1lBQUEsOERBQUE7RVA0U0Y7RU8zUEU7SUFDSSxVQUFBO0lBQ0EsNkNBQUE7WUFBQSxxQ0FBQTtFUDZQTjtFTzNQRTtJQUNJLFVBQUE7SUFDQSwwQ0FBQTtZQUFBLGtDQUFBO0VQNlBOO0VPM1BFO0lBQ0ksMkNBQUE7WUFBQSxtQ0FBQTtFUDZQTjtFTzNQRTtJQUNJLHlDQUFBO1lBQUEsaUNBQUE7RVA2UE47RU8zUEU7SUFDSSx1QkFBQTtZQUFBLGVBQUE7RVA2UE47QUFDRjtBTzFQQTtFQUNJO0lBQ0ksVUFBQTtJQUNBLDBDQUFBO1lBQUEsa0NBQUE7RVA0UE47RU8xUEU7SUFDSSxVQUFBO0lBQ0EsNkNBQUE7WUFBQSxxQ0FBQTtFUDRQTjtBQUNGO0FPcFFBO0VBQ0k7SUFDSSxVQUFBO0lBQ0EsMENBQUE7WUFBQSxrQ0FBQTtFUDRQTjtFTzFQRTtJQUNJLFVBQUE7SUFDQSw2Q0FBQTtZQUFBLHFDQUFBO0VQNFBOO0FBQ0Y7QU96UEE7RUFDSTtJQWhGQSxzRUFBQTtZQUFBLDhEQUFBO0VQNFVGO0VPclBFO0lBQ0ksVUFBQTtJQUNBLDRDQUFBO1lBQUEsb0NBQUE7RVB1UE47RU9yUEU7SUFDSSxVQUFBO0lBQ0EsMkNBQUE7WUFBQSxtQ0FBQTtFUHVQTjtFT3JQRTtJQUNJLDBDQUFBO1lBQUEsa0NBQUE7RVB1UE47RU9yUEU7SUFDSSwwQ0FBQTtZQUFBLGtDQUFBO0VQdVBOO0VPclBFO0lBQ0ksdUNBQUE7WUFBQSwrQkFBQTtFUHVQTjtBQUNGO0FPL1FBO0VBQ0k7SUFoRkEsc0VBQUE7WUFBQSw4REFBQTtFUDRVRjtFT3JQRTtJQUNJLFVBQUE7SUFDQSw0Q0FBQTtZQUFBLG9DQUFBO0VQdVBOO0VPclBFO0lBQ0ksVUFBQTtJQUNBLDJDQUFBO1lBQUEsbUNBQUE7RVB1UE47RU9yUEU7SUFDSSwwQ0FBQTtZQUFBLGtDQUFBO0VQdVBOO0VPclBFO0lBQ0ksMENBQUE7WUFBQSxrQ0FBQTtFUHVQTjtFT3JQRTtJQUNJLHVDQUFBO1lBQUEsK0JBQUE7RVB1UE47QUFDRjtBT3BQQTtFQUNJO0lBQ0ksMkNBQUE7WUFBQSxtQ0FBQTtFUHNQTjtFT3BQRTtJQUVJLFVBQUE7SUFDQSwwQ0FBQTtZQUFBLGtDQUFBO0VQcVBOO0VPblBFO0lBQ0ksVUFBQTtJQUNBLDZDQUFBO1lBQUEscUNBQUE7RVBxUE47QUFDRjtBT2pRQTtFQUNJO0lBQ0ksMkNBQUE7WUFBQSxtQ0FBQTtFUHNQTjtFT3BQRTtJQUVJLFVBQUE7SUFDQSwwQ0FBQTtZQUFBLGtDQUFBO0VQcVBOO0VPblBFO0lBQ0ksVUFBQTtJQUNBLDZDQUFBO1lBQUEscUNBQUE7RVBxUE47QUFDRjtBT2xQQTtFQUNJO0lBMUhBLHNFQUFBO1lBQUEsOERBQUE7RVArV0Y7RU85T0U7SUFDSSxVQUFBO0lBQ0EsNkNBQUE7WUFBQSxxQ0FBQTtFUGdQTjtFTzlPRTtJQUNJLFVBQUE7SUFDQSwwQ0FBQTtZQUFBLGtDQUFBO0VQZ1BOO0VPOU9FO0lBQ0ksMkNBQUE7WUFBQSxtQ0FBQTtFUGdQTjtFTzlPRTtJQUNJLHlDQUFBO1lBQUEsaUNBQUE7RVBnUE47RU85T0U7SUFDSSx1QkFBQTtZQUFBLGVBQUE7RVBnUE47QUFDRjtBT3hRQTtFQUNJO0lBMUhBLHNFQUFBO1lBQUEsOERBQUE7RVArV0Y7RU85T0U7SUFDSSxVQUFBO0lBQ0EsNkNBQUE7WUFBQSxxQ0FBQTtFUGdQTjtFTzlPRTtJQUNJLFVBQUE7SUFDQSwwQ0FBQTtZQUFBLGtDQUFBO0VQZ1BOO0VPOU9FO0lBQ0ksMkNBQUE7WUFBQSxtQ0FBQTtFUGdQTjtFTzlPRTtJQUNJLHlDQUFBO1lBQUEsaUNBQUE7RVBnUE47RU85T0U7SUFDSSx1QkFBQTtZQUFBLGVBQUE7RVBnUE47QUFDRjtBTzdPQTtFQUNJO0lBQ0ksMENBQUE7WUFBQSxrQ0FBQTtFUCtPTjtFTzdPRTtJQUVJLFVBQUE7SUFDQSwyQ0FBQTtZQUFBLG1DQUFBO0VQOE9OO0VPNU9FO0lBQ0ksVUFBQTtJQUNBLDRDQUFBO1lBQUEsb0NBQUE7RVA4T047QUFDRjtBTzFQQTtFQUNJO0lBQ0ksMENBQUE7WUFBQSxrQ0FBQTtFUCtPTjtFTzdPRTtJQUVJLFVBQUE7SUFDQSwyQ0FBQTtZQUFBLG1DQUFBO0VQOE9OO0VPNU9FO0lBQ0ksVUFBQTtJQUNBLDRDQUFBO1lBQUEsb0NBQUE7RVA4T047QUFDRjtBTzFPSTtFQUVJLDhDQUFBO1VBQUEsc0NBQUE7QVAyT1I7QU96T0k7RUFFSSwrQ0FBQTtVQUFBLHVDQUFBO0FQME9SO0FPeE9JO0VBQ0ksOENBQUE7VUFBQSxzQ0FBQTtBUDBPUjtBT3hPSTtFQUNJLDRDQUFBO1VBQUEsb0NBQUE7QVAwT1I7O0FPck9JO0VBRUksK0NBQUE7VUFBQSx1Q0FBQTtBUHVPUjtBT3JPSTtFQUVJLGdEQUFBO1VBQUEsd0NBQUE7QVBzT1I7QU9wT0k7RUFDSSw2Q0FBQTtVQUFBLHFDQUFBO0FQc09SO0FPcE9JO0VBQ0ksK0NBQUE7VUFBQSx1Q0FBQTtBUHNPUjs7QVF4YUE7RUFDSTtJQUNJLFVBQUE7SUFDQSx5Q0FBQTtZQUFBLGlDQUFBO0VSMmFOO0VRemFFO0lBQ0ksVUFBQTtFUjJhTjtBQUNGOztBUWxiQTtFQUNJO0lBQ0ksVUFBQTtJQUNBLHlDQUFBO1lBQUEsaUNBQUE7RVIyYU47RVF6YUU7SUFDSSxVQUFBO0VSMmFOO0FBQ0Y7QVF4YUE7RUFDSTtJQUNJLFVBQUE7RVIwYU47RVF4YUU7SUFDSSxVQUFBO0lBQ0EseUNBQUE7WUFBQSxpQ0FBQTtFUjBhTjtFUXhhRTtJQUNJLFVBQUE7RVIwYU47QUFDRjtBUXBiQTtFQUNJO0lBQ0ksVUFBQTtFUjBhTjtFUXhhRTtJQUNJLFVBQUE7SUFDQSx5Q0FBQTtZQUFBLGlDQUFBO0VSMGFOO0VReGFFO0lBQ0ksVUFBQTtFUjBhTjtBQUNGO0FRdmFBO0VBQ0ksd0NBQUE7VUFBQSxnQ0FBQTtBUnlhSjs7QVF0YUE7RUFDSSx5Q0FBQTtVQUFBLGlDQUFBO0FSeWFKOztBU3JjQTtFQUNJO0lBQ0ksOERBQUE7WUFBQSxzREFBQTtJQUNBLDBDQUFBO1lBQUEsa0NBQUE7SUFDQSxVQUFBO0VUd2NOO0VTdGNFO0lBQ0ksK0RBQUE7WUFBQSx1REFBQTtJQUNBLDBDQUFBO1lBQUEsa0NBQUE7RVR3Y047RVN0Y0U7SUFDSSw4REFBQTtZQUFBLHNEQUFBO0lBQ0EsVUFBQTtFVHdjTjtFU3RjRTtJQUNJLDhEQUFBO1lBQUEsc0RBQUE7RVR3Y047RVN0Y0U7SUFDSSxxQ0FBQTtZQUFBLDZCQUFBO0VUd2NOO0FBQ0Y7O0FTM2RBO0VBQ0k7SUFDSSw4REFBQTtZQUFBLHNEQUFBO0lBQ0EsMENBQUE7WUFBQSxrQ0FBQTtJQUNBLFVBQUE7RVR3Y047RVN0Y0U7SUFDSSwrREFBQTtZQUFBLHVEQUFBO0lBQ0EsMENBQUE7WUFBQSxrQ0FBQTtFVHdjTjtFU3RjRTtJQUNJLDhEQUFBO1lBQUEsc0RBQUE7SUFDQSxVQUFBO0VUd2NOO0VTdGNFO0lBQ0ksOERBQUE7WUFBQSxzREFBQTtFVHdjTjtFU3RjRTtJQUNJLHFDQUFBO1lBQUEsNkJBQUE7RVR3Y047QUFDRjtBU3JjQTtFQUNJO0lBQ0kscUNBQUE7WUFBQSw2QkFBQTtFVHVjTjtFU3JjRTtJQUNJLCtEQUFBO1lBQUEsdURBQUE7SUFDQSxVQUFBO0VUdWNOO0VTcmNFO0lBQ0ksOERBQUE7WUFBQSxzREFBQTtJQUNBLFVBQUE7RVR1Y047QUFDRjtBU2xkQTtFQUNJO0lBQ0kscUNBQUE7WUFBQSw2QkFBQTtFVHVjTjtFU3JjRTtJQUNJLCtEQUFBO1lBQUEsdURBQUE7SUFDQSxVQUFBO0VUdWNOO0VTcmNFO0lBQ0ksOERBQUE7WUFBQSxzREFBQTtJQUNBLFVBQUE7RVR1Y047QUFDRjtBU3BjQTtFQUNJLHdDQUFBO1VBQUEsZ0NBQUE7QVRzY0o7O0FTbmNBO0VBQ0kseUNBQUE7VUFBQSxpQ0FBQTtBVHNjSjs7QVUzZUE7RUFDSTtJQUNJLDBDQUFBO1lBQUEsa0NBQUE7SUFDQSxtQkFBQTtFVjhlTjtFVTVlRTtJQVJBLHVDQUFBO1lBQUEsK0JBQUE7RVZ1ZkY7QUFDRjs7QVVyZkE7RUFDSTtJQUNJLDBDQUFBO1lBQUEsa0NBQUE7SUFDQSxtQkFBQTtFVjhlTjtFVTVlRTtJQVJBLHVDQUFBO1lBQUEsK0JBQUE7RVZ1ZkY7QUFDRjtBVTNlQTtFQUNJO0lBQ0ksMkNBQUE7WUFBQSxtQ0FBQTtJQUNBLG1CQUFBO0VWNmVOO0VVM2VFO0lBbEJBLHVDQUFBO1lBQUEsK0JBQUE7RVZnZ0JGO0FBQ0Y7QVVwZkE7RUFDSTtJQUNJLDJDQUFBO1lBQUEsbUNBQUE7SUFDQSxtQkFBQTtFVjZlTjtFVTNlRTtJQWxCQSx1Q0FBQTtZQUFBLCtCQUFBO0VWZ2dCRjtBQUNGO0FVMWVBO0VBQ0k7SUFDSSwwQ0FBQTtZQUFBLGtDQUFBO0lBQ0EsbUJBQUE7RVY0ZU47RVUxZUU7SUE1QkEsdUNBQUE7WUFBQSwrQkFBQTtFVnlnQkY7QUFDRjtBVW5mQTtFQUNJO0lBQ0ksMENBQUE7WUFBQSxrQ0FBQTtJQUNBLG1CQUFBO0VWNGVOO0VVMWVFO0lBNUJBLHVDQUFBO1lBQUEsK0JBQUE7RVZ5Z0JGO0FBQ0Y7QVV6ZUE7RUFDSTtJQUNJLDJDQUFBO1lBQUEsbUNBQUE7SUFDQSxtQkFBQTtFVjJlTjtFVXplRTtJQXRDQSx1Q0FBQTtZQUFBLCtCQUFBO0VWa2hCRjtBQUNGO0FVbGZBO0VBQ0k7SUFDSSwyQ0FBQTtZQUFBLG1DQUFBO0lBQ0EsbUJBQUE7RVYyZU47RVV6ZUU7SUF0Q0EsdUNBQUE7WUFBQSwrQkFBQTtFVmtoQkY7QUFDRjtBVXhlQTtFQUNJO0lBNUNBLHVDQUFBO1lBQUEsK0JBQUE7RVZ1aEJGO0VVeGVFO0lBQ0ksa0JBQUE7SUFDQSwwQ0FBQTtZQUFBLGtDQUFBO0VWMGVOO0FBQ0Y7QVVqZkE7RUFDSTtJQTVDQSx1Q0FBQTtZQUFBLCtCQUFBO0VWdWhCRjtFVXhlRTtJQUNJLGtCQUFBO0lBQ0EsMENBQUE7WUFBQSxrQ0FBQTtFVjBlTjtBQUNGO0FVdmVBO0VBQ0k7SUF0REEsdUNBQUE7WUFBQSwrQkFBQTtFVmdpQkY7RVV2ZUU7SUFDSSxrQkFBQTtJQUNBLDJDQUFBO1lBQUEsbUNBQUE7RVZ5ZU47QUFDRjtBVWhmQTtFQUNJO0lBdERBLHVDQUFBO1lBQUEsK0JBQUE7RVZnaUJGO0VVdmVFO0lBQ0ksa0JBQUE7SUFDQSwyQ0FBQTtZQUFBLG1DQUFBO0VWeWVOO0FBQ0Y7QVV0ZUE7RUFDSTtJQWhFQSx1Q0FBQTtZQUFBLCtCQUFBO0VWeWlCRjtFVXRlRTtJQUNJLGtCQUFBO0lBQ0EsMkNBQUE7WUFBQSxtQ0FBQTtFVndlTjtBQUNGO0FVL2VBO0VBQ0k7SUFoRUEsdUNBQUE7WUFBQSwrQkFBQTtFVnlpQkY7RVV0ZUU7SUFDSSxrQkFBQTtJQUNBLDJDQUFBO1lBQUEsbUNBQUE7RVZ3ZU47QUFDRjtBVXJlQTtFQUNJO0lBMUVBLHVDQUFBO1lBQUEsK0JBQUE7RVZrakJGO0VVcmVFO0lBQ0ksa0JBQUE7SUFDQSw0Q0FBQTtZQUFBLG9DQUFBO0VWdWVOO0FBQ0Y7QVU5ZUE7RUFDSTtJQTFFQSx1Q0FBQTtZQUFBLCtCQUFBO0VWa2pCRjtFVXJlRTtJQUNJLGtCQUFBO0lBQ0EsNENBQUE7WUFBQSxvQ0FBQTtFVnVlTjtBQUNGO0FVbmVJO0VBRUksNkNBQUE7VUFBQSxxQ0FBQTtBVm9lUjtBVWxlSTtFQUVJLDhDQUFBO1VBQUEsc0NBQUE7QVZtZVI7QVVqZUk7RUFDSSw2Q0FBQTtVQUFBLHFDQUFBO0FWbWVSO0FVamVJO0VBQ0ksMkNBQUE7VUFBQSxtQ0FBQTtBVm1lUjs7QVU5ZEk7RUFFSSw4Q0FBQTtVQUFBLHNDQUFBO0FWZ2VSO0FVOWRJO0VBRUksK0NBQUE7VUFBQSx1Q0FBQTtBVitkUjtBVTdkSTtFQUNJLDRDQUFBO1VBQUEsb0NBQUE7QVYrZFI7QVU3ZEk7RUFDSSw4Q0FBQTtVQUFBLHNDQUFBO0FWK2RSOztBV2psQkE7RUFDRTtJQUNFLCtCQUFBO1lBQUEsdUJBQUE7RVhvbEJGO0VXbGxCQTtJQUNFLGlDQUFBO1lBQUEseUJBQUE7RVhvbEJGO0FBQ0Y7O0FXMWxCQTtFQUNFO0lBQ0UsK0JBQUE7WUFBQSx1QkFBQTtFWG9sQkY7RVdsbEJBO0lBQ0UsaUNBQUE7WUFBQSx5QkFBQTtFWG9sQkY7QUFDRjs7QUFZQSw0Q0FBNENcIixcInNvdXJjZVJvb3RcIjpcIlwifV0pO1xuLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQgX19fQ1NTX0xPQURFUl9FWFBPUlRfX187XG4iLCIvLyBFeHBvcnRzXG5leHBvcnQgZGVmYXVsdCB7XG5cdFwiaGVhZGVyXCI6IFwic3JjLWFwcC1zdHlsZXMtbW9kdWxlX19oZWFkZXJcIixcblx0XCJsb2dvXCI6IFwic3JjLWFwcC1zdHlsZXMtbW9kdWxlX19sb2dvXCIsXG5cdFwic2l0ZU5hbWVcIjogXCJzcmMtYXBwLXN0eWxlcy1tb2R1bGVfX3NpdGVOYW1lXCIsXG5cdFwic2l0ZURlc2NyaXB0aW9uXCI6IFwic3JjLWFwcC1zdHlsZXMtbW9kdWxlX19zaXRlRGVzY3JpcHRpb25cIlxufTtcbiIsIi8vIEV4cG9ydHNcbmV4cG9ydCBkZWZhdWx0IHtcblx0XCJqYXYtZ2FtZS1saXN0XCI6IFwic3JjLWNvbXBvbmVudHMtQWRkRW52aWUtc3R5bGVzLW1vZHVsZV9famF2LWdhbWUtbGlzdFwiXG59O1xuIiwiLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQge1xuXHRcImphdi1nYW1lLWxpc3RcIjogXCJzcmMtY29tcG9uZW50cy1KZXVKYXZMaXN0LXN0eWxlcy1tb2R1bGVfX2phdi1nYW1lLWxpc3RcIlxufTtcbiIsIi8vIEV4cG9ydHNcbmV4cG9ydCBkZWZhdWx0IHtcblx0XCJsb2FkaW5nXCI6IFwic3JjLWNvbXBvbmVudHMtTG9hZGluZy1zdHlsZXMtbW9kdWxlX19sb2FkaW5nXCJcbn07XG4iLCIvLyBFeHBvcnRzXG5leHBvcnQgZGVmYXVsdCB7XG5cdFwibWVtYnJlLWNhcmRcIjogXCJzcmMtY29tcG9uZW50cy1NZW1icmVJbmZvLXN0eWxlcy1tb2R1bGVfX21lbWJyZS1jYXJkXCJcbn07XG4iLCIvLyBFeHBvcnRzXG5leHBvcnQgZGVmYXVsdCB7XG5cdFwidXNlci1saXN0XCI6IFwic3JjLWNvbXBvbmVudHMtTWVtYnJlTGlzdC1zdHlsZXMtbW9kdWxlX191c2VyLWxpc3RcIlxufTtcbiIsIi8vIEV4cG9ydHNcbmV4cG9ydCBkZWZhdWx0IHtcblx0XCJqYXYtZ2FtZS1saXN0XCI6IFwic3JjLWNvbXBvbmVudHMtTWVtYnJlU2V0LXN0eWxlcy1tb2R1bGVfX2phdi1nYW1lLWxpc3RcIlxufTtcbiIsIi8vIEV4cG9ydHNcbmV4cG9ydCBkZWZhdWx0IHtcblx0XCJob21lXCI6IFwic3JjLXBhZ2VzLUhvbWUtc3R5bGVzLW1vZHVsZV9faG9tZVwiXG59O1xuIiwiLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQge1xuXHRcIm1lbWJyZVwiOiBcInNyYy1wYWdlcy1NZW1icmVQYWdlLXN0eWxlcy1tb2R1bGVfX21lbWJyZVwiXG59O1xuIiwiLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQge1xuXHRcIm5vdC1mb3VuZFwiOiBcInNyYy1wYWdlcy1Ob3RGb3VuZC1zdHlsZXMtbW9kdWxlX19ub3QtZm91bmRcIlxufTtcbiIsIlwidXNlIHN0cmljdFwiO1xuXG4vKlxuICBNSVQgTGljZW5zZSBodHRwOi8vd3d3Lm9wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL21pdC1saWNlbnNlLnBocFxuICBBdXRob3IgVG9iaWFzIEtvcHBlcnMgQHNva3JhXG4qL1xuLy8gY3NzIGJhc2UgY29kZSwgaW5qZWN0ZWQgYnkgdGhlIGNzcy1sb2FkZXJcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBmdW5jLW5hbWVzXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChjc3NXaXRoTWFwcGluZ1RvU3RyaW5nKSB7XG4gIHZhciBsaXN0ID0gW107IC8vIHJldHVybiB0aGUgbGlzdCBvZiBtb2R1bGVzIGFzIGNzcyBzdHJpbmdcblxuICBsaXN0LnRvU3RyaW5nID0gZnVuY3Rpb24gdG9TdHJpbmcoKSB7XG4gICAgcmV0dXJuIHRoaXMubWFwKGZ1bmN0aW9uIChpdGVtKSB7XG4gICAgICB2YXIgY29udGVudCA9IGNzc1dpdGhNYXBwaW5nVG9TdHJpbmcoaXRlbSk7XG5cbiAgICAgIGlmIChpdGVtWzJdKSB7XG4gICAgICAgIHJldHVybiBcIkBtZWRpYSBcIi5jb25jYXQoaXRlbVsyXSwgXCIge1wiKS5jb25jYXQoY29udGVudCwgXCJ9XCIpO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gY29udGVudDtcbiAgICB9KS5qb2luKFwiXCIpO1xuICB9OyAvLyBpbXBvcnQgYSBsaXN0IG9mIG1vZHVsZXMgaW50byB0aGUgbGlzdFxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZnVuYy1uYW1lc1xuXG5cbiAgbGlzdC5pID0gZnVuY3Rpb24gKG1vZHVsZXMsIG1lZGlhUXVlcnksIGRlZHVwZSkge1xuICAgIGlmICh0eXBlb2YgbW9kdWxlcyA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXBhcmFtLXJlYXNzaWduXG4gICAgICBtb2R1bGVzID0gW1tudWxsLCBtb2R1bGVzLCBcIlwiXV07XG4gICAgfVxuXG4gICAgdmFyIGFscmVhZHlJbXBvcnRlZE1vZHVsZXMgPSB7fTtcblxuICAgIGlmIChkZWR1cGUpIHtcbiAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdGhpcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcHJlZmVyLWRlc3RydWN0dXJpbmdcbiAgICAgICAgdmFyIGlkID0gdGhpc1tpXVswXTtcblxuICAgICAgICBpZiAoaWQgIT0gbnVsbCkge1xuICAgICAgICAgIGFscmVhZHlJbXBvcnRlZE1vZHVsZXNbaWRdID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIGZvciAodmFyIF9pID0gMDsgX2kgPCBtb2R1bGVzLmxlbmd0aDsgX2krKykge1xuICAgICAgdmFyIGl0ZW0gPSBbXS5jb25jYXQobW9kdWxlc1tfaV0pO1xuXG4gICAgICBpZiAoZGVkdXBlICYmIGFscmVhZHlJbXBvcnRlZE1vZHVsZXNbaXRlbVswXV0pIHtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWNvbnRpbnVlXG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuXG4gICAgICBpZiAobWVkaWFRdWVyeSkge1xuICAgICAgICBpZiAoIWl0ZW1bMl0pIHtcbiAgICAgICAgICBpdGVtWzJdID0gbWVkaWFRdWVyeTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBpdGVtWzJdID0gXCJcIi5jb25jYXQobWVkaWFRdWVyeSwgXCIgYW5kIFwiKS5jb25jYXQoaXRlbVsyXSk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgbGlzdC5wdXNoKGl0ZW0pO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gbGlzdDtcbn07IiwiXCJ1c2Ugc3RyaWN0XCI7XG5cbmZ1bmN0aW9uIF9zbGljZWRUb0FycmF5KGFyciwgaSkgeyByZXR1cm4gX2FycmF5V2l0aEhvbGVzKGFycikgfHwgX2l0ZXJhYmxlVG9BcnJheUxpbWl0KGFyciwgaSkgfHwgX3Vuc3VwcG9ydGVkSXRlcmFibGVUb0FycmF5KGFyciwgaSkgfHwgX25vbkl0ZXJhYmxlUmVzdCgpOyB9XG5cbmZ1bmN0aW9uIF9ub25JdGVyYWJsZVJlc3QoKSB7IHRocm93IG5ldyBUeXBlRXJyb3IoXCJJbnZhbGlkIGF0dGVtcHQgdG8gZGVzdHJ1Y3R1cmUgbm9uLWl0ZXJhYmxlIGluc3RhbmNlLlxcbkluIG9yZGVyIHRvIGJlIGl0ZXJhYmxlLCBub24tYXJyYXkgb2JqZWN0cyBtdXN0IGhhdmUgYSBbU3ltYm9sLml0ZXJhdG9yXSgpIG1ldGhvZC5cIik7IH1cblxuZnVuY3Rpb24gX3Vuc3VwcG9ydGVkSXRlcmFibGVUb0FycmF5KG8sIG1pbkxlbikgeyBpZiAoIW8pIHJldHVybjsgaWYgKHR5cGVvZiBvID09PSBcInN0cmluZ1wiKSByZXR1cm4gX2FycmF5TGlrZVRvQXJyYXkobywgbWluTGVuKTsgdmFyIG4gPSBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwobykuc2xpY2UoOCwgLTEpOyBpZiAobiA9PT0gXCJPYmplY3RcIiAmJiBvLmNvbnN0cnVjdG9yKSBuID0gby5jb25zdHJ1Y3Rvci5uYW1lOyBpZiAobiA9PT0gXCJNYXBcIiB8fCBuID09PSBcIlNldFwiKSByZXR1cm4gQXJyYXkuZnJvbShvKTsgaWYgKG4gPT09IFwiQXJndW1lbnRzXCIgfHwgL14oPzpVaXxJKW50KD86OHwxNnwzMikoPzpDbGFtcGVkKT9BcnJheSQvLnRlc3QobikpIHJldHVybiBfYXJyYXlMaWtlVG9BcnJheShvLCBtaW5MZW4pOyB9XG5cbmZ1bmN0aW9uIF9hcnJheUxpa2VUb0FycmF5KGFyciwgbGVuKSB7IGlmIChsZW4gPT0gbnVsbCB8fCBsZW4gPiBhcnIubGVuZ3RoKSBsZW4gPSBhcnIubGVuZ3RoOyBmb3IgKHZhciBpID0gMCwgYXJyMiA9IG5ldyBBcnJheShsZW4pOyBpIDwgbGVuOyBpKyspIHsgYXJyMltpXSA9IGFycltpXTsgfSByZXR1cm4gYXJyMjsgfVxuXG5mdW5jdGlvbiBfaXRlcmFibGVUb0FycmF5TGltaXQoYXJyLCBpKSB7IHZhciBfaSA9IGFyciAmJiAodHlwZW9mIFN5bWJvbCAhPT0gXCJ1bmRlZmluZWRcIiAmJiBhcnJbU3ltYm9sLml0ZXJhdG9yXSB8fCBhcnJbXCJAQGl0ZXJhdG9yXCJdKTsgaWYgKF9pID09IG51bGwpIHJldHVybjsgdmFyIF9hcnIgPSBbXTsgdmFyIF9uID0gdHJ1ZTsgdmFyIF9kID0gZmFsc2U7IHZhciBfcywgX2U7IHRyeSB7IGZvciAoX2kgPSBfaS5jYWxsKGFycik7ICEoX24gPSAoX3MgPSBfaS5uZXh0KCkpLmRvbmUpOyBfbiA9IHRydWUpIHsgX2Fyci5wdXNoKF9zLnZhbHVlKTsgaWYgKGkgJiYgX2Fyci5sZW5ndGggPT09IGkpIGJyZWFrOyB9IH0gY2F0Y2ggKGVycikgeyBfZCA9IHRydWU7IF9lID0gZXJyOyB9IGZpbmFsbHkgeyB0cnkgeyBpZiAoIV9uICYmIF9pW1wicmV0dXJuXCJdICE9IG51bGwpIF9pW1wicmV0dXJuXCJdKCk7IH0gZmluYWxseSB7IGlmIChfZCkgdGhyb3cgX2U7IH0gfSByZXR1cm4gX2FycjsgfVxuXG5mdW5jdGlvbiBfYXJyYXlXaXRoSG9sZXMoYXJyKSB7IGlmIChBcnJheS5pc0FycmF5KGFycikpIHJldHVybiBhcnI7IH1cblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBjc3NXaXRoTWFwcGluZ1RvU3RyaW5nKGl0ZW0pIHtcbiAgdmFyIF9pdGVtID0gX3NsaWNlZFRvQXJyYXkoaXRlbSwgNCksXG4gICAgICBjb250ZW50ID0gX2l0ZW1bMV0sXG4gICAgICBjc3NNYXBwaW5nID0gX2l0ZW1bM107XG5cbiAgaWYgKCFjc3NNYXBwaW5nKSB7XG4gICAgcmV0dXJuIGNvbnRlbnQ7XG4gIH1cblxuICBpZiAodHlwZW9mIGJ0b2EgPT09IFwiZnVuY3Rpb25cIikge1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby11bmRlZlxuICAgIHZhciBiYXNlNjQgPSBidG9hKHVuZXNjYXBlKGVuY29kZVVSSUNvbXBvbmVudChKU09OLnN0cmluZ2lmeShjc3NNYXBwaW5nKSkpKTtcbiAgICB2YXIgZGF0YSA9IFwic291cmNlTWFwcGluZ1VSTD1kYXRhOmFwcGxpY2F0aW9uL2pzb247Y2hhcnNldD11dGYtODtiYXNlNjQsXCIuY29uY2F0KGJhc2U2NCk7XG4gICAgdmFyIHNvdXJjZU1hcHBpbmcgPSBcIi8qIyBcIi5jb25jYXQoZGF0YSwgXCIgKi9cIik7XG4gICAgdmFyIHNvdXJjZVVSTHMgPSBjc3NNYXBwaW5nLnNvdXJjZXMubWFwKGZ1bmN0aW9uIChzb3VyY2UpIHtcbiAgICAgIHJldHVybiBcIi8qIyBzb3VyY2VVUkw9XCIuY29uY2F0KGNzc01hcHBpbmcuc291cmNlUm9vdCB8fCBcIlwiKS5jb25jYXQoc291cmNlLCBcIiAqL1wiKTtcbiAgICB9KTtcbiAgICByZXR1cm4gW2NvbnRlbnRdLmNvbmNhdChzb3VyY2VVUkxzKS5jb25jYXQoW3NvdXJjZU1hcHBpbmddKS5qb2luKFwiXFxuXCIpO1xuICB9XG5cbiAgcmV0dXJuIFtjb250ZW50XS5qb2luKFwiXFxuXCIpO1xufTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAYmFiZWwvcnVudGltZS9oZWxwZXJzL2FzeW5jVG9HZW5lcmF0b3JcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9jbGFzc0NhbGxDaGVja1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAYmFiZWwvcnVudGltZS9oZWxwZXJzL2NyZWF0ZUNsYXNzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBiYWJlbC9ydW50aW1lL2hlbHBlcnMvZGVmaW5lUHJvcGVydHlcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy9nZXRQcm90b3R5cGVPZlwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAYmFiZWwvcnVudGltZS9oZWxwZXJzL2luaGVyaXRzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBiYWJlbC9ydW50aW1lL2hlbHBlcnMvcG9zc2libGVDb25zdHJ1Y3RvclJldHVyblwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAYmFiZWwvcnVudGltZS9oZWxwZXJzL3NsaWNlZFRvQXJyYXlcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQGJhYmVsL3J1bnRpbWUvaGVscGVycy90b0NvbnN1bWFibGVBcnJheVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAYmFiZWwvcnVudGltZS9yZWdlbmVyYXRvclwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbG9hZGFibGUvc2VydmVyXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBsb2FkYWJsZS93ZWJwYWNrLXBsdWdpblwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAcG1tbXdoL3JlYWN0LXJlZnJlc2gtd2VicGFjay1wbHVnaW5cIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQHJlZHV4anMvdG9vbGtpdFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJheGlvc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJiY3J5cHRcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiY2hhbGtcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiY29tcHJlc3Npb25cIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiY29tcHJlc3Npb24td2VicGFjay1wbHVnaW5cIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiY29ubmVjdGVkLXJlYWN0LXJvdXRlclwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJjc3MtbWluaW1pemVyLXdlYnBhY2stcGx1Z2luXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImV4cHJlc3NcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiZm9yay10cy1jaGVja2VyLXdlYnBhY2stcGx1Z2luXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImZzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImdvb2dsZS1zcHJlYWRzaGVldFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJoZWxtZXRcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiaGlzdG9yeVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJocHBcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiaHRtbC1taW5pZmllclwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJodHRwc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJpbWFnZS1taW5pbWl6ZXItd2VicGFjay1wbHVnaW5cIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwianNvbndlYnRva2VuXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImxvZGFzaFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJtaW5pLWNzcy1leHRyYWN0LXBsdWdpblwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJtb3JnYW5cIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3RcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QtZG9tL3NlcnZlclwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC1oZWxtZXRcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QtcmVkdXhcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3Qtcm91dGVyLWNvbmZpZ1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC1yb3V0ZXItZG9tXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0LXRvYXN0aWZ5XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0L2pzeC1ydW50aW1lXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInNlcmlhbGl6ZS1qYXZhc2NyaXB0XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInNlcnZlLWZhdmljb25cIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwidGVyc2VyLXdlYnBhY2stcGx1Z2luXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIndlYnBhY2tcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwid2VicGFjay1idW5kbGUtYW5hbHl6ZXJcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwid2VicGFjay1kZXYtbWlkZGxld2FyZVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJ3ZWJwYWNrLWhvdC1taWRkbGV3YXJlXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIndlYnBhY2stbWFuaWZlc3QtcGx1Z2luXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIndlYnBhY2stbWVyZ2VcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQGxvYWRhYmxlL2NvbXBvbmVudFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJodHRwXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInBhdGhcIik7IiwiLy8gVGhlIG1vZHVsZSBjYWNoZVxudmFyIF9fd2VicGFja19tb2R1bGVfY2FjaGVfXyA9IHt9O1xuXG4vLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcblx0dmFyIGNhY2hlZE1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG5cdGlmIChjYWNoZWRNb2R1bGUgIT09IHVuZGVmaW5lZCkge1xuXHRcdHJldHVybiBjYWNoZWRNb2R1bGUuZXhwb3J0cztcblx0fVxuXHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuXHR2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHtcblx0XHRpZDogbW9kdWxlSWQsXG5cdFx0Ly8gbm8gbW9kdWxlLmxvYWRlZCBuZWVkZWRcblx0XHRleHBvcnRzOiB7fVxuXHR9O1xuXG5cdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuXHRfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXShtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuXHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuXHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG59XG5cbi8vIGV4cG9zZSB0aGUgbW9kdWxlcyBvYmplY3QgKF9fd2VicGFja19tb2R1bGVzX18pXG5fX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBfX3dlYnBhY2tfbW9kdWxlc19fO1xuXG4iLCIvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuX193ZWJwYWNrX3JlcXVpcmVfXy5uID0gKG1vZHVsZSkgPT4ge1xuXHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cblx0XHQoKSA9PiAobW9kdWxlWydkZWZhdWx0J10pIDpcblx0XHQoKSA9PiAobW9kdWxlKTtcblx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgeyBhOiBnZXR0ZXIgfSk7XG5cdHJldHVybiBnZXR0ZXI7XG59OyIsIi8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb25zIGZvciBoYXJtb255IGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uZCA9IChleHBvcnRzLCBkZWZpbml0aW9uKSA9PiB7XG5cdGZvcih2YXIga2V5IGluIGRlZmluaXRpb24pIHtcblx0XHRpZihfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZGVmaW5pdGlvbiwga2V5KSAmJiAhX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIGtleSkpIHtcblx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBrZXksIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBkZWZpbml0aW9uW2tleV0gfSk7XG5cdFx0fVxuXHR9XG59OyIsIl9fd2VicGFja19yZXF1aXJlX18uZiA9IHt9O1xuLy8gVGhpcyBmaWxlIGNvbnRhaW5zIG9ubHkgdGhlIGVudHJ5IGNodW5rLlxuLy8gVGhlIGNodW5rIGxvYWRpbmcgZnVuY3Rpb24gZm9yIGFkZGl0aW9uYWwgY2h1bmtzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLmUgPSAoY2h1bmtJZCkgPT4ge1xuXHRyZXR1cm4gUHJvbWlzZS5hbGwoT2JqZWN0LmtleXMoX193ZWJwYWNrX3JlcXVpcmVfXy5mKS5yZWR1Y2UoKHByb21pc2VzLCBrZXkpID0+IHtcblx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLmZba2V5XShjaHVua0lkLCBwcm9taXNlcyk7XG5cdFx0cmV0dXJuIHByb21pc2VzO1xuXHR9LCBbXSkpO1xufTsiLCIvLyBUaGlzIGZ1bmN0aW9uIGFsbG93IHRvIHJlZmVyZW5jZSBhc3luYyBjaHVua3Ncbl9fd2VicGFja19yZXF1aXJlX18udSA9IChjaHVua0lkKSA9PiB7XG5cdC8vIHJldHVybiB1cmwgZm9yIGZpbGVuYW1lcyBiYXNlZCBvbiB0ZW1wbGF0ZVxuXHRyZXR1cm4gXCJcIiArIGNodW5rSWQgKyBcIi5qc1wiO1xufTsiLCJfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSAob2JqLCBwcm9wKSA9PiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iaiwgcHJvcCkpIiwiLy8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5yID0gKGV4cG9ydHMpID0+IHtcblx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG5cdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG5cdH1cblx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbn07IiwiLy8gbm8gYmFzZVVSSVxuXG4vLyBvYmplY3QgdG8gc3RvcmUgbG9hZGVkIGNodW5rc1xuLy8gXCIxXCIgbWVhbnMgXCJsb2FkZWRcIiwgb3RoZXJ3aXNlIG5vdCBsb2FkZWQgeWV0XG52YXIgaW5zdGFsbGVkQ2h1bmtzID0ge1xuXHRcIm1haW5cIjogMVxufTtcblxuLy8gbm8gb24gY2h1bmtzIGxvYWRlZFxuXG52YXIgaW5zdGFsbENodW5rID0gKGNodW5rKSA9PiB7XG5cdHZhciBtb3JlTW9kdWxlcyA9IGNodW5rLm1vZHVsZXMsIGNodW5rSWRzID0gY2h1bmsuaWRzLCBydW50aW1lID0gY2h1bmsucnVudGltZTtcblx0Zm9yKHZhciBtb2R1bGVJZCBpbiBtb3JlTW9kdWxlcykge1xuXHRcdGlmKF9fd2VicGFja19yZXF1aXJlX18ubyhtb3JlTW9kdWxlcywgbW9kdWxlSWQpKSB7XG5cdFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLm1bbW9kdWxlSWRdID0gbW9yZU1vZHVsZXNbbW9kdWxlSWRdO1xuXHRcdH1cblx0fVxuXHRpZihydW50aW1lKSBydW50aW1lKF9fd2VicGFja19yZXF1aXJlX18pO1xuXHRmb3IodmFyIGkgPSAwOyBpIDwgY2h1bmtJZHMubGVuZ3RoOyBpKyspXG5cdFx0aW5zdGFsbGVkQ2h1bmtzW2NodW5rSWRzW2ldXSA9IDE7XG5cbn07XG5cbi8vIHJlcXVpcmUoKSBjaHVuayBsb2FkaW5nIGZvciBqYXZhc2NyaXB0XG5fX3dlYnBhY2tfcmVxdWlyZV9fLmYucmVxdWlyZSA9IChjaHVua0lkLCBwcm9taXNlcykgPT4ge1xuXHQvLyBcIjFcIiBpcyB0aGUgc2lnbmFsIGZvciBcImFscmVhZHkgbG9hZGVkXCJcblx0aWYoIWluc3RhbGxlZENodW5rc1tjaHVua0lkXSkge1xuXHRcdGlmKHRydWUpIHsgLy8gYWxsIGNodW5rcyBoYXZlIEpTXG5cdFx0XHRpbnN0YWxsQ2h1bmsocmVxdWlyZShcIi4vXCIgKyBfX3dlYnBhY2tfcmVxdWlyZV9fLnUoY2h1bmtJZCkpKTtcblx0XHR9IGVsc2UgaW5zdGFsbGVkQ2h1bmtzW2NodW5rSWRdID0gMTtcblx0fVxufTtcblxuLy8gbm8gZXh0ZXJuYWwgaW5zdGFsbCBjaHVua1xuXG4vLyBubyBITVJcblxuLy8gbm8gSE1SIG1hbmlmZXN0IiwiIiwiLy8gbW9kdWxlIGZhY3RvcmllcyBhcmUgdXNlZCBzbyBlbnRyeSBpbmxpbmluZyBpcyBkaXNhYmxlZFxuLy8gc3RhcnR1cFxuLy8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG52YXIgX193ZWJwYWNrX2V4cG9ydHNfXyA9IF9fd2VicGFja19yZXF1aXJlX18oXCIuL3NyYy9zZXJ2ZXIvaW5kZXgudHNcIik7XG4iLCIiXSwibmFtZXMiOlsiTGluayIsInJlbmRlclJvdXRlcyIsIkhlbG1ldCIsIlRvYXN0Q29udGFpbmVyIiwiY29uZmlnIiwic3R5bGVzIiwiQXBwIiwicm91dGUiLCJBUFAiLCJoZWFkZXIiLCJsb2dvIiwic2l0ZU5hbWUiLCJ0aXRsZSIsInNpdGVEZXNjcmlwdGlvbiIsImRlc2NyaXB0aW9uIiwicm91dGVzIiwiUmVhY3QiLCJ1c2VTdGF0ZSIsIm1lbW8iLCJ0b2FzdCIsImZldGNoRW52aWVBZGQiLCJBZGRFbnZpZSIsImRpc3BhdGNoIiwiZG9tYWluZSIsInNldERvbWFpbmUiLCJlbnZpZXMiLCJzZXRFbnZpZXMiLCJwcmVjaXNpb25zIiwic2V0UHJlY2lzaW9ucyIsImVxdWlwZXMiLCJzZXRFcXVpcGVzIiwiZGF0ZUFqb3V0Iiwic2V0RGF0ZUFqb3V0Iiwib25Eb21haW5lQ2hhbmdlZCIsImUiLCJ0YXJnZXQiLCJ2YWx1ZSIsIm9uRW52aWVzQ2hhbmdlZCIsIm9uUHJlY2lzaW9uc0NoYW5nZWQiLCJvbkVxdWlwZXNDaGFuZ2VkIiwic3BsaXQiLCJvbkRhdGVBam91dENoYW5nZWQiLCJvblNhdmVQb3N0Q2xpY2tlZCIsIndhcm5pbmciLCJwb3NpdGlvbiIsImF1dG9DbG9zZSIsImhpZGVQcm9ncmVzc0JhciIsImNsb3NlT25DbGljayIsInBhdXNlT25Ib3ZlciIsImRyYWdnYWJsZSIsInByb2dyZXNzIiwidW5kZWZpbmVkIiwiRW52aWVMaXN0Iiwiam9pbiIsIlB1cmVDb21wb25lbnQiLCJFcnJvckJvdW5kYXJ5IiwicHJvcHMiLCJzdGF0ZSIsImVycm9yIiwiZXJyb3JJbmZvIiwic2V0U3RhdGUiLCJjaGlsZHJlbiIsIndoaXRlU3BhY2UiLCJ0b1N0cmluZyIsImNvbXBvbmVudFN0YWNrIiwidXNlU2VsZWN0b3IiLCJzaGFsbG93RXF1YWwiLCJKZXVKYXZMaXN0IiwiaWRzIiwiamV1SmF2TGlzdCIsImpldXhKYXYiLCJlbnRpdGllcyIsIm1hcCIsImlkIiwiamV1IiwidGl0cmUiLCJiZ2dJZCIsIkxvYWRpbmciLCJsb2FkaW5nIiwiTWVtYnJlSW5mbyIsIml0ZW0iLCJNZW1icmVDYXJkIiwicHJlbm9tIiwibm9tIiwiTWVtYnJlTGlzdCIsIml0ZW1zIiwiZmV0Y2hNZW1icmVTZXQiLCJNZW1icmVTZXQiLCJtZW1icmUiLCJzZXRQcmVub20iLCJzZXROb20iLCJtYWpldXIiLCJzZXRNYWpldXIiLCJvblByZW5vbUNoYW5nZWQiLCJvbk5vbUNoYW5nZWQiLCJvbk1hamV1ckNoYW5nZWQiLCJIT1NUIiwiUE9SVCIsIkFQSV9VUkwiLCJHT09HTEVfU0hFRVRfSUQiLCJodG1sQXR0cmlidXRlcyIsImxhbmciLCJ0aXRsZVRlbXBsYXRlIiwibWV0YSIsIm5hbWUiLCJjb250ZW50IiwiSldUX1NFQ1JFVCIsImRlZmF1bHRDb25maWciLCJwcm9kQ29uZmlnIiwiX19ERVZfXyIsIl9fTE9DQUxfXyIsInVzZUVmZmVjdCIsInVzZURpc3BhdGNoIiwiZmV0Y2hKZXVKYXZMaXN0SWZOZWVkIiwiZmV0Y2hFbnZpZUxpc3RJZk5lZWQiLCJ1c2VMaXN0Iiwic3RhdGVUb1Byb3AiLCJmZXRjaERhdGFJZk5lZWQiLCJyZWFkeVN0YXR1cyIsIkhvbWUiLCJob21lIiwibG9hZERhdGEiLCJsb2FkYWJsZSIsImZhbGxiYWNrIiwiTG9naW5QYWdlIiwiZmV0Y2hNZW1icmVJZk5lZWQiLCJNZW1icmVQYWdlIiwibWF0Y2giLCJyYXdJZCIsInBhcmFtcyIsInJlbmRlckluZm8iLCJtZW1icmVJbmZvIiwiZW50aXR5IiwiTm90Rm91bmQiLCJzdGF0aWNDb250ZXh0Iiwic3RhdHVzQ29kZSIsIlJlZ2lzdGVyUGFnZSIsIlJvdXRlciIsInBhdGgiLCJjZXJ0Ym90Um91dGVyIiwidXNlIiwicmVxdWVzdCIsInJlc3BvbnNlIiwiX25leHQiLCJmaWxlbmFtZSIsIm9yaWdpbmFsVXJsIiwicmVwbGFjZSIsInJlc29sdmVkUGF0aCIsInJlc29sdmUiLCJzZXRIZWFkZXIiLCJzZW5kRmlsZSIsIkFzeW5jSG9tZSIsImxvYWRIb21lRGF0YSIsIkFzeW5jTWVtYnJlUGFnZSIsImxvYWRNZW1icmVQYWdlRGF0YSIsIkxvZ2luIiwiUmVnaXN0ZXIiLCJjb21wb25lbnQiLCJleGFjdCIsImNoYWxrIiwiYXBwIiwid2VicGFjayIsInJlcXVpcmUiLCJ3ZWJwYWNrQ29uZmlnIiwiZGVmYXVsdCIsImNvbXBpbGVyIiwiaW5zdGFuY2UiLCJoZWFkZXJzIiwic2VydmVyU2lkZVJlbmRlciIsImxvZyIsImhlYXJ0YmVhdCIsIndhaXRVbnRpbFZhbGlkIiwiY29uc29sZSIsImluZm8iLCJncmVlbiIsIkNBQ0hFX1JFTkVXX0RFTEFZIiwiY2FjaGUiLCJjYWNoZVRpbWUiLCJEQk1hbmFnZXIiLCJzaGVldE5hbWUiLCJvcGVyYXRpb25zIiwiYWRkREJPcGVyYXRpb24iLCJ0eXBlIiwidGFzayIsIlByb21pc2UiLCJyZWplY3QiLCJwdXNoIiwibGVuZ3RoIiwicnVuT3BlcmF0aW9uIiwicnVuTmV4dERCT3BlcmF0aW9uIiwic2hpZnQiLCJvcGVyYXRpb24iLCJub3ciLCJEYXRlIiwidGhlbiIsInZhbCIsImNhdGNoIiwiZmluYWxseSIsIl8iLCJwcm9taXNlcyIsImZzIiwiR29vZ2xlU3ByZWFkc2hlZXQiLCJDUkVEX1BBVEgiLCJwcm9jZXNzIiwiY3dkIiwiZ2V0QWNjZXNzb3JzIiwic3BlY2ltZW4iLCJsaXN0R2V0IiwiZ2V0R1NoZWV0Iiwic2hlZXQiLCJnZXRSb3dzIiwicm93cyIsImVsZW1lbnRzIiwiRXJyb3IiLCJ0eXBlcyIsInBpY2siLCJPYmplY3QiLCJrZXlzIiwiZm9yRWFjaCIsInJvdyIsInN0cmluZ2lmaWVkRWxlbWVudCIsImVsZW1lbnQiLCJwYXJzZUVsZW1lbnQiLCJnZXQiLCJtZW1icmVJZCIsImxpc3QiLCJmaW5kIiwic2V0TGlzdCIsInJvd2lkIiwic3RyaW5naWZpZWRSb3ciLCJzdHJpbmdpZnlFbGVtZW50IiwiYWRkUm93Iiwic2FtZUNlbGxzIiwiZXZlcnkiLCJrZXkiLCJzYXZlIiwicm93VG9EZWxldGUiLCJyb3dDb3VudCIsImRlbGV0ZSIsInNldCIsInJvd0l0ZW0iLCJhc3NpZ24iLCJhZGQiLCJwYXJ0aWFsRWxlbWVudCIsImhpZ2hlc3RJZCIsInJlZHVjZSIsIk1hdGgiLCJtYXgiLCJkb2MiLCJyZWFkRmlsZSIsImNyZWRzIiwidXNlU2VydmljZUFjY291bnRBdXRoIiwiSlNPTiIsInBhcnNlIiwibG9hZEluZm8iLCJzaGVldHNCeVRpdGxlIiwicmF3RWxlbWVudCIsImZ1bGxFbGVtZW50IiwicHJvcCIsInJhd1Byb3AiLCJtYXRjaERhdGUiLCJtYXRjaEFycmF5VHlwZSIsImFycmF5VHlwZSIsImRlbGltaXRlciIsInJhd0RhdGVzIiwicmlnaHRGb3JtYXQiLCJyYXdEYXRlIiwibWF0Y2hEYXRlQXJyYXkiLCJzdHJpbmdpZnkiLCJmb3JtdWxhU2FmZSIsInN0cmluZ2lmaWVkRGF0ZSIsImlzQXJyYXkiLCJpc1N0cmluZyIsImlzTnVtYmVyIiwiaXNCb29sZWFuIiwiaXNEYXRlIiwiZ2V0RGF0ZSIsImdldE1vbnRoIiwiZ2V0RnVsbFllYXIiLCJkYXRlIiwiZ2V0RXhwcmVzc0FjY2Vzc29ycyIsIkVudmllIiwibGlzdEdldFJlcXVlc3QiLCJnZXRSZXF1ZXN0Iiwic2V0UmVxdWVzdCIsImFkZFJlcXVlc3QiLCJlbnZpZUxpc3RHZXQiLCJlbnZpZUdldCIsImVudmllQWRkIiwiZW52aWVTZXQiLCJfcmVxdWVzdCIsInN0YXR1cyIsImpzb24iLCJwYXJzZUludCIsInF1ZXJ5IiwiYm9keSIsIkpldUphdiIsImpldUphdkxpc3RHZXQiLCJqZXVKYXZHZXQiLCJqZXVKYXZBZGQiLCJqZXVKYXZTZXQiLCJNZW1icmUiLCJtZW1icmVMaXN0R2V0IiwibWVtYnJlR2V0IiwibWVtYnJlQWRkIiwibWVtYnJlU2V0IiwiZXhwcmVzcyIsImxvZ2dlciIsImNvbXByZXNzaW9uIiwiaGVsbWV0IiwiaHBwIiwiZmF2aWNvbiIsImh0dHAiLCJodHRwcyIsImRldlNlcnZlciIsInNzciIsInNlY3VyZSIsImxvZ2luSGFuZGxlciIsImNvbnRlbnRTZWN1cml0eVBvbGljeSIsInNraXAiLCJfcmVxIiwicmVzIiwic3RhdGljIiwicG9zdCIsInNlcnZlcnMiLCJwcm90b2NvbCIsInNlcnZlciIsImNyZWF0ZVNlcnZlciIsImNlcnRQYXRocyIsImNlcnQiLCJ2YWxpZENlcnRQYXRoIiwiY2VydFBhdGgiLCJwZW1QYXRoIiwiZXhpc3RzU3luYyIsImh0dHBzT3B0aW9ucyIsIm1hcFZhbHVlcyIsInJlYWRGaWxlU3luYyIsImxpc3RlbiIsIm9uIiwib25FcnJvciIsIm9uTGlzdGVuaW5nIiwicmVkIiwiYWRkciIsImFkZHJlc3MiLCJiaW5kIiwicG9ydCIsInNlcmlhbGl6ZSIsIm1pbmlmeSIsImhlYWQiLCJleHRyYWN0b3IiLCJodG1sQ29udGVudCIsImluaXRpYWxTdGF0ZSIsImh0bWwiLCJiYXNlIiwibGluayIsImdldExpbmtUYWdzIiwiZ2V0U3R5bGVUYWdzIiwiZ2V0U2NyaXB0VGFncyIsInNjcmlwdCIsIm1pbmlmeUNvbmZpZyIsImNvbGxhcHNlV2hpdGVzcGFjZSIsInJlbW92ZUNvbW1lbnRzIiwidHJpbUN1c3RvbUZyYWdtZW50cyIsIm1pbmlmeUNTUyIsIm1pbmlmeUpTIiwibWluaWZ5VVJMcyIsInZlcmlmeSIsInNpZ24iLCJjYW5vbmljYWxFbWFpbCIsImNhY2hlZFNlY3JldCIsImdldFNlY3JldCIsIm5leHQiLCJyYXdUb2tlbiIsImF1dGhvcml6YXRpb24iLCJ0b2tlbiIsInRva2VuRXJyb3IiLCJkZWNvZGVkIiwidXNlciIsImxvY2FscyIsImp3dCIsIlNFQ1JFVF9QQVRIIiwic2VjcmV0Q29udGVudCIsInNlY3JldCIsImdldEp3dCIsImVtYWlsIiwicGVybWlzc2lvbnMiLCJfX1RFU1RfXyIsImV4cGlyZXNJbiIsInJlbmRlclRvU3RyaW5nIiwiU3RhdGljUm91dGVyIiwibWF0Y2hSb3V0ZXMiLCJQcm92aWRlciIsIkNodW5rRXh0cmFjdG9yIiwiY3JlYXRlU3RvcmUiLCJyZW5kZXJIdG1sIiwicmVxIiwidXJsIiwic3RvcmUiLCJsb2FkQnJhbmNoRGF0YSIsImJyYW5jaCIsImFsbCIsImdldFN0YXRlIiwic3RhdHNGaWxlIiwiY29sbGVjdENodW5rcyIsInJlbmRlclN0YXRpYyIsImVuZCIsInNlbmQiLCJiY3J5cHQiLCJlbWFpbFJlZ2V4cCIsInBhc3N3b3JkTWluTGVuZ3RoIiwicGFzc3dvcmQiLCJsb2dpbiIsIm1lc3NhZ2UiLCJyYXdFbWFpbCIsInJhd1Bhc3N3b3JkIiwidGVzdCIsIm1lbWJyZXMiLCJtIiwibWFpbCIsImNvbXBhcmUiLCJwYXNzZSIsInBhc3N3b3JkTWF0Y2giLCJheGlvcyIsImF4aW9zQ29uZmlnIiwiZWxlbWVudE5hbWUiLCJkYXRhIiwibWVtYnJlV2l0aG91dElkIiwic3RvcmFnZSIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJzZXRKV1QiLCJBdXRob3JpemF0aW9uIiwic2V0SXRlbSIsInVuc2V0SldUIiwicmVtb3ZlSXRlbSIsImNyZWF0ZVNsaWNlIiwiY3JlYXRlRW50aXR5QWRhcHRlciIsInRvYXN0RXJyb3IiLCJ0b2FzdFN1Y2Nlc3MiLCJlbGVtZW50QWRkRmV0Y2giLCJlbnZpZUFkYXB0ZXIiLCJlbnZpZUFkZFNsaWNlIiwiZ2V0SW5pdGlhbFN0YXRlIiwicmVkdWNlcnMiLCJnZXRSZXF1ZXN0aW5nIiwiZ2V0U3VjY2VzcyIsInBheWxvYWQiLCJhZGRPbmUiLCJnZXRGYWlsdXJlIiwicmVkdWNlciIsImFjdGlvbnMiLCJlbGVtZW50TGlzdEZldGNoIiwiZW52aWVMaXN0Iiwic2V0QWxsIiwiZmV0Y2hFbnZpZUxpc3QiLCJzaG91bGRGZXRjaEVudmllTGlzdCIsImNyZWF0ZU1lbW9yeUhpc3RvcnkiLCJjcmVhdGVCcm93c2VySGlzdG9yeSIsImNvbmZpZ3VyZVN0b3JlIiwicm91dGVyTWlkZGxld2FyZSIsImNyZWF0ZVJvb3RSZWR1Y2VyIiwiaGlzdG9yeSIsIl9fU0VSVkVSX18iLCJpbml0aWFsRW50cmllcyIsInByZWxvYWRlZFN0YXRlIiwibWlkZGxld2FyZSIsImdldERlZmF1bHRNaWRkbGV3YXJlIiwiZGV2VG9vbHMiLCJqZXVKYXZBZGFwdGVyIiwiZmV0Y2hKZXVKYXZMaXN0Iiwic2hvdWxkRmV0Y2hKZXVKYXZMaXN0IiwiZWxlbWVudEZldGNoIiwiZmV0Y2hNZW1icmUiLCJzaG91bGRGZXRjaE1lbWJyZSIsIm1lbWJyZUFkYXB0ZXIiLCJtZW1icmVBZGRTbGljZSIsImZldGNoTWVtYnJlQWRkIiwibWVtYnJlTGlzdCIsImZldGNoTWVtYnJlTGlzdCIsInNob3VsZEZldGNoTWVtYnJlTGlzdCIsImZldGNoTWVtYnJlTGlzdElmTmVlZCIsImVsZW1lbnRTZXQiLCJtZW1icmVTZXRTbGljZSIsInNldE9uZSIsImNvbm5lY3RSb3V0ZXIiLCJyb3V0ZXIiLCJzdWNjZXNzIiwiZWxlbWVudFNlcnZpY2UiLCJlcnJvck1lc3NhZ2UiLCJfZXJyb3IiLCJzdWNjZXNzTWVzc2FnZSIsImVsZW1lbnRBZGRTZXJ2aWNlIiwiZWxlbWVudExpc3RTZXJ2aWNlIiwiZWxlbWVudFNldFNlcnZpY2UiLCJkb21haW4iLCJ0b0xvd2VyQ2FzZSIsInZhbGlkRW1haWwiLCJXZWJwYWNrTWFuaWZlc3RQbHVnaW4iLCJUZXJzZXJQbHVnaW4iLCJNaW5pQ3NzRXh0cmFjdFBsdWdpbiIsIkZvcmtUc0NoZWNrZXJXZWJwYWNrUGx1Z2luIiwiTG9hZGFibGVQbHVnaW4iLCJCdW5kbGVBbmFseXplclBsdWdpbiIsImlzRGV2IiwiZW52IiwiTk9ERV9FTlYiLCJpc0xvY2FsIiwiTE9DQUwiLCJnZXRTdHlsZUxvYWRlcnMiLCJpc1dlYiIsImlzU2FzcyIsImxvYWRlcnMiLCJsb2FkZXIiLCJvcHRpb25zIiwiaW1wb3J0TG9hZGVycyIsIm1vZHVsZXMiLCJhdXRvIiwibG9jYWxJZGVudE5hbWUiLCJleHBvcnRPbmx5TG9jYWxzIiwiZ2V0UGx1Z2lucyIsInBsdWdpbnMiLCJQcm9ncmVzc1BsdWdpbiIsImZpbGVOYW1lIiwiZmlsdGVyIiwiZmlsZSIsImlzSW5pdGlhbCIsIndyaXRlVG9EaXNrIiwiRGVmaW5lUGx1Z2luIiwiX19DTElFTlRfXyIsImVzbGludCIsImZpbGVzIiwiYW5hbHl6ZXJNb2RlIiwibW9kZSIsInN0YXRzIiwiY29udGV4dCIsIm91dHB1dCIsImNsZWFuIiwib3B0aW1pemF0aW9uIiwibWluaW1pemVyIiwidGVyc2VyT3B0aW9ucyIsImNvbXByZXNzIiwiZHJvcF9jb25zb2xlIiwibW9kdWxlIiwicnVsZXMiLCJleGNsdWRlIiwiY2FsbGVyIiwiY2FjaGVEaXJlY3RvcnkiLCJnZW5lcmF0b3IiLCJlbWl0IiwiZXh0ZW5zaW9ucyIsIlJlYWN0UmVmcmVzaFdlYnBhY2tQbHVnaW4iLCJDc3NNaW5pbWl6ZXJQbHVnaW4iLCJDb21wcmVzc2lvblBsdWdpbiIsIkltYWdlTWluaW1pemVyUGx1Z2luIiwibWVyZ2UiLCJiYXNlQ29uZmlnIiwiY2h1bmtGaWxlbmFtZSIsIkhvdE1vZHVsZVJlcGxhY2VtZW50UGx1Z2luIiwib3ZlcmxheSIsInNvY2tJbnRlZ3JhdGlvbiIsIm1pbmltaXplck9wdGlvbnMiLCJkZXZ0b29sIiwiZW50cnkiLCJwdWJsaWNQYXRoIiwicGVyZm9ybWFuY2UiLCJtYXhBc3NldFNpemUiLCJtYXhFbnRyeXBvaW50U2l6ZSJdLCJzb3VyY2VSb290IjoiIn0=