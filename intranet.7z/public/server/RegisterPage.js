require("source-map-support").install();
"use strict";
exports.id = "RegisterPage";
exports.ids = ["RegisterPage"];
exports.modules = {

/***/ "./src/components/RegisterForm/RegisterForm.tsx":
/*!******************************************************!*\
  !*** ./src/components/RegisterForm/RegisterForm.tsx ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./styles.module.scss */ "./src/components/RegisterForm/styles.module.scss");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-runtime */ "react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);





var RegisterForm = function RegisterForm() {
  var onSubmit = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function (event) {
    event.preventDefault();
    var target = event.target;
    var firstname = target.firstname.value;
    var lastname = target.lastname.value;
    var email = target.email.value;
    var phone = target.phone.value;
    console.log("register fields checked", firstname, lastname, email, phone); // call service with fields
  }, []);
  /*
  prenom
  nom
  mail
  tel
  j'ai déjà été bénévole pour PEL
  un petit mot...
   */

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("form", {
    onSubmit: onSubmit,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("dl", {
      className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].registerIntro,
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("dt", {
        children: "Qu'est-ce le festival ?"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("dd", {
        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("dt", {
        children: "\xCAtre b\xE9n\xE9vole \xE0 PEL c'est :"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("dd", {
        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
      })]
    }, "register-intro"), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
      className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].formLine,
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("label", {
        htmlFor: "firstname",
        children: "Pr\xE9nom"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("input", {
        type: "text",
        id: "firstname"
      })]
    }, "line-firstname"), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
      className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].formLine,
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("label", {
        htmlFor: "lastname",
        children: "Nom"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("input", {
        type: "text",
        id: "lastname"
      })]
    }, "line-lastname"), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
      className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].formLine,
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("label", {
        htmlFor: "email",
        children: "Email"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("input", {
        type: "email",
        id: "email"
      })]
    }, "line-email"), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
      className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].formLine,
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("label", {
        htmlFor: "phone",
        children: "T\xE9l\xE9phone"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("input", {
        type: "text",
        id: "phone"
      })]
    }, "line-phone"), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
      className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].formLine,
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("div", {
        children: "J'ai d\xE9j\xE0 \xE9t\xE9 b\xE9n\xE9vole"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("input", {
        type: "radio",
        name: "alreadyVolunteer",
        id: "alreadyVolunteer-yes",
        className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].inputRadio
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("label", {
        htmlFor: "alreadyVolunteer-yes",
        children: "Oui"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("input", {
        type: "radio",
        name: "alreadyVolunteer",
        id: "alreadyVolunteer-no",
        className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].inputRadio
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("label", {
        htmlFor: "alreadyVolunteer-no",
        children: "Non"
      })]
    }, "line-already-volunteer"), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
      className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].formLine,
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("label", {
        htmlFor: "message",
        children: "Des petits mots sympas, questions, envies, des infos sur toi, des comp\xE9tences dont tu aimerais te servir... dis-nous !!!"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("textarea", {
        name: "message",
        id: "message"
      })]
    }, "line-message"), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("div", {
      className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].formButtons,
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("button", {
        type: "submit",
        children: "Je deviens b\xE9n\xE9vole"
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(RegisterForm));

/***/ }),

/***/ "./src/pages/Register/RegisterPage.tsx":
/*!*********************************************!*\
  !*** ./src/pages/Register/RegisterPage.tsx ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-helmet */ "react-helmet");
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_helmet__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles.module.scss */ "./src/pages/Register/styles.module.scss");
/* harmony import */ var _components_RegisterForm_RegisterForm__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../components/RegisterForm/RegisterForm */ "./src/components/RegisterForm/RegisterForm.tsx");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-runtime */ "react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);







var RegisterPage = function RegisterPage() {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)("div", {
    className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].registerPage,
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
      className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].registerContent,
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(react_helmet__WEBPACK_IMPORTED_MODULE_1__.Helmet, {
        title: "RegisterPage"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_components_RegisterForm_RegisterForm__WEBPACK_IMPORTED_MODULE_3__["default"], {})]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(RegisterPage));

/***/ }),

/***/ "./src/components/RegisterForm/styles.module.scss":
/*!********************************************************!*\
  !*** ./src/components/RegisterForm/styles.module.scss ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
	"registerIntro": "src-components-RegisterForm-styles-module__registerIntro",
	"formLine": "src-components-RegisterForm-styles-module__formLine",
	"inputRadio": "src-components-RegisterForm-styles-module__inputRadio",
	"formButtons": "src-components-RegisterForm-styles-module__formButtons"
});


/***/ }),

/***/ "./src/pages/Register/styles.module.scss":
/*!***********************************************!*\
  !*** ./src/pages/Register/styles.module.scss ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
	"registerPage": "src-pages-Register-styles-module__registerPage",
	"registerContent": "src-pages-Register-styles-module__registerContent"
});


/***/ })

};
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiUmVnaXN0ZXJQYWdlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7Ozs7QUFFQSxJQUFNSSxZQUFZLEdBQUcsU0FBZkEsWUFBZSxHQUFtQjtBQUNwQyxNQUFNQyxRQUFRLEdBQUdILGtEQUFXLENBQUMsVUFBQ0ksS0FBRCxFQUF1QztBQUNoRUEsSUFBQUEsS0FBSyxDQUFDQyxjQUFOO0FBQ0EsUUFBTUMsTUFBTSxHQUFHRixLQUFLLENBQUNFLE1BQXJCO0FBTUEsUUFBTUMsU0FBUyxHQUFHRCxNQUFNLENBQUNDLFNBQVAsQ0FBaUJDLEtBQW5DO0FBQ0EsUUFBTUMsUUFBUSxHQUFHSCxNQUFNLENBQUNHLFFBQVAsQ0FBZ0JELEtBQWpDO0FBQ0EsUUFBTUUsS0FBSyxHQUFHSixNQUFNLENBQUNJLEtBQVAsQ0FBYUYsS0FBM0I7QUFDQSxRQUFNRyxLQUFLLEdBQUdMLE1BQU0sQ0FBQ0ssS0FBUCxDQUFhSCxLQUEzQjtBQUVBSSxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSx5QkFBWixFQUF1Q04sU0FBdkMsRUFBa0RFLFFBQWxELEVBQTREQyxLQUE1RCxFQUFtRUMsS0FBbkUsRUFiZ0UsQ0FlaEU7QUFDSCxHQWhCMkIsRUFnQnpCLEVBaEJ5QixDQUE1QjtBQWtCQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVJLHNCQUNJO0FBQU0sWUFBUSxFQUFFUixRQUFoQjtBQUFBLDRCQUNJO0FBQUksZUFBUyxFQUFFRix5RUFBZjtBQUFBLDhCQUNJO0FBQUE7QUFBQSxRQURKLGVBRUk7QUFBQTtBQUFBLFFBRkosZUFVSTtBQUFBO0FBQUEsUUFWSixlQVdJO0FBQUE7QUFBQSxRQVhKO0FBQUEsT0FBeUMsZ0JBQXpDLENBREosZUFxQkk7QUFBSyxlQUFTLEVBQUVBLG9FQUFoQjtBQUFBLDhCQUNJO0FBQU8sZUFBTyxFQUFDLFdBQWY7QUFBQTtBQUFBLFFBREosZUFFSTtBQUFPLFlBQUksRUFBQyxNQUFaO0FBQW1CLFVBQUUsRUFBQztBQUF0QixRQUZKO0FBQUEsT0FBcUMsZ0JBQXJDLENBckJKLGVBeUJJO0FBQUssZUFBUyxFQUFFQSxvRUFBaEI7QUFBQSw4QkFDSTtBQUFPLGVBQU8sRUFBQyxVQUFmO0FBQUE7QUFBQSxRQURKLGVBRUk7QUFBTyxZQUFJLEVBQUMsTUFBWjtBQUFtQixVQUFFLEVBQUM7QUFBdEIsUUFGSjtBQUFBLE9BQXFDLGVBQXJDLENBekJKLGVBNkJJO0FBQUssZUFBUyxFQUFFQSxvRUFBaEI7QUFBQSw4QkFDSTtBQUFPLGVBQU8sRUFBQyxPQUFmO0FBQUE7QUFBQSxRQURKLGVBRUk7QUFBTyxZQUFJLEVBQUMsT0FBWjtBQUFvQixVQUFFLEVBQUM7QUFBdkIsUUFGSjtBQUFBLE9BQXFDLFlBQXJDLENBN0JKLGVBaUNJO0FBQUssZUFBUyxFQUFFQSxvRUFBaEI7QUFBQSw4QkFDSTtBQUFPLGVBQU8sRUFBQyxPQUFmO0FBQUE7QUFBQSxRQURKLGVBRUk7QUFBTyxZQUFJLEVBQUMsTUFBWjtBQUFtQixVQUFFLEVBQUM7QUFBdEIsUUFGSjtBQUFBLE9BQXFDLFlBQXJDLENBakNKLGVBcUNJO0FBQUssZUFBUyxFQUFFQSxvRUFBaEI7QUFBQSw4QkFDSTtBQUFBO0FBQUEsUUFESixlQUVJO0FBQ0ksWUFBSSxFQUFDLE9BRFQ7QUFFSSxZQUFJLEVBQUMsa0JBRlQ7QUFHSSxVQUFFLEVBQUMsc0JBSFA7QUFJSSxpQkFBUyxFQUFFQSxzRUFBaUJlO0FBSmhDLFFBRkosZUFRSTtBQUFPLGVBQU8sRUFBQyxzQkFBZjtBQUFBO0FBQUEsUUFSSixlQVNJO0FBQ0ksWUFBSSxFQUFDLE9BRFQ7QUFFSSxZQUFJLEVBQUMsa0JBRlQ7QUFHSSxVQUFFLEVBQUMscUJBSFA7QUFJSSxpQkFBUyxFQUFFZixzRUFBaUJlO0FBSmhDLFFBVEosZUFlSTtBQUFPLGVBQU8sRUFBQyxxQkFBZjtBQUFBO0FBQUEsUUFmSjtBQUFBLE9BQXFDLHdCQUFyQyxDQXJDSixlQXNESTtBQUFLLGVBQVMsRUFBRWYsb0VBQWhCO0FBQUEsOEJBQ0k7QUFBTyxlQUFPLEVBQUMsU0FBZjtBQUFBO0FBQUEsUUFESixlQUtJO0FBQVUsWUFBSSxFQUFDLFNBQWY7QUFBeUIsVUFBRSxFQUFDO0FBQTVCLFFBTEo7QUFBQSxPQUFxQyxjQUFyQyxDQXRESixlQTZESTtBQUFLLGVBQVMsRUFBRUEsdUVBQWhCO0FBQUEsNkJBQ0k7QUFBUSxZQUFJLEVBQUMsUUFBYjtBQUFBO0FBQUE7QUFESixNQTdESjtBQUFBLElBREo7QUFtRUgsQ0EvRkQ7O0FBaUdBLDhFQUFlRiwyQ0FBSSxDQUFDRyxZQUFELENBQW5COzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbkdBO0FBQ0E7QUFDQTtBQUNBOzs7O0FBSUEsSUFBTWlCLFlBQTZCLEdBQUcsU0FBaENBLFlBQWdDO0FBQUEsc0JBQ2xDO0FBQUssYUFBUyxFQUFFbEIsd0VBQWhCO0FBQUEsMkJBQ0k7QUFBSyxlQUFTLEVBQUVBLDJFQUFoQjtBQUFBLDhCQUNJLHVEQUFDLGdEQUFEO0FBQVEsYUFBSyxFQUFDO0FBQWQsUUFESixlQUVJLHVEQUFDLDZFQUFELEtBRko7QUFBQTtBQURKLElBRGtDO0FBQUEsQ0FBdEM7O0FBU0EsOEVBQWVGLDJDQUFJLENBQUNvQixZQUFELENBQW5COzs7Ozs7Ozs7Ozs7OztBQ2pCQTtBQUNBLGlFQUFlO0FBQ2Y7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDLEVBQUM7Ozs7Ozs7Ozs7Ozs7OztBQ05GO0FBQ0EsaUVBQWU7QUFDZjtBQUNBO0FBQ0EsQ0FBQyxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vaW50cmFuZXQvLi9zcmMvY29tcG9uZW50cy9SZWdpc3RlckZvcm0vUmVnaXN0ZXJGb3JtLnRzeCIsIndlYnBhY2s6Ly9pbnRyYW5ldC8uL3NyYy9wYWdlcy9SZWdpc3Rlci9SZWdpc3RlclBhZ2UudHN4Iiwid2VicGFjazovL2ludHJhbmV0Ly4vc3JjL2NvbXBvbmVudHMvUmVnaXN0ZXJGb3JtL3N0eWxlcy5tb2R1bGUuc2NzcyIsIndlYnBhY2s6Ly9pbnRyYW5ldC8uL3NyYy9wYWdlcy9SZWdpc3Rlci9zdHlsZXMubW9kdWxlLnNjc3MiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IG1lbW8sIHVzZUNhbGxiYWNrIH0gZnJvbSBcInJlYWN0XCJcbmltcG9ydCBzdHlsZXMgZnJvbSBcIi4vc3R5bGVzLm1vZHVsZS5zY3NzXCJcblxuY29uc3QgUmVnaXN0ZXJGb3JtID0gKCk6IEpTWC5FbGVtZW50ID0+IHtcbiAgICBjb25zdCBvblN1Ym1pdCA9IHVzZUNhbGxiYWNrKChldmVudDogUmVhY3QuU3ludGhldGljRXZlbnQpOiB2b2lkID0+IHtcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxuICAgICAgICBjb25zdCB0YXJnZXQgPSBldmVudC50YXJnZXQgYXMgdHlwZW9mIGV2ZW50LnRhcmdldCAmIHtcbiAgICAgICAgICAgIGZpcnN0bmFtZTogeyB2YWx1ZTogc3RyaW5nIH1cbiAgICAgICAgICAgIGxhc3RuYW1lOiB7IHZhbHVlOiBzdHJpbmcgfVxuICAgICAgICAgICAgZW1haWw6IHsgdmFsdWU6IHN0cmluZyB9XG4gICAgICAgICAgICBwaG9uZTogeyB2YWx1ZTogc3RyaW5nIH1cbiAgICAgICAgfVxuICAgICAgICBjb25zdCBmaXJzdG5hbWUgPSB0YXJnZXQuZmlyc3RuYW1lLnZhbHVlXG4gICAgICAgIGNvbnN0IGxhc3RuYW1lID0gdGFyZ2V0Lmxhc3RuYW1lLnZhbHVlXG4gICAgICAgIGNvbnN0IGVtYWlsID0gdGFyZ2V0LmVtYWlsLnZhbHVlXG4gICAgICAgIGNvbnN0IHBob25lID0gdGFyZ2V0LnBob25lLnZhbHVlXG5cbiAgICAgICAgY29uc29sZS5sb2coXCJyZWdpc3RlciBmaWVsZHMgY2hlY2tlZFwiLCBmaXJzdG5hbWUsIGxhc3RuYW1lLCBlbWFpbCwgcGhvbmUpXG5cbiAgICAgICAgLy8gY2FsbCBzZXJ2aWNlIHdpdGggZmllbGRzXG4gICAgfSwgW10pXG5cbiAgICAvKlxuICAgIHByZW5vbVxuICAgIG5vbVxuICAgIG1haWxcbiAgICB0ZWxcbiAgICBqJ2FpIGTDqWrDoCDDqXTDqSBiw6luw6l2b2xlIHBvdXIgUEVMXG4gICAgdW4gcGV0aXQgbW90Li4uXG4gICAgICovXG5cbiAgICByZXR1cm4gKFxuICAgICAgICA8Zm9ybSBvblN1Ym1pdD17b25TdWJtaXR9PlxuICAgICAgICAgICAgPGRsIGNsYXNzTmFtZT17c3R5bGVzLnJlZ2lzdGVySW50cm99IGtleT1cInJlZ2lzdGVyLWludHJvXCI+XG4gICAgICAgICAgICAgICAgPGR0PlF1JmFwb3M7ZXN0LWNlIGxlIGZlc3RpdmFsID88L2R0PlxuICAgICAgICAgICAgICAgIDxkZD5cbiAgICAgICAgICAgICAgICAgICAgTG9yZW0gaXBzdW0gZG9sb3Igc2l0IGFtZXQsIGNvbnNlY3RldHVyIGFkaXBpc2NpbmcgZWxpdCwgc2VkIGRvIGVpdXNtb2QgdGVtcG9yXG4gICAgICAgICAgICAgICAgICAgIGluY2lkaWR1bnQgdXQgbGFib3JlIGV0IGRvbG9yZSBtYWduYSBhbGlxdWEuIFV0IGVuaW0gYWQgbWluaW0gdmVuaWFtLCBxdWlzXG4gICAgICAgICAgICAgICAgICAgIG5vc3RydWQgZXhlcmNpdGF0aW9uIHVsbGFtY28gbGFib3JpcyBuaXNpIHV0IGFsaXF1aXAgZXggZWEgY29tbW9kbyBjb25zZXF1YXQuXG4gICAgICAgICAgICAgICAgICAgIER1aXMgYXV0ZSBpcnVyZSBkb2xvciBpbiByZXByZWhlbmRlcml0IGluIHZvbHVwdGF0ZSB2ZWxpdCBlc3NlIGNpbGx1bSBkb2xvcmUgZXVcbiAgICAgICAgICAgICAgICAgICAgZnVnaWF0IG51bGxhIHBhcmlhdHVyLiBFeGNlcHRldXIgc2ludCBvY2NhZWNhdCBjdXBpZGF0YXQgbm9uIHByb2lkZW50LCBzdW50IGluXG4gICAgICAgICAgICAgICAgICAgIGN1bHBhIHF1aSBvZmZpY2lhIGRlc2VydW50IG1vbGxpdCBhbmltIGlkIGVzdCBsYWJvcnVtLlxuICAgICAgICAgICAgICAgIDwvZGQ+XG4gICAgICAgICAgICAgICAgPGR0PsOKdHJlIGLDqW7DqXZvbGUgw6AgUEVMIGMmYXBvcztlc3QgOjwvZHQ+XG4gICAgICAgICAgICAgICAgPGRkPlxuICAgICAgICAgICAgICAgICAgICBMb3JlbSBpcHN1bSBkb2xvciBzaXQgYW1ldCwgY29uc2VjdGV0dXIgYWRpcGlzY2luZyBlbGl0LCBzZWQgZG8gZWl1c21vZCB0ZW1wb3JcbiAgICAgICAgICAgICAgICAgICAgaW5jaWRpZHVudCB1dCBsYWJvcmUgZXQgZG9sb3JlIG1hZ25hIGFsaXF1YS4gVXQgZW5pbSBhZCBtaW5pbSB2ZW5pYW0sIHF1aXNcbiAgICAgICAgICAgICAgICAgICAgbm9zdHJ1ZCBleGVyY2l0YXRpb24gdWxsYW1jbyBsYWJvcmlzIG5pc2kgdXQgYWxpcXVpcCBleCBlYSBjb21tb2RvIGNvbnNlcXVhdC5cbiAgICAgICAgICAgICAgICAgICAgRHVpcyBhdXRlIGlydXJlIGRvbG9yIGluIHJlcHJlaGVuZGVyaXQgaW4gdm9sdXB0YXRlIHZlbGl0IGVzc2UgY2lsbHVtIGRvbG9yZSBldVxuICAgICAgICAgICAgICAgICAgICBmdWdpYXQgbnVsbGEgcGFyaWF0dXIuIEV4Y2VwdGV1ciBzaW50IG9jY2FlY2F0IGN1cGlkYXRhdCBub24gcHJvaWRlbnQsIHN1bnQgaW5cbiAgICAgICAgICAgICAgICAgICAgY3VscGEgcXVpIG9mZmljaWEgZGVzZXJ1bnQgbW9sbGl0IGFuaW0gaWQgZXN0IGxhYm9ydW0uXG4gICAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgIDwvZGw+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmZvcm1MaW5lfSBrZXk9XCJsaW5lLWZpcnN0bmFtZVwiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiZmlyc3RuYW1lXCI+UHLDqW5vbTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgaWQ9XCJmaXJzdG5hbWVcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmZvcm1MaW5lfSBrZXk9XCJsaW5lLWxhc3RuYW1lXCI+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJsYXN0bmFtZVwiPk5vbTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgaWQ9XCJsYXN0bmFtZVwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuZm9ybUxpbmV9IGtleT1cImxpbmUtZW1haWxcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImVtYWlsXCI+RW1haWw8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZW1haWxcIiBpZD1cImVtYWlsXCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5mb3JtTGluZX0ga2V5PVwibGluZS1waG9uZVwiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwicGhvbmVcIj5Uw6lsw6lwaG9uZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgaWQ9XCJwaG9uZVwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuZm9ybUxpbmV9IGtleT1cImxpbmUtYWxyZWFkeS12b2x1bnRlZXJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PkomYXBvczthaSBkw6lqw6Agw6l0w6kgYsOpbsOpdm9sZTwvZGl2PlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwicmFkaW9cIlxuICAgICAgICAgICAgICAgICAgICBuYW1lPVwiYWxyZWFkeVZvbHVudGVlclwiXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiYWxyZWFkeVZvbHVudGVlci15ZXNcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e3N0eWxlcy5pbnB1dFJhZGlvfVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJhbHJlYWR5Vm9sdW50ZWVyLXllc1wiPk91aTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYWRpb1wiXG4gICAgICAgICAgICAgICAgICAgIG5hbWU9XCJhbHJlYWR5Vm9sdW50ZWVyXCJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJhbHJlYWR5Vm9sdW50ZWVyLW5vXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtzdHlsZXMuaW5wdXRSYWRpb31cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiYWxyZWFkeVZvbHVudGVlci1ub1wiPk5vbjwvbGFiZWw+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuZm9ybUxpbmV9IGtleT1cImxpbmUtbWVzc2FnZVwiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwibWVzc2FnZVwiPlxuICAgICAgICAgICAgICAgICAgICBEZXMgcGV0aXRzIG1vdHMgc3ltcGFzLCBxdWVzdGlvbnMsIGVudmllcywgZGVzIGluZm9zIHN1ciB0b2ksIGRlcyBjb21ww6l0ZW5jZXNcbiAgICAgICAgICAgICAgICAgICAgZG9udCB0dSBhaW1lcmFpcyB0ZSBzZXJ2aXIuLi4gZGlzLW5vdXMgISEhXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8dGV4dGFyZWEgbmFtZT1cIm1lc3NhZ2VcIiBpZD1cIm1lc3NhZ2VcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmZvcm1CdXR0b25zfT5cbiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIj5KZSBkZXZpZW5zIGLDqW7DqXZvbGU8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Zvcm0+XG4gICAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBtZW1vKFJlZ2lzdGVyRm9ybSlcbiIsImltcG9ydCB7IFJvdXRlQ29tcG9uZW50UHJvcHMgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiXG5pbXBvcnQgUmVhY3QsIHsgbWVtbyB9IGZyb20gXCJyZWFjdFwiXG5pbXBvcnQgeyBIZWxtZXQgfSBmcm9tIFwicmVhY3QtaGVsbWV0XCJcbmltcG9ydCBzdHlsZXMgZnJvbSBcIi4vc3R5bGVzLm1vZHVsZS5zY3NzXCJcbmltcG9ydCBSZWdpc3RlckZvcm0gZnJvbSBcIi4uLy4uL2NvbXBvbmVudHMvUmVnaXN0ZXJGb3JtL1JlZ2lzdGVyRm9ybVwiXG5cbmV4cG9ydCB0eXBlIFByb3BzID0gUm91dGVDb21wb25lbnRQcm9wc1xuXG5jb25zdCBSZWdpc3RlclBhZ2U6IFJlYWN0LkZDPFByb3BzPiA9ICgpOiBKU1guRWxlbWVudCA9PiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5yZWdpc3RlclBhZ2V9PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLnJlZ2lzdGVyQ29udGVudH0+XG4gICAgICAgICAgICA8SGVsbWV0IHRpdGxlPVwiUmVnaXN0ZXJQYWdlXCIgLz5cbiAgICAgICAgICAgIDxSZWdpc3RlckZvcm0gLz5cbiAgICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4pXG5cbmV4cG9ydCBkZWZhdWx0IG1lbW8oUmVnaXN0ZXJQYWdlKVxuIiwiLy8gRXhwb3J0c1xuZXhwb3J0IGRlZmF1bHQge1xuXHRcInJlZ2lzdGVySW50cm9cIjogXCJzcmMtY29tcG9uZW50cy1SZWdpc3RlckZvcm0tc3R5bGVzLW1vZHVsZV9fcmVnaXN0ZXJJbnRyb1wiLFxuXHRcImZvcm1MaW5lXCI6IFwic3JjLWNvbXBvbmVudHMtUmVnaXN0ZXJGb3JtLXN0eWxlcy1tb2R1bGVfX2Zvcm1MaW5lXCIsXG5cdFwiaW5wdXRSYWRpb1wiOiBcInNyYy1jb21wb25lbnRzLVJlZ2lzdGVyRm9ybS1zdHlsZXMtbW9kdWxlX19pbnB1dFJhZGlvXCIsXG5cdFwiZm9ybUJ1dHRvbnNcIjogXCJzcmMtY29tcG9uZW50cy1SZWdpc3RlckZvcm0tc3R5bGVzLW1vZHVsZV9fZm9ybUJ1dHRvbnNcIlxufTtcbiIsIi8vIEV4cG9ydHNcbmV4cG9ydCBkZWZhdWx0IHtcblx0XCJyZWdpc3RlclBhZ2VcIjogXCJzcmMtcGFnZXMtUmVnaXN0ZXItc3R5bGVzLW1vZHVsZV9fcmVnaXN0ZXJQYWdlXCIsXG5cdFwicmVnaXN0ZXJDb250ZW50XCI6IFwic3JjLXBhZ2VzLVJlZ2lzdGVyLXN0eWxlcy1tb2R1bGVfX3JlZ2lzdGVyQ29udGVudFwiXG59O1xuIl0sIm5hbWVzIjpbIlJlYWN0IiwibWVtbyIsInVzZUNhbGxiYWNrIiwic3R5bGVzIiwiUmVnaXN0ZXJGb3JtIiwib25TdWJtaXQiLCJldmVudCIsInByZXZlbnREZWZhdWx0IiwidGFyZ2V0IiwiZmlyc3RuYW1lIiwidmFsdWUiLCJsYXN0bmFtZSIsImVtYWlsIiwicGhvbmUiLCJjb25zb2xlIiwibG9nIiwicmVnaXN0ZXJJbnRybyIsImZvcm1MaW5lIiwiaW5wdXRSYWRpbyIsImZvcm1CdXR0b25zIiwiSGVsbWV0IiwiUmVnaXN0ZXJQYWdlIiwicmVnaXN0ZXJQYWdlIiwicmVnaXN0ZXJDb250ZW50Il0sInNvdXJjZVJvb3QiOiIifQ==