require("source-map-support").install();
"use strict";
exports.id = "LoginPage";
exports.ids = ["LoginPage"];
exports.modules = {

/***/ "./src/components/LoginForm/LoginForm.tsx":
/*!************************************************!*\
  !*** ./src/components/LoginForm/LoginForm.tsx ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./styles.module.scss */ "./src/components/LoginForm/styles.module.scss");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react/jsx-runtime */ "react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);





var LoginForm = function LoginForm() {
  var onSubmit = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function (event) {
    event.preventDefault();
    var target = event.target;
    var email = target.email.value;
    var password = target.password.value;
    console.log("email and password checked", email, password); // call service with email & password
  }, []);
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("form", {
    onSubmit: onSubmit,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("div", {
      className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].loginIntro,
      children: "Connectez-vous pour acc\xE9der \xE0 votre espace."
    }, "login-intro"), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
      className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].formLine,
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("label", {
        htmlFor: "email",
        children: "Email"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("input", {
        type: "email",
        id: "email"
      })]
    }, "line-email"), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
      className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].formLine,
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("label", {
        htmlFor: "password",
        children: "Mot de passe"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("input", {
        type: "password",
        id: "password"
      })]
    }, "line-password"), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("div", {
      className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].formButtons,
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx)("button", {
        type: "submit",
        children: "Connexion"
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(LoginForm));

/***/ }),

/***/ "./src/pages/Login/LoginPage.tsx":
/*!***************************************!*\
  !*** ./src/pages/Login/LoginPage.tsx ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-helmet */ "react-helmet");
/* harmony import */ var react_helmet__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_helmet__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./styles.module.scss */ "./src/pages/Login/styles.module.scss");
/* harmony import */ var _components_LoginForm_LoginForm__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../components/LoginForm/LoginForm */ "./src/components/LoginForm/LoginForm.tsx");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react/jsx-runtime */ "react/jsx-runtime");
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);







var RegisterPage = function RegisterPage() {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)("div", {
    className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].loginPage,
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
      className: _styles_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].loginContent,
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(react_helmet__WEBPACK_IMPORTED_MODULE_1__.Helmet, {
        title: "RegisterPage"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx)(_components_LoginForm_LoginForm__WEBPACK_IMPORTED_MODULE_3__["default"], {})]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.memo)(RegisterPage));

/***/ }),

/***/ "./src/components/LoginForm/styles.module.scss":
/*!*****************************************************!*\
  !*** ./src/components/LoginForm/styles.module.scss ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
	"loginIntro": "src-components-LoginForm-styles-module__loginIntro",
	"formLine": "src-components-LoginForm-styles-module__formLine",
	"formButtons": "src-components-LoginForm-styles-module__formButtons"
});


/***/ }),

/***/ "./src/pages/Login/styles.module.scss":
/*!********************************************!*\
  !*** ./src/pages/Login/styles.module.scss ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
	"loginPage": "src-pages-Login-styles-module__loginPage",
	"loginContent": "src-pages-Login-styles-module__loginContent"
});


/***/ })

};
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTG9naW5QYWdlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7Ozs7QUFFQSxJQUFNSSxTQUFTLEdBQUcsU0FBWkEsU0FBWSxHQUFtQjtBQUNqQyxNQUFNQyxRQUFRLEdBQUdILGtEQUFXLENBQUMsVUFBQ0ksS0FBRCxFQUF1QztBQUNoRUEsSUFBQUEsS0FBSyxDQUFDQyxjQUFOO0FBQ0EsUUFBTUMsTUFBTSxHQUFHRixLQUFLLENBQUNFLE1BQXJCO0FBSUEsUUFBTUMsS0FBSyxHQUFHRCxNQUFNLENBQUNDLEtBQVAsQ0FBYUMsS0FBM0I7QUFDQSxRQUFNQyxRQUFRLEdBQUdILE1BQU0sQ0FBQ0csUUFBUCxDQUFnQkQsS0FBakM7QUFFQUUsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksNEJBQVosRUFBMENKLEtBQTFDLEVBQWlERSxRQUFqRCxFQVRnRSxDQVdoRTtBQUNILEdBWjJCLEVBWXpCLEVBWnlCLENBQTVCO0FBY0Esc0JBQ0k7QUFBTSxZQUFRLEVBQUVOLFFBQWhCO0FBQUEsNEJBQ0k7QUFBSyxlQUFTLEVBQUVGLHNFQUFoQjtBQUFBO0FBQUEsT0FBdUMsYUFBdkMsQ0FESixlQUlJO0FBQUssZUFBUyxFQUFFQSxvRUFBaEI7QUFBQSw4QkFDSTtBQUFPLGVBQU8sRUFBQyxPQUFmO0FBQUE7QUFBQSxRQURKLGVBRUk7QUFBTyxZQUFJLEVBQUMsT0FBWjtBQUFvQixVQUFFLEVBQUM7QUFBdkIsUUFGSjtBQUFBLE9BQXFDLFlBQXJDLENBSkosZUFRSTtBQUFLLGVBQVMsRUFBRUEsb0VBQWhCO0FBQUEsOEJBQ0k7QUFBTyxlQUFPLEVBQUMsVUFBZjtBQUFBO0FBQUEsUUFESixlQUVJO0FBQU8sWUFBSSxFQUFDLFVBQVo7QUFBdUIsVUFBRSxFQUFDO0FBQTFCLFFBRko7QUFBQSxPQUFxQyxlQUFyQyxDQVJKLGVBWUk7QUFBSyxlQUFTLEVBQUVBLHVFQUFoQjtBQUFBLDZCQUNJO0FBQVEsWUFBSSxFQUFDLFFBQWI7QUFBQTtBQUFBO0FBREosTUFaSjtBQUFBLElBREo7QUFrQkgsQ0FqQ0Q7O0FBbUNBLDhFQUFlRiwyQ0FBSSxDQUFDRyxTQUFELENBQW5COzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDckNBO0FBQ0E7QUFDQTtBQUNBOzs7O0FBSUEsSUFBTWMsWUFBNkIsR0FBRyxTQUFoQ0EsWUFBZ0M7QUFBQSxzQkFDbEM7QUFBSyxhQUFTLEVBQUVmLHFFQUFoQjtBQUFBLDJCQUNJO0FBQUssZUFBUyxFQUFFQSx3RUFBaEI7QUFBQSw4QkFDSSx1REFBQyxnREFBRDtBQUFRLGFBQUssRUFBQztBQUFkLFFBREosZUFFSSx1REFBQyx1RUFBRCxLQUZKO0FBQUE7QUFESixJQURrQztBQUFBLENBQXRDOztBQVNBLDhFQUFlRiwyQ0FBSSxDQUFDaUIsWUFBRCxDQUFuQjs7Ozs7Ozs7Ozs7Ozs7QUNqQkE7QUFDQSxpRUFBZTtBQUNmO0FBQ0E7QUFDQTtBQUNBLENBQUMsRUFBQzs7Ozs7Ozs7Ozs7Ozs7O0FDTEY7QUFDQSxpRUFBZTtBQUNmO0FBQ0E7QUFDQSxDQUFDLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9pbnRyYW5ldC8uL3NyYy9jb21wb25lbnRzL0xvZ2luRm9ybS9Mb2dpbkZvcm0udHN4Iiwid2VicGFjazovL2ludHJhbmV0Ly4vc3JjL3BhZ2VzL0xvZ2luL0xvZ2luUGFnZS50c3giLCJ3ZWJwYWNrOi8vaW50cmFuZXQvLi9zcmMvY29tcG9uZW50cy9Mb2dpbkZvcm0vc3R5bGVzLm1vZHVsZS5zY3NzIiwid2VicGFjazovL2ludHJhbmV0Ly4vc3JjL3BhZ2VzL0xvZ2luL3N0eWxlcy5tb2R1bGUuc2NzcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgbWVtbywgdXNlQ2FsbGJhY2sgfSBmcm9tIFwicmVhY3RcIlxuaW1wb3J0IHN0eWxlcyBmcm9tIFwiLi9zdHlsZXMubW9kdWxlLnNjc3NcIlxuXG5jb25zdCBMb2dpbkZvcm0gPSAoKTogSlNYLkVsZW1lbnQgPT4ge1xuICAgIGNvbnN0IG9uU3VibWl0ID0gdXNlQ2FsbGJhY2soKGV2ZW50OiBSZWFjdC5TeW50aGV0aWNFdmVudCk6IHZvaWQgPT4ge1xuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXG4gICAgICAgIGNvbnN0IHRhcmdldCA9IGV2ZW50LnRhcmdldCBhcyB0eXBlb2YgZXZlbnQudGFyZ2V0ICYge1xuICAgICAgICAgICAgZW1haWw6IHsgdmFsdWU6IHN0cmluZyB9XG4gICAgICAgICAgICBwYXNzd29yZDogeyB2YWx1ZTogc3RyaW5nIH1cbiAgICAgICAgfVxuICAgICAgICBjb25zdCBlbWFpbCA9IHRhcmdldC5lbWFpbC52YWx1ZVxuICAgICAgICBjb25zdCBwYXNzd29yZCA9IHRhcmdldC5wYXNzd29yZC52YWx1ZVxuXG4gICAgICAgIGNvbnNvbGUubG9nKFwiZW1haWwgYW5kIHBhc3N3b3JkIGNoZWNrZWRcIiwgZW1haWwsIHBhc3N3b3JkKVxuXG4gICAgICAgIC8vIGNhbGwgc2VydmljZSB3aXRoIGVtYWlsICYgcGFzc3dvcmRcbiAgICB9LCBbXSlcblxuICAgIHJldHVybiAoXG4gICAgICAgIDxmb3JtIG9uU3VibWl0PXtvblN1Ym1pdH0+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17c3R5bGVzLmxvZ2luSW50cm99IGtleT1cImxvZ2luLWludHJvXCI+XG4gICAgICAgICAgICAgICAgQ29ubmVjdGV6LXZvdXMgcG91ciBhY2PDqWRlciDDoCB2b3RyZSBlc3BhY2UuXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMuZm9ybUxpbmV9IGtleT1cImxpbmUtZW1haWxcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImVtYWlsXCI+RW1haWw8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZW1haWxcIiBpZD1cImVtYWlsXCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5mb3JtTGluZX0ga2V5PVwibGluZS1wYXNzd29yZFwiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwicGFzc3dvcmRcIj5Nb3QgZGUgcGFzc2U8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwicGFzc3dvcmRcIiBpZD1cInBhc3N3b3JkXCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5mb3JtQnV0dG9uc30+XG4gICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCI+Q29ubmV4aW9uPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9mb3JtPlxuICAgIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgbWVtbyhMb2dpbkZvcm0pXG4iLCJpbXBvcnQgeyBSb3V0ZUNvbXBvbmVudFByb3BzIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIlxuaW1wb3J0IFJlYWN0LCB7IG1lbW8gfSBmcm9tIFwicmVhY3RcIlxuaW1wb3J0IHsgSGVsbWV0IH0gZnJvbSBcInJlYWN0LWhlbG1ldFwiXG5pbXBvcnQgc3R5bGVzIGZyb20gXCIuL3N0eWxlcy5tb2R1bGUuc2Nzc1wiXG5pbXBvcnQgTG9naW5Gb3JtIGZyb20gXCIuLi8uLi9jb21wb25lbnRzL0xvZ2luRm9ybS9Mb2dpbkZvcm1cIlxuXG5leHBvcnQgdHlwZSBQcm9wcyA9IFJvdXRlQ29tcG9uZW50UHJvcHNcblxuY29uc3QgUmVnaXN0ZXJQYWdlOiBSZWFjdC5GQzxQcm9wcz4gPSAoKTogSlNYLkVsZW1lbnQgPT4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPXtzdHlsZXMubG9naW5QYWdlfT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e3N0eWxlcy5sb2dpbkNvbnRlbnR9PlxuICAgICAgICAgICAgPEhlbG1ldCB0aXRsZT1cIlJlZ2lzdGVyUGFnZVwiIC8+XG4gICAgICAgICAgICA8TG9naW5Gb3JtIC8+XG4gICAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuKVxuXG5leHBvcnQgZGVmYXVsdCBtZW1vKFJlZ2lzdGVyUGFnZSlcbiIsIi8vIEV4cG9ydHNcbmV4cG9ydCBkZWZhdWx0IHtcblx0XCJsb2dpbkludHJvXCI6IFwic3JjLWNvbXBvbmVudHMtTG9naW5Gb3JtLXN0eWxlcy1tb2R1bGVfX2xvZ2luSW50cm9cIixcblx0XCJmb3JtTGluZVwiOiBcInNyYy1jb21wb25lbnRzLUxvZ2luRm9ybS1zdHlsZXMtbW9kdWxlX19mb3JtTGluZVwiLFxuXHRcImZvcm1CdXR0b25zXCI6IFwic3JjLWNvbXBvbmVudHMtTG9naW5Gb3JtLXN0eWxlcy1tb2R1bGVfX2Zvcm1CdXR0b25zXCJcbn07XG4iLCIvLyBFeHBvcnRzXG5leHBvcnQgZGVmYXVsdCB7XG5cdFwibG9naW5QYWdlXCI6IFwic3JjLXBhZ2VzLUxvZ2luLXN0eWxlcy1tb2R1bGVfX2xvZ2luUGFnZVwiLFxuXHRcImxvZ2luQ29udGVudFwiOiBcInNyYy1wYWdlcy1Mb2dpbi1zdHlsZXMtbW9kdWxlX19sb2dpbkNvbnRlbnRcIlxufTtcbiJdLCJuYW1lcyI6WyJSZWFjdCIsIm1lbW8iLCJ1c2VDYWxsYmFjayIsInN0eWxlcyIsIkxvZ2luRm9ybSIsIm9uU3VibWl0IiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsInRhcmdldCIsImVtYWlsIiwidmFsdWUiLCJwYXNzd29yZCIsImNvbnNvbGUiLCJsb2ciLCJsb2dpbkludHJvIiwiZm9ybUxpbmUiLCJmb3JtQnV0dG9ucyIsIkhlbG1ldCIsIlJlZ2lzdGVyUGFnZSIsImxvZ2luUGFnZSIsImxvZ2luQ29udGVudCJdLCJzb3VyY2VSb290IjoiIn0=